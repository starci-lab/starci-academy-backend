# workspace.bind — brief

Follow operator.md; write its declared paths and your branch response/; replace the running response.json before exit. ? optional; * fallback.

## Done when

Done when the `workspace-route-binding` and its `route` name one checkout resolved from the declaration and its hydrated projection alone, on a branch the routed policy permits with a working tree carrying nothing the policy refuses, at its observed source head with its derived mutation readiness, and with no runtime bound.

Primary output: `workspace-route-binding`

## Inputs

none

## Outputs

Before write/resume, read ../../templates/kinds/<kind>: md .contract.json + .skeleton.md; data .schema.json; artifact follows operator.md. Current-status declared kinds; evidence must exist. Paths: response/.

`workspace-route-binding` `response.md` (md)
`route` `data/route.json` (data)

## Stops

`INVALID_INPUT`, `SOURCE_DRIFT`, `NO_PROGRESS`, `IDENTITY_UNVERIFIED`, `ROUTE_UNDECLARED`, `ROUTE_UNHYDRATED`, `ROUTE_MISMATCH`, `BRANCH_POLICY_VIOLATION`, `CHECKOUT_DIRTY`
