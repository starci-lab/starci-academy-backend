# interface.draw

## Job

Draw one surface’s business-grounded PNG concepts before frontend implementation, then preserve the resolved direction as an exact typed handoff.

## Done when

Done when the `frontend-art-direction` binds the frozen brief, actual PNG/prompt provenance, Grammar adoption and the selected direction ready to be displayed before frontend implementation.

## Drawing inputs and concept

The request freezes request/art-direction-brief.json under frozenInputs, following [art-direction-brief.schema.json](../../templates/kinds/art-direction-brief.schema.json). Business purpose, actors, journey, actions, information and required states have actual approved or observed source references. Examples stay labelled; unknown necessary inputs stop before ImageGen. Inspiration is not feature, metric, testimonial or permission authority. Each concept states its central idea, story, tone, art style, hierarchy and coherent imagery language, mapped to business journeys and Grammar-owned regions.

Every region’s imagery plan decides its purpose, subject, coherence, reuse, medium, prominence, placement, responsive/accessibility and delivery constraints. Brand or atmosphere is a valid purpose. Rich imagery may span many sections; there is no hero-only template or global asset-minimization rule. Controls, tables and live data remain native. The full-page PNG guides implementation; separately usable assets have their own specifications and provenance.

## One direction authority

Grammar owns component geometry, tokens and icon contracts. Resolve an incompatible drawing before selection; never turn it into arbitrary application CSS. The ImageGen prompt contains the complete frozen brief and the exact concept; a generic beauty prompt is insufficient. PNG file integrity, dimensions and prompt provenance are checked by [art-direction.mjs](../../scripts/art-direction.mjs). The image is reviewed against the business-to-region acceptance mapping. Semantic quality and truthful external tool attribution remain accountable review, not conclusions hashes can prove.

## Selection and presentation

The interaction policy owns candidate counts. By default draw exactly one PNG, publish it as a done visual direction, print it inline and continue without a user question or fabricated choice. Only an explicit compare request enables multiple directions and actual user selection. An unselected comparison sheet ends blocked DIRECTION_CHOICE_REQUIRED with its exact tier-choice options and candidate PNGs. Run node scripts/art-direction.mjs present <branch>, emit that actual Markdown with native PNG embeds, then record the actual answer through node scripts/art-direction.mjs answer <branch> <actual-answer.json>. The answer binds selectedBy:user, sourceRef, presentationSourceRef and presentationHash of that exact embedded sheet. A URL-only sheet cannot satisfy it. After emitting either a selected result or the default PNG, record its actual display through node scripts/art-direction.mjs shown <branch> <display.json>; display.json binds sourceRef and presentationHash. The normal comparison resume binds the original decision id and selected option, reuses the exact candidate bytes and publishes selected PNG as outcome.primary. A validator verifies the retained presentation and attribution, not whether a human physically viewed it.

This operator writes only its branch response artifacts. It writes no frontend source, starts no implementation server and overrides no backend or coordination owner.

## Explicit visual acceptance

Before ImageGen, the brief's visual contract enumerates every required region element and separately usable asset by stable identity. Record native controls, semantic icons with their meaning and bound registry glyph, and code-native connectors with their actual endpoint identities. Freeze anatomy, per-viewport width/height bounds, responsive arrangement and normal/reduced-motion intent. A repeated grid is valid when that is the declared composition. The candidate anchors every element within the actual PNG; a whole strip cannot replace independently declared subjects.

For extracted transparent assets, retain the exact pre-extraction reference and identify enclosed negative space and subject areas that must survive. A transparent sample or alpha minimum does not establish clean extraction. The implementation's [art-direction-adoption](../../templates/kinds/art-direction-adoption.schema.json) requires exact black, white and chromatic composites, plus explicit outer, enclosed, subject, silhouette and edge review. [art-visual-proof.mjs](../../scripts/art-visual-proof.mjs) verifies composite derivation and complete identities; the reviewer must inspect the images against the retained reference. Hashes cannot decide whether a face, white material, fine edge or enclosed region was wrongly removed.

## Context

| Alias | Bind | Required |
| --- | --- | --- |
| `@workspaces/fe` | Exact routed source head and the existing surface or proof of its absence | yes |
| `@grammar/core` | Resolved published component geometry, props and token ownership | yes |
| `@knowledge/ui/composition` | Complete applicable composition manifest and Cases | yes |
| `@knowledge/ui/presentation` | Published application-owned presentation rules | yes |
| `@knowledge/ui/proof` | Still-image critique criteria; no behavioral claim from a drawing | yes |
| `@knowledge/grammars/<family>` | Resolved family/version, visual language and adoption rules | yes |

## Inputs

| Kind | From | Required |
| --- | --- | --- |
| `business-promise-authority` | business.decide; the approved business model when the surface consumes one | no |
| `backend-source-application` | backend.generate; actual data/action contract when bound | no |
| `architecture-decision` | architecture.decide; approved boundaries when relevant | no |
| `landing-composition` | landing.compose; the exact read-only section, ownership and imagery contract when present | no |
| `surface-map` | interface.plan; whole-feature shell and exact selected surface | no |
| `frontend-art-direction` | interface.draw; unchanged candidate bundle when resuming the actual choice | no |

## Requirements

| Field | Type | Default | Ask |
| --- | --- | --- | --- |
| `target` | id | — | The exact surface identifier |
| `changeLevel` | enum: new, reconstruct | new | Create a new surface or redesign an existing one |
| `compare` | enum: no, yes | no | Explicit user request to compare distinct PNG concepts; default is one PNG without a choice wait |
| `selectionPolicy` | enum: automatic, approval-required | automatic | automatic for the default one PNG, approval-required only for explicit compare=yes |
| `resume` | token | null | The blocked direction sheet when the user returns their selection |

## Steps

| # | Step | Params | Reads | Writes | Stops with |
| --- | --- | --- | --- | --- | --- |
| 1 | Validate the frozen business drawing brief and exact source/Grammar bindings | `target`, `changeLevel` | request/request.json, request/art-direction-brief.json, @workspaces/fe, @tools/git | — | `INVALID_INPUT`, `SOURCE_DRIFT`, `NO_PROGRESS` |
| 2 | Read the declared business purpose, actors, actions, states and content; distinguish facts, intent, examples and unresolved inputs | — | input business-promise-authority, input backend-source-application, input architecture-decision, input surface-map, input landing-composition when present, the frozen brief | — | `EVIDENCE_MISSING` |
| 3 | Bind Grammar and judge each concept and imagery plan against business-to-region acceptance before drawing | — | @tools/registry, @grammar/core, @knowledge/ui/composition, @knowledge/ui/presentation, @knowledge/ui/proof, @knowledge/grammars/<family> | `knowledge-coverage`, `family-understanding` | `INVALID_INPUT` |
| 4 | Generate distinct PNG directions from the complete frozen brief and each explicit concept, retaining the exact prompt and actual ImageGen provenance | — | @tools/imagegen, frozen concepts and imagery plan | `art-direction-png`, `art-direction-prompt` | `EVIDENCE_MISSING` |
| 5 | Inspect each PNG for business contradictions, Grammar feasibility, hierarchy, useful imagery and responsive limits; retain separate usable asset specifications | — | the actual PNGs, @tools/fileread, frozen business and Grammar adoption | `frontend-art-direction` | `INVALID_INPUT` |
| 6 | Emit the default PNG or explicitly requested comparison sheet for inline Operator Result presentation and the actual user choice; on `resume` retain the selected PNG without redrawing | `resume`, `compare`, `selectionPolicy` | the sealed candidate bundle, @tools/print, state.json.choices | `response/response.json` | `DIRECTION_CHOICE_REQUIRED` |

## Outputs

| Kind | File | Type | Required |
| --- | --- | --- | --- |
| `frontend-art-direction` | `response/data/art-direction.json` | data | yes |
| `art-direction-png` | `response/artifacts/<candidate>.png` | artifact | yes |
| `art-direction-prompt` | `response/artifacts/<candidate>.prompt.txt` | artifact | yes |
| `knowledge-coverage` | `response/data/knowledge-coverage.json` | data | no |
| `family-understanding` | `response/data/family-understanding.json` | data | no |

## Operator Result

Show the actual full PNGs inline before explanatory detail and before frontend code. A blocked sheet shows all offered directions and its truthful unanswered choice. A done result embeds the selected PNG first. An image link, prompt text, HTML preview or asset thumbnail is not a substitute.

## Stops

| Code | Disposition |
| --- | --- |
| `INVALID_INPUT` | terminate |
| `SOURCE_DRIFT` | terminate |
| `EVIDENCE_MISSING` | terminate |
| `NO_PROGRESS` | terminate |
| `DIRECTION_CHOICE_REQUIRED` | fallback |

## Next

| When | Operator |
| --- | --- |
| the exact selected PNG and published Grammar adoption are ready for implementation | `interface.generate` |
| the actual user must select from the displayed concepts | `user` |
| the requested design artifact is complete and no implementation was requested | `user` |
