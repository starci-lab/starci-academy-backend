# business.decide

## Việc

Quyết và publish một lời hứa nghiệp vụ có bằng chứng thành thẩm quyền bền do backend sở hữu, đóng
băng sau một ma trận phủ đầy đủ từ lời hứa tới điểm thực thi.

## Xong khi

Xong khi một head feature đã được publish dưới lease độc quyền và `model` nói đúng những gì head ấy
đang giữ, `claims` tách mọi quan sát theo vai với mọi fact claim ràng vào head source đóng băng,
`restatement` đã xác nhận của lời hứa đi cùng `business-promise-authority`, và `coverage-matrix` cho
mọi dimension đã khai cùng mọi consumer phát hiện được đúng một disposition.

## Một head, quyết ở đây và đối chiếu ở nơi khác

Operator này mô hình hoá lời hứa và đóng băng ma trận phủ: một head dưới
`@worktrees/businesses/<featureId>` và một `response/data/model.json` nói đúng những gì head ấy đang
giữ, với `reconciliation` là null vì chưa đọc thứ gì đã giao. Đối chiếu head ấy với source mà một
lượt backend giao sau đó là việc của `business.reconcile`, và `implemented` được publish ở đó hoặc
không bao giờ; một request mang source đã giao tới đây bị từ chối, vì một lời hứa vừa mô hình vừa đối
chiếu trong một lượt là một lời hứa tự chấm bản giao của chính mình.

## Lần chạy đầu bắt đầu từ lời hứa của người

Một feature chưa có source hiện thực thì theo định nghĩa không có claim fact. Ở lần chạy đầu, lời
hứa người dùng nêu trong `promise` được ghi thành claim intent duy nhất, ràng vào
`request/request.json#requirements.promise` thay vì một dòng source, và mô hình dựng từ đó;
`EVIDENCE_MISSING` áp cho claim fact không có file đứng sau, không bao giờ áp cho intent của một lời
hứa đang được quyết lần đầu. Mọi hàng enforcing của coverage matrix vẫn phải tựa trên claim fact, nên
head greenfield publish với các hàng enforcing còn mở, đó chính là nghĩa của `pending`.

## Lời hứa được nói lại trước khi được mô hình hoá

Khi request cung cấp `promise`, ở lần chạy đầu hay ở lần chạy mà lời hứa đã đổi, bước 2 ghi `response/restatement.md` trước khi bất cứ thứ gì được mô hình hoá: những dòng bằng ngôn
ngữ thường, trong số dòng mà kind `restatement` cho phép, nói lời hứa đã được hiểu là gì, và nguyên
văn lời của người dưới `## Source`. Các dòng ấy viết bằng ngôn ngữ của `promise`, vì một bản nói lại
mà người không đọc được thì không xác nhận được gì; validator kiểm hình dạng và phần trích dẫn chứ
không kiểm ngôn ngữ, nên ngôn ngữ là bổn phận của agent. Trừ khi request mang `decisionId` cấp gốc
gắn nội dung theo [chính sách tương tác](../../resources/interaction.vi.md) cùng một `selectedOption` đã ghi trong state.json.choices, nhánh kết thúc
`blocked` với `RESTATEMENT_UNCONFIRMED`, có `fields.restatement` và không có đầu ra nào khác, cùng
`interaction` kiểu `restatement-confirm` trên đúng decisionId ấy với đúng hai lựa chọn `as-stated` và
`corrected`. Một lần vào lại chọn `corrected` nêu nhánh bị chặn trong `resume` và mang một `promise`
khác với promise của nhánh ấy; lần vào lại chọn `as-stated` mang cùng promise; nhánh sau đó chạy tiếp
và receipt done vẫn mang `fields.restatement`. Một lần chạy mà request không có `promise` dùng lại lời
hứa của head trước và không nợ bản nói lại nào.

## Tách loại claim trước khi mô hình hoá

Mô hình hoá bắt đầu bằng việc tách mọi quan sát thành fact, intent, example, unknown hay
contradiction, và cách tách ấy được ghi vào `response/data/claims.json` trước khi có gì được mô hình
từ nó. Nó tồn tại để một phép thay thế trở thành bất khả: một ví dụ, một ảnh chụp màn hình hay ý định
của người chủ chỉ minh hoạ lời hứa, còn chỉ một fact quan sát được trong source được route mới chứng
minh lời hứa đó có người thực thi. Vì vậy một hàng phủ khẳng định có thực thi phải dẫn ít nhất một
claim fact, và mọi claim fact phải ràng head source đã quan sát. Một claim dẫn nguồn không ai ràng là
input sai chứ không phải cảnh báo, vì một trích dẫn không ràng thì không phân biệt được với một trích
dẫn bịa. Hai claim mâu thuẫn về cùng một hành vi không bao giờ được lấy trung bình thành một cách đọc
ở giữa; mâu thuẫn dừng lượt chạy và trả về cho chủ của nó.

## Không có phủ thì không có lời hứa

Một lời hứa chỉ publish được khi mọi chiều mà request đã khai đều mang đúng một disposition, và mọi
consumer cùng nhánh vòng đời mà operator phát hiện đều được xử lý đích danh. `dimensions` mặc định
lấy theo các chiều của head trước, nên nó bắt buộc ở lần chạy đầu: lần publish đầu tiên chính là lần
quyết định lời hứa phải chịu trách nhiệm về những gì. Luật này có vì "full access" từng được mô hình,
cài đặt và publish trong khi các consumer khoá học, cộng đồng, blog, AI, phỏng vấn thử, bán legacy,
quota, tất toán, gia hạn, huỷ và khôi phục chưa từng được chứng minh đủ. Lời hứa đúng ở chỗ chào bán
và sai ở chỗ guard. Bốn điều cấm gánh phần sửa, và mỗi điều được cưỡng chế chứ không phải khuyên. Một
consumer đã phát hiện mà không có hàng trong ma trận là `CONSUMER_UNPROVEN`. Một chiều bắt buộc, gồm
actor và eligibility, offer entry, read entry, purchase side effect, settlement, idempotency,
entitlement consumer và denial, không bao giờ được đánh không áp dụng khi nó đã được khai. Một chiều
mà nhánh của nó đã được quan sát trong source cũng không bao giờ được đánh không áp dụng, vì đã tìm
thấy tức là có áp dụng. Một disposition preserve hay replace mà thiếu negative proof bị từ chối, vì
chứng minh dương chỉ cho thấy lời hứa được cấp, không bao giờ cho thấy nó bị từ chối đúng lúc phải từ
chối.

## Các disposition và phần thực chất mỗi loại phải mang

`preserve` giữ nguyên phần thực thi đang có và mang owner, source, positive proof, negative proof và
một claim fact. `replace` đổi phần thực thi và mang đúng ngần ấy thực chất cho đường mới. `retire`
đóng một đường có chủ ý và mang owner, source, bằng chứng đường đã đóng, và một claim fact. `defer`
hoãn một nhánh cho một chủ có tên, mang một tham chiếu hoãn, và không mang bằng chứng nào, vì bằng
chứng cho việc chưa làm là kiểu pass giả thuyết phục nhất. `not-applicable` nói nhánh không thể xảy
ra và không mang gì cả: không owner, không source, không proof, không consumer, không claim. `defer`
là một disposition nên nhánh được hoãn không chặn publish; thứ chặn publish là sự im lặng.

## Một gốc thẩm quyền phẳng

Một feature sở hữu đúng một thư mục head, `<gốc businesses>/features/<featureId>`, mà `model.json`
trong đó là head, và bước 9 giữ lease độc quyền trên alias ấy trước khi ghi. Hai nhánh của cùng một
bước không được publish cùng một feature. `features/` là đoạn duy nhất giữa gốc và một feature: chèn
một đoạn project dưới gốc là sinh ra cây thẩm quyền thứ hai mà người đọc sau không bao giờ tìm ra,
nên mọi head không đúng `features/<featureId>` đều bị từ chối. Head được phân loại absent, fresh hay
stale so với bằng chứng đã đóng băng và head source đã đóng băng, và phân loại đó quyết định chuyển
trạng thái nào hợp lệ. Từ chối vẫn giữ dòng dõi bằng cách nêu tên head trước thay vì xoá nó, và
`implemented` không bao giờ được publish dựa trên một kế hoạch: source đã giao phải được đối chiếu
với ma trận đóng băng trước, bởi `business.reconcile`.

## Luồng attempt cụ thể

Các row của operator này được gate bởi hợp đồng attempt expected/actual dùng chung trong `scripts/attempt-gate.mjs`.

| Trạng thái quan sát | Hành động | Kiểm actual | Nhánh kế tiếp |
| --- | --- | --- | --- |
| published promise còn hiệu lực | tái dùng row actor/rule/outcome hợp lệ | chạy lại scenario cho row giữ và row yêu cầu | phát lineage tới head tái dùng |
| promise thiếu | tạo từ restatement đã xác nhận | mọi matrix dimension có outcome quan sát và evidence | chỉ publish khi criterion bắt buộc match |
| dimension stale hoặc sai | chỉ cập nhật row bị bác bỏ | kiểm scenario đã đổi và giữ | repair attempt mới; mở rộng scope phát replan evidence |

## Ranh giới

Context chỉ đọc, trừ đúng một head feature. Operator chỉ ghi `response/` của nhánh mình, gồm
`response.md`, `response/restatement.md` khi request cung cấp `promise`, `response/data/claims.json`,
`response/data/coverage-matrix.json`, `response/data/model.json` và `response.json`, cùng một head
feature dưới `@worktrees/businesses/<featureId>`. Nó không bao giờ publish một lời hứa khi còn một
consumer hay nhánh vòng đời đã phát hiện chưa có disposition, không nâng một ví dụ, một ảnh chụp hay
một claim ý định thành sự thật sản phẩm, không bịa hành vi actor, entitlement, quota, thanh toán, tất
toán hay vòng đời mà bằng chứng không nói, không đẩy head qua một chuyển trạng thái vòng đời không
cho phép, không publish `implemented`, không đọc source đã giao, và không ghi head dưới một đoạn
project trong gốc businesses. Nó không sửa source sản phẩm, thẩm quyền kiến trúc, thẩm quyền frontend
hay phần cài đặt backend, và không bao giờ tuyên bố rằng một bản cài đặt, một cổng chất lượng hay một
lượt UAT đã qua.

## Context

| Alias | Bind | Bắt buộc |
| --- | --- | --- |
| `@worktrees/businesses/<featureId>` | head lời hứa và trạng thái vòng đời của nó, theo địa chỉ nội dung từ registry; nơi duy nhất operator này ghi ngoài nhánh của mình | có |
| `@workspaces/be` | checkout backend được route, đọc ở head đã đóng băng; mọi claim fact dẫn nó theo path, khoảng dòng và head | có |

## Đầu vào

| Kind | Từ đâu | Bắt buộc |
| --- | --- | --- |
| `architecture-decision` | `architecture.decide`; bằng chứng kiến trúc, không bao giờ là nguồn của hành vi nghiệp vụ | không |

## Yêu cầu

| Field | Kiểu | Mặc định | Hỏi |
| --- | --- | --- | --- |
| `featureId` | id | — | Một feature duy nhất mà lời hứa thuộc về |
| `promise` | prompt | the promise the previous head states | Lời hứa bằng lời của người dùng; bắt buộc ở lần chạy đầu khi chưa có head, và được ghi thành claim intent ràng vào `request/request.json#requirements.promise` |
| `targetState` | choice | — | `pending`, `in-progress` hay `rejected` cho head được publish; `implemented` do `business.reconcile` publish |
| `dimensions` | list | the dimensions of the previous head | Bề mặt phủ mà lời hứa này chịu trách nhiệm; bắt buộc ở lần chạy đầu, vì chưa head nào khai nó |
| `approval` | id | null | Phê duyệt của chủ mà chuyển trạng thái cần, nhập khi chạy lại sau `APPROVAL_REQUIRED` |
| `resume` | token | null | Token của nhánh bị chặn khi vào lại sau một mã dừng |

## Các bước

| # | Bước | Tham số | Đọc | Ghi | Dừng với |
| --- | --- | --- | --- | --- | --- |
| 1 | Kiểm gate và chạy lại | `resume` | `request/request.json`, @workspaces/be ở head đóng băng | — | `INVALID_INPUT`, `SOURCE_DRIFT`, `NO_PROGRESS` |
| 2 | Nói lại lời hứa bằng ngôn ngữ của người và chờ họ xác nhận, khi request cung cấp nó | `promise` | `request/request.json`: `requirements.promise`, cùng `decisionId` và `selectedOption` của nó khi lựa chọn đã được ghi | `restatement` | `RESTATEMENT_UNCONFIRMED` |
| 3 | Chuẩn hoá bằng chứng thành claim | — | @workspaces/be, mọi quan sát kèm vai, path, khoảng dòng và head, đầu vào `architecture-decision` nếu có và chỉ như bằng chứng, @tools/git | `response/data/claims.json` | `EVIDENCE_MISSING`, `CONTRADICTION_UNRESOLVED` |
| 4 | Kiểm published head và transition authority, phân loại promise được yêu cầu là reusable, missing hoặc invalid trước mọi model write | `featureId`, `targetState`, `approval` | @worktrees/businesses/<featureId>: head hiện tại, trạng thái và bằng chứng đóng băng của nó | — | `LIFECYCLE_TRANSITION_INVALID`, `AUTHORITY_CONFLICT`, `APPROVAL_REQUIRED` |
| 5 | Tái dùng promise row hợp lệ, tạo row được yêu cầu còn thiếu và chỉ update row sai; giữ decision không bị ảnh hưởng | `promise` | `response/data/claims.json`, @workspaces/be ở head đóng băng, @tools/websearch | — | `EVIDENCE_MISSING` |
| 6 | Đóng băng ma trận phủ | `dimensions` | `response/data/claims.json`, @workspaces/be và bề mặt nó phát hiện | `response/data/coverage-matrix.json` | `COVERAGE_INCOMPLETE`, `CONSUMER_UNPROVEN` |
| 7 | Xử lý phần chung sống với legacy | — | `response/data/coverage-matrix.json`: các hàng legacy create, read, settle và bằng chứng của chúng | — | `CONTRADICTION_UNRESOLVED` |
| 8 | Publish một head dưới lease độc quyền | — | `response/data/claims.json`, @worktrees/businesses/<featureId> ở head trước | @worktrees/businesses/<featureId> thành model.json head mới, `response/data/model.json`, @tools/sourcewrite | `SOURCE_DRIFT` |
| 9 | Phát | — | mọi thứ ở trên | `response/response.md`, `response/response.json` | — |

Legacy create, read và settle mỗi thứ giữ một hàng riêng khi chúng được khai: một đường bán mới chỉ
được retire phần tạo legacy khi quyền đã mua vẫn đọc được và phần tất toán legacy còn treo vẫn hoàn
tất, và việc retire ấy mang bằng chứng rằng đường tạo đã đóng. Ma trận được địa chỉ theo nội dung và
fingerprint của nó đi trong binding, nên phần cài đặt backend, phần tích hợp chất lượng và UAT chứng
minh được rằng chúng tiêu thụ đúng ma trận ấy chứ không phải một bản diễn giải. Chạy lại thì bắt đầu
lại từ bước 1, chỉ dùng lại quan sát có fingerprint không đổi, và tiêu thụ đúng phần delta; bằng
chứng publish lại tới dưới dạng một fingerprint bằng chứng mới, vì cùng một fingerprint không thể cho
một câu trả lời khác.

## Đầu ra

| Kind | File | Kiểu | Bắt buộc |
| --- | --- | --- | --- |
| `business-promise-authority` | `response/response.md` | md | có |
| `restatement` | `response/restatement.md` | md | không |
| `claims` | `response/data/claims.json` | data | có |
| `coverage-matrix` | `response/data/coverage-matrix.json` | data | có |
| `model` | `response/data/model.json` | data | có |

## Operator Result

Khi `done`, in **Operator Result** là bảng phủ lời hứa trong `response/data/coverage-matrix.json`, kèm authority đã chấp nhận ở `response/response.md` và `response/data/model.json` làm evidence phụ. Restatement chưa xác nhận phải được hiện từ `response/restatement.md` cùng điểm dừng và không bao giờ được trình bày như lời hứa đã quyết.

## Dừng

| Code | Xử lý |
| --- | --- |
| `INVALID_INPUT` | terminate |
| `SOURCE_DRIFT` | terminate |
| `NO_PROGRESS` | terminate |
| `RESTATEMENT_UNCONFIRMED` | terminate |
| `EVIDENCE_MISSING` | terminate |
| `CONTRADICTION_UNRESOLVED` | terminate |
| `LIFECYCLE_TRANSITION_INVALID` | terminate |
| `AUTHORITY_CONFLICT` | terminate |
| `APPROVAL_REQUIRED` | terminate |
| `COVERAGE_INCOMPLETE` | terminate |
| `CONSUMER_UNPROVEN` | terminate |

## Kế tiếp

| Khi | Operator |
| --- | --- |
| Ý định nghiệp vụ đã duyệt cần concept PNG trước khi tạo hoặc thiết kế lại frontend | `interface.draw` |
| lời hứa có nhiều đơn vị frontend, nên lập đủ bản đồ bề mặt trước khi sinh từng đơn vị | `interface.plan` |
| lời hứa đã publish và một bề mặt frontend phải mang nó | `interface.generate` |
| lời hứa đã publish và một contract backend phải mang nó | `backend.generate` |
| lời hứa cần quyết ranh giới và quyền sở hữu dữ liệu trước khi thực thi được | `architecture.decide` |
| lời hứa đã publish và source giao theo nó phải được đối chiếu với ma trận đã đóng băng | `business.reconcile` |
