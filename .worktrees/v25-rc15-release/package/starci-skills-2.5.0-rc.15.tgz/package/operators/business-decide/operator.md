# business.decide

## Job

Decide and publish one evidence-backed business promise as durable backend-owned authority, frozen
behind a complete promise-to-enforcement coverage matrix.

## Done when

Done when one feature head is published under the exclusive lease and the `model` says exactly what
that head now holds, the `claims` separate every observation by role with every fact claim bound to
the frozen source head, the confirmed `restatement` of the promise travels with the
`business-promise-authority`, and the `coverage-matrix` gives every declared dimension and every
discovered consumer exactly one disposition.

## One head, decided here and reconciled elsewhere

This operator models the promise and freezes the coverage matrix: one head under
`@worktrees/businesses/<featureId>` and one `response/data/model.json` that says exactly what that
head now holds, with `reconciliation` null because nothing delivered has been read yet. Comparing
that head against the source a backend run later delivers is `business.reconcile`'s job, and
`implemented` is published there or not at all; a request that carries delivered source here is
refused, because a promise modelled and reconciled in one pass is a promise that grades its own
delivery.

## A first run starts from the person's promise

A feature that no source implements yet has no fact claim by construction. On a first run, the
promise the person stated in `promise` is recorded as the one intent claim, bound to
`request/request.json#requirements.promise` instead of a source line, and the model is built from it;
`EVIDENCE_MISSING` applies to a fact claim without a file behind it, never to the intent of a promise
that is being decided for the first time. Every enforcing row of the coverage matrix still rests on a
fact claim, so a greenfield head publishes with its enforcing rows open, which is what `pending` means.

## The promise is restated before it is modelled

When the request supplies `promise`, on a first run or a run whose promise changed, step 2 writes `response/restatement.md` before anything is modelled: plain-language lines, within the
count the `restatement` kind allows, saying what the promise was read to mean, and the person's own
words quoted verbatim under `## Source`. The lines are written in the language of `promise`, because
a restatement the person cannot read confirms nothing; the validator checks the shape and the quote,
not the language, so the language is the agent's duty. Unless the request carries the top-level
content-bound `decisionId` defined by [the interaction policy](../../resources/interaction.md) with a `selectedOption` recorded in state.json.choices, the
branch ends `blocked` with `RESTATEMENT_UNCONFIRMED`, `fields.restatement` set and no other output,
and `interaction` of kind `restatement-confirm` on that decisionId offering exactly `as-stated` and
`corrected`. A re-entry that selects `corrected` names the blocked branch in `resume` and carries a
`promise` that differs from that branch's; one that selects `as-stated` carries the same promise; the
branch then proceeds and the done receipt still carries `fields.restatement`. A run whose request has
no `promise` reuses the previous head's promise and owes no restatement.

## Separate the claim before modelling it

Modelling begins by separating every observation into fact, intent, example, unknown, or
contradiction, and that separation is written to `response/data/claims.json` before anything is
modelled from it. The separation exists to make one substitution impossible: an example, a
screenshot, or an owner's intent illustrates a promise, and only an observed fact in routed source
proves that the promise is enforced. A coverage row that asserts enforcement therefore cites at least
one fact claim, and every fact claim binds the observed source head. A claim that cites a source
nobody bound is invalid input rather than a warning, because an unbound citation cannot be told apart
from an invented one. Two claims that disagree about the same behaviour are never averaged into a
middle reading; the contradiction stops the invocation and returns to its owner.

## No promise without coverage

A promise is publishable only when every dimension the request declared carries exactly one
disposition, and every consumer and lifecycle branch the operator discovered is disposed by name.
`dimensions` defaults to the dimensions of the previous head, which is why it is required on a first
run: the first publication is the one that decides what the promise is even accountable for. That
rule exists because "full access" was modelled, implemented, and published while its course,
community, blog, AI, mock-interview, legacy-sale, quota, settlement, renewal, cancellation, and
recovery consumers had never all been proved. The promise was true in the offer and false at the
guard. Four prohibitions carry the repair, and each is enforced rather than advised. A discovered
consumer with no matrix row is `CONSUMER_UNPROVEN`. A mandatory dimension, meaning actor and
eligibility, offer entry, read entry, purchase side effect, settlement, idempotency, entitlement
consumer, and denial, can never be marked not applicable when it was declared. A dimension whose
branch was observed in source can never be marked not applicable either, because it was found, so it
applies. A preserve or replace disposition without a negative proof is rejected, since positive proof
alone shows the promise is granted and never that it is denied when it should be.

## The dispositions and what each one must carry

`preserve` keeps the existing enforcement and carries owner, source, positive proof, negative proof,
and one fact claim. `replace` changes the enforcement and carries the same substance for the new
path. `retire` closes a path on purpose and carries owner, source, proof the path is closed, and one
fact claim. `defer` postpones a branch to a named owner, carries a deferral reference, and carries no
proof at all, because proof for work that has not happened is the most convincing kind of false pass.
`not-applicable` states the branch cannot occur and carries nothing: no owner, no source, no proof, no
consumer, no claim. `defer` is a disposition, so a deferred branch does not block publication; what
blocks publication is silence.

## One flat authority root

One feature owns exactly one head directory, `<businesses root>/features/<featureId>`, whose
`model.json` is the head, and step 9 takes an exclusive lease on that alias before it writes. Two
branches of the same step may not publish the same feature. `features/` is the only segment between
the root and a feature: a project segment inserted below the root starts a second authority tree that
later readers never find, so any head that is not exactly `features/<featureId>` is refused. The head
is classified absent, fresh, or stale against the frozen evidence and the frozen source head, and
that classification decides which lifecycle transition is legal. Rejection preserves lineage by
naming the previous head rather than erasing it, and `implemented` is never published on the strength
of a plan: delivered source is compared against the frozen matrix first, by `business.reconcile`.

## Concrete attempt flow

This operator's rows are gated by the shared expected/actual attempt contract in `scripts/attempt-gate.mjs`.

| Observed state | Action | Actual check | Next branch |
| --- | --- | --- | --- |
| current published promise | reuse valid actor/rule/outcome rows | rerun scenarios for retained and requested rows | emit lineage to reused head |
| missing promise | create from confirmed restatement | every matrix dimension has observable outcome and evidence | publish only after required criteria match |
| stale or invalid dimension | update only disproved rows | check changed and retained scenarios | repair in new attempt; scope growth emits replan evidence |

## Boundary

Context is read-only apart from the one feature head. The operator writes only `response/` of its own
branch, `response.md`, `response/restatement.md` when the request supplies `promise`,
`response/data/claims.json`, `response/data/coverage-matrix.json`, `response/data/model.json` and
`response.json`, plus the one feature head under `@worktrees/businesses/<featureId>`. It never
publishes a promise while a discovered consumer or lifecycle branch carries no disposition, promotes
an example, a screenshot, or an intent claim into product truth, invents an actor, entitlement,
quota, payment, settlement, or lifecycle behaviour the evidence does not state, advances a head
through a transition the lifecycle does not allow, publishes `implemented`, reads delivered source,
or writes a head below a project segment under the businesses root. It does not modify product
source, architecture authority, frontend authority, or backend implementation, and it never claims
that an implementation, a quality gate, or a UAT run has passed.

## Context

| Alias | Bind | Required |
| --- | --- | --- |
| `@worktrees/businesses/<featureId>` | the promise head and its lifecycle state, by content address from the registry; the one place this operator writes outside its branch | yes |
| `@workspaces/be` | the routed backend checkout read at the frozen head; every fact claim cites it by path, line range, and head | yes |

## Inputs

| Kind | From | Required |
| --- | --- | --- |
| `architecture-decision` | `architecture.decide`; architecture evidence, never a source of business behaviour | no |

## Requirements

| Field | Type | Default | Ask |
| --- | --- | --- | --- |
| `featureId` | id | — | The one feature the promise belongs to |
| `promise` | prompt | the promise the previous head states | The promise in the person's words; required on a first run, when no head exists yet, and recorded as the intent claim bound to `request/request.json#requirements.promise` |
| `targetState` | choice | — | `pending`, `in-progress` or `rejected` for the published head; `implemented` is published by `business.reconcile` |
| `dimensions` | list | the dimensions of the previous head | The coverage surface this promise is accountable for; required on a first run, because no previous head declares it |
| `approval` | id | null | The owner approval the transition needs, supplied on resume after `APPROVAL_REQUIRED` |
| `resume` | token | null | The blocked branch's token when re-entering after a stop |

## Steps

| # | Step | Params | Reads | Writes | Stops with |
| --- | --- | --- | --- | --- | --- |
| 1 | Validate the gate and resume | `resume` | `request/request.json`, @workspaces/be at the frozen head | — | `INVALID_INPUT`, `SOURCE_DRIFT`, `NO_PROGRESS` |
| 2 | Restate the promise in the person's language and hold for their confirmation, when the request supplies it | `promise` | `request/request.json`: `requirements.promise`, and its `decisionId` and `selectedOption` when the choice is already recorded | `restatement` | `RESTATEMENT_UNCONFIRMED` |
| 3 | Normalize the evidence into claims | — | @workspaces/be, every observation with its role, path, line range and head, input `architecture-decision` when present as evidence only, @tools/git | `response/data/claims.json` | `EVIDENCE_MISSING`, `CONTRADICTION_UNRESOLVED` |
| 4 | Inspect the published head and transition authority, classifying the requested promise as reusable, missing or invalid before any model write | `featureId`, `targetState`, `approval` | @worktrees/businesses/<featureId>: the current head, its state and its frozen evidence | — | `LIFECYCLE_TRANSITION_INVALID`, `AUTHORITY_CONFLICT`, `APPROVAL_REQUIRED` |
| 5 | Reuse valid promise rows, create missing requested rows and update only invalid requested rows; keep unaffected decisions unchanged | `promise` | `response/data/claims.json`, @workspaces/be at the frozen head, @tools/websearch | — | `EVIDENCE_MISSING` |
| 6 | Freeze the coverage matrix | `dimensions` | `response/data/claims.json`, @workspaces/be and the surface it discovers | `response/data/coverage-matrix.json` | `COVERAGE_INCOMPLETE`, `CONSUMER_UNPROVEN` |
| 7 | Dispose legacy coexistence | — | `response/data/coverage-matrix.json`: the legacy create, read and settle rows and their proof | — | `CONTRADICTION_UNRESOLVED` |
| 8 | Publish one head under an exclusive lease | — | `response/data/claims.json`, @worktrees/businesses/<featureId> at the previous head | @worktrees/businesses/<featureId> as the new model.json head, `response/data/model.json`, @tools/sourcewrite | `SOURCE_DRIFT` |
| 9 | Emit | — | everything above | `response/response.md`, `response/response.json` | — |

Legacy create, read, and settle each take their own row when they are declared: a new sale path may
retire legacy creation only while already-purchased rights stay readable and pending legacy
settlement still completes, and the retirement carries proof that the creation path is closed. The
matrix is content addressed and its fingerprint travels in the binding, so backend implementation,
quality integration, and UAT can prove they consumed the same matrix rather than a paraphrase of it.
A resume begins again at step 1, reuses only unchanged fingerprinted observations, and consumes the
exact delta; republished evidence arrives as a new evidence fingerprint, because the same fingerprint
cannot yield a different answer.

## Outputs

| Kind | File | Type | Required |
| --- | --- | --- | --- |
| `business-promise-authority` | `response/response.md` | md | yes |
| `restatement` | `response/restatement.md` | md | no |
| `claims` | `response/data/claims.json` | data | yes |
| `coverage-matrix` | `response/data/coverage-matrix.json` | data | yes |
| `model` | `response/data/model.json` | data | yes |

## Operator Result

On `done`, print **Operator Result** as the promise coverage table in `response/data/coverage-matrix.json`, with the accepted authority in `response/response.md` and `response/data/model.json` as secondary evidence. An unconfirmed restatement is shown from `response/restatement.md` with its stop and is never presented as the decided promise.

## Stops

| Code | Disposition |
| --- | --- |
| `INVALID_INPUT` | terminate |
| `SOURCE_DRIFT` | terminate |
| `NO_PROGRESS` | terminate |
| `RESTATEMENT_UNCONFIRMED` | terminate |
| `EVIDENCE_MISSING` | terminate |
| `CONTRADICTION_UNRESOLVED` | terminate |
| `LIFECYCLE_TRANSITION_INVALID` | terminate |
| `AUTHORITY_CONFLICT` | terminate |
| `APPROVAL_REQUIRED` | terminate |
| `COVERAGE_INCOMPLETE` | terminate |
| `CONSUMER_UNPROVEN` | terminate |

## Next

| When | Operator |
| --- | --- |
| the approved business intent needs a PNG concept before frontend creation or redesign | `interface.draw` |
| the promise names multiple frontend units, so their complete surface map is planned before generation | `interface.plan` |
| the promise is published and a frontend surface must carry it | `interface.generate` |
| the promise is published and a backend contract must carry it | `backend.generate` |
| the promise needs boundaries and data ownership decided before it can be enforced | `architecture.decide` |
| the promise is published and source delivered against it must be compared with the frozen matrix | `business.reconcile` |
