# interface.audit

## Việc

Quan sát bề mặt đã commit ở route đang được phục vụ, qua đúng ma trận mà coverage của hướng suy ra,
đo mọi node có mang lời khai, và phán quyết từng phép đo theo luật proof đã publish, dựa trên chủ sở
hữu của node mà nó đứng lên.

## Xong khi

Xong khi mọi mục ma trận được chọn có `capture`, `screenshot` và dòng của nó trong `verdicts`, mọi
lời khai bên trong một bề mặt được chọn đã được đo trên head được phục vụ có chứa commit đã áp dụng
và được phán quyết bởi chủ sở hữu node của nó, mỗi chủ đề proof đã tự đóng theo luật của chính nó
thành một dòng trong bảng phán quyết của `frontend-surface-audit` kèm tuyến mà một thất bại mang
theo, và sheet đã được phục vụ qua `host` và in cho người xem kèm ảnh chụp tệ nhất của mỗi chủ đề.

## Sẵn sàng, chụp và phán quyết là một việc

Tách chúng ra đã sinh ra một kiểu hỏng quen thuộc: một bức chụp lấy trước khi bề mặt sẵn sàng, bị
phán quyết bởi một bước không còn cách nào biết điều đó, dựa trên bằng chứng mà chính nó không thu.
Một operator vừa chờ, vừa đo, vừa phán quyết dưới một biên nhận thì không đánh mất mối nối ấy.

Với hình ảnh, áp playbook của family đã bind vào chủ thể, kích thước, tương phản và crop thực tế.
Ghi hình làm nổi bật ý nào và thứ tự chú ý sau render có hỗ trợ nội dung cùng hành động chính không.
Điểm nhấn thị giác hoặc cảm xúc phù hợp có thể đáng dùng; lấp kín khoảng trống hay chỉ có một hình
trên trang đều chưa chứng minh chất lượng.

## Route có cổng canh thì đi vào, không phải tuyên bố runtime chết

Một route trả về màn hình đăng nhập là đang phục vụ rất tốt; thứ còn thiếu là một danh tính, và danh
tính là thứ runtime có. Vì thế sự sẵn sàng bao gồm cả việc đăng nhập bằng tài khoản riêng của luồng khi
route đòi hỏi: thông tin đăng nhập được giải theo tên, được gõ vào form chứ không vào đâu khác, và việc
chụp chỉ bắt đầu khi cú chuyển hướng đã tới nơi, nên không khung hình nào operator này công bố có thể
chứa nó. Báo một route có cổng canh thành một runtime không sẵn sàng là một âm tính giả đẩy người ta đi
khởi động lại một dịch vụ chưa bao giờ chết. Mã dừng thật lòng duy nhất ở đây là luồng này chưa có tài
khoản nào, tức `IDENTITY_MISSING`: một lần bàn giao cho operator cấp tài khoản, không bao giờ là một
phán quyết về bề mặt, và không bao giờ là lời nhờ một người đi tạo tài khoản.

## Sự sẵn sàng đọc entry của đúng route này

Sổ đăng ký runtime giữ một entry cho mỗi route, và lượt audit này đọc entry của route nó được bind vào.
Một sổ được tra như một khối duy nhất sẽ trả lời thay cho bất kỳ route nào tình cờ được ghi trong đó, và
đó chính là cách một lượt audit đi tới chỗ báo rằng chẳng có gì đang phục vụ trong khi bề mặt nó cần
đang hiện trên màn hình.

## Bề mặt phải chứa bề mặt đã commit

Biên bản áp nêu tên commit nó đã ghi, còn runtime phục vụ một nhánh tích hợp cho mỗi sản phẩm, mang
việc của mọi phiên đã xin. Nên phép thử không phải phép bằng — làm thế sẽ hỏng ngay khi có phiên thứ
hai, và hỏng vì số học chứ không vì bằng chứng — mà là quan hệ tổ tiên: commit đã áp phải là tổ tiên
của head đang phục vụ, và có mặt trong danh sách commit mà entry của chủ runtime cho route này ghi là đã chứa. Một head đang
phục vụ không qua phép thử đó là `SOURCE_DRIFT` và không chụp gì cả, vì đo một cây khác chẳng chứng
minh được gì về cây này. Biên bản nêu cả hai commit dưới `## Served surface`, vì quan hệ tổ tiên mà
người đọc không thấy được thì chỉ là lời khẳng định.

Endpoint là cái route đã bind mang theo, không bao giờ là cái operator này tự suy ra: route nêu tên
cổng mà entry của nó phục vụ, và trạng thái sẵn sàng đạt được ở đó. Khi head đang phục vụ không chứa
commit đã áp, hoặc chẳng có gì đang phục vụ, `RUNTIME_UNAVAILABLE` nêu tên commit cần được phục vụ và
thao tác sẽ phục vụ nó, và chủ runtime mới là bên hành động.

## Một bề mặt đang phục vụ cũng có thể trôi ở family nó render

Quan hệ tổ tiên sạch chứng minh nguồn đúng; nó không chứng minh gì về family mà head đang phục vụ
render nguồn đó qua. Nhánh tích hợp còn được merge từ mainline, nên một phiên bản Grammar hay
dependency khác mà phiên này chưa từng resolve theo có thể đã có sẵn trên head đang phục vụ vào lúc
audit này chạy, và một verdict trình bày bị lật vì thế thì chẳng liên quan gì tới nguồn mà phiên này đã
ghi. Vì vậy `## Served surface` luôn nêu tên phiên bản family mà head đang phục vụ thật sự render, cạnh
phiên bản mà lần giao hàng đã resolve theo; khi hai phiên bản khác nhau, sự trôi đó không bị bỏ ngầm
trong phép thử tổ tiên vốn đã qua. Ở bất cứ đâu mà bằng chứng đo được của một verdict là thứ một sự
trôi phiên bản có thể đã lật thay vì nguồn, đúng ô đo của node đó nêu tên cả hai phiên bản lại một lần
nữa, để người đọc không bao giờ phải đoán trong hai nguyên nhân khả dĩ, cái nào đã sinh ra verdict đó.
Đây là bằng chứng, không phải một gate mới: nó không nêu câu hỏi phạm vi nào, và không dừng ở bất cứ gì
mà luật chứng minh của chính bề mặt chưa từng dừng ở.

## Hai phiên trên một sản phẩm

Luật cô lập được công bố đúng một lần, ở operator sở hữu runtime, và lần audit này làm việc bên trong
luật đó chứ không chép lại: một sản phẩm phục vụ một nhánh tích hợp trên một cổng, và thứ giữ cho hai
lượt audit chạy song song không đọc trạng thái của nhau là mỗi lượt lái profile trình duyệt của riêng
mình. Profile đó được ghi dưới `## Served surface`, để một biên bản có trạng thái đăng nhập đến từ
nơi khác lộ ra chứ không chỉ bị nghi ngờ.

## Phép đo thắng lời khai, luôn luôn

Mỗi node mang những identifier nó khai là mình thoả, và lượt audit đo thứ bề mặt thực sự render ra.
Lời khai không bao giờ là bằng chứng của việc pass: một node khai `GAP-4` trong khi gap tính được đo
ra `1.5rem` là một lần hỏng, và khai bao nhiêu cũng không đổi được phép đo. Đó là toàn bộ cơ chế, và
đó là lý do lời khai tồn tại.

## Hai loại làn, hai cách phán

Các topic mà lượt audit này đóng không được phán cùng một cách. Presentation, composition, responsive,
motion, accessibility, contrast và render-truth là những thứ đo được: một gap tính ra, một tỷ lệ tương
phản, phần tử đang giữ focus, một tuyên bố truy về được authority. Chúng được phán mù, theo từng đơn vị
— một trang hay một modal, mỗi lần một mục ma trận — vì một phép đo không cần tấm nào khác để đúng, và
một người chấm đã nhìn trang bên cạnh chẳng đem thêm gì cho cây thước. Ống kính thẩm mỹ không phải phép
đo trên một tấm; nó là một vị trí trên một cái thang, và cái thang ấy trôi giữa các tấm khi mỗi tấm bị
chấm một mình. Vì thế thẩm mỹ — và ống kính trải nghiệm ở bất cứ đâu một biên nhận chấm nó từ ảnh chụp
— được chấm một lần cho cả tính năng bởi một người chấm, trên mọi bề mặt đã chọn của phạm vi đóng băng
trong cùng một vòng, theo tương quan: các tấm được xếp hạng so với nhau, và biên nhận nói dưới
`## Ranked against` nó đã xếp những tấm nào, để một điểm đọc ra là một vị trí trên thang chứ không phải
một tâm trạng.

Thứ giữ cho cái thang ấy là cùng một thang từ vòng này sang vòng khác, từ người chấm này sang người chấm
khác, là bộ hiệu chuẩn mà `@knowledge/ui/proof` mang dưới `calibration/`: ba tấm mốc, dải mà mỗi tấm
được kỳ vọng rơi vào cùng lý do một dòng, và khoảng dung sai, nêu một lần trong `calibration.json`.
Người chấm chấm ba tấm mốc trong cùng vòng chấm bề mặt, ghi chúng dưới `## Calibration` và trong
`verdicts.calibration`, rồi mới đặt bề mặt lên thang; một ống kính chấm mà không có mốc nào, hay có một
mốc rơi ra ngoài dải xa hơn khoảng dung sai, là `CALIBRATION_OFF` (`TASTE-13` Case 9): cái thang của
vòng chưa được chứng minh, không điểm nào nó sinh ra so sánh được, và chính người chấm ấy vào lại rồi
chấm các mốc lần nữa. Một nhánh đơn vị chấm thẩm mỹ cho một tính năng bị chia qua nhiều nhánh thì xếp
hạng so với riêng các mốc, và đó chính là thứ khiến điểm của hai nhánh so được với nhau.

Một bản giao không bố cục gì thì không bị phán như thể nó có. Khi direction mà lần audit này đọc khai
delta trình bày là `none` — một thay đổi chữ, hành vi hay ràng buộc, không publish giá trị trình bày
nào — thì bố cục dưới bức chụp là của một direction trước đó, nên vòng này mang theo ống kính thẩm mỹ
của lần audit ấy thay vì lấy lại cái thang: `## Calibration` ghi mỗi ống kính một hàng có ô mốc đọc là
`inherited` và ô kỳ vọng gọi tên nhánh đã chấm ống kính ấy, verdicts không mang điểm mốc nào, và
`## Ranked against` không xếp gì, vì ở đây không có gì được xếp. Cũng dưới delta ấy, tiêu chí tham
chiếu thôi không áp dụng, theo đúng những gì `TASTE-12` Case 5 nêu, và validator chỉ cho dấu ấy đứng
trên đúng tiêu chí đó và đúng delta đó. Một `fix-first` mang theo kiểu ấy là finding của chính bố
cục trước đó: nó đứng nguyên chỗ nó được nêu, nhánh này không mở vòng direction nào cho nó, và `next`
được phép gọi tên `quality.verify`. Một `fix-first` trên bố cục mà chính bản giao này có chạm thì giữ
luật ở trên — bề mặt được bố cục lại từ một direction mới và các gate của checkout chờ một `ship`.

## Chủ sở hữu quyết định chỗ hỏng đi về đâu

Một lời khai hỏng trên node do ứng dụng sở hữu là một giá trị mà resolution phải publish lại, nên nó
quay về `interface.fix` như một phát hiện duy nhất, được sửa trong cỡ fix của orchestrator từ chính kho
resolution ấy; phát hiện lớn hơn cỡ đó dừng ở đấy với `FIX_TOO_LARGE` và chạy lại bằng
`interface.generate`, chính operator giữ số vòng. Một lời khai hỏng trên phần render của
chính một component Grammar, trong hành vi đã công bố, là `grammar-gap`: ghi bằng chứng vào bảng gap
của họ rồi chuyển `workspace.bind` để bind checkout chủ thư viện. Khi đã bind, yêu cầu sửa đã được cho
phép đi tiếp `library.update` với kế hoạch chủ sở hữu giới hạn và gate hồi quy; không cần hỏi lại
thông lệ. Một hướng trình bày hoặc tier thật sự mới mang route `direction`, đi `interface.generate`
để giữ quyền chọn của người dùng. Cả hai đường đều không cho phép dùng CSS ứng dụng để vá hành vi riêng
của component. Phần
ruột của node do ứng dụng sở hữu không mang lời khai nào và không bị audit; chỉ các luật đo của chính
node ấy bị audit.

## Lượt đi thử được viết ra, không bao giờ được lập trình

Dưới `@tools/browsercontrol` chế độ `playwright`, người audit viết một `uat-walk` cho mỗi mục ma
trận — viewport và tông màu của mục làm ngữ cảnh riêng của lượt đi, các target theo vai trò và tên
để tới được trạng thái, route vào đúng một lần ở bước 1, thông tin đăng nhập theo tên khi route có
cổng canh, và một bức chụp mang tên mục ma trận — rồi runner của cây lái nó, nên ảnh chụp, ảnh cây
truy cập và bản ghi DOM mà audit đo tới từ một trình duyệt không ai lập trình. Một bức chụp ghi chế
độ này nêu lượt đi của mình, `walk-result` mà runner ghi cạnh đó ở đúng digest đã chạy, bước chụp
của lượt đi mang tên mục ma trận, và điều khiển mà bước ấy đi theo đúng như lượt đi nêu; viewport và
tông màu của nó là của lượt đi; còn một bức chụp không có lượt đi bên cạnh, hay một lượt đi có bức
chụp runner không sinh ra, bị từ chối. Các node, lời khai và phép đo của chúng vẫn là của người audit,
đọc từ bản ghi runner để lại.

## Audit không đổi gì cả

Không phán quyết nào là một lần sửa, một cách chữa cháy hay một mệnh lệnh. Một chỗ hỏng vẫn là chỗ
hỏng trong biên nhận cho tới khi một lượt resolution publish giá trị mới và người ghi viết nó xuống,
rồi chính bề mặt ấy được audit lại. Sự tách bạch đó là lý do biên nhận này có giá trị: một operator
có thể tự sửa thứ nó tìm ra thì lúc nào cũng báo được một bề mặt sạch.

## Ranh giới

Context chỉ đọc, và runtime là thứ được tiêu thụ chứ không được sở hữu. Operator chỉ ghi `response/`
của nhánh mình: biên nhận audit, các bức chụp, các ảnh màn hình và các phán quyết. Nó không sửa source
sản phẩm, cây đã áp dụng, knowledge hay Grammar, không sửa chữa, không tô lại, không chữa cháy bất cứ
thứ gì nó thấy, không khởi động, dừng, deploy hay cấu hình lại dịch vụ runtime, không trích một
identifier vắng mặt trong kho đã bind, không phán quyết một node nó chưa đo, và không nhận lời khai
làm bằng chứng rằng node đã pass.

## Độ khớp hướng đã chốt

Khi source mang art-direction-adoption, ghi art-direction-fidelity so với đúng PNG và business region mapping gốc. Mỗi region dẫn capture render thật, nêu sai khác quan sát được và verdict tổng hợp trung thực bên cạnh Grammar/accessibility/responsive. PNG không chứng minh control/data hoạt động; UAT bình thường vẫn bắt buộc.


## Đủ bằng chứng khớp PNG

Với bề mặt theo art direction, [art-direction-fidelity](../../templates/kinds/art-direction-fidelity.schema.json) bao phủ từng phần tử, state và viewport đã đóng băng theo anatomy, kích thước, responsive, motion và ngữ nghĩa. So anchor trong PNG đã chốt với composition thật, gồm đầu nối, tâm hình, baseline chữ và kích thước quang học của icon khi phù hợp. Bind mỗi nhận xét với rule của đúng owner, screenshot, node đã đo và walk/result của capture. Width/height phải bằng số runner đo và nằm trong khoảng responsive đã đóng băng; viewport và device scale theo driver capture thật. Chỉ kiểm overflow là thiếu.

Độ giống ngữ nghĩa, căn chỉnh quang học và chất lượng motion vẫn là trách nhiệm review render/walk đã giữ, không suy ra từ hash pixel hay build pass. Mục fail giữ đúng owner sửa và chặn hoàn tất bề mặt. Render/audit lại source đã sửa với technical proof mới đúng HEAD; giữ nguyên bằng chứng fail.

## Context

| Alias | Bind | Bắt buộc |
| --- | --- | --- |
| `@knowledge/ui/composition` | mọi rule và Case composition chuẩn, từng mục được phán tính áp dụng trên bề mặt đã render | có |
| `@knowledge/ui/presentation` | mọi rule và Case presentation chuẩn, từng mục được phán tính áp dụng trên bề mặt đã render | có |
| `@knowledge/ui/proof` | mọi rule, Case proof đã render và asset hiệu chuẩn chuẩn | có |
| `@workspaces/fe` | checkout được route ở commit mà lần áp dụng đã ghi; chủ sở hữu và identifier được quan sát ở đó | có |
| `@worktrees/sessions/central-runtime` | chủ runtime dùng chung: preview đang phục vụ worktree phiên ở commit ấy | có |
| `@knowledge/grammars/<family>` | mọi file authored của family cụ thể theo route, gồm snapshot package và bảng gap chuẩn | có |
| `@worktrees/unchecked/<product>` | phần chưa kiểm của tính năng này: những đơn vị và state mà các nhiệm vụ trước để lại chưa chứng minh trong làn audit, và cái nào trong số đó vòng này kiểm | không |

## Đầu vào

| Kind | Từ đâu | Bắt buộc |
| --- | --- | --- |
| `quality-verification` | quality.verify; required current-head technical gate proof before final audit of an art-directed source | no |
| `frontend-source-application` | `interface.generate`, hoặc `interface.fix` đã sửa một phát hiện trên đó; commit đang được quan sát và các lời khai nó đã ghi | có |
| `frontend-presentation-resolution` | `interface.generate`, chủ sở hữu của từng node | có |
| `frontend-direction-decision` | `interface.generate`, route và coverage mà ma trận suy ra từ đó | có |
| `route` | `workspace.bind`, route đã bind: checkout đã kiểm và source head mà commit đã áp xuất phát từ đó; endpoint lấy từ entry của chủ runtime, không bao giờ từ đây | có |
| `uat-account` | `identity.provision`, tài khoản dùng để đi vào route có cổng canh; vắng ở lượt đầu, và đó chính là thứ `IDENTITY_MISSING` bàn giao | không |
| `platform-operation-receipt` | `runtime.serve`, lượt phục vụ đã đưa commit vào quan sát trên cổng của sản phẩm; vắng khi bề mặt đã được phục vụ sẵn | không |
| `seed-receipt` | `data.seed`, những dòng đã đặt ở mức khối lượng đại diện của luồng để mật độ được chấm trên dữ liệu chứ không trên kho rỗng | không |
| `units` | `interface.plan`; bản đồ bề mặt mà nhánh này đo đúng một trang hay một modal của nó, gọi tên bằng `request.unit` | không |
| `landing-composition` | `landing.compose`; contract bằng chứng storytelling, motion, reduced-motion và performance khi bề mặt quan sát là landing | không |
| `knowledge-repair-receipt` | `knowledge.repair`, khi đây là lần thử lại với manifest đã bind lại | không |

## Yêu cầu

| Field | Kiểu | Mặc định | Hỏi |
| --- | --- | --- | --- |
| `auditScope` | object | — | Đóng băng danh mục bề mặt và mục ma trận từ nhiệm vụ; mode mặc định primary-surfaces theo audit-scope.schema.json |
| `feature` | id | — | Khoá feature dùng để địa chỉ hoá sổ unchecked mà các state hoãn và khoảng trống phủ của lượt soi này được ghi vào, @worktrees/unchecked/<product>/<feature>.jsonl |
| `matrix` | list | selected surface entries | Chỉ thu hẹp trong phạm vi đã đóng băng; không bỏ mục bắt buộc của bề mặt đã chọn |
| `readinessProbe` | choice | route-served | Mức sàn của sẵn sàng; một state cần dữ liệu tự nâng lên `route-and-data-served` |
| `account` | id | null | Hồ sơ tài khoản dùng để đăng nhập khi route đòi một danh tính; giá trị là tham chiếu tới một hồ sơ toàn tên, không bao giờ là thông tin đăng nhập |
| `env` | id | dev | Stack mà lượt soi này đọc entry và tài khoản của nó; một bề mặt quan sát ở stack này không nói gì về stack khác |
| `resume` | token | null | Token của nhánh bị chặn khi vào lại sau một mã dừng |

## Các bước

| # | Bước | Tham số | Đọc | Ghi | Dừng với |
| --- | --- | --- | --- | --- | --- |
| 1 | Kiểm cổng vào và resume, và xác nhận commit đã áp nằm trong head mà route đang phục vụ | `resume` | `request/request.json`, đầu vào `frontend-source-application` (commit nó đã ghi), đầu vào `route` (nhánh đang phục vụ, head đang phục vụ và những commit head đó chứa), @workspaces/fe tại head đã đóng băng, @worktrees/sessions/central-runtime, @tools/git | — | `INVALID_INPUT`, `SOURCE_DRIFT`, `NO_PROGRESS` |
| 2 | Bind toàn bộ thẩm quyền UI và family | — | manifest chính xác cho @knowledge/ui/composition, @knowledge/ui/presentation, @knowledge/ui/proof, catalog Grammar và mọi file family đã viết; đầu vào `frontend-source-application` (các lời khai), đầu vào `frontend-presentation-resolution` (chủ sở hữu của từng node), @worktrees/sessions/central-runtime | — | — |
| 3 | Bind phạm vi bề mặt chính, các mục ma trận và lớp bề mặt đã khai, rồi cho mỗi state vòng này sẽ không tới đúng một câu nói vì sao | `feature`, `auditScope`, `matrix` | đầu vào `frontend-direction-decision` (chính `response/data/coverage.json` của nó: state nhân viewport nhân bảng màu, và `surfaceClass` mà quyết định ấy đã khai), @worktrees/unchecked/<product> cho thứ tính năng này đang nợ trong làn audit | — | `SURFACE_CLASS_MISSING`, `UNCHECKED_UNLAWFUL` |
| 4 | Chờ từng mục tới lúc sẵn sàng trên cổng mà entry của chủ runtime cho route này mang theo, trong profile trình duyệt của riêng phiên này, đăng nhập bằng tài khoản của luồng khi route đòi một danh tính | `readinessProbe`, `account`, `env` | @worktrees/sessions/central-runtime để lấy entry của đúng route này và endpoint nó phục vụ, đầu vào `uat-account` cho hồ sơ toàn tên, @tools/http, @tools/secrets, @tools/browsercontrol | — | `RUNTIME_UNAVAILABLE`, `IDENTITY_MISSING` |
| 5 | Viết một lượt đi thử cho mỗi mục ma trận: viewport và tông màu của mục làm ngữ cảnh, target theo vai trò và tên để tới trạng thái, route vào đúng một lần ở bước 1, thông tin đăng nhập theo tên khi route có cổng canh, một bức chụp mang tên mục | — | đầu vào `frontend-direction-decision` (các mục ma trận), đầu vào `route`, đầu vào `uat-account` cho hồ sơ toàn tên | `uat-walk` | — |
| 6 | Chạy từng lượt đi qua runner của cây dưới @tools/browsercontrol chế độ `playwright` — một ngữ cảnh trình duyệt mới tinh cho mỗi lượt đi tại endpoint mà entry của chủ runtime mang — hoặc lái mục đó qua trình duyệt dưới chế độ `required` khi không viết lượt đi nào | — | `uat-walk`, @worktrees/sessions/central-runtime để lấy endpoint, @tools/browsercontrol, @tools/secrets | `walk-result`, `response/artifacts/<matrixId>.png` | `RUNTIME_UNAVAILABLE` |
| 7 | Chụp và đo từng mục, đọc các node, lời khai và giá trị của chúng từ bản ghi runner để lại hoặc từ trình duyệt đang lái | — | @worktrees/sessions/central-runtime, @workspaces/fe (các owner được quan sát và identifier từng node mang), `walk-result`, @tools/browsercontrol | `response/artifacts/<matrixId>.png`, `response/data/captures/<matrixId>.json` | `EVIDENCE_MISSING` |
| 8 | Phán các làn đo được theo từng mục: đối chiếu với lời khai cùng mọi file, rule và Case kiến thức đã bind mà áp dụng được, phán theo chủ sở hữu, và để từng topic đo được tự đóng; với landing, còn phải chứng minh bằng chứng visual storytelling, motion, reduced-motion và performance của composition contract, rồi route lỗi theo audit contract của nó. Dưới chế độ `playwright`, mọi kết quả presentation, contrast, accessibility và responsive trích dẫn đúng phần tử của bản ghi `capture-measurements` mà runner đã đo — `ref` và giá trị đọc được — để biên nhận không nêu một con số nào runner chưa ghi. Mỗi mục không áp dụng mang lý do cụ thể và bằng chứng. Nếu một mục kiến thức đã bind không thể áp dụng nhất quán, ghi câu hỏi có kiểu rồi dừng thay vì sửa kiến thức tại đây | — | manifest kiến thức và brief hiểu family đã đóng băng, cả ba nhóm @knowledge/ui, @knowledge/grammars/<family>, đầu vào `landing-composition` khi có, các bức chụp, `walk-result` (bản ghi `capture-measurements` nó nêu cạnh từng bức chụp) | `knowledge-coverage`, `family-understanding`, hoặc `knowledge-question` | `UNKNOWN_RULE`, `KNOWLEDGE_QUESTION` |
| 9 | Chấm ống kính thẩm mỹ một lần trên mọi tấm của phạm vi, hiệu chuẩn trên ba tấm mốc và xếp hạng theo tương quan, rồi phát | — | @knowledge/ui/proof (bộ hiệu chuẩn dưới `calibration/`: các mốc, dải của chúng và khoảng dung sai), các bức chụp của mọi bề mặt đã chọn | `verdicts`, `art-direction-fidelity`, `frontend-surface-audit`, `findings`, `response/response.json`, `host` | `CALIBRATION_OFF`, `NO_PROGRESS` |

Bậc 8 phán mọi lời khai và để từng topic proof đo được tự đóng lại. Phần phán canon là cái ở trên: mọi
lời khai đều được đo, phán theo luật đã publish, định tuyến theo chủ sở hữu của node nó đứng lên; tra
cứu có giới hạn (`@tools/websearch`) chỉ giải nghĩa một referent mà rule gọi tên, không quyết thêm gì.
Mỗi topic được ràng tự tính verdict của mình bằng chính rule đóng của nó — phần số học sống ở đó và
không nhắc lại ở đây — và bậc 9 publish mỗi topic một hàng dưới `## Verdict`: presentation,
composition, responsive, motion, accessibility, contrast, render-truth và taste, mỗi hàng mang verdict
mà rule của topic ấy sinh ra cùng đường đi của một lần fail. Một topic không có bằng chứng tới nơi là
`blocked`, và `blocked` không bao giờ được báo thành đạt cũng không bao giờ thành hỏng. Hàng taste
được chấm theo từng mục ma trận trên cái thang đã hiệu chuẩn rồi gộp lại, điểm thấp nhất và phán quyết
hỏng thắng, vì một bề mặt chỉ tốt bằng viewport tệ nhất đã chụp; một `fix-first` ở đó vẫn đứng ngay cả
khi mọi luật canon đều xanh, và các cổng của chính checkout chờ một `ship`.

Đầu ra `findings` không phải của agent để ghi. Khi biên nhận này được chấp nhận, orchestrator ghi thêm
mọi lần hỏng nó đã ghi vào sổ cái findings và vật chất hoá các dòng đang mở của sổ cái cho những bề mặt
đã quan sát cạnh biên nhận, theo luật và script mà
[mục lục findings](../../knowledge/findings/INDEX.vi.md) nêu; gate phiên từ chối một lượt audit đã
xong mà sổ cái không giữ các lần hỏng của nó.

Bảng chụp được dựng bằng `@tools/visualize` và được phục vụ chứ không chỉ được lưu (bằng tool có sẵn trong sổ đăng ký). `@tools/host` đặt `response/artifacts/` lên loopback ở
cổng trống đầu tiên trong dải của sổ đăng ký và ghi URL, cổng, thư mục cùng pid vào
`response/artifacts/host.json`, rồi dừng khi nhánh kết thúc hoặc được resume; một người mở bảng ấy và
thấy từng mục ma trận cạnh phán quyết của nó. Không gì bind `0.0.0.0`.

Phục vụ chưa phải là nói. Bậc 9 in qua `@tools/print`, thẳng vào cuộc trò chuyện người ta đang
đọc, URL của bảng chụp, ảnh chụp điểm thấp nhất của từng topic và bảng `## Verdict`, còn biên nhận
liệt kê từng artifact đã in dưới `## Printed` kèm lý do. Một phán quyết không ai thấy thì không đưa ai
đi đâu, và một lượt soi lưu bảng chụp rồi im lặng chỉ soi chính nó.

Một phán quyết bố cục hay thẩm mỹ không bao giờ được đóng bằng cách hỏi. Khi một topic như thế đóng ở
fail hay fix-first, hàng của nó định tuyến về `direction` và chuỗi bàn giao sang
`interface.generate`, nơi chấm các phương án đã render theo đúng các tiêu chí mà audit này đã
đánh rớt rồi áp dụng chính sách lựa chọn cùng [chính sách tương tác](../../resources/interaction.vi.md).
Audit này không dựng gì, không xếp hạng gì và không mời chọn gì: validator từ chối một route `user`
mà còn để một topic bố cục hay thẩm mỹ mở; direction sở hữu việc so sánh phương án và lựa chọn hướng
khác biệt. Các mã dừng
về phía caller và `NO_PROGRESS` ở đây là việc vận hành — cùng một head đo lại mà không có delta — nên
`reason` của chúng nói rõ điều ấy và không mang phương án nào. Một topic `blocked` vì matrix exhaustive bỏ sót
một state đã khai không phải là cùng một head đo lại, và cũng không phải một finding bố cục hay thẩm
mỹ: nó không tính vào `NO_PROGRESS` và không đóng một topic bố cục hay thẩm mỹ thành `fix-first`. Một
điểm trung bình thẩm mỹ chỉ so được giữa các vòng khi cả hai vòng phủ cùng một tập state; một vòng có
phạm vi chính mới có thể hoàn thành trên bằng chứng riêng nhưng không được đem so với vòng exhaustive để dùng ngân sách tiến độ.

Một tiêu chí phụ thuộc vào khối lượng dữ liệu được đo ở khối lượng seed đại diện của luồng, khối
lượng mà `TASTE-9` Case 5 định nghĩa, không bao giờ ở bất kỳ thứ gì workspace đang phục vụ tình cờ
đang có. Khi workspace đang phục vụ ở dưới mức ấy, topic thẩm mỹ là `blocked` và định tuyến về
`seed`: operator sở hữu dữ liệu đưa workspace lên đủ khối lượng rồi mục ấy được chụp lại — không phải
một lượt direction, cũng không phải một câu có/không cho người, vì cây đã trả lời sẵn bằng cách tạo ra
dữ liệu. Đo lại ở đủ khối lượng mà vẫn hỏng, tiêu chí ấy được ghi `data-bound` trong ô Measured và
`TASTE-13` Case 6 để nó ngoài verdict, nên nó không chặn quality cũng không chặn UAT.

Một lựa chọn người đã lấy từ một bảng đã in đóng lại những tiêu chí mà lựa chọn ấy đã biết là rớt. Khi
quyết định direction mà audit này đọc đã được người duyệt và `## Scores` của nó cho thấy một tiêu chí
rớt ở phương án được chọn vào lúc chọn, audit này ghi tiêu chí ấy là `person-accepted` trong ô
Measured, gọi tên nhánh của quyết định đó, thay vì đánh rớt nó ngược về direction; `TASTE-13` Case 7
để nó ngoài verdict và topic đóng trên các tiêu chí còn lại. Thang điểm không bao giờ lật một quyết
định người đã lấy trên chính bằng chứng của mình trong cùng phiên, nên một lens thẩm mỹ mà mọi tiêu
chí rớt đều là `data-bound` hay `person-accepted` thì ship, và `next` gọi tên `quality.verify`.
Validator từ chối một hàng `person-accepted` không gọi tên nhánh quyết định nào, gọi tên một quyết định
operator tự lấy, hay phủ lên một tiêu chí mà phương án được chọn không được cho thấy là rớt.

Lớp bề mặt không phải thứ operator này được chọn, cũng không phải thứ nó khai. Nó được đọc từ coverage
của `frontend-direction-decision` mà audit này nhận vào, nơi hướng đã khai nó từ bộ từ vựng mà
`COVERAGE-1` Case 7 publish; mọi rule proof có dải đọc ngưỡng của mình từ cái tên ấy, còn audit chỉ
mang nó vào `## Surface class` và vào verdicts, nguyên vẹn. Một quyết định đầu vào không mang lớp nào
— một quyết định viết từ trước khi lớp được khai — hay mang một tên ngoài bộ từ vựng, là
`SURFACE_CLASS_MISSING`: không dải, không ngưỡng, không có gì để phán, và hướng được quyết lại trước
khi bề mặt được phán.

Phạm vi được đóng băng trước khi chụp bằng `auditScope`, được kiểm bởi
[schema phạm vi audit](../../templates/kinds/audit-scope.schema.json). Mặc định là `primary-surfaces`:
soi các màn hình chính và layout quan trọng trước; state phụ và bề mặt hoãn lại vẫn được ghi rõ là
việc chưa làm. Orchestrator lấy danh mục từ nhiệm vụ và direction hiện có, không hỏi xác nhận thường
lệ. `exhaustive` chỉ dùng khi chủ động chọn kiểm toàn bộ ma trận state đã khai.

Mỗi mục danh sách ghi id ổn định, loại page/layout/modal/drawer, route và các matrix id bắt buộc.
Mục chính có entry; mục deferred không có entry. Mọi entry đã chọn phải
có capture, screenshot và verdict. Mọi lời khai đo trên bề mặt đã chọn vẫn phải được phán. Hoãn bề
mặt hay state khác không miễn lỗi hoặc assertion còn thiếu trong matrix đã chọn. Thiếu entry đã
chọn là `EVIDENCE_MISSING`.

`verdicts.auditScope` chép nguyên danh mục cùng mode chuẩn hóa, liệt kê state phụ đã khai nhưng chưa
chụp trong `deferredStates`, và ghi `coverageClaim`. Audit chính chỉ được khai `selected-surfaces`;
không được biến các topic đạt thành lời khai đã kiểm toàn bộ state UI. Audit exhaustive thiếu state
đã khai vẫn bị chặn và ghi `## Coverage gaps`. `TASTE-13` Case 8 sở hữu việc so state và so các vòng.
Các gate unit, integration và regression giữ nguyên hợp đồng coverage riêng.

Một state được hoãn là phần phủ chưa kiểm, và nó được ghi xuống đúng như thế. Mỗi mục của
`deferredStates` mang lý do của mình trong `deferrals`, chính câu mà sổ cái dưới `@worktrees/unchecked`
chép lại chứ không tự bịa, để một người đọc sổ cái nhiều tháng sau học được vì sao state ấy bị bỏ qua
từ chính lượt audit đã bỏ qua nó. Nhánh này đo đúng một đơn vị mà hành trình của nhiệm vụ đi qua —
việc toả nhánh không bao giờ gửi một đơn vị đã hoãn tới đây — và một đơn vị hành trình được chứng
minh ở mọi state mà người đọc gặp trên đường đi qua nó: bốn state mà schema phạm vi publish thành
`journeyStates`. Gọi tên một trong bốn state ấy là đã hoãn là `UNCHECKED_UNLAWFUL` và quay về bản kế
hoạch, vì cách sửa cho phần phủ mà hành trình cần là một lần xếp tier khác, không bao giờ là một lượt
audit nhỏ hơn.


## Đầu ra

| Kind | File | Kiểu | Bắt buộc |
| --- | --- | --- | --- |
| `art-direction-fidelity` | `response/data/art-direction-fidelity.json` | data | no |
| `frontend-surface-audit` | `response/response.md` | md | có |
| `capture` | `response/data/captures/<matrixId>.json` | data | có |
| `screenshot` | `response/artifacts/<matrixId>.png` | artifact | có |
| `verdicts` | `response/data/verdicts.json` | data | có |
| `findings` | `response/data/findings.json` | data | không |
| `uat-walk` | `response/data/walks/<walk>/walk.json` | data | không |
| `walk-result` | `response/data/walks/<walk>/walk-result.json` | data | không |
| `host` | `response/artifacts/host.json` | artifact | không |
| `knowledge-coverage` | `response/data/knowledge-coverage.json` | data | không |
| `family-understanding` | `response/data/family-understanding.json` | data | không |
| `knowledge-question` | `response/data/knowledge-question.json` | data | không |

## Operator Result

Với audit đã hoàn tất, `outcome.primary` là một capture `image` thật đã khai của bề mặt được audit.
Một verdict table hoặc tài liệu audit bắt buộc làm mục phụ để ảnh không bao giờ được trình mà thiếu
finding và kết luận conform/chất lượng. Nhãn xác định vùng đạt hoặc lỗi cùng verdict thấy được trong
state và viewport hữu ích nhất cho quyết định; primary là capture của chính lượt audit, không phải
mock đẹp hơn nhưng không liên quan.

## Dừng

| Code | Xử lý |
| --- | --- |
| `INVALID_INPUT` | terminate |
| `SOURCE_DRIFT` | terminate |
| `RUNTIME_UNAVAILABLE` | terminate |
| `IDENTITY_MISSING` | terminate |
| `EVIDENCE_MISSING` | terminate |
| `UNKNOWN_RULE` | terminate |
| `KNOWLEDGE_QUESTION` | terminate |
| `SURFACE_CLASS_MISSING` | terminate |
| `CALIBRATION_OFF` | terminate |
| `UNCHECKED_UNLAWFUL` | terminate |
| `NO_PROGRESS` | terminate |

## Kế tiếp

| Khi | Operator |
| --- | --- |
| knowledge đã bind mâu thuẫn với bằng chứng render đã kiểm, nên owner chuẩn sửa nó trước khi audit lại cùng bề mặt và tham chiếu | `knowledge.repair` |
| một lời khai hỏng trên node do ứng dụng sở hữu, nên một phát hiện được sửa từ chính kho resolution trong cỡ fix của orchestrator | `interface.fix` |
| một verdict topic là fix-first, hoặc hướng không khai lớp bề mặt nào, nên bề mặt được sinh lại từ một hướng mới trước khi có giá trị nào được quyết | `interface.generate` |
| mọi topic đều ship hoặc đạt, và các cổng của chính checkout phải chạy | `quality.verify` |
| grammar-gap xác định hành vi thư viện hiện có bị lỗi, nên bind checkout chủ thư viện trước khi thực hiện yêu cầu sửa đã được cho phép | `workspace.bind` |
| phát hiện trên Grammar đòi hướng trình bày hoặc tier thật sự mới, nên quyết hướng do người dùng chọn trước khi triển khai | `interface.generate` |
| một topic đọc xuyên state bị blocked vì matrix bỏ sót một state mà coverage của hướng đã khai, nên bề mặt được audit lại khi matrix đã phủ đủ | `interface.audit` |
| một state của đơn vị hành trình bị hoãn thay vì được đo, nên bản kế hoạch đã xếp tier cho đơn vị ấy xếp lại tier trước khi bề mặt được audit | `interface.plan` |
| một tiêu chí mật độ được đo dưới khối lượng seed đại diện của luồng, nên dữ liệu được seed trước khi bề mặt được phán lại | `data.seed` |
| route đòi một danh tính mà luồng này chưa có tài khoản, nên tài khoản được cấp trước khi bề mặt được quan sát | `identity.provision` |
