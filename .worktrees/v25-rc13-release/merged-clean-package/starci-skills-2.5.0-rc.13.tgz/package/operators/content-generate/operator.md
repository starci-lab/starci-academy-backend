# content.generate

## Job

Generate or refactor one educational content unit in one linear pass: a teacher brief that constrains
everything after it, one written edition per declared language, images made to a stated claim, code
and executable checks that actually run, and an independent review that receives the artifacts
without the producer's rationale.

## Done when

Done when the `content-brief` was frozen before any edition, every declared language has an
`article` covering the whole published outcome set, every declared `track` was built and checked by
its declared command with a zero exit code recorded in `e2e`, an `image` exists only when its stage
was on and then with its `image-prompt` beside it, and an independent `content-review` written
without the producer's rationale approves the unit with every applicable score at or above the
published minimum and no open error finding, as the `content-generation-receipt` states.

## The brief comes first and constrains what follows

The teacher brief is written before anything else, from curriculum and source evidence, in one fresh
execution that inherits no turns. It publishes the learner inputs, the observable outcomes, the claims
a visual may encode, the examples, and the explicit add, change, and remove dispositions, and it is
then fingerprinted so nothing downstream may extend it. Everything after it is measured against it: an
edition may only claim coverage of an outcome the brief published, an image may only encode a claim
the brief published, and every declared edition must cover the whole published outcome set before the
unit can ship. An edition that covers part of the brief is a partial lesson in one language and a
complete one in another, which is exactly the silent defect this check exists to catch. A change or
remove disposition names what it acts on, because a disposition with no target is a wish.

## Generated code must actually run

Every implementation track is built with the exact command `commands` names for it, and the exit code
is read and recorded in `response/data/e2e.json`. A non-zero exit code cannot ship, because the lesson
would tell a learner that code works on nobody's evidence. Step 7 runs the declared command per track
inside a bounded run, read and repair loop whose ceiling is `maxE2eIterations`; the loop lives inside
the step, so `E2E_FAILED` is raised once, when the iterations are spent, rather than on the first red
run. The loop may repair the implementation or the harness. It may never move the contract it is
measured by, so the contract fingerprint is taken before the first run and compared after the last
one: a test deleted, skipped, loosened, or special cased to make the run green is the failure that
comparison exists to catch, and it is `CONTRACT_WEAKENED`. A track carries its build command and its
exit code, a run carries its command, its exit code, and its named assertions, and neither carries a
sentence claiming success.

## The image is made to a stated intent

The visual is derived from the brief's claims, the prompt that states that intent is persisted beside
the result, and the result is inspected for legibility, hierarchy, and claim fidelity. Step 5 runs
only when `stageModes` turns the image on; with the image off the step produces nothing at all, no
image and no prompt, and the receipt records `STAGE_DISABLED`, because a decision that leaves no
record reads later as an omission. A claim the brief never published cannot appear, and a visual that
fails its own claim-fidelity inspection cannot ship. An image is not decoration added at the end; it
is one of the claims, drawn.

## The review is a nested exchange, and revision is a fallback with a ceiling

After the executable check, the branch pauses: it emits `response/response.json` with status `waiting`
and `awaiting { exchange: review, kind: content-review }`. The orchestrator writes
`review/request/request.json` with the produced artifacts and the claims they make as inputs, never
the producer's rationale, and runs a fresh agent on this operator's own profile with no inherited
turns; that agent is never the execution that wrote the brief or an edition, and it writes only
`review/response/`. It scores correctness, pedagogy, interview value and language, and, where those
stages ran, visual fidelity, code quality and executable proof. Approval requires every applicable
score at or above 85 and no open error finding. A returned revision is not a stop: it is the fallback
`REVIEW_REVISION_REQUIRED`, and the branch repairs exactly the artifacts the review's findings name,
by owning stage, then reopens the exchange for the next round. The ceiling is `maxReviewRounds`; when
those rounds are spent and the review still returns a revision, `REVIEW_ROUNDS_EXHAUSTED` terminates,
because a unit that has been rewritten to a reviewer's satisfaction after unbounded rounds was
rewritten by the reviewer. A unit that passes its own author's review has not been reviewed, which is
why shared executions, inherited turns, and producer rationale are three separate refusals.

## Concrete attempt flow

This operator's rows are gated by the shared expected/actual attempt contract in `scripts/attempt-gate.mjs`.

| Observed state | Action | Actual check | Next branch |
| --- | --- | --- | --- |
| artifact matches frozen brief | reuse its fingerprint | structure, source, image or executable checks pass | receipt marks reused |
| artifact missing | create declared edition, image or track | run artifact-specific check | continue only on match |
| artifact invalid | update owning prose/image/track/harness stage | rerun failed and dependent checks | new repair attempt preserves prior review |
| review exceeds brief | change no goal silently | record scope-changing finding | emit replan evidence |
| valid alternatives tie | choose by brief fit, learner clarity, support, lower cost, stable id | record scores and differentiator | continue |

## Boundary

Context is read-only. The operator writes only `response/` of its own branch: the brief, the receipt,
the machine record of the build and the executable check, and the editions, image, prompt and tracks
under `response/artifacts/`; the review agent writes only `review/response/`. It runs only the
declared build and executable-check commands. It never writes an article before the brief is frozen or
beyond what the brief published, claims a learning outcome, example, or visual claim the brief does not
publish, reports a build or executable check that was not run or whose exit code was not read, changes
the executable contract during a repair loop, lets the producer of an artifact perform, steer, or
brief its own review, or approves a unit while any applicable score sits below the published minimum.
It does not edit the curriculum, publish the unit to the served object, or claim any readiness beyond
the checks it actually ran.

## Context

| Alias | Bind | Required |
| --- | --- | --- |
| `@remote/minio/<contentId>/<locale>` | the lesson as served, by the fingerprint of the fetched object; the unit being authored or revised | yes |
| `@worktrees/sessions/central-runtime` | the AI runtime that runs, reads, and repairs generated code, by generation | yes |

## Inputs

| Kind | From | Required |
| --- | --- | --- |
| `content-generation-receipt` | a prior run of `content.generate` on the same unit; regression history, absent on the first pass | no |

## Requirements

| Field | Type | Default | Ask |
| --- | --- | --- | --- |
| `unit` | id | — | The content unit being authored or revised |
| `naturalLanguages` | list | vi | The languages the unit is written in; every one of them covers the whole outcome set |
| `implementationLanguages` | list | empty | The languages the implementation tracks are written in; empty means no code and no executable check |
| `stageModes` | list of `{image}` | image off | Which optional stages run; `image on` turns step 5 on |
| `commands` | list of `{language, buildCommand, checkCommand}` | the commands the unit declares | The exact command each track is built and checked with |
| `maxE2eIterations` | number 1–20 | 2 | How many run, read and repair iterations step 7 may spend before `E2E_FAILED` |
| `maxReviewRounds` | number 1–20 | 2 | How many review rounds the revision fallback may spend before `REVIEW_ROUNDS_EXHAUSTED` |
| `resume` | token | null | The blocked branch's token when re-entering after a stop |

## Steps

| # | Step | Params | Reads | Writes | Stops with |
| --- | --- | --- | --- | --- | --- |
| 1 | Validate the gate and resume | `resume` | `request/request.json`, input `content-generation-receipt` when present, @remote/minio/<contentId>/<locale> at the frozen unit binding | — | `INVALID_INPUT`, `SOURCE_DRIFT`, `NO_PROGRESS` |
| 2 | Inspect every edition, image and track, classifying each reusable, missing or invalid against the bound curriculum, source and runtime | `unit` | @remote/minio/<contentId>/<locale> for curriculum and style as served, @worktrees/sessions/central-runtime for the runtime configuration, @tools/objectstorage | — | — |
| 3 | Write and freeze the brief | `naturalLanguages`, `implementationLanguages` | @remote/minio/<contentId>/<locale> for curriculum and source evidence, @tools/websearch | `response/brief.md` | `BRIEF_UNBOUND` |
| 4 | Reuse valid editions, create missing editions and update only invalid editions from the frozen brief | `naturalLanguages` | `response/brief.md` as the frozen brief | `response/artifacts/article.<language>.md` | `OUTCOME_UNCOVERED` |
| 5 | Reuse a valid image, or generate and inspect a missing or invalid image and prompt; mismatch opens a new image repair attempt | `stageModes` | `response/brief.md` for the claims and the stated image intent | `response/artifacts/image.<name>`, `response/artifacts/prompt.<name>.txt`, @tools/imagegen | `IMAGE_UNAVAILABLE` |
| 6 | Reuse valid tracks, create missing tracks and repair invalid tracks, then build each declared track without changing the brief | `implementationLanguages`, `commands` | `response/brief.md`, @worktrees/sessions/central-runtime where each build command runs | `response/artifacts/track.<language>.<extension>`, @tools/shell | `CODE_BUILD_FAILED` |
| 7 | Run the executable check, at most `maxE2eIterations` iterations | `maxE2eIterations` | @worktrees/sessions/central-runtime where each declared command runs | `response/data/e2e.json`, @tools/shell | `E2E_FAILED`, `CONTRACT_WEAKENED` |
| 8 | Await the review: pause, a fresh agent reads the artifacts without the producer's rationale, revise and reopen while rounds remain | `maxReviewRounds` | `review/response/review.md` once the exchange is done | `response/response.json` (waiting, awaiting review) | `REVIEW_REVISION_REQUIRED`, `REVIEW_ROUNDS_EXHAUSTED` |
| 9 | Write the receipt and emit | — | everything above | `response/response.md`, `response/response.json` | — |

Under the defaults the unit is one Vietnamese edition with no image, no track and no executable check,
and its quality rests entirely on step 8. A resume begins again at step 1, reuses only unchanged
fingerprinted observations, and consumes the exact delta; a revised brief arrives as a new
fingerprint, because the same fingerprint cannot yield a different answer. The receipt claims no
publication, no learner outcome in production, and no acceptance beyond the checks actually run.

## Outputs

| Kind | File | Type | Required |
| --- | --- | --- | --- |
| `content-generation-receipt` | `response/response.md` | md | yes |
| `content-brief` | `response/brief.md` | md | yes |
| `e2e` | `response/data/e2e.json` | data | no |
| `content-review` | `review/response/review.md` | md | yes |
| `article` | `response/artifacts/article.<language>.md` | artifact | yes |
| `image` | `response/artifacts/image.<name>` | artifact | no |
| `image-prompt` | `response/artifacts/prompt.<name>.txt` | artifact | no |
| `track` | `response/artifacts/track.<language>.<extension>` | artifact | no |

## Operator Result

On `done`, print **Operator Result** by rendering `response/artifacts/article.<language>.md`; display each declared `response/artifacts/image.<name>` beside the relevant passage and link any `response/artifacts/track.<language>.<extension>` as secondary output. A failed review presents `review/response/review.md` and the unresolved issue, never the draft as finished content.

## Stops

| Code | Disposition |
| --- | --- |
| `INVALID_INPUT` | terminate |
| `SOURCE_DRIFT` | terminate |
| `NO_PROGRESS` | terminate |
| `BRIEF_UNBOUND` | terminate |
| `OUTCOME_UNCOVERED` | terminate |
| `IMAGE_UNAVAILABLE` | terminate |
| `CODE_BUILD_FAILED` | terminate |
| `E2E_FAILED` | terminate |
| `CONTRACT_WEAKENED` | terminate |
| `REVIEW_REVISION_REQUIRED` | fallback |
| `REVIEW_ROUNDS_EXHAUSTED` | terminate |

## Next

| When | Operator |
| --- | --- |
| the routed content object or the shared runtime does not answer at the frozen binding | `workspace.bind` |
| the unit is written, reviewed and stored, and a person decides its publication | `user` |
