# service.operate

## Job

Bring one auxiliary service the environment declares — an observability stack, a code-quality
service, a tunnel beside a served runtime — to the state that declaration asks for, prove from its
own probe that it is in that state, and record the holder that answers, under the lease that orders
sessions.

## Done when

Done when the `service-receipt` binds the one service the environment declares and the authority
that covered it, and its Checks prove the observed state from the service's own probe — an `up` that
answers, a `down` whose port is free — with the holder that answers recorded and no credential value
anywhere in it.

## One service of the environment, one branch

A machine that runs a product also runs the things beside it: the stack that collects its metrics
and logs, the service a code-quality gate posts to, the tunnel that carries a served runtime out to
somewhere a person or a provider can reach. None of them is the product, none of them is the
product's runtime, and each is a different thing to start, a different thing to probe and a
different owner when it will not come up. An operator handed all of them at once is an operator that
reports one outcome for several unrelated services, so the unit here is one service: the request
names it, the branch moves it, and the receipt speaks about it and about nothing else.

They are enumerated by the environment, not by a plan. Every service this operator may touch is a
row of `services` in the environment's declaration — its `id`, its `kind`, the state the environment
wants it in, the declared command that moves it, the probe that proves it, and whether the
environment keeps it with a person — so there is nothing for a `service.plan` to discover and no
`units` list to fan out over. A mission that needs two of them names this operator on two done-when
lines, and the planner's rule for an operator with no plan sibling puts each on its own branch, the
second after the first. A request naming a service the declaration does not carry is `INVALID_INPUT`,
because a service nobody declared is not a service this operator is allowed to invent.

## The declaration is the authority, and a service may still be a person's

Where the authority behind `approval` comes from is the environment's to say, and this operator does
not restate the law the environment schema publishes
(`readiness/initialization/stacks/environment.schema.json`): the class here is `service`, a
non-production environment answers it by declaration and a production one keeps it with a person,
any declaration may tighten it, and `approval` therefore accepts either an approval id or the
declaration's reference — its path and the hash of its bytes. Two things are this operator's own.
The first is that the service row carries its own `holder`: an environment may answer the class by
declaration and still keep one particular service with a person, and that service is
`SERVICE_APPROVAL_REQUIRED` however the class reads. The second is that the stop is taken before
anything moves, so a service a person holds is never started and then reported.

## A state nobody probed is not a state

The receipt records two states and never one. `Desired` is what the request asked for; `Observed` is
what the service was in when the branch ended, and it is set from the declared probe and from
nothing else — not from the exit code of the command, not from a log line, not from the fact that
the command was run. An `up` whose probe does not answer is `SERVICE_UNPROVEN`, and so is a `down`
whose port is still held; both resume this operator with the service repaired or the probe
corrected, and neither is ever answered by dropping the probe. A request may also ask for
`attested`, which changes nothing and reports what stands: the declared command is not run, the
probe is read, and the receipt records the observation as a finding rather than as a move. Attesting
never restarts anything, for the same reason the runtime owner gives: a healthy service restarted in
order to be described is the state the next step was going to measure, destroyed.

A service that already stands in the desired state is a proved no-op. The command is not run, the
probe still decides `Observed`, and the receipt records `SERVICE_ALREADY_IN_STATE` under its
findings, so a reader can tell a service this branch started from one it merely found.

## The holder is recorded, and the port is not reclaimed

A service that is up is a process, and a process nobody recorded is a process nobody can stop. The
receipt records the pid that answers on the declared endpoint, and the service entry beside the
runtime registry carries the same record, so the branch that later takes the service down stops the
tree it recorded and no other. A declared public port a product route is already projected onto is a
collision between two owners: it is recorded as `SERVICE_PORT_SHARED` under the findings, with both
claimants named, and it is never resolved by moving a port or by stopping whatever holds one. This
operator stops only what its own record names.

## The lease is the order between sessions

One session moves a service at a time. The session that operates takes the lease of the environment's
service entry while it runs the declared command and probes the result, and releases it when the
probe has answered; a session that asks while another holds it waits and is told the holder. The wait
is short by construction: a lease is held for one command and one probe, never for the length of the
work the service exists to support.

## Concrete attempt flow

This operator's rows are gated by the shared expected/actual attempt contract in `scripts/attempt-gate.mjs`.

| Observed state | Action | Actual check | Next branch |
| --- | --- | --- | --- |
| declared service matches config and functional probe | reuse and record live identity | health and goal-specific probe pass | emit unchanged receipt |
| service missing | create/start only approved kind and refs | read process/container, endpoint and probe | emit created delta |
| service invalid | update mutable declared refs only | rerun health and failed functional probe | new repair attempt; foreign/wider effect owner handoff |
| mutation uncertain | inventory again before action | classify converged, not converged or uncertain | never blind-repeat |

## Boundary

Context is read-only apart from the service entry. The operator runs exactly the command the
declaration names, for exactly the service the request names, and writes only that service's entry
under `@worktrees/sessions/central-runtime` and `response/` of its own branch: `response.md` and
`response.json`. It does not write an environment declaration or otherwise grant its own approval;
does not start, stop, or reconfigure a service the declaration does not name; does not touch a
product route's server, its integration branch or its port; does not move a port or free one by
stopping whatever holds it; does not stop a process its own record did not name; does not restart a
service in order to attest it; does not seed data, provision an account, run a gate or judge a
product; and does not record a credential value, a capability handle or a secret-shaped token
anywhere in what it writes.

## Context

| Alias | Bind | Required |
| --- | --- | --- |
| `@worktrees/sessions/central-runtime` | the shared runtime owner: the environment's service entry with its holder record, its lease and its queue, bound by fingerprint and written only under an exclusive lease | yes |
| `@workspaces/ports/<project>` | the port projection of the project sharing this machine, read only to see whether a declared public port is one a product route already owns | no |
| `@workspaces/device-state` | the credential the declared command needs, by name and with its custody; values never appear | no |

## Inputs

| Kind | From | Required |
| --- | --- | --- |
| — | the services are enumerated by the environment's declaration, so this operator consumes no earlier branch | no |

## Requirements

| Field | Type | Default | Ask |
| --- | --- | --- | --- |
| `service` | id | — | The `id` of the one service, as the environment declaration names it under `services` |
| `env` | id | dev | The environment whose declaration names the service and whose entry records it |
| `desired` | choice | up | `up` runs the declared command up, `down` runs it down, `attested` changes nothing and reports what the probe finds |
| `approval` | id | — | The authority that covers this service and this state: an approval id, or the environment declaration's reference — its path and content hash — when that declaration marks `service` `declared` for `env`; no default, because silence is not consent |
| `resume` | token | null | The blocked branch's token when re-entering after a stop |

## Steps

| # | Step | Params | Reads | Writes | Stops with |
| --- | --- | --- | --- | --- | --- |
| 1 | Validate the gate and the resume against the frozen service entry | `resume` | `request/request.json`, @worktrees/sessions/central-runtime at the frozen fingerprint | — | `INVALID_INPUT`, `NO_PROGRESS` |
| 2 | Bind the one service the environment declares: its kind, its declared command, its probe, its holder and its public port | `service`, `env` | the environment's declaration of `env`, @worktrees/sessions/central-runtime for the service entry | — | `INVALID_INPUT` |
| 3 | Bind the authority for the `service` class and for this service's own holder, resolving the command's credential by name | `approval` | the environment's declaration re-read and re-hashed, @workspaces/device-state for the credential by name, @tools/secrets | — | `SERVICE_APPROVAL_REQUIRED` |
| 4 | Read the port projection and record a declared public port a product route already owns as a finding, never as a port to move | — | @workspaces/ports/<project>, @tools/shell for the socket table | — | — |
| 5 | Inspect the declared probe, process or container holder and configuration, classifying the service reusable, missing, invalid or uncertain before any command | — | @tools/http, @tools/shell, @worktrees/sessions/central-runtime | — | — |
| 6 | Reuse matching service state, create or start a missing service, update only invalid declared mutable resources, and change nothing on uncertain or foreign ownership | `desired` | @tools/shell, @tools/container, @worktrees/sessions/central-runtime for the lease and the queue | @worktrees/sessions/central-runtime | — |
| 7 | Prove the observed state from the declared probe alone: an `up` answers it, a `down` leaves its port free, and the pid that answers is recorded | — | @tools/http, @tools/shell | @worktrees/sessions/central-runtime | `SERVICE_UNPROVEN` |
| 8 | Release the lease, write the receipt and emit | — | everything above | `service-receipt`, `response/response.json` | — |

Steps 2, 3 and 7 are the only steps that stop. A resume begins again at step 1, re-reads the
declaration and the entry, and proves the state again from the probe; a re-entry that brings no
change to the service, the declaration or the authority is `NO_PROGRESS`.

## Outputs

| Kind | File | Type | Required |
| --- | --- | --- | --- |
| `service-receipt` | `response/response.md` | md | yes |

## Operator Result

Print **Operator Result** as the requested and observed service states with the proving probe in `response/response.md`. An approval stop or failed probe shows the unchanged service and its owner rather than claiming the service was moved.

## Stops

| Code | Disposition |
| --- | --- |
| `INVALID_INPUT` | terminate |
| `NO_PROGRESS` | terminate |
| `SERVICE_APPROVAL_REQUIRED` | terminate |
| `SERVICE_UNPROVEN` | terminate |

## Next

| When | Operator |
| --- | --- |
| the code-quality service is up and the gates that post to it may run | `quality.verify` |
| the tunnel is up and the walk that reaches the product through it may run | `uat.verify` |
| a service moved and the readiness of the machine is read again with it | `environment.preflight` |
| the environment keeps this service with a person, or the person asked for nothing beyond the receipt | `user` |
