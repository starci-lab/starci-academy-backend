# workflow.verify

## Job

Verify one coordinator's frozen peer portfolio from the original terminal solo session receipts and
evidence, independently proving every child goal and pinning every delivered repository boundary,
without changing any peer session, worktree, source or ledger.

## Done when

Done when the `workflow-verification-report` maps every frozen coordinator done-when line to its assigned peer, proves each peer completed every line of the exact frozen child goal, binds each routed repository's full delivered head to accepted delivery evidence and its exact current Git HEAD, keeps earlier source-bound goal evidence only when its revision is an ancestor in that same repository, and preserves rereadable state and branch fingerprints for every claim.

## Messages locate proof, never become proof

The coordinator may use ordinary two-way task messages to assign work, receive a session id, report
status, return feedback and choose when to look again. Those messages are transport only: they grant
nothing, route no operator step and prove no outcome. Before this operator runs, the coordinator
freezes the received identities and exact child mission goals in `request/peers.json`; this operator reads that file and the
original peer evidence, and imports no peer receipt.

The coordinator does not impersonate this operator's bound profile. The orchestrator dispatches one
isolated `sol-reviewer` worker, with no inherited task transcript, inside the coordinator's existing
StarCi session. That worker opens no native task or user workflow: its request, attempt, receipt,
lease and worker slot remain in the coordinator's same chain, ledger and shared slot budget. The
coordinator still owns decomposition, messages, waiting, feedback and the final portfolio conclusion;
the isolated worker owns only this read-only verification attempt and records the profile that really
ran it.

Before dispatch, the caller must expand the frozen peer inventory into the request's Context list.
For every peer it names at least one concrete original evidence alias —
`@worktrees/sessions/<sessionId>` while live, `@worktrees/done/<sessionId>` after close-success, or
both through normal retention — with the same session id found in `request/peers.json`. Only those
explicitly bound locations may be read. A bare sessions or done root, a sibling scan, an alias not
present in the frozen inventory, and discovery from message prose are all forbidden.

Each peer remains the sole owner of its own solo workflow, session ledger and worktree. A peer counts
only when its original session is terminally successful, has no unfinished attempt, blocker, worker
or lease, has the same mission goal frozen for it, and passes the session and response gates from its
own bytes. For a version 2 snapshot, every original done-when line is proved independently. A
source-bound proof must resolve in the repository named by its routed workspace alias and be an
ancestor of that repository's delivered head. Each delivered head must also have the snapshot's
named original child done-when evidence accepted at that exact revision, resolve as a commit in that
same repository, and equal the proving worktree's current HEAD. Version 1 keeps the original
single-head equality law and host-bound worktree fallback for already frozen one-repository peers.
A context head mention alone never binds a peer. Version 2 may resolve a context-only binding only
from validator-accepted proof that unambiguously maps that alias to one Git repository. A live
session is read where it stands; an
explicitly closed session is read only after its retained bundle passes the normal retention check.

The coordinated topology's `ancestralEvidenceOperators` is the one closed exception list. For every
other original done-when producer, every routed workspace alias in its accepted proof is a required
exact-head obligation. `deliveryDoneWhen` records that derived obligation; it cannot omit or weaken
one. An accepted proof carrying both frontend and backend contexts therefore binds both boundaries,
even when the two repositories happen to contain a commit with the same object id. One accepted
proving row must simultaneously match every routed repository head for that done-when; rows from
different runs cannot be combined into a repository-head tuple that was never observed.

Missing, changing or rejected peer evidence produces no partial report. The coordinated session may
keep waiting, send feedback to the owning peer, and enter a new local verifier attempt under the same
authorized goal when evidence changes; this operator never edits the peer to manufacture that delta.

## Context

| Alias | Bind | Required |
| --- | --- | --- |
| `@worktrees/sessions/<sessionId>` | a concrete original live peer session whose session id is frozen in `request/peers.json`; only the explicitly bound location may be read, never the sessions root or a discovered sibling | no |
| `@worktrees/done/<sessionId>` | a concrete peer named by the frozen inventory after explicit close-success, read only at its explicitly bound location through its verified retention manifest and retained bundle; it may be bound beside the live alias during normal retention, never as the done root | no |

## Inputs

| Kind | From | Required |
| --- | --- | --- |
| `—` | this operator consumes no typed producer output; peer outcomes stay in their original sessions and ordinary task messages are never imported | no |

## Requirements

| Field | Type | Default | Ask |
| --- | --- | --- | --- |
| `peers` | file | — | The orchestrator supplies exactly `request/peers.json`, a digest-frozen snapshot whose sole shape is `templates/kinds/workflow-peers.schema.json` |

## Steps

| # | Step | Params | Reads | Writes | Stops with |
| --- | --- | --- | --- | --- | --- |
| 1 | Gate the coordinated request and its immutable peer inventory, requiring the snapshot task set, owned scopes and legacy head or repository head set to equal `brief.peers`, freezing each exact child mission goal, covering every coordinator done-when produced by this operator, and binding at least one concrete live or done Context alias per frozen peer; both may be bound and only explicit locations may be read | `peers` | `request/request.json`, `request/peers.json`, coordinator `state.json` | — | `INVALID_INPUT` |
| 2 | Resolve each distinct peer session live or from a verified close-success bundle, then validate its exact frozen goal, solo topology, terminal local state, every original goal ledger entry, accepted responses and evidence manifests; for version 2, resolve source-bound proof only within its routed repository ancestry and require the named delivery evidence at each exact current repository HEAD; version 1 keeps its single-head equality check | — | @worktrees/sessions/<sessionId>, @worktrees/done/<sessionId>, @tools/git | — | `EVIDENCE_MISSING` |
| 3 | Reread the frozen snapshot and peer bytes, bind their hashes, and emit the exact peer-to-done-when map, one indexed original proof per child goal, and one exact delivered-head proof per repository boundary | — | `request/peers.json`, the validated peer state and proving branches above | `workflow-verification-report`, `response/response.json` | `EVIDENCE_MISSING` |

## Outputs

| Kind | File | Type | Required |
| --- | --- | --- | --- |
| `workflow-verification-report` | `response/data/workflow-verification-report.json` | data | yes |

## Operator Result

On `done`, `response/data/workflow-verification-report.json` is the whole portfolio proof: its peer
set, exact child goals, ownership and repository heads equal the frozen coordinator snapshot; every coordinator done-when line is
owned; and every peer row names the original solo session state hash, each original goal proof, plus exact delivered-head evidence
fingerprints. It contains no message transcript, copied receipt, inferred success or partial verdict.

## Stops

| Code | Disposition |
| --- | --- |
| `INVALID_INPUT` | terminate |
| `EVIDENCE_MISSING` | terminate |

## Next

| When | Operator |
| --- | --- |
| the frozen portfolio is verified and the coordinator may conclude from the local matched receipt | `user` |

For an active coordinated assignment, the version 2 peer inventory also freezes its assignment and exact original source incorporation, consumer regression and combined verification selectors. The verifier reads those original current accepted records under the explicit session contexts. Each consumer regression follows incorporation at the affected repository head; a separate accepted quality, API or UAT verification freezes a mandatory integrated criterion and the actual head tuple containing every producer and consumer contribution. Unrelated repository boundaries retain the normal peer proof requirements. The executable owner of these checks and automatic dependency readiness is scripts/workflow-coordination.mjs, under resources/orchestrator.json#workflowTopologies.coordination.

The report retains each source consumer's sealed incorporation intent and actual merge receipt. Combined proof additionally joins actual API and browser endpoint records to two accepted runtime observations per role, bracketing each verifier. Those observations measure the serving checkout and process; pinned source contexts cannot substitute for served heads. A BE-only extraction still requires the consumers' delivered FE contributions in the combined runtime when their original missions include FE, without inventing an FE source application for the BE producer. The authoritative selectors are the existing request integration and peer/report schemas; `scripts/workflow-runtime-proof.mjs` verifies their measured joins.
