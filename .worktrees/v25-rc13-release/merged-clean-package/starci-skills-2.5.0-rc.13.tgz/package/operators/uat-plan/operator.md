# uat.plan

## Job

Enumerate the user journeys the mission goal names, one flow per journey with its entry route, its
step budget, its declared account and fixture prerequisites, so that the blind walkers that follow
each walk one flow and no two of them ever share a row.

## Done when

Done when the `uat-plan` names one flow per journey the goal names, each with its entry route, its
step budget, its declared account and fixture prerequisites and its tier, and the `units` file carries
one flow unit per Flows row with the same id and tier.

## The unit of a blind walker is one flow

A walker that starts with an empty context can hold one journey whole: where it enters, which
controls it presses in order, who it signs in as and what it must find seeded. It cannot hold a
mission's worth of journeys, and a mission handed to one walker becomes the run that seeds
everything, signs in as everybody and proves nothing about any of them. This operator is the only
place the goal is read for its journeys: every journey the goal names — an actor doing one thing
that ends in one observable state — becomes one Flows row and one `units` entry with the journey as
its goal line, and the two are one list. The Flows table carries what a walker needs before it
drafts anything: the route the journey enters at, its budget in steps, its account alias and its
seed namespace.

## Every flow owns its rows

Two walkers that share an account share a sign-in, and then each proves the other's session; two
walkers that share a seed namespace share a cleanup, and one run's rollback becomes the other's
failure. The plan therefore gives each authenticated flow its own account alias and each seeded flow its own namespace, disjoint
from every other flow of the plan, and the validator refuses a plan in which two rows carry the same
alias or the same namespace. A flow folder that already exists keeps the name, the aliases and the
namespace it has, because a record nobody can predict is a record nobody reads; the plan reuses it
and never renames it.

## A journey without an entry is not a flow

A journey the goal names that starts nowhere the surface map or an existing flow shows is
`FLOW_UNDEFINED`. The stop is this operator's own and routes to itself: the same plan runs again
with a surface map that names the entry, or with the entry route named in the goal. It is never the
caller's defect and never becomes `INVALID_INPUT`, because a goal is allowed to name a journey in a
person's words and it is this operator that turns words into an entry route.

## The journey is walked, and everything else is unchecked

The goal names journeys; the mission's "done when" lines name which of them this run has to prove.
Those flows are `journey` and the walker is dispatched over them. A flow the plan names because the
feature has it, but no done-when line reaches, is `secondary`: it carries one sentence saying why, and
is written down as unchecked in the walk lane under `@worktrees/unchecked` rather than walked — so a
run that proves three journeys out of seven says which four it did not, instead of leaving the reader
to assume it proved everything. A flow the feature already carries an open walk entry on is taken back
into the journey by this plan, which covers it when the walk runs, or extended by a secondary row with a
reason of this plan's own; a plan that drops it from the list defers it again with nobody's agreement,
and is refused.

## Concrete attempt flow

This operator's rows are gated by the shared expected/actual attempt contract in `scripts/attempt-gate.mjs`.

| Observed state | Action | Actual check | Next branch |
| --- | --- | --- | --- |
| flow and case sheet still match journey, route and env | reuse stable ids, aliases and namespace | validate table and machine JSON against goal and route | emit reused plan and sheet |
| missing | create one flow per journey and cases before execution | each case has actor, precondition, input, UI actions, assertions, expected, verification, JSON, optional SQL and cleanup | emit plan, sheet and units |
| stale or invalid | update affected case/alias/fixture refs; keep history | rerun route, actor, assertion, namespace and fixture checks | repair attempt; undefined route owner handoff |
| fixture creates asserted outcome | reject fixture | name conflicting precondition/assertion | handoff `data.plan` |

## Boundary

Context is read-only. The operator writes only `response/` of its own branch: the plan, the unit list
and `response.json`. It drafts no flow document, seeds nothing, provisions no account, signs in
nowhere, opens no browser and walks nothing; the walk belongs to the operator that receives one flow.
It names credentials by alias only and has no field that could hold one.

## Journey prerequisites

The request and each machine flow freeze access, fixtures and sourceRoles; snapshot and verdict must preserve them. Defaults are authenticated, seeded and full. Anonymous drives a public surface in a fresh browser context, carries null walk account and case actor anonymous, and accepts no account or credential. None carries null case fixture and plan seed namespace, case cleanup none, no seed receipt, no seeded or rollback ids and no data.seed handoff. Run evidence still uses uat-<runId>. Frontend pins the frontend head and both actual admissions at that head, with no invented backend head. These modes are independent: an anonymous journey may need seeded data, and a no-fixture journey may need sign-in. Account, sign-in and seed procedures apply only when their respective prerequisites require them; every case, control, capture, runtime ancestry check, all three lanes and append-only history remain mandatory.

## Context

| Alias | Bind | Required |
| --- | --- | --- |
| `@worktrees/_templates` | the UAT flow template the tree ships: the shape a flow folder takes, its cases, the aliases they act as and its seed, so every planned flow is one a walker can draft | yes |
| `@worktrees/uat/<flow>` | the flow folders that already exist under the feature: a flow that exists keeps its name, its account aliases and its seed namespace | no |
| `@worktrees/unchecked/<product>` | the unchecked coverage this feature already carries in the walk lane: every flow an earlier mission deferred, so this plan covers it or extends it rather than deferring it again in silence | no |

## Inputs

| Kind | From | Required |
| --- | --- | --- |
| `surface-map` | `interface.plan`; the pages and modals the journeys cross, with the routes they enter at, when the mission built a surface | no |

## Requirements

| Field | Type | Default | Ask |
| --- | --- | --- | --- |
| `goal` | text | — | The mission goal in the person's words; every journey it names becomes one flow |
| `feature` | id | — | The feature key that addresses the flow directories and titles the plan |
| `env` | id | dev | The environment whose flow folders, accounts and seed the flows are planned for |
| `access` | enum:authenticated,anonymous | authenticated | Access frozen by the plan; anonymous uses a fresh unauthenticated browser and no credential. |
| `fixtures` | enum:seeded,none | seeded | Fixture prerequisites frozen by the plan; none carries no seed input or database cleanup. |
| `sourceRoles` | enum:full,frontend | full | Source dependencies exercised by the journey; frontend pins only frontend delivery. |
| `resume` | token | null | The blocked branch's token when re-entering after a stop |

## Steps

| # | Step | Params | Reads | Writes | Stops with |
| --- | --- | --- | --- | --- | --- |
| 1 | Validate the gate and resume | `resume`, `access`, `fixtures`, `sourceRoles` | `request/request.json`, the blocked plan when resuming | — | `INVALID_INPUT`, `NO_PROGRESS` |
| 2 | Read the goal: every user journey it names, each as one sentence with the actor that walks it | `goal` | the goal the request carries | — | — |
| 3 | Read the surface map when bound: the entry route each journey starts at and the pages and modals it crosses | — | input `surface-map` | — | — |
| 4 | Inspect existing flow folders and machine case sheets, classifying stable flows and cases reusable, missing or invalid while preserving names, aliases, namespaces and history | `feature`, `env` | @worktrees/uat/<flow>, @worktrees/_templates for the shape a flow folder takes | — | — |
| 5 | Reuse, update or create one flow per journey and write its cases before execution: actor, precondition, input, ordered UI actions, assertions, expected result, verification, JSON fixture, optional SQL and cleanup | — | the journeys, the map, the existing flows | — | `FLOW_UNDEFINED` |
| 6 | Freeze each flow’s access, fixtures and sourceRoles; give authenticated flows distinct account aliases and seeded flows distinct namespaces, otherwise record the explicit absence | `env` | the flows, @worktrees/uat/<flow> for the aliases already provisioned | — | — |
| 7 | Tier every flow against the mission's done-when lines: `journey` where a line walks it, `secondary` with one sentence of reason where none does, and every open entry of this feature taken back or extended | — | the mission's done-when lines, the flows, @worktrees/unchecked/<product> | — | — |
| 8 | Write the unit list: one flow unit per Flows row with the same id and tier, the journey as its goal and its deferral reason where it has one | — | the plan | `units` | — |
| 9 | Emit the human plan, machine case sheet, matching units and receipt only after every case and fixture reference validates | — | everything above | `uat-plan`, `uat-case-sheet`, `response/data/cases.json`, `units`, `response/response.json` | — |

Step 5 is the only step that stops on the plan itself: a journey that step 2 found and no map or
folder gives an entry to is `FLOW_UNDEFINED`, with the reason naming it in one paragraph, and
nothing is emitted. A resume begins again at step 1 and reads the goal and the map again; a re-entry
whose plan names the same flows as the branch it resumes is `NO_PROGRESS`.

## Outputs

| Kind | File | Type | Required |
| --- | --- | --- | --- |
| `uat-plan` | `response/response.md` | md | yes |
| `uat-case-sheet` | `response/data/cases.json` | data | yes |
| `units` | `response/data/units.json` | data | yes |

## Operator Result

On `done`, print **Operator Result** as the flow and case table from `response/data/cases.json`, showing actor, entry, account alias, fixture reference and isolated namespace, with `response/data/units.json` and `response/response.md` as secondary plan evidence. Missing entries or fixtures remain explicit unchecked rows and are never presented as runnable cases.

## Stops

| Code | Disposition |
| --- | --- |
| `INVALID_INPUT` | terminate |
| `NO_PROGRESS` | terminate |
| `FLOW_UNDEFINED` | terminate |

## Next

| When | Operator |
| --- | --- |
| every flow has its entry, its account alias and its namespace: each flow is walked on its own branch carrying its unit id | `uat.verify` |
| every case has frozen preconditions and fixture references that must become one executable seed unit per flow | `data.plan` |
| a journey the goal names is one the person may not want walked, so the person says whether it belongs to the mission | `user` |
| the case sheet is frozen and the planned frontend journey still needs its implementation | `interface.generate` |
