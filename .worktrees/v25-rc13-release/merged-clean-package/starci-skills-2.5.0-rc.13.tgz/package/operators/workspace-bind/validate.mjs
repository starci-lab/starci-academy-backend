// workspace.bind's own law over one branch, on top of the shared step check: the receipt and the route
// name the same checkout and head; a source checkout carries no directory and a sibling one
// does; the hydrated route belongs to this Source and to the requested project and role; the observed
// checkout is the one the route resolved to; mutation is ready only on the mutation branch and a
// forbidden worktree policy binds nowhere else; the businesses root is derived from the checkout, never
// typed; the route binds no runtime, because the runtime owner serves and binds the entry a caller
// consumes; no hint survives the gate; and a blocked branch records no hydration.
import { existsSync } from 'node:fs';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';
import { validateStep } from '../../scripts/validate-step.mjs';
import { tableUnder } from '../../scripts/validate-response.mjs';
import { validateWorkspaceCheckoutBinding, gitPolicyErrors, installedTreeOf } from '../../scripts/workspace-checkout.mjs';
import { sealedWorkspaceBindingErrors } from '../../scripts/validate-request.mjs';
import { currentRequestPhase } from '../../scripts/validation-phase.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const empty = (v) => v === undefined || v === null || v === '' || v === '—';
const fields = (rows) => Object.fromEntries((rows ?? []).map(([k, v]) => [k, v]));
// Route paths arrive from two files written on different machines, so they are compared as normalised
// strings: separator style and a trailing slash are notation, not identity.
const comparablePath = (value) => String(value).replaceAll('\\', '/').replace(/\/+$/, '').toLowerCase();

export async function validateWorkspaceStep(branchDir, root = ROOT) {
  const base = await validateStep(root, branchDir);
  const errors = [...base.errors];
  const { response, requirements = {}, present = new Set() } = base;
  if (!response || response.operatorId !== 'workspace.bind') return { errors };
  const has = (f) => existsSync(path.join(branchDir, f));
  const read = (f) => readFile(path.join(branchDir, f), 'utf8');

  let route = null;
  if (present.has('route') && has('response/data/route.json')) {
    try { route = JSON.parse(await read('response/data/route.json')); } catch { route = null; }
  }
  if (response.status === 'blocked' && route !== null) {
    errors.push('response/response.json: a blocked branch cannot carry a route');
  }

  if (route) {
    let sealed = null;
    if (currentRequestPhase() === 'accept') {
      const session = path.resolve(branchDir, '../..');
      try { sealed = await sealedWorkspaceBindingErrors(session, JSON.parse(await readFile(path.join(session, 'state.json'), 'utf8')), base.request); }
      catch (error) { sealed = [error.message]; }
    }
    errors.push(...(sealed ?? validateWorkspaceCheckoutBinding(root, base.request, route, branchDir)));
    const { checkout, gitPolicy, mutationReadiness, runtime } = route;
    if (!empty(requirements.project) && route.project !== requirements.project) errors.push(`response/data/route.json: project ${route.project} differs from the request's ${requirements.project}`);
    if (!empty(requirements.role) && route.role !== requirements.role) errors.push(`response/data/route.json: role ${route.role} differs from the request's ${requirements.role}`);
    if (checkout.sourceHead !== route.sourceHead) errors.push('response/data/route.json: the binding and the routed checkout must name the same source head');
    if (comparablePath(checkout.diskPath) !== comparablePath(checkout.gitRoot)) errors.push('response/data/route.json: the checkout disk path and Git root must be the same checkout');
    if (checkout.repositoryKind === 'source' && checkout.directory !== null) errors.push('response/data/route.json: a source checkout must report a null directory');
    if (checkout.repositoryKind === 'sibling' && checkout.directory === null) errors.push('response/data/route.json: a sibling checkout must report its relative directory');

    // The businesses root is derived from the checkout, never typed by a caller: on a source checkout it
    // is <gitRoot>/.worktrees/businesses when that worktree exists, otherwise null; a sibling checkout
    // carries no business authority. business.decide copies this value.
    const derivedBusinesses = `${String(checkout.gitRoot).replace(/[\\/]+$/, '')}/.worktrees/businesses`;
    const { businesses } = route.authorityRoots;
    if (checkout.repositoryKind === 'sibling' && businesses !== null) errors.push('response/data/route.json: a sibling checkout carries no business authority root');
    if (businesses !== null && businesses !== derivedBusinesses) errors.push(`response/data/route.json: authorityRoots.businesses must be derived from the checkout as ${derivedBusinesses}`);

    // The request's policy is the declared route's, in the declared shape (scripts/workspace-checkout.mjs#gitPolicyErrors).
    // Mutation is ready only on the declared mutation branch. Reporting readiness anywhere else is how a
    // task branch acquires permission it was never routed.
    errors.push(...gitPolicyErrors(requirements.gitPolicy, gitPolicy));
    const declaredRoots = Array.isArray(requirements.declaredWriteRoots) ? requirements.declaredWriteRoots : [];
    for (const root of declaredRoots) if (!route.writeRoots.includes(root)) errors.push(`response/data/route.json: the request declared the write root ${root}, which the binding does not carry`);
    const sessionBranch = gitPolicy.worktreeBranches === 'session-only' && /^session\/[A-Za-z0-9._-]+$/.test(checkout.branch);
    if (mutationReadiness === 'ready' && checkout.branch !== gitPolicy.mutationBranch && !sessionBranch) errors.push(`response/data/route.json: mutation is ready only on ${gitPolicy.mutationBranch} or a declared session branch, not on ${checkout.branch}`);
    if (gitPolicy.worktreeBranches === 'session-only' && checkout.branch !== gitPolicy.mutationBranch && !/^session\//.test(checkout.branch)) errors.push(`response/data/route.json: a session-only worktree policy binds only on ${gitPolicy.mutationBranch} or on a session/<sessionId> branch, not on ${checkout.branch}`);
    if (gitPolicy.worktreeBranches === 'forbidden' && checkout.branch !== gitPolicy.mutationBranch) errors.push('response/data/route.json: a forbidden worktree policy cannot bind a route on another branch');

    // The route binds no runtime: the runtime owner serves and binds the entry a caller consumes, so a
    // receipt that carries one has consumed a shared resource on its own initiative.
    if (runtime !== null && runtime !== undefined) errors.push('response/data/route.json: the route carries a runtime binding; workspace.bind binds a checkout and a head, and the runtime owner binds the entry a caller consumes');
  }

  if (present.has('workspace-route-binding') && has('response/response.md')) {
    const text = await read('response/response.md');
    const binding = fields(tableUnder(text, '## Binding'));
    const checkout = fields(tableUnder(text, '## Checkout'));
    const policy = fields(tableUnder(text, '## Policy'));
    const runtimeRows = fields(tableUnder(text, '## Runtime'));
    const writeRoots = (tableUnder(text, '## Write roots') ?? []).map(([p]) => p);

    const findingKeys = new Set();
    for (const [code, subject] of tableUnder(text, '## Findings') ?? []) {
      const key = `${code}|${subject}`;
      if (findingKeys.has(key)) errors.push(`response/response.md: finding ${code} repeats subject ${subject}`);
      findingKeys.add(key);
    }

    if (route) {
      if (binding.Project !== route.project) errors.push(`response/response.md: Project ${binding.Project} differs from the route binding's ${route.project}`);
      if (binding.Role !== route.role) errors.push(`response/response.md: Role ${binding.Role} differs from the route binding's ${route.role}`);
      if (binding['Source head'] !== route.sourceHead) errors.push('response/response.md: Source head differs from the route binding');
      if (binding['Hydrated route'] !== route.hydratedRouteRef) errors.push('response/response.md: Hydrated route differs from the route binding');
      if (checkout.Branch !== route.checkout.branch) errors.push(`response/response.md: Branch ${checkout.Branch} differs from the route binding's ${route.checkout.branch}`);
      for (const [label, key] of [['Disk path', 'diskPath'], ['Git root', 'gitRoot'], ['Git repository', 'gitRepository'], ['Source head', 'sourceHead']]) {
        if (checkout[label] !== route.checkout[key]) errors.push(`response/response.md: ${label} differs from the selected checkout`);
      }
      if (checkout['Mutation readiness'] !== route.mutationReadiness) errors.push('response/response.md: Mutation readiness differs from the route binding');
      if (checkout['Repository kind'] !== route.checkout.repositoryKind) errors.push('response/response.md: Repository kind differs from the route binding');
      const businesses = route.authorityRoots.businesses;
      if ((empty(checkout['Businesses root']) ? null : checkout['Businesses root']) !== businesses) errors.push(`response/response.md: Businesses root ${checkout['Businesses root']} differs from the derived ${String(businesses)}`);

      // The installed tree is part of what a checkout is. `node_modules` is routinely a junction onto one
      // installed tree several checkouts share, and a recursive delete inside such a checkout travels
      // through the link and empties the tree every other checkout is using; a reader who is told the
      // link is there before they reach for one is the only thing that stops it. The label is observed,
      // never asserted, and a shared tree is bound only where the request declared it on purpose.
      const installed = checkout['Installed tree'];
      if (empty(installed)) errors.push('response/response.md: the Checkout table records no Installed tree; a binding says whether node_modules is a junction and to where, because nothing under a checkout that holds one is ever deleted by hand');
      else {
        const observed = existsSync(route.checkout.diskPath) ? installedTreeOf(route.checkout.diskPath) : null;
        if (observed && installed !== observed.label) errors.push(`response/response.md: Installed tree ${installed} differs from the observed ${observed.label}`);
        const target = /^junction to (.+)$/.exec(installed)?.[1] ?? null;
        const shared = target !== null && target !== 'an unresolvable target' && comparablePath(target) !== comparablePath(route.checkout.diskPath) && !comparablePath(target).startsWith(`${comparablePath(route.checkout.diskPath)}/`);
        if (shared && requirements.sharedInstall !== true && String(requirements.sharedInstall) !== 'true') errors.push(`response/response.md: Installed tree is a junction to ${target}, outside the checkout; a binding takes a shared installed tree only when the request declares sharedInstall: true`);
      }
      if (policy['Worktree branches'] !== route.gitPolicy.worktreeBranches) errors.push('response/response.md: Worktree branches differs from the route binding');
      if (policy['Mutation branch'] !== route.gitPolicy.mutationBranch) errors.push('response/response.md: Mutation branch differs from the route binding');
      if (writeRoots.length !== route.writeRoots.length || writeRoots.some((p) => !route.writeRoots.includes(p))) errors.push('response/response.md: Write roots differ from the route binding');

      // The portable-to-hydrated resolution is the whole authority of this receipt, so it is stated
      // rather than assumed.
      if (!findingKeys.has(`ROUTE_HYDRATED_FROM_PORTABLE|${route.hydratedRouteRef}`)) errors.push('response/response.md: a bound route must record the hydrated route it resolved from');
      if (route.gitPolicy.worktreeBranches === 'forbidden' && !findingKeys.has(`WORKTREE_BRANCH_FORBIDDEN|${route.gitPolicy.mutationBranch}`)) errors.push('response/response.md: a forbidden worktree policy must be recorded on the bound route');
      if (route.gitPolicy.worktreeBranches === 'session-only' && !findingKeys.has(`WORKTREE_BRANCH_SESSION_ONLY|${route.gitPolicy.mutationBranch}`)) errors.push('response/response.md: a session-only worktree policy must be recorded on the bound route');
      if (route.provenanceHeadRef !== null && !findingKeys.has(`PROVENANCE_HEAD_BOUND|${route.provenanceHeadRef}`)) errors.push('response/response.md: a bound provenance head must be recorded');
      if (Object.keys(runtimeRows).length) errors.push('response/response.md: the Runtime section carries rows; the route binds no runtime');
      for (const key of findingKeys) if (key.startsWith('RUNTIME_')) errors.push(`response/response.md: finding ${key.split('|')[0]} records a runtime this route never bound`);
    }

    // Hints are refused at the gate, so no finding may record one as if it had been weighed.
    for (const key of findingKeys) if (key.startsWith('HINT_REJECTED|')) errors.push('response/response.md: a hint is INVALID_INPUT at the gate, so a bound receipt never records HINT_REJECTED');
    // Only the sealed roster reference is bound; no credential is read.
    if (![...findingKeys].some((key) => key.startsWith('IDENTITY_ROSTER_SEALED|'))) errors.push('response/response.md: a bound route must record that the credential roster was sealed and never read');
  } else if (response.status === 'done') {
    errors.push('response/response.md: a bound branch needs the route receipt');
  }
  return { errors };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const target = process.argv[2];
  if (!target) { process.stderr.write('usage: node validate.mjs <session>/step-N/parallel-M\n'); process.exit(2); }
  const { errors } = await validateWorkspaceStep(path.resolve(target));
  if (errors.length) { process.stderr.write(`${errors.join('\n')}\n`); process.exitCode = 1; } else process.stdout.write('valid workspace.bind branch\n');
}
