# generate-banks

## Job

Read what a product has already left behind — its routes, the coverage nobody took, the findings nobody answered, the walks and the API runs that failed, the feature models and the person's own notes — and draft a bank of missions the harness can take one after another, each with the goal block a session needs and at least one observation it came from.

## Done when

Done when the `bank-queue` orders one entry per mission the reading found, every entry has a `banked-mission` carrying its goal block, its routes, its environment and at least one evidence ref, and the `helper-run` names every input read with the head it was read at.

## A helper is not an operator

An operator does one job on one unit inside a session chain, under a goal a person confirmed. This runs before any of that: it opens no session, writes no product source, touches no runtime, publishes nothing and asks nothing. Its whole authority is reading, and its whole output is a proposal — a bank the person approves once, after which the harness can open mission after mission without anybody composing a prompt. Nothing here decides that a mission is right; the person's approval does that, and the plan of each mission is drawn when the mission opens, against heads read then rather than heads read here.

## A mission with no evidence is an idea

Every mission this drafts names at least one observation it was drafted from: an entry of the unchecked ledger, a finding, a walk or an API run, a source path in a bound route, or a reference to something the person wrote. A draft that cannot name one is refused with `BANK_UNGROUNDED` rather than banked with a plausible reason, because a bank of plausible missions is worse than an empty one: the person approves it once and the harness runs it all.

## What the reading carries forward, and what it does not

The unchecked ledger says what an earlier mission deliberately did not prove, and with what reason. A mission drafted from an open entry carries that entry's tier as a hint, so a reader can tell a mission that closes a journey gap from one that closes a deferral. It stays a hint: the tier itself belongs to the plan of the mission, which reads it against a done-when journey that does not exist yet at banking time.

## Boundary

Everything the Reads table names is read-only. The only places written are the two the Writes table names, which are the two `alias/alias.json` marks writable by the support layer. No checkout, no runtime owner, no registry, no session folder and no ledger the operators own is touched, and there is no field here that could hold a credential.

## Concrete run flow

The invocation reuses the host session binding already established by StarCi and records it in
`helper-run`; it does not open an operator session. Before reading evidence it records the requested
product, routes, evidence classes and limit as the expected coverage. The run record is written for
every terminal outcome, including `BANK_EMPTY`, invalid optional sources and a no-change rerun.

| Observed bank/evidence state | Action | Actual check |
| --- | --- | --- |
| An existing mission still has the same evidence, goal and dependencies | reuse its stable mission id and content | the emitted queue points to the same mission bytes and retains its status |
| New evidence belongs to an existing mission | update that draft by joining the evidence refs and recomputing dependencies | one mission names all contributing observations; no duplicate mission describes the same owner outcome |
| A grounded thread has no mission | create one draft with the confirmed route and evidence refs | schema, route, dependency and grounding checks pass |
| An optional source is missing, stale, unreadable or invalid | record that source state and continue with the valid sources | the run outcome is incomplete and never claims that evidence class was checked |
| A queue has approval or a `running`/`done` status | preserve approval bytes and every non-draft status; never rewrite them as banked | before/after summaries prove the preserved authority and progress |
| No grounded thread remains | write no queue or mission change, but write the run record with outcome empty | the record lists what was read and why no mission was emitted |

A retry is a new run id and never overwrites an earlier run. It may replace an invalid draft only
after recording the changed evidence; changing queue composition invalidates approval through
`scripts/bank.mjs`, while a no-change reuse preserves it.

## Reads

| Alias | Bind | Required |
| --- | --- | --- |
| `@workspaces/projects` | the product's route declarations: which roles it has and what each one is, so a drafted mission names routes that exist | yes |
| `@workspaces/ports` | the port projection of the product, so a mission that needs a served runtime names the slot it would run on | no |
| `@workspaces/<project>/<role>` | the product's routed checkouts, read only and at their observed head: what a `source:` evidence ref points at, and what tells a promise already delivered from one still owed | no |
| `@worktrees/unchecked/<product>` | the coverage earlier missions deliberately did not take, each with its lane, its unit and its reason: the first source of a mission nobody has run yet | no |
| `@knowledge/findings` | the findings audits and walks recorded and nobody has answered, per family | no |
| `@worktrees/uat/<flow>` | the walks this product has run and what they failed on | no |
| `@worktrees/e2e/<flow>` | the API runs this product has run and which cases they failed | no |
| `@worktrees/businesses` | the feature models and the promises they publish, so a drafted mission is about a promise and not about a file | no |
| `@worktrees/banked/<product>` | the existing queue, missions, approval bytes and statuses used for reuse, update and duplicate checks | no |

## Writes

| Alias | What |
| --- | --- |
| `@worktrees/banked/<product>` | the queue of the product's bank and one folder per mission it drafts, each with the mission a person reads beside the one the harness reads |
| `@worktrees/helpers/<id>` | the run record of this reading: what was read at which head, what was written, and between which instants |

## Requirements

| Field | Type | Default | Ask |
| --- | --- | --- | --- |
| `product` | id | — | The product whose ledgers, evidence and routes are read and whose bank is drafted |
| `env` | id | dev | The environment whose declaration the drafted missions name |
| `language` | tag | settings | The language the goal blocks and the mission documents are written in; the display language unless the invocation names another |
| `limit` | count | 12 | The most missions one bank may carry; a reading that finds more banks the most grounded and says what it left |
| `notes` | ref | null | A reference to what the person wrote that this bank should answer; it becomes a `note:` evidence ref |
| `runId` | token | — | The run id of this invocation, which the run record and every mission it drafts name |

## Steps

| # | Step | Params | Reads | Writes | Stops with |
| --- | --- | --- | --- | --- | --- |
| 1 | Validate the invocation and bind this helper run to the existing Codex or Claude host session; never create a StarCi user session | `product`, `runId` | invocation and host binding | — | `INVALID_INPUT` |
| 2 | Read routes, ports and checkout heads, then inspect the existing queue, missions, approval bytes and statuses before deciding reuse, update or create | `product` | @workspaces/projects, @workspaces/ports, @workspaces/<project>/<role>, @worktrees/banked/<product>, @tools/git | — | `PRODUCT_UNROUTED` |
| 3 | Read and classify every unchecked-ledger source as valid, missing, invalid or stale, preserving evidence for the classification | `product` | @worktrees/unchecked/<product> | — | — |
| 4 | Read and classify the open findings of every family this product composes | — | @knowledge/findings | — | — |
| 5 | Read and classify the last UAT walk and API run of each e2e flow, including incomplete and failed attempts | — | @worktrees/uat/<flow>, @worktrees/e2e/<flow> | — | — |
| 6 | Read and classify the published feature models and the referenced person notes; optional absent sources make the run incomplete rather than silently empty | `notes` | @worktrees/businesses | — | — |
| 7 | Resolve duplicate open threads against the existing bank; reuse an unchanged mission, update only changed draft fields, or create one mission for a new thread | `product`, `env`, `language`, `limit` | classified sources and bank-before snapshot | `banked-mission` | `BANK_EMPTY` |
| 8 | Refuse drafts without evidence and record every merge as kept mission, merged mission ids and supporting refs | — | drafts and deduplication map | — | `BANK_UNGROUNDED` |
| 9 | Order the queue while preserving approval bytes and every running or done status; never reopen a terminal mission during refresh | — | bank-before and accepted drafts | `bank-queue` | — |
| 10 | Record every run, including empty and incomplete outcomes, source coverage, before/after hashes and entries, deduplications, outputs, profile, host binding and instants | `runId` | everything above | `helper-run` | — |

Step 7 reads the person's goal only through referenced product evidence. A run finding no open thread
does not write a queue or mission, but it still writes an `outcome: empty` helper-run record. A run
with a missing, invalid or stale source writes `outcome: incomplete` and never overwrites a valid bank.

## Outputs

| Kind | File | Type | Required |
| --- | --- | --- | --- |
| `bank-queue` | `@worktrees/banked/<product>/queue.json` | data | yes |
| `banked-mission` | `@worktrees/banked/<product>/<missionId>/mission.json` | data | yes |
| `helper-run` | `@worktrees/helpers/<id>/runs/<runId>/run.json` | data | yes |

## Operator Result

After every terminal helper run, print **Operator Result** as the reviewable queue change: link the preserved `bank-queue` and the affected `banked-mission` records for `drafted`, `updated` or `reused`; for `empty` or `incomplete`, link the `helper-run` record and show its source-coverage reason. This presentation never fabricates an operator receipt, never treats a proposal as approved, and keeps existing approval bytes and running or done statuses visible.

## Stops

| Code | Disposition |
| --- | --- |
| `INVALID_INPUT` | terminate |
| `PRODUCT_UNROUTED` | terminate |
| `BANK_EMPTY` | terminate |
| `BANK_UNGROUNDED` | terminate |
