# Alias

Mọi nơi một operator được đọc, theo alias, gom theo vùng. Sinh từ `alias/alias.json` (sổ cho máy) và mọi `operator.json` bởi `scripts/generate-alias-doc.mjs`; `--check` chạy trong `npm test`. Operator chỉ đọc những alias mà bảng Context trong `operator.md` của nó gọi tên; trang này là toàn bộ từ vựng mà các bảng đó lấy ra. Phân giải theo tiền tố đăng ký dài nhất, đuôi đường dẫn thu hẹp alias, đoạn trong ngoặc nhọn do lần gọi cung cấp.

## Workspaces — vùng làm việc

Vùng làm việc: các checkout đã route của project đang bind, và khai báo, route, port, danh tính để tìm ra chúng.

| Alias | Tham số | Trỏ tới | Bind | Ai ghi | Operator ràng | Mục đích |
| --- | --- | --- | --- | --- | --- | --- |
| `@workspaces` | `<project>`, `<role>` | `<checkout:project/role>  (any routed checkout named explicitly, for cross-project reads: @workspaces/other-project/fe)` | fingerprint + sourceHead (git rev-parse HEAD of the checkout) | — | — | A checkout of another project. The bound project's own are @workspaces/fe and @workspaces/be. |
| `@workspaces/be` | — | `<checkout:input.project.id/be>  (diskPath from <Source>/.workspaces/local/routes/<project>/be/config.json); friendly segments: /husky, /package, /gates (see segments)` | fingerprint + sourceHead (git rev-parse HEAD of the checkout) | `backend.generate` | — | The routed backend checkout of the bound project. |
| `@workspaces/device-state` | — | `<Source>/.workspaces/device-state.json  (sealed keys live in <Source>/.workspaces/local/credentials/*.key.enc and are bound by name, never read)` | fingerprint | — | — | Machine identity and the encrypted credential roster reference. |
| `@workspaces/fe` | — | `<checkout:input.project.id/fe>  (diskPath from <Source>/.workspaces/local/routes/<project>/fe/config.json); friendly segments: /husky, /package, /gates, /grammar (see segments)` | fingerprint + sourceHead (git rev-parse HEAD of the checkout) | `interface.generate`, `interface.fix`, `library.update` | — | The routed frontend checkout of the bound project. |
| `@workspaces/local/routes` | — | `<Source>/.workspaces/local/routes/<project>/<role>/config.json` | fingerprint | `workspace.bind` | — | Machine-local hydrated routes; project the declarations onto this disk. Ignored by Git. |
| `@workspaces/ports` | — | `<Source>/.workspaces/ports/<project>.json` | fingerprint | — | — | Port projection: project offset and application slots. Endpoints are derived, never typed. |
| `@workspaces/projects` | — | `<Source>/.workspaces/projects/<project>/<role>.json` | fingerprint | — | — | Portable route declarations, tracked. The only place a route is declared. |

## Grammar — gói

Gói Grammar như app đang resolve: sự thật duy nhất về việc component sở hữu gì.

| Alias | Tham số | Trỏ tới | Bind | Ai ghi | Operator ràng | Mục đích |
| --- | --- | --- | --- | --- | --- | --- |
| `@grammar` | `<family>` | `the Grammar package as the bound app resolves it (file:packages/grammar inside @workspaces/fe when vendored locally, or @remote/npm when published), narrowed to one family <family>: @grammar/core, @grammar/heritage, @grammar/offset-pop; @grammar/common is the shared layer every family imports` | package.json version + the resolved location's fingerprint (checkout head for file:, tarball integrity for npm) | — | — | The Grammar as it runs: Common renderers, props, owned relationships, data-contract claims, and the family's own CSS. The only fact about what a component owns. |

## Knowledge — luật

Luật chuẩn trong cây này: luật UI phổ quát (ui), khẩu vị của họ (grammars), quy ước code (patterns). Chỉ đọc; chủ mới sửa.

| Alias | Tham số | Trỏ tới | Bind | Ai ghi | Operator ràng | Mục đích |
| --- | --- | --- | --- | --- | --- | --- |
| `@knowledge/findings` | — | `<Source>/.claude/knowledge/findings/  (<family>.jsonl, one append-only line per finding; INDEX.md is the reading map)` | a finding binds by its id, whose newest line is its state | — | — | What audits and walks found and nobody has answered yet, per visual family: appended by scripts/record-findings.mjs after every done audit or walk, materialized beside a receipt as the findings kind, and read by the support layer to see what is still open across a product. |
| `@knowledge/grammars` | — | `<Source>/.claude/knowledge/grammars/<family>/  (DNA.md generated from the package; idioms.md and playbook.md are the owner's taste; family.md holds the visual DNA and the gap table)` | fingerprint per file; DNA.md additionally binds the package version and checkout head it was generated from | `knowledge.repair` | — | How the family composes: the owner's taste (idioms, playbook) and what exists (DNA). Never the Grammar itself; where a taste row disagrees with @grammar, @grammar is the fact and the row is the finding. Canonical changes are owned by knowledge.repair after evidence-backed applicability and ownership analysis; readers cannot override rules locally. |
| `@knowledge/patterns` | — | `<Source>/.claude/knowledge/patterns/  (fe/, be/)` | fingerprint per file; rule inventory = every `## PREFIX-n` heading in the folder | — | — | Code conventions counted from the two live sources; a rule cites two real paths. |
| `@knowledge/ui` | — | `<Source>/.claude/knowledge/ui/  (composition/, presentation/, proof/; a sub-path narrows: @knowledge/ui/presentation)` | fingerprint per canonical file; exhaustive manifest of published rule IDs (including nonnumeric IDs) and each Case, plus catalogs and bound calibration dependencies | `knowledge.repair` | — | Universal UI law: what a tree must contain, which value an app boundary takes, what is only true once rendered. Canonical changes are owned by knowledge.repair after evidence-backed applicability and ownership analysis; readers cannot override rules locally. |

## Worktrees — thẩm quyền và bằng chứng máy-cục-bộ

Thẩm quyền và bằng chứng máy-cục-bộ ngoài mọi checkout: head nghiệp vụ, UAT pair, nợ, phần chưa kiểm, kho nhiệm vụ, lần chạy helper, bằng chứng user-session, khuôn và runtime owner dùng chung.

| Alias | Tham số | Trỏ tới | Bind | Ai ghi | Operator ràng | Mục đích |
| --- | --- | --- | --- | --- | --- | --- |
| `@worktrees/_templates` | — | `<Source>/.worktrees/_templates/  (businesses/, debts/, sessions/); uat/ resolves to <Source>/.claude/templates/uat/` | fingerprint per file | — | — | Authority templates for new heads, debts, sessions, and UAT flows. The UAT flow template ships with the tree at templates/uat/ (README.md as the folder contract, flow.md, accounts.json.example, run.md, seed/), so a fresh install has one without provisioning a worktree, and a flow folder that does not exist yet is drafted from it. Consumed, never modified. |
| `@worktrees/banked` | `<product>` | `<Workflow>/.worktrees/banked/<product>/  (queue.json against templates/kinds/bank-queue.schema.json: the ordered entries with their status, dependsOn and priority; approvals.json against bank-approvals.schema.json: the person's approval of one queue hash; <missionId>/mission.json against banked-mission.schema.json and <missionId>/mission.md the person reads)` | the queue hash of queue.json; a mission binds by its missionId inside it | `generate-banks` | — | A bank of missions the harness can run one after another without the person composing a prompt each time: each entry carries the goal block a session needs and at least one evidence ref, and one approval of the whole queue counts as the goal-confirm of every mission it lists. |
| `@worktrees/businesses` | — | `<Workflow>/.worktrees/businesses/  (features/<featureId>/model.json; business-registry-v1.json is the head index; objects/sha256/ the content store)` | content address from business-registry-v1.json featureHeads.&lt;featureId&gt;.head, with authorityStatus | `business.decide`, `business.reconcile` | — | Business promise heads. Its own git worktree; a head binds by content address even before its commit lands. |
| `@worktrees/debts` | — | `<Workflow>/.worktrees/debts/  (be.md, fe.md, per-item files)` | fingerprint per file | — | — | Owner-approved quality debts. A debt without a live approval here is not a debt. |
| `@worktrees/done` | — | `<Workflow>/.worktrees/done/  (<sessionId>.md compact; <sessionId>/bundle/ retained state and branch request/response artifacts; retention.json hashes and import references)` | retention manifest and content hashes | — | — | Owned by scripts/session-cleanup.mjs close-success, never an operator write target. workflow.verify may read a peer bundle here only after its retention manifest verifies, and imports or changes nothing. Verify every retained reference before removing only the corresponding active session; keep central-runtime and user source worktrees. |
| `@worktrees/e2e` | — | `<Workflow>/.worktrees/e2e/<flow>/  (flow.md: the API journey, the suite files it runs, the served route and the namespace it walks on; runs/<runId>/ append-only, runId = <yyyymmdd-HHMMss>-<commit7>: result.json (the run record: every case the repository's own e2e runner reported with its status, assertion and evidence ref; the three lanes contract, data and lifecycle judged apart; the namespace and its cleanup), the runner's own output; latest.json names the newest run and history.md keeps one line per run). <case> narrows to one case` | fingerprint of cases.json and verdicts.json | `api.verify` | — | E2E evidence: what the served backend did as a client saw it, on seeded data, run by the repository's own suite; the backend's counterpart of @worktrees/uat, kept apart from it because a person's walk and a runner's cases are two kinds of proof with two readers |
| `@worktrees/helpers` | `<id>` | `<Workflow>/.worktrees/helpers/<id>/runs/<runId>/  (run.json against templates/kinds/helper-run.schema.json: the helper, its arguments, every input it read with the head it read at, every output it wrote, the instants it ran between and the profile it ran on)` | fingerprint of run.json; a run binds by its runId | `generate-banks` | — | The append-only support run record: every draft names the helper run that produced it. A v2.2 helper belongs to the existing user host session and uses helper-request plus acquire-helper to share its worker limit and resource leases; it opens no separate user session and produces a helper-run rather than an operator receipt. Standalone legacy run records remain readable. |
| `@worktrees/sessions` | — | `<Workflow>/.worktrees/sessions/<sessionId>/  (state.json; step-<N>/parallel-<M>/ branches, each with request/ and response/ — see @dynamic; central-runtime/ is the shared runtime owner registry outside any session)` | fingerprint per file read | `*` | — | The session container. workflow.verify alone may read an original peer session here, read only, to verify its terminal solo state and accepted evidence at the recorded head; every other operator reads its own session through @dynamic. |
| `@worktrees/sessions/central-runtime` | — | `<Source>/.worktrees/sessions/central-runtime/owner.json  (runtimes: one entry per <project>/<role> with its endpoints, head, generation, status, health evidence and identity declaration; generation-<n>-ready.json and logs/ beside it)` | fingerprint + generation | `identity.provision`, `data.seed`, `runtime.serve`, `service.operate` | — | The shared runtime owner, keyed per project route: each entry carries its own generation, status, endpoints, health evidence and identity provider. Callers consume the entry of their own route, never own it. |
| `@worktrees/uat` | — | `<Workflow>/.worktrees/uat/<flow>/  (flow.md: goal, role, preconditions, budget and the step table; accounts.<env>.json: one account per alias the steps act as, each a username, a role, a credential name, the sealed file and the registry entry, never a secret; seed/: README.md, records.json and fixtures/; snapshots/: the approved reference a person promotes, with its captures and data/after.json; runs/<runId>/ append-only, runId = <yyyymmdd-HHMMss>-<commit7>: snapshot.json, steps/<NN-slug>/, db/, diff/, verdicts.json, run.md; latest.json names the newest run and history.md keeps one line per run). <case> narrows to one case of the flow` | fingerprint of snapshot.json and result.json | `identity.provision`, `data.seed`, `runtime.serve`, `uat.verify` | — | UAT authority per flow: the flow document, its dedicated account, its seed, the approved reference, and the append-only history of every run with the commit it verified. A record that is absent is created by the runtime, never reported as missing. |
| `@worktrees/unchecked` | `<product>`, `<featureId>` | `<Workflow>/.worktrees/unchecked/<product>/<featureId>.jsonl  (append-only, one line per unchecked entry against templates/kinds/unchecked.schema.json). A sub-path narrows to one product or one feature: @worktrees/unchecked/<product>` | an entry binds by its id, whose newest line is its state | `interface.plan`, `uat.plan`, `interface.audit`, `uat.verify`, `api.verify` | — | Coverage a mission deliberately did not take, on record: a unit or a state the verification did not cover because the done-when journey does not pass through it, written by scripts/record-unchecked.mjs so that narrowing a run is visible to the next plan instead of silent. Read also by business.reconcile, which lists what is still unchecked beside the claims, and by release.deploy, which refuses production over an unchecked journey. |

## Remote — internet

Internet. Registry, git remote, kho image, run CI, object storage. Đọc qua mạng; bind bằng version, digest hay head quan sát được.

| Alias | Tham số | Trỏ tới | Bind | Ai ghi | Operator ràng | Mục đích |
| --- | --- | --- | --- | --- | --- | --- |
| `@remote/ghcr` | `<image>` | `ghcr.io/<image>@<digest>` | digest | `release.deploy` | — | Immutable release images. A tag is never a binding; a digest is. |
| `@remote/git` | `<project>`, `<role>` | `the origin URL in @workspaces/local/routes/<project>/<role> (repository.gitRepository)` | observed remote head (git ls-remote) at invocation time | `git.publish` | — | The publication target; fast-forwardness is decided against this observation. |
| `@remote/github-actions` | `<runId>` | `GitHub Actions run <runId> of the routed repository` | run id + conclusion | — | — | CI evidence of a build or rollout, read only. |
| `@remote/minio` | `<contentId>`, `<locale>` | `MinIO object contents/<contentId>/<locale>.json through the routed runtime` | fingerprint of the fetched object | `content.generate` | — | Authored lesson content as served, not as drafted. |
| `@remote/npm` | `<package>` | `the npm registry entry for <package>, e.g. @remote/npm/@scope/package@1.0.0` | version + tarball integrity | — | — | Published packages. A version is the binding; latest never is. |

## Dynamic — sinh trong phiên

Sinh trong host session hiện tại. Đóng thành công giữ field và bằng chứng đã khai báo trong bundle done trước khi xóa thư mục active; phiên blocked hoặc failed vẫn tiếp tục được.

| Alias | Tham số | Trỏ tới | Bind | Ai ghi | Operator ràng | Mục đích |
| --- | --- | --- | --- | --- | --- | --- |
| `@dynamic` | `<kind>` | `<Workflow>/.worktrees/sessions/<sessionId>/step-<N>/parallel-<M>/ — one branch of one step. request/request.json is the gate in (orchestrator writes it); response/ is the agent's: response.json (gate out), response.md and other markdown kinds, data/<name>.json, artifacts/<file>; a nested exchange adds <exchange>/request/ and <exchange>/response/. A kind is passed by explicit path in request.json inputs, from the session root. Dynamic files are passed as kinds (templates/kinds/<kind>), never as aliases. The orchestrator creates the session folder. scripts/session-cleanup.mjs close-success retains required artifacts in @worktrees/done and verifies them before removing only this folder; git.publish does not delete the session or user worktree. Blocked or failed work is kept for resume` | kind contract or schema under templates/kinds; response.json fields is the registry of what a branch produced | `*` | — | Everything produced inside the session and nothing that existed before it. Always dynamic; typed by kind. |

## undefined



| Alias | Tham số | Trỏ tới | Bind | Ai ghi | Operator ràng | Mục đích |
| --- | --- | --- | --- | --- | --- | --- |
| `@tools/browsercontrol` | — | `resources/tools.json#tools.browsercontrol` | mode declared in operator.json → resources.tools; modes: never \| required \| playwright | — | — | Drive a real browser against a served route: navigate, act, capture screenshots and DOM measurements. |
| `@tools/ci` | — | `resources/tools.json#tools.ci` | mode declared in operator.json → resources.tools; modes: never \| read \| dispatch | — | — | Observe or dispatch continuous-integration runs. |
| `@tools/container` | — | `resources/tools.json#tools.container` | mode declared in operator.json → resources.tools; modes: never \| read \| operate | — | — | Inspect or operate containers and images: compose services, GHCR images by digest. |
| `@tools/database` | — | `resources/tools.json#tools.database` | mode declared in operator.json → resources.tools; modes: never \| read \| namespaced-write | — | — | Read or write the product database for verification: seeds, fixtures, is_uat records. |
| `@tools/fileread` | — | `resources/tools.json#tools.fileread` | mode declared in operator.json → resources.tools; modes: never \| context-aliases | — | — | Read files and directories at the aliases the Context table names, at the frozen head. |
| `@tools/git` | — | `resources/tools.json#tools.git` | mode declared in operator.json → resources.tools; modes: never \| read \| commit-session-branch \| merge-and-push \| merge-into-integration-branch | — | — | Read and change repository state: heads, branches, worktrees, commits, merges, pushes. |
| `@tools/host` | — | `resources/tools.json#tools.host` | mode declared in operator.json → resources.tools; modes: never \| loopback | — | — | Serve a folder of static HTML on the loopback interface so a person can open it in a browser. The port is tried from 60000 upward to 60100 and the first free one wins; the receipt records the URL, the port, the folder and the pid under response/artifacts/host.json, and the server is stopped when the branch ends or is resumed. It never binds 0.0.0.0, so nothing it serves leaves the machine. |
| `@tools/http` | — | `resources/tools.json#tools.http` | mode declared in operator.json → resources.tools; modes: never \| probe | — | — | Probe an endpoint: readiness, health, a served route, a GraphQL typename, a status page. |
| `@tools/imagegen` | — | `resources/tools.json#tools.imagegen` | mode declared in operator.json → resources.tools; modes: never \| judged \| required | — | — | Produce artwork: a digital image from an image model, made to one stated claim. Rendering HTML is the visualize tool, not this one. |
| `@tools/objectstorage` | — | `resources/tools.json#tools.objectstorage` | mode declared in operator.json → resources.tools; modes: never \| read \| write | — | — | Read or write objects in the content store (MinIO): curriculum, style references, published units. |
| `@tools/print` | — | `resources/tools.json#tools.print` | mode declared in operator.json → resources.tools; modes: never \| decision-points | — | — | Hand an artifact to the person in the conversation, rendered when the client can (image, HTML) and as a path or URL otherwise, at the moment a decision or a verdict needs their eyes. A run that produced the artifact and said nothing served nobody: the artifact reaches the person where they are reading, not where the branch happened to write it. |
| `@tools/registry` | — | `resources/tools.json#tools.registry` | mode declared in operator.json → resources.tools; modes: never \| read \| publish | — | — | Read a package registry — a published package, its version, its files — and publish one packed release to it. |
| `@tools/secrets` | — | `resources/tools.json#tools.secrets` | mode declared in operator.json → resources.tools; modes: never \| resolve-by-name | — | — | Resolve a sealed credential by name at the moment it is used; never read, print or store its value. The value may enter the request body of the call that consumes it or the field of a form in a driven browser, and nowhere else: not a file, not a fixture, not a recorded command, not a screenshot, not a log and not a receipt. |
| `@tools/shell` | — | `resources/tools.json#tools.shell` | mode declared in operator.json → resources.tools; modes: never \| declared-commands | — | — | Run declared commands: gates, builds, proofs, hooks, deployment plans. |
| `@tools/sourcewrite` | — | `resources/tools.json#tools.sourcewrite` | mode declared in operator.json → resources.tools; modes: never \| declared-write-set | — | — | Write files inside a routed checkout or an authority root. |
| `@tools/visualize` | — | `resources/tools.json#tools.visualize` | mode declared in operator.json → resources.tools; modes: never \| html | — | — | Render HTML for a person to look at: direction candidates, audit sheets, alternative comparisons, previews. No model grant is involved. |
| `@tools/websearch` | — | `resources/tools.json#tools.websearch` | mode declared in operator.json → resources.tools; modes: never \| bounded | — | — | Read public web pages to close one named gap in the evidence; results are references with URLs, never authority. |

## Đoạn thân thiện trong một checkout

Human-friendly segments inside any checkout alias (@workspaces/fe, @workspaces/be, @workspaces/<project>/<role>), mapped to the exact path. Write the friendly word; the resolver substitutes the path.

| Đoạn | Trỏ tới |
| --- | --- |
| `husky` | `.husky/  (pre-commit, pre-push)` |
| `package` | `package.json  (scripts, dependencies, the package version)` |
| `gates` | `package.json#scripts plus the configs it names (eslint.config.*, tsconfig*.json, jest.config.*/vitest.config.*, sonar-project.properties)` |
| `grammar` | `packages/grammar  (the Grammar package source inside @workspaces/fe)` |
| `/branch/session` | `the session branch session/<sessionId> of that checkout, in its own git worktree prepared from the frozen head; the only branch a source-writing operator may commit to` |
| `/commit/<sha>` | `that checkout at one commit; how a later step names exactly what an earlier step wrote (response.json.commits[])` |

