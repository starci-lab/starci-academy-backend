# title
System Design Mastery

# description
Khóa học dành cho developers muốn nâng cao kỹ năng thiết kế hệ thống, hiểu sâu về kiến trúc phân tán, scalability và các pattern phổ biến trong thực tế. Chương trình giúp bạn tự tin tham gia các cuộc phỏng vấn System Design và có khả năng thiết kế hệ thống production-ready.

# prerequisites
## 0
### text
Nắm vững kiến thức nền tảng về Backend, Frontend và Database.
## 1
### text
Hiểu các khái niệm Backend cơ bản: Authentication, Authorization, JWT, REST API.
## 2
### text
Hiểu cơ chế caching (Redis hoặc tương đương) và mục đích tối ưu performance.

# qnas
## 0
### question
Mình chưa từng xây hệ thống quy mô lớn — có học được không?
### answer
Được, nếu bạn đáp ứng các prerequisite. Khóa học đi từ nền tảng đến bài tập thiết kế thực tế. Bạn sẽ luyện tư duy trade-off, capacity và reliability ngay cả khi chưa vận hành hệ thống cực lớn.
## 1
### question
Khóa học nặng lý thuyết hay thực hành?
### answer
Cả hai. Bạn học mental model và pattern, sau đó áp dụng qua thiết kế các dạng hệ thống quen thuộc (ví dụ social feed, video streaming, e-commerce). Bạn cũng nhận feedback có cấu trúc về bài thiết kế của mình.

# valuePropositions
## 0
### text
Chương trình tập trung vào tư duy và kỹ năng thiết kế hệ thống thực tế.
## 1
### text
Thực hành thiết kế các hệ thống phổ biến: social network, video streaming, e-commerce...
## 2
### text
Được hỗ trợ review design và nhận feedback từ mentor có kinh nghiệm.

# originalPrice
1500000

# coverImageUrl
https://starci-academy.sgp1.cdn.digitaloceanspaces.com/system-design-mastery.png

# livestreamSessions
## 0
### dayOfWeek
monday
### startTime
20:30:00
### expectedEndTime
22:30:00
### isOverridable
true

## 1
### dayOfWeek
friday
### startTime
20:30:00
### expectedEndTime
22:30:00
### isOverridable
true

# pricingPhases
## 0
### phase
pioneer
### price
990000
### slotAvailable
30

## 1
### phase
earlyBird
### price
1190000
### slotAvailable
50
## 2
### phase
regular
### price
null
### slotAvailable
null