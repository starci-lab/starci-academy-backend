# title
System Design Mastery

# description
A course for developers who want to strengthen system design skills, deepen understanding of distributed architecture, scalability, and common production patterns. The program helps you confidently tackle System Design interviews and design systems that are ready for real-world constraints.

# prerequisites
## 0
### text
Solid foundations in backend, frontend, and databases.
## 1
### text
Familiarity with core backend concepts: authentication, authorization, JWT, and REST APIs.
## 2
### text
Understanding of caching (Redis or equivalent) and why it matters for performance.

# qnas
## 0
### question
I have not built large-scale systems yet — is this course for me?
### answer
Yes, if you meet the prerequisites. The course builds from fundamentals toward practical design exercises. You will practice reasoning about trade-offs, capacity, and reliability even before you have run systems at massive scale.
## 1
### question
Is this mostly theory or hands-on practice?
### answer
Both. You learn the mental models and patterns, then apply them by designing well-known system types (for example social feeds, video streaming, e-commerce). You also get structured feedback on your designs.

# valuePropositions
## 0
### text
A curriculum centered on practical system design thinking and skills.
## 1
### text
Hands-on practice designing common real-world systems: social networks, video streaming, e-commerce, and more.
## 2
### text
Mentor-led design reviews and actionable feedback on your solutions.

# originalPrice
1500000

# coverImageUrl
https://starci-academy.sgp1.cdn.digitaloceanspaces.com/system-design-mastery.png

# livestreamSessions
## 0
### dayOfWeek
monday
### startTime
20:30:00
### expectedEndTime
22:30:00
### isOverridable
true

## 1
### dayOfWeek
friday
### startTime
20:30:00
### expectedEndTime
22:30:00
### isOverridable
true

# pricingPhases
## 0
### phase
pioneer
### price
990000
### slotAvailable
30

## 1
### phase
earlyBird
### price
1190000
### slotAvailable
50

## 2
### phase
regular
### price
null
### slotAvailable
null
