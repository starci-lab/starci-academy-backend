# title
Caching cơ bản: Giải cứu Database khỏi bão đọc

# description
Bốn tầng cache phòng thủ chuyên sâu trong hệ thống — Nginx Microcaching ở biên, Cache-Aside thủ công, query cache của TypeORM, và response cache của CacheInterceptor. Tầng application tích hợp Keyv multi-tier (LRU in-process + Redis) cùng chiến lược invalidate siêu chặt chẽ, mở rộng được bằng Kubernetes.

# body

## I. Lời mở đầu

App của bạn đã scale ra **20 instance**. Mọi thứ chạy trơn tru cho đến khi một người nổi tiếng tweet về sản phẩm của bạn. Đùng một cái, **5 triệu request** ập vào xem đúng **một** trang sản phẩm. Cả 20 instance gửi cùng một truy vấn — `SELECT * FROM products WHERE id = 1` — tới **database duy nhất**. Read lock chồng chất, CPU chạm **100%**, database đóng băng.

Tầng application không có vấn đề gì; bottleneck nằm ở tầng storage bị hỏi cùng một câu hỏi hàng triệu lần. Nếu đáp án không thay đổi so với một mili giây trước, tại sao phải hỏi database lần nữa? **Caching** là nghệ thuật nhớ các câu trả lời gần đây trong bộ nhớ siêu tốc để DB không phải chịu tải thừa. Cache được thiết kế tốt có thể hấp thụ **hơn 90%** toàn bộ traffic đọc ở ngay cổng nhà — và trong thực tế bạn hiếm khi chỉ dùng **một** tầng: lưu lượng đi qua **Nginx → LRU in-process → Redis shared → Database**, mỗi tầng sẽ chặn lấy một phần traffic.

## II. Demo trực quan và thực hành

**Repo** dưới đây triển khai **bốn pattern cache** (4 tầng cache) cùng lúc trên cùng một bộ dữ liệu **Product** mẫu:

- **Nginx Microcaching** — chặn hoàn toàn request lặp lại ở rìa mạng qua cấu hình `proxy_cache`. Đây là tầng bảo vệ ngoài cùng.
- **Response cache** của NestJS qua `CacheInterceptor` — ngăn chặn ở biên ứng dụng, cache toàn JSON body.
- **Query-level cache** của **TypeORM** — gắn `.cache(id, ttl)` trên `QueryBuilder` để lưu tạm các kết quả **SQL**.
- **Cache-Aside** thủ công qua `@Inject(CACHE_MANAGER)` — mã nguồn tự xử lý `get/set/del` vào `product:{id}`.

Sâu bên dưới Node.js, Module được cấu hình **multi-tier** gồm tier 1 là **LRU in-memory** local cho mỗi process, tier 2 là **Redis** dùng chung. Phía đích là **Postgres** được ép ngủ **300 ms** (bằng `pg_sleep(0.3)`) để giả lập tải chậm, nhằm đo chính xác cost của dữ liệu mà không vướng overhead máy ảo.

**Clone** ở đây: [Caching Basics — demo](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/caching-basics)

| Thành phần | Cổng | Công nghệ | Trách nhiệm |
|-----------|------|-----------|-------------|
| **Nginx** | **8080** | **Nginx** | Tầng 1: Microcaching & Reverse Proxy chặn request ở biên ngoại |
| **cache-app** | **3000** | **NestJS** + **TypeORM** | Tầng 2, 3, 4: `GET`, `PUT` API — Tầng ngăn chặn bên trong ứng dụng |
| **Postgres** | **5432** | **PostgreSQL 16** | Bảng `products` — bản chân lý gốc (source of truth); mô phỏng độ trễ |
| **Redis** | **6379** | **Redis 7** | Tier-2 cache cho multi-tier chia sẻ qua các pods |

![Sơ đồ kiến trúc bốn tầng cache với Nginx ở biên, LRU in-process và Redis shared](https://starci.org/system-design-mastery/caching-basics/0.svg)

*Hình 1. Hướng đọc: qua biên Nginx → LRU → Redis → Postgres; Hướng ghi: đi ngược dòng và invalidate sạch sẽ.*

### 1. Chuẩn bị và chạy môi trường

Giả định **kubectl** đã nối tới cluster (**Minikube**, **kind**, hoặc **Docker Desktop**). Service nội bộ là **ClusterIP**;

Image **`cache-app`** đã có sẵn trên registry: **`starci183/cache-app:latest`**. Trong `cache-app-deployment.yaml`, để `image` trỏ tới tag này nếu bạn chỉ muốn kéo về chạy. Còn không, tự build trong `example-backend/`, tag và **push lên registry của bạn**, rồi sửa `image` trong manifest cho đúng host/tag bạn kiểm soát.

**Tự build và đẩy registry riêng** (khi chỉnh code hoặc không dùng image public):

```
cd example-backend
docker compose -f docker-compose.yaml build
docker tag <image-local-sau-build> YOUR_REGISTRY/cache-app:latest
docker push YOUR_REGISTRY/cache-app:latest
```

Quay về thư mục gốc của demo, apply manifest theo từng tầng:

```
kubectl apply -f postgres-pod.yaml
kubectl apply -f postgres-service.yaml
kubectl apply -f redis-pod.yaml
kubectl apply -f redis-service.yaml
kubectl apply -f cache-app-deployment.yaml
kubectl apply -f cache-app-service.yaml
kubectl apply -f nginx-configmap.yaml
kubectl apply -f nginx-deployment.yaml
kubectl apply -f nginx-service.yaml
```

Đợi các pod ready:

```
kubectl wait --for=condition=Ready pod/postgres-pod --timeout=120s
kubectl wait --for=condition=Ready pod/redis-pod --timeout=120s
kubectl rollout status deploy/cache-app --timeout=120s
kubectl rollout status deploy/nginx-cache --timeout=120s
```

Kiểm tra:

```
kubectl get pods -o wide
kubectl get services
```

`nginx-cache-service` sẽ mở NodePort **30080** để client ngoài cluster truy cập. Trong khi đó `cache-app-service`, `redis-service`, `postgres-service` giữ kiểu ClusterIP.

Nếu muốn test trực tiếp app (bỏ qua Nginx) để so sánh latency, mở thêm terminal và chạy:

```
kubectl port-forward svc/cache-app-service 3000:3000
```

**Kết quả mong đợi**

`postgres-pod`, `redis-pod`, `nginx-cache-*` ở trạng thái `Running`; `cache-app` có `2/2 READY`. Gọi qua Nginx:

```
curl -s http://<NODE_IP>:30080/products/health
```

trả `{ "pod": "...", "ok": true }`. Gọi qua port-forward `http://localhost:3000/products/health` cũng trả kết quả tương tự.

**Kết luận**

Bốn tầng đã lên đủ: **Nginx (edge cache)** -> **cache-app (3 app-level cache)** -> **Redis shared cache** -> **Postgres source of truth**. Cấu trúc tách rõ tầng compute, tầng stateful, và điểm vào từ bên ngoài cluster.

### 2. Nginx Microcaching — Tầng 1 chặn bão ở Rìa Mạng

**Nginx Microcaching** đóng vai một khiên chắn thép ngoài biên: Các request động nếu chỉ thay đổi ít, khi bật cache, Nginx lấy vùng memory riêng tống trả JSON trong chớp mắt. Hệ thống NestJS "còn chưa hề biết" nổ ra request đó.

**Câu lệnh `curl` thử thách:** (bật -D soi Headers)

```
curl -s -D - http://localhost:8080/products/stats/summary
curl -s -D - http://localhost:8080/products/stats/summary
```

Dấu hiệu nhận biết: `X-Proxy-Cache: MISS` ở lần ngấp nghé thứ nhất. Nhưng ở đợt lũ thứ hai lập tức hiện `X-Proxy-Cache: HIT`.

**Kết quả mong đợi:** Tốc độ thần sầu (~**0.1 ms**). Việc chặn rác chặn lũ ở Edge Controller giúp bạn giảm chi phí tính toán đám mây. Mẹo: chỉ cần cấu hình TTL sinh tồn khoảng **(1-5 giây)** là đủ ngắt 99% dông bão Thundering Herd mà ít gây sai lệch số liệu.

### 3. Response Cache của Nest JS — Tầng 2 Nội Cung

Lọt qua Nginx, endpoint `GET /products/stats/summary` gặp tầng `@UseInterceptors(CacheInterceptor)`. Framework gói ghém mọi JSON body nhét sẵn ở RAM.

Phân tích: Ở độ sâu này, TCP socket đã tống thẳng vào Process của V8 Engine NodeJS. Dù vẫn hao tổn bộ nhớ của bộ biên dịch JS nhưng framework cản luồng không cho hàm Logic/Controller tính toán thống kê. Rẻ hơn chọc xuống tầng database gấp ngàn lần.

### 4. TypeORM query-level cache — Tầng 3 cản ở SQL

TypeORM ở DataSource cắm sẵn `cache: { type: 'redis', ... }`, kết hợp hàm `.cache('products:1', 30_000)` vào `QueryBuilder`.

```
curl -s http://localhost:8080/products
```

Lần 1 body `"source": "db", "durationMs": 45...`
Lần 2 lập tức `"source": "typeorm-cache"`. Chặn hàm chạy dịch SQL nặng. Phương pháp này trị bá bệnh ở các Leaderboard View bảng xếp hạng danh vọng, trang chủ E-commerce.

### 5. Cache-Aside đa tầng cốt lõi — Tầng 4 Cơ Sở Nhất

Chỉ khi bạn không thể đoán ý đồ request, buộc phải tự tay viết Cache Aside qua logic cơ duyên `get/set` (thủ công qua `@Inject(CACHE_MANAGER)`). Mật mã này nhúng hẳn Multi-Tier.

- **Đọc trượt** (Tốn ~300ms do pg_sleep): miss -> đọc DB -> set LRU & Redis.
- **Đọc thành công** (~ 1-3ms): Đọc ngay từ phân vùng LRU. Không thèm gửi gói tin sang Redis chia sẻ.

Tuy nhiên ở đây là nơi quản lý sự khốc liệt nhất của Invalidate Cache:
Khi ai đó đụng vào giá (PUT):

```
curl -X PUT http://localhost:8080/products/1/price -H "Content-Type: application/json" -d "{\"price\": 1099}"
```

Kết quả: `"invalidated": ["product:1", "products:stats-summary", "products:cheapest"]`. Update xong thì mã nguồn của chúng ta phải **fan-out đấm xoá cả 3 lớp nội bộ** (Tầng 2, 3, 4). (Vì tầng Nginx nằm tít ngoài hệ thống biên, nên phải bỏ mặc đợi vòng quay TTL ngắn hạn tự tiêu hoá).

## III. Tinh tuý và Kết Luận

### 1. Cuộc chiến RAM đỉnh cao

Tùy vào công nghệ, độ trễ giáng giật khác nhau vạn dặm:
**DB qua ổ cứng SSD (Postgres Cache Miss):** chậm 10–100 ms.
**Redis kết nối Node mạng (TCP Hit):** chậm 0.3–1 ms.
**RAM In-process LRU (Local hit):** lướt < 0.001 ms.
**Edge Microcache (Nginx Hit):** < 0.1 ms cắt cả IO Node.js.

### 2. Các chiến lược Invalidation

- **Write-Through / Broadcast Message**: Khi có cập nhật từ nguồn, gửi thông điệp qua Redis Pub/Sub để xóa các khóa (key) tương ứng trên các Node cục bộ (LRU tier-1).
- **Tránh Cache Avalance (Hiệu ứng lở tuyết):** Thêm yếu tố ngẫu nhiên (Jitter) khoảng ±10% vào thời gian TTL để tránh tình trạng nhiều khóa đồng loạt hết hạn, gây quá tải cục bộ cho database.
- **Chống Penetration (Xuyên thủng cache):** Lưu các giá trị `null` với thời gian sống ngắn (short TTL) cho các truy vấn không tồn tại, hoặc sử dụng Bloom filter để lọc các yêu cầu không hợp lệ.

### 3. Tổng kết các Pattern

| Tầng Caching | Đặc điểm và Ứng dụng |
|--------------|----------------------|
| **Nginx Edge proxy** | Chặn request ở biên hiệu quả. Việc invalidate có thể phức tạp. |
| **Response Cache** | Bỏ qua bước xử lý logic của Controller. Thích hợp cho API ít thay đổi. |
| **Query Cache** | Bỏ qua việc thực thi và biên dịch SQL ở DB. Giảm tải nhanh chóng cho driver. |
| **Cache Aside** | Linh hoạt, dễ tùy chỉnh và kiểm soát logic, nhưng cần quản lý chặt chẽ để tránh lỗi dữ liệu cũ (stale data). |

Việc đo lường thông số `"durationMs"` trên console giúp làm rõ sự khác biệt về độ trễ giữa các tầng bộ nhớ, từ đó đưa ra lựa chọn phù hợp cho việc tối ưu hiệu suất hệ thống.

# references
## 0
### alias
Redis — Caching Architecture Guidelines
### url
https://redis.io/learn/howtos/solutions/caching-architecture
## 1
### alias
AWS — Cache-Aside Design
### url
https://docs.aws.amazon.com/prescriptive-guidance/latest/cloud-design-patterns/cache-aside.html
## 2
### alias
NestJS & Microcaching Cấu Hiệu
### url
https://docs.nestjs.com/techniques/caching
## 3
### alias
Nginx — Microcaching Pattern
### url
https://www.nginx.com/blog/benefits-of-microcaching-nginx/

# minutesRead
30
