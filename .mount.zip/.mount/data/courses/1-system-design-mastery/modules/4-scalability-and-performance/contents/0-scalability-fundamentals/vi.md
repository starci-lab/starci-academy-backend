# title
Scalability là gì? Điểm nghẽn khi Traffic tăng đột biến

# description
Khái niệm cốt lõi về scalability và vì sao hệ thống thường đứt ở tầng stateful thay vì ứng dụng khi lượng người dùng tăng đột ngột — chứng minh trên Kubernetes với hai app NestJS: một stateless (Postgres) scale mượt, một stateful (SQLite) vỡ khi scale-out — rồi đọc sâu về Single Point of Failure ở tầng state và cách khắc phục.

# body

## I. Lời mở đầu

Khi phỏng vấn, câu hỏi *"Nếu traffic tăng **10×**, bạn xử lý thế nào?"* luôn phân biệt rõ ai hiểu kiến trúc phân tán và ai chưa. Hầu hết vội trả lời *"em thêm **RAM**"* hoặc *"em chạy thêm **instance**"*. Nhưng nếu thêm máy xong mà hệ thống vẫn kẹt ở tầng **database** thì sao? Vấn đề thật sự không nằm ở bất kỳ thành phần đơn lẻ nào — mà nằm ở chỗ tài nguyên **stateful** (database, session store, bất cứ thứ gì phải giữ trạng thái giữa các request) sẽ trở thành điểm nghẽn mỗi khi tải tăng, trong khi phần compute **stateless** có thể scale thoải mái. Tệ hơn, tầng stateful thường là **Single Point of Failure** — con **Postgres** duy nhất chết là toàn hệ **API** chết theo, dù có chạy **50 replica** app ở trên.

Bài này cung cấp mô hình tư duy: khi request tăng đột biến, hệ thống **đứt** ở đâu, điều gì khiến một component scalable hay không, và **SPOF** ở tầng state có thể né thế nào — rồi bạn chứng minh trên cluster **Kubernetes** chạy thật.

## II. Demo trực quan và thực hành

**Repo** dưới đây là một **NestJS** **monorepo** chứa **hai app** dùng chung cùng một **TypeORM** entity (`Note`) và controller. Điểm khác biệt duy nhất là **nơi lưu state**:

- **`postgres-app`** — kết nối tới một **Postgres Pod** dùng chung qua **ClusterIP Service** → từ góc nhìn app thì process là **stateless**, vì mọi pod đọc-ghi cùng một database duy nhất.
- **`sqlite-app`** — ghi vào **file SQLite cục bộ** bên trong `emptyDir` của mỗi pod → mỗi pod giữ **state riêng**, khiến app trở thành **stateful**.

Cả hai app được triển khai dưới dạng **Kubernetes Deployment** và expose qua **ClusterIP Service** — không mở ra ngoài; để gọi từ máy host ta dùng **`kubectl port-forward`** để forward cổng cluster nội bộ về máy mình.

**Clone** ở đây: [Scalability Fundamental — demo (Kubernetes)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/scalibity-fundamental)

| Thành phần | Cổng nội bộ (ClusterIP) | Cổng local (port-forward) | Công nghệ | Trách nhiệm |
|-----------|------|------|-----------|-------------|
| **postgres-app** | **3000** | **3001** | **NestJS** + **TypeORM** (pg driver) | `POST /notes`, `GET /notes` — ghi vào **Postgres** dùng chung |
| **sqlite-app** | **3000** | **3002** | **NestJS** + **TypeORM** (sqlite3 driver) | `POST /notes`, `GET /notes` — ghi vào **file SQLite cục bộ** mỗi pod |
| **Postgres Pod** | **5432** (ClusterIP) | — | **PostgreSQL** | Store trạng thái dùng chung cho `postgres-app` |

![Sơ đồ kiến trúc triển khai ứng dụng stateless và stateful trên Kubernetes](https://starci.org/system-design-mastery/scalability-fundamentals/1.svg)

*Hình 1. Sơ đồ kiến trúc hệ thống từ source code trên.*

Kiến trúc minh họa hai **Deployment** độc lập: `postgres-app` lưu trữ trạng thái vào một **Postgres Pod** dùng chung (hoàn toàn **stateless** từ góc nhìn của app), trong khi `sqlite-app` ghi dữ liệu vào volume `emptyDir` cục bộ của mỗi Pod (bị **stateful**).

### 1. Chuẩn bị và triển khai

Giả định **kubectl** đã nối tới cluster (**Minikube**, **kind**, hoặc **Docker Desktop**). Có thể dùng image có sẵn trên registry (`starci183/scalibity-postgres-app:latest`, `starci183/scalibity-sqlite-app:latest`) — hoặc tự build để nhìn rõ codebase được đóng gói thế nào.

Từ thư mục **`example-backend/`** bên trong repo, build và push hai image:

```shell
cd example-backend
docker compose -f apps/postgres-app/docker-compose.yaml build
docker push starci183/scalibity-postgres-app:latest
docker compose -f apps/sqlite-app/docker-compose.yaml build
docker push starci183/scalibity-sqlite-app:latest
```

Quay về thư mục gốc của demo rồi apply toàn bộ manifest:

```
kubectl apply -f postgres-pod.yaml
kubectl apply -f postgres-service.yaml
kubectl apply -f postgres-app-deployment.yaml
kubectl apply -f postgres-app-service.yaml
kubectl apply -f sqlite-app-deployment.yaml
kubectl apply -f sqlite-app-service.yaml
```

Đợi tất cả pod ready:

```
kubectl wait --for=condition=Ready pod/postgres-pod --timeout=120s
kubectl rollout status deploy/postgres-app --timeout=120s
kubectl rollout status deploy/sqlite-app   --timeout=120s
```

Kiểm tra:

```
kubectl get pods -o wide
kubectl get services
```

Cả hai **Service** đều kiểu **ClusterIP** (cổng nội bộ **3000**) — chưa expose ra ngoài cluster. Để gọi được từ máy host, mở **hai terminal riêng** và chạy **`kubectl port-forward`** (giữ terminal sống trong suốt demo):

```
kubectl port-forward svc/postgres-app-service 3001:3000
```

```
kubectl port-forward svc/sqlite-app-service 3002:3000
```

Lệnh này mở cổng **3001** và **3002** trên máy host, tunnel vào **Service** ClusterIP tương ứng bên trong cluster. Kubernetes sẽ round-robin request tới các pod đứng sau Service như bình thường.

**Kết quả mong đợi**

Tất cả Pod ở trạng thái `Running`. Hai terminal `port-forward` in ra dòng `Forwarding from 127.0.0.1:3001 -> 3000` và tương tự cho **3002**. Từ máy host, `curl http://localhost:3001/notes` và `curl http://localhost:3002/notes` đều hoạt động.

**Kết luận**

Hai codebase giống hệt nhau (cùng entity, cùng controller) đang chạy trên cluster, chỉ nhìn ra được qua **port-forward**. Điểm khác biệt **duy nhất** là storage backend: một dùng **Postgres** Pod dùng chung, một ghi vào file **SQLite** cục bộ. Đây là thiết lập để chứng minh rằng scalability sống hay chết phụ thuộc vào tầng **state**.

### 2. Stateless scale được — postgres-app

Scale app **stateless** lên **5** replica:

```
kubectl scale deploy/postgres-app --replicas=5
kubectl rollout status deploy/postgres-app --timeout=120s
```

Tạo **6 note** qua port-forward:

```
for i in 1 2 3 4 5 6; do
  curl -s -X POST http://localhost:3001/notes \
    -H "Content-Type: application/json" \
    -d "{\"content\":\"note-$i\"}"
  echo
done
```

Đọc lại:

```
curl -s http://localhost:3001/notes
```

**Kết quả mong đợi**

Mỗi lần `GET /notes` đều trả về **đủ 6 note** với `count=6`. Lưu ý: `kubectl port-forward svc/...` giữ kết nối cố định vào **một pod** trong suốt session — nên `createdByPod` có thể cùng trỏ về một pod. Muốn nhìn rõ nhiều pod ghi khác nhau, mở **thêm vài session port-forward song song** hoặc `exec` curl từ bên trong một pod khác cùng cluster. Điểm cốt lõi vẫn nguyên: **bất kỳ pod nào cũng đọc được toàn bộ dataset** vì đều dùng chung **Postgres**.

Scale xuống để kiểm chứng dữ liệu vẫn còn:

```
kubectl scale deploy/postgres-app --replicas=1
kubectl rollout status deploy/postgres-app --timeout=60s
curl -s http://localhost:3001/notes
```

**Kết quả mong đợi**

Vẫn **6 note**. Pod sinh ra rồi mất đi nhưng dữ liệu sống trong **Postgres** — app thực sự **stateless**.

**Kết luận**

Khi state được externalize sang service chuyên giữ state (**Postgres**), tầng app có thể scale ngang mà không mất dữ liệu hay mất tính nhất quán. **Service** round-robin thoải mái vì mọi replica đều giống hệt nhau và có thể thay thế bất cứ lúc nào.

### 3. Stateful vỡ — sqlite-app

Scale app **stateful** lên **3** replica:

```
kubectl scale deploy/sqlite-app --replicas=3
kubectl rollout status deploy/sqlite-app --timeout=120s
```

Tạo **9 note**:

```
for i in $(seq 1 9); do
  curl -s -X POST http://localhost:3002/notes \
    -H "Content-Type: application/json" \
    -d "{\"content\":\"sqlite-$i\"}"
  echo
done
```

Đọc nhiều lần:

```
for i in 1 2 3 4 5 6; do
  curl -s http://localhost:3002/notes
  echo
done
```

**Kết quả mong đợi**

Nếu chạy **nhiều session `kubectl port-forward svc/sqlite-app-service 3002:3000`** song song (mỗi session chọn một pod khác nhau), mỗi session sẽ trả về `count` **khác nhau** — `3`, `2`, `4`, … — vì mỗi pod chỉ thấy những note mà **chính nó** đã nhận. Giá trị `id` thậm chí bị trùng (mỗi SQLite tự đánh số từ 1 một cách độc lập). Nói cách khác: với một **Load Balancer** thật đứng trước (hoặc Service round-robin khi request phát từ bên trong cluster), user sẽ thấy dữ liệu **nhảy loạn** giữa các lần gọi.

Scale xuống:

```
kubectl scale deploy/sqlite-app --replicas=1
curl -s http://localhost:3002/notes
```

**Kết quả mong đợi**

Hai pod bị xóa → volume `emptyDir` của chúng bị hủy → **hai file SQLite cùng toàn bộ note bên trong biến mất vĩnh viễn**. Rolling update cũng cho kết quả y hệt: pod mới = `emptyDir` mới = database trắng.

**Kết luận**

Khi state nằm bên trong pod (local filesystem), **scale ngang làm vỡ dữ liệu** và **scale xuống làm mất dữ liệu vĩnh viễn**. Đây là **anti-pattern stateful** kinh điển trong container orchestration. Nếu bắt buộc phải giữ state trong pod, tối thiểu phải dùng **StatefulSet** với **PersistentVolumeClaim** — nhưng ngay cả vậy, đó vẫn không phải "horizontal scaling" theo nghĩa cổ điển.

### 4. Postgres Pod là Single Point of Failure — giết nó và quan sát

Đưa `postgres-app` về lại **5 replica** cho "mạnh":

```
kubectl scale deploy/postgres-app --replicas=5
kubectl rollout status deploy/postgres-app --timeout=60s
```

Xác nhận app vẫn đọc được dữ liệu:

```
curl -s http://localhost:3001/notes
```

Giờ **xoá** pod Postgres duy nhất đang giữ state:

```
kubectl delete pod postgres-pod
```

Ngay lập tức thử lại request:

```
curl -s -X POST http://localhost:3001/notes \
  -H "Content-Type: application/json" \
  -d "{\"content\":\"after-db-down\"}"
curl -s http://localhost:3001/notes
```

**Kết quả mong đợi**

**5 pod `postgres-app` vẫn `Running` và khoẻ mạnh**, nhưng mọi request đều trả **500** / **ECONNREFUSED** — app không có đối tượng để đọc/ghi. Kiểm tra:

```
kubectl get pods
kubectl logs deploy/postgres-app --tail=20
```

Log app đầy các lỗi kết nối tới **`postgres-service:5432`**. Toàn bộ **API** nằm dưới một **service duy nhất** ở tầng state — đây chính là **Single Point of Failure**, dù tầng compute đã scale ngang rất đẹp.

Chờ Kubernetes tự tạo lại pod Postgres (khoảng **10–30s**):

```
kubectl wait --for=condition=Ready pod -l app=postgres --timeout=120s
curl -s http://localhost:3001/notes
```

**Kết quả mong đợi**

Pod mới `postgres-pod` ở trạng thái `Running`, API hoạt động lại — nhưng vì đây là **Pod** đơn lẻ với volume `emptyDir`, **toàn bộ 6 note trước đó đã mất**. Muốn giữ dữ liệu qua restart phải chuyển sang **StatefulSet** + **PersistentVolumeClaim**; muốn tránh downtime vài chục giây khi pod chết phải chạy **nhiều replica** + **automatic failover**.

**Kết luận**

**Stateless hoá app** chỉ giải quyết nửa bài toán — tầng state bên dưới vẫn có thể là **SPOF**. Trong demo này, **Postgres Pod duy nhất** là điểm chết cứng: nó xuống là cả **5 replica** app thành vô dụng. Phần **III.3** sẽ nói cách né SPOF này trên thực tế.

## III. Giải thích nâng cao và kết luận

### 1. Bản chất của Scalability

**Scalability** không phải "vung tiền thêm máy". Nó là khả năng hệ thống **duy trì hoặc cải thiện** hiệu năng (throughput, latency) **tỷ lệ thuận** khi bạn bơm thêm tài nguyên. Nếu tăng gấp đôi phần cứng mà capacity chỉ tăng **20%**, hệ thống đó gọi là **không scalable**.

- **Ví dụ:** **Deployment** `postgres-app` scale gần như tuyến tính — thêm replica thứ năm, xử lý thêm khoảng một phần năm throughput request. Trần nằm ở chỗ shared state sống: trong trường hợp này là **Postgres** Pod.
- **Ví dụ:** **Deployment** `sqlite-app` thêm replica, nhưng kết quả **tệ hơn** so với không scale: dữ liệu vỡ, đọc bất nhất, và scale xuống gây mất dữ liệu vĩnh viễn.

### 2. Scale Up vs Scale Out

Khi tải vượt quá năng lực, bạn có hai hướng tiếp cận:

- **Scale Up (Vertical Scaling):** Nâng cấp chính cái máy hiện tại — thêm **RAM**, CPU mạnh hơn, SSD lớn hơn. Không cần sửa code, triển khai nhanh. Trần là giới hạn vật lý của phần cứng và **single point of failure**: máy đó chết thì mất hết.
- **Scale Out (Horizontal Scaling):** Thêm nhiều máy nhỏ và phân tán công việc. Đây là sức mạnh cốt lõi của kiến trúc phân tán — lý thuyết thì trần cứ tăng khi thêm node. Đổi lại là độ phức tạp vận hành: cần **Load Balancer** (hoặc **Kubernetes Service**), app phải **stateless**, và bài toán nhất quán dữ liệu xuyên node trở thành vấn đề kỹ thuật thực sự.

Demo ở phần trên cho thấy tại sao **horizontal scaling** đòi hỏi ứng dụng **stateless**. `postgres-app` hoạt động ở bất kỳ số lượng replica nào vì state đã được externalize sang **Postgres**; `sqlite-app` vỡ ngay khi có replica thứ hai.

### 3. Single Point of Failure ở tầng state — và cách khắc phục

**SPOF** là bất kỳ component nào mà "chết là cả hệ chết". Trong demo trên, **Postgres Pod** duy nhất chính là SPOF: **5 replica** của `postgres-app` khoẻ mạnh cũng không cứu được gì khi cái Pod đó xuống. Quy luật chung: **stateless hoá app chỉ đẩy SPOF xuống tầng state**, không xoá được nó — cần chọn đúng kỹ thuật để né.

Một số hướng xử lý theo mức độ phức tạp tăng dần:

- **Persistent volume — né data loss, không né downtime.** Chuyển `postgres-pod.yaml` sang **StatefulSet** + **PersistentVolumeClaim**. Pod chết, Kubernetes tạo pod mới và **gắn lại volume cũ** → dữ liệu còn nguyên. Nhưng trong lúc pod đang khởi động lại, API vẫn **down vài chục giây**.
- **Primary-Replica + automatic failover — né downtime.** Chạy **ít nhất 2 Postgres node** với **streaming replication**; đặt trước chúng một bộ điều phối (**Patroni** + **etcd**, **pg_auto_failover**, hoặc **CloudNativePG operator** trên Kubernetes). Primary chết → replica được bầu lên thành primary mới trong **vài giây**, app tự kết nối lại qua DNS/virtual IP. Đây là "mất primary nhưng không mất service".
- **Read Replica — né SPOF cho đường đọc, song song giảm tải.** Nhân bản read-only cho các truy vấn `SELECT`. Khi primary chết, replica vẫn phục vụ đọc (chế độ degraded) trong khi failover đang chạy.
- **Managed database** (**RDS**, **Cloud SQL**, **Neon**, **Supabase**…) — nhà cung cấp lo replication, backup, và failover. Đắt hơn nhưng xoá phần lớn gánh vận hành; đây là mặc định hợp lý cho đa số team sản phẩm.
- **Health check + retry + circuit breaker ở tầng client** — app phải **coi kết nối DB là có thể đứt bất kỳ lúc nào**: đặt timeout ngắn, retry có backoff, và không để một request lỗi DB khoá cả event loop. Thiếu phần này, dù hạ tầng có failover nhanh mấy thì user vẫn thấy lỗi trần trụi.
- **Mở rộng ra toàn hệ:** mỗi tầng (API Gateway, cache, message broker, DNS, load balancer) đều có khả năng là SPOF. Nguyên tắc "**no single replica of anything critical**" áp dụng chung — luôn chạy ≥2 instance và có cơ chế failover tự động.

Quay lại bối cảnh bài học: demo đang dùng **một Pod Postgres với `emptyDir`** vì mục đích sư phạm — nó phơi bày SPOF rõ ràng. Trong hệ sản xuất, **không ai** deploy như vậy; các bài kế tiếp (**Database Scaling**, **Horizontal Scaling & Load Balancing**) sẽ đi sâu từng kỹ thuật ở trên.

### 4. Điểm nghẽn thật sự nằm ở đâu

Một mô hình tư duy hữu ích: truy vết đường đi của request và tìm component **stateful** không thể nhân bản tự do.

- **API layer** — thường stateless, scale ngang phía sau **Kubernetes Service** hoặc **Load Balancer**.
- **Cache layer** (**Redis**, **Memcached**) — shared state, nhưng được thiết kế chuyên biệt để chịu throughput đọc cực lớn; có thể cluster.
- **Database layer** — thành lũy stateful cuối cùng. Ghi phải đi vào một primary duy nhất (hoặc nhóm **shard** phối hợp). Khi tải ghi vượt quá khả năng một node, bạn cần **Read Replica** (giảm tải đọc) hoặc **Sharding** (chia ghi ra nhiều node) — cả hai đều kèm trade-off nghiêm trọng.

### 5. Các bài học cốt lõi

- **State quyết định khả năng scale.** Cùng codebase, chỉ thay nơi lưu state đã biến từ scale-được sang không-scale-được.
- **App phải stateless; state đẩy xuống service chuyên giữ state** (**Postgres**, **Redis**, **S3** …).
- **`Deployment` + filesystem cục bộ = anti-pattern.** Nếu bắt buộc phải giữ state trong pod, tối thiểu phải dùng **StatefulSet** + **PersistentVolumeClaim** — nhưng đó vẫn không phải "scale ngang" theo nghĩa cổ điển.
- **Service round-robin không cứu được state cục bộ** — user thấy kết quả nhảy loạn, đúng như demo `sqlite-app`.
- **Stateless hoá app không xoá được SPOF — nó đẩy SPOF xuống tầng state.** Phải né bằng **replication + automatic failover**, **PersistentVolumeClaim**, hoặc **managed database**.
- **Trần thật nằm ở tầng stateful.** Khi traffic tăng **10×**, `postgres-app` scale tuyến tính; giới hạn chạm đúng vào **Postgres** — và đó là lúc cần các kỹ thuật như **Read Replica**, **Sharding**, và **Caching**.

# references
## 0
### alias
The Twelve-Factor App — Processes
### url
https://12factor.net/processes
## 1
### alias
Kubernetes — Deployments
### url
https://kubernetes.io/docs/concepts/workloads/controllers/deployment/
## 2
### alias
Kubernetes — Services
### url
https://kubernetes.io/docs/concepts/services-networking/service/
## 3
### alias
Kubernetes — StatefulSets
### url
https://kubernetes.io/docs/concepts/workloads/controllers/statefulset/
## 4
### alias
CloudNativePG — PostgreSQL Operator for Kubernetes
### url
https://cloudnative-pg.io/

# minutesRead
30
