# title
Mở rộng cơ sở dữ liệu (Database Scaling): Polyglot Persistence trên Kubernetes

# description
Bài học này phân tích các giới hạn của việc mở rộng cơ sở dữ liệu, đồng thời hướng dẫn triển khai một kiến trúc đa ngôn ngữ lưu trữ (Polyglot Persistence). Chúng ta sẽ tìm hiểu cách một backend NestJS giao tiếp và vận hành chiến lược mở rộng song song của 4 loại cơ sở dữ liệu: PostgreSQL HA, Redis Cluster, MongoDB Sharded và Cassandra.

# body

## I. Giới thiệu tổng quan

Ngay cả khi ứng dụng đã được tối ưu hóa khả năng phân phối tải bằng Load Balancer và bộ nhớ đệm (Caching), hệ thống vẫn có thể gặp nguy cơ quá tải khi lưu lượng ghi (Write traffic) tăng đột biến. Các tương tác như giao dịch tài chính, lịch sử đơn hàng, cập nhật hồ sơ sẽ tạo áp lực trực tiếp lên tầng lưu trữ (Storage). Điều này có thể dẫn đến hiện tượng nghẽn I/O (Disk I/O) và sử dụng CPU Database ở mức tối đa.

Trong thực tế, việc mở rộng cơ sở dữ liệu không có một công thức duy nhất áp dụng cho mọi hệ thống. Mỗi loại cơ sở dữ liệu có những nguyên lý quản lý và phân phối dữ liệu riêng:
- **PostgreSQL (OLTP quản trị cơ sở dữ liệu quan hệ)**: Sử dụng mô hình Primary/Standby kết hợp với Connection Pooler để mở rộng kết nối.
- **MongoDB (Document-based)**: Quản lý phân mảnh dữ liệu bằng Replica Set, Router (`mongos`) và Shard Key.
- **Redis (In-memory/Key-value)**: Định tuyến luồng dữ liệu thông qua 16,384 Hash Slots của hệ thống Cluster.
- **Cassandra (Wide-column)**: Tổ chức mạng lưới theo Topology Ring, quản trị bằng cấp độ Consistency (CL) và Replication Factor (RF).

Tiếp cận mô hình SQL cho những hệ cơ sở dữ liệu lưu trữ NoSQL mà thiếu quan sát đặc tính có thể gây gián đoạn quy trình xử lý. Bài viết này sẽ minh họa cách vận hành cả 4 kiểu loại cơ sở dữ liệu trên cùng một nền tảng Kubernetes để giúp bạn hiểu được ngữ nghĩa (semantics) mở rộng riêng biệt của từng kiến trúc.

## II. Demo trực quan và thực hành: Triển khai kiến trúc Polyglot

**Repo** dưới đây triển khai **bốn loại hệ quản trị CSDL** cùng lúc trên cùng một kiến trúc lưu trữ đa ngôn ngữ (Polyglot Persistence):

- **PostgreSQL HA** — CSDL quan hệ OLTP, xử lý lệnh đọc/ghi thông qua lớp trung gian `Pgpool`.
- **Redis Cluster** — Lưu trữ Key-Value in-memory phân chia định tuyến qua 16,384 Hash Slots.
- **MongoDB Sharded** — Phân mảnh tài liệu Document thông qua tầng Router `mongos`.
- **Cassandra** — Phân phối dữ liệu Wide-Column qua mạng lưới Topology Ring.

Sâu bên trong Kubernetes, module cấu hình bốn instance lưu trữ chạy song song bằng biểu đồ Helm (Bitnami OCI). Ứng dụng backend duy nhất được xây dựng trên **NestJS** để kiểm chứng việc giao tiếp với chúng.

**Clone** ở đây: [Database Scaling — Module 4.3](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/database-scaling)

| Thành phần | Cổng | Công nghệ | Trách nhiệm |
|-----------|------|-----------|-------------|
| **example-backend** | **3000** | **NestJS** | Ứng dụng backend gọi 4 drivers (TypeORM, Mongoose, ioredis, cassandra-driver) |
| **postgresql-ha** | **5432** | **PostgreSQL 16** + **Pgpool** | CSDL quan hệ lưu bảng chuẩn hóa đồ thị nghiệp vụ |
| **redis-cluster** | **6379** | **Redis 7** | Bộ nhớ chia sẻ tốc độ cao để đệm cache và đếm số |
| **mongodb-sharded** | **27017** | **MongoDB** + **Mongos** | Khối dữ liệu chứa Document phân mảnh |
| **cassandra** | **9042** | **Cassandra** | Khối không gian lưu trữ dữ kiện dạng log dàn trải |

![Sơ đồ kiến trúc Polyglot Persistence tích hợp 4 CSDL](https://starci.org/system-design-mastery/database-scaling/0.svg)

*Hình 1. Kiến trúc Polyglot Persistence: Một ứng dụng chịu trách nhiệm tương tác hệ thống qua nhiều giải pháp lưu trữ phức tạp.*

### 1. Cài đặt 4 loại cơ sở dữ liệu trên Kubernetes

**Điều kiện cài đặt:** Đã thiết lập thành công các Node hệ thống cluster Kubernetes và công cụ Helm (phiên bản >3.8).

Mở terminal, chuyển tới thư mục cấu trúc source code dự án và chạy tuần tự các shell khởi chạy lệnh sau:

```bash
cd helm/postgresql-ha && ./run.sh && cd ../..
cd helm/redis-cluster   && ./run.sh && cd ../..
cd helm/mongodb-sharded && ./run.sh && cd ../..
cd helm/cassandra       && ./run.sh && cd ../..
```

*(Đối với môi trường hệ điều hành Windows, có thể thay thế bằng file Script `run.ps1` thông qua giao diện truyền lệnh PowerShell).*

**Xóa cài đặt hệ thống (Khi kết thúc kiểm tra):**
```bash
helm uninstall postgresql-ha redis-cluster mongodb-sharded cassandra -n database
kubectl delete pvc --all -n database
kubectl delete namespace database
```

### 2. Mở kết nối chuyển tiếp (Port-forward) và chạy ứng dụng `example-backend`

Thông thường ứng dụng sẽ gọi bằng DNS nội bộ ở cấu trúc mạng cluster. Để chạy thử trên Local, người quản trị mở port-forward để định tuyến từ cluster kết xuất ra ngoài:

```bash
kubectl port-forward -n database svc/postgresql-ha-pgpool 5432:5432
kubectl port-forward -n database svc/redis-cluster 6379:6379
kubectl port-forward -n database svc/mongodb-sharded-mongodb-sharded 27017:27017
kubectl port-forward -n database svc/cassandra 9042:9042
```

Bước tiếp theo, sử dụng server NestJS và đối chiếu môi trường máy cá nhân `127.0.0.1` với file `.env`:

```bash
cd example-backend
npm install
cp .env.example .env
npx nest start --watch
```

### 3. Kiểm tra các chức năng dịch vụ API

Mô đun có sẵn một vài giao tiếp request lệnh kiểm tra thông qua công cụ như sau:
- **`GET /health`** — Thăm dò xem thiết lập server ứng dụng đã cài đặt và chuẩn bị truy xuất sẵn sàng chưa.
- **`GET /integrations`** — Truy vấn đánh giá liên kết đường truyền đến từng khối lưu trữ: Postgres (qua Pgpool), Redis Cluster, Mongo (qua mongos), và thiết lập của CSLD hệ thống Cassandra.
- **`POST /integrations/demo-write`** — Thiết lập Write dữ liệu thông điệp chuỗi vào tập Mongo, nội dung lưu trữ đối tượng dạng bảng của không gian Cassandra và điều hướng đếm tăng số trong kho Redis.

Cú pháp thực hành lệnh:
```bash
curl -s http://localhost:3000/integrations
curl -X POST http://localhost:3000/integrations/demo-write -H "Content-Type: application/json" -d "{\"message\":\"Khởi chạy dịch vụ polyglot\"}"
```

**Tính năng đánh giá thực hành:** Cơ cấu quản lý một mạng đa kết xuất xử lý mô hình database đòi hỏi kiến trúc chuyên tầng lớp cài đặt driver. Trong thực tế ứng dụng sẽ có tính chất phức tạp với giao diện quản trị điều phối từ Microservices cho đến mô hình chia nhóm quy mô (Data Sharding) có kiểm soát.

---

## III. Phân tích kiến trúc mở rộng của 4 loại cơ sở dữ liệu

Dưới đây là thiết kế phân lớp so sánh cấu trúc thiết kế mở rộng cơ bản của từng đại diện lưu trữ nhằm giúp tối ưu yêu cầu ứng dụng linh hoạt (Access Pattern):

| Phân vùng cơ sở dữ liệu | Cấu trúc mở rộng Đọc (Scale Read) | Chiến lược mở rộng Ghi / Scale Storage (Dung lượng) | Rủi ro quy trình kĩ thuật (Trade-offs lưu ý) |
|------------|------------------------|-------------------------------------|---------------|
| **OLTP Quan hệ** (PostgreSQL, MySQL…) | Phân tán ứng dụng Replica (Sync/Async), chèn công cụ cân bằng luồng Connection Pooler (Pgpool) | Tập trung mở rộng bộ vi xử lý máy; Bóc tách mô-đun chia cấu trúc Sharding thông qua việc giao tiếp cấp độ ứng dụng. | Xử lý trễ thời gian **Replication lag**: Hành động tại khối Replica dễ nhận luồng tài nguyên chưa nhất quán khi quá trình đồng bộ hóa bị lỗi hoặc cập nhật trễ; Trở ngại khi tối ưu cho câu chữ ghép JOIN phức tạp liên kết bảng. |
| **Document** (MongoDB…) | Tạo bản ghi Secondaries thông qua Replica Set | Định hình **Sharded cluster**, sử dụng bộ kết xuất trung tâm điều hướng phân tích truy cập Router `mongos`, xây dựng thuộc nhóm đặc trưng Shard Key | Khi triển khai các thuộc tính truy xuất Key thiếu hiệu quả sẽ sinh tác động ảnh hưởng dẫn đến hiện tượng dò diện rộng (**Scatter/gather**), vượt sức quản trị tiêu hao tài nguyên định kì hệ thống máy vật lý. |
| **Key-Value** (Redis…) | Truy vấn rẽ nhánh thêm mạng xử lý sao chép (Replica đọc phân cấp) đến riêng các bộ nhớ định quy | Đảm trách khối lưu lượng trên khối không gian địa chỉ phân luồng trên toán học hệ 16,384 Hash slots bằng **Redis Cluster** | Các vấn đề liên đới do các luồng quản trị chia cấp quy mô cho chỉ mục RAM có rủi ro bão hòa vượt bộ nhớ; Chuyển tiếp phụ thuộc độ dài làm mới bằng thời gian biểu định thức của thông tin kho lưu (TTL thời hạn). |
| **Wide-Column** (Cassandra…) | Tái định hình quy ước kiến trúc Ring Topology, Cấu hình các thông số chỉ mục cấp độ (CL Read) | Nới rộng hệ thống trên luồng trục ngang (Scale-out thiết lập hạ tầng vật lý bằng bổ sung Server Cluster bổ sung); Phân định tính linh hoạt Partition Key tối đa bằng biểu đồ yêu cầu lưu chuyển query. | Trong chu kỳ cấp quyền và duy trì Replication Factor, tính chuẩn xác hay Consistency Level (RF/CL) đánh giá cấu trúc rủi ro dễ làm đình trệ toàn tính năng định tuyến cho vùng cấu trúc thông số dữ liệu phân cấp. |

### 1. PostgreSQL HA + Pgpool

Quy trình hoạt động ứng dụng `postgresql-ha` kết xuất bằng cấu hình đi đường tắt của việc giảm tải thông lượng đến Data chính không qua phương thức gọi luồng trung gian. Việc sử dụng proxy như **Pgpool** cung cấp việc tổ chức Read-only của dữ liệu từ mạng Standby node và các lệnh hệ thống thông điệp Write xuống vị trí Primary node cấu hình mặc định. Nhưng quá trình xử lý có khuynh hướng đối diện điểm hạn chế **Replication Lag**. Vẫn cần xử lý kỹ thuật lập trình hệ trên mức truy xuất giao dịch Read ngay sau tác quyền dòng cập nhật kết xuất Write bằng chỉ thị tham gia liên hệ đến Master node.

### 2. Redis Cluster

Tái tổ chức quản trị cấu hình lưu lượng khối phân mảnh Redis phụ thuộc chặt chẽ quy luật kiểm dẫn 16,384 luồng điều phố Hash Slots. Phác họa cho phân tích chu kỳ Scale-out dựa vào các di dời truy xuất theo chỉ thị Slot liên đới dịch chuyển (Slot Migration) đẩy dòng Token cấu trúc cụm Master gốc của định dạng mạng về với Master mới hơn. Tín năng làm việc duy trì khả năng đồng bộ từ sơ đồ luồng hệ cụm để thông qua Token.

### 3. MongoDB Sharded

Ngôn ngữ điều hướng cơ cấu phân mảnh tầng che lưu lượng truy xuất của **Mongos** có thể tự rải lớp kiến trúc vật lý qua việc sắp xếp đặc điểm lưu thông quy phân vùng theo Shard Data. Khi đó, lúc hoạt động vòng truy vấn chạy khuyết chuỗi Key xác nhận từ khóa, cơ chế ứng dụng vận hành hệ chức năng tìm khảo vùng Broadcast dải luồng mạng truy qua một chuỗi khối Cluster rủi ro. Sẽ sinh hệ quả hiện tượng dò dữ liệu mở rộng đa chiều (**Scatter/Gather**) dẫn tới tác động nghẽn vận tải toàn mạng lưới vòng tải trong chu trình chia Shard Logic khi mà MongoDB duy trì.

### 4. Cassandra

Trong nội dung kiến trúc tại demo nhỏ mức độ RF tương ứng 1 (Replication Factor = 1), hoạt động khá giản lược, hệ thống đáp ứng không thực tế, vì môi trường vận hành sẽ nâng Quorum và đẩy mức độ cao lên. Các thủ thuật thêm thiết bị Server Cluster kết hợp vòng mạng topology (Topology Ring) đi với Consistency Hashing thiết lập tổ chức tái định chỉ mục và định phân mức tự động, mang tiện tích hỗ trợ Scale. Nên lưu ý một điểm nếu cài đặt các thông số thiết kế kết cấu chia khóa tìm truy vết Partition Key thiếu khảo sát chuỗi logic, dòng phân phối lưu dữ bị ứ trệ, không gian điểm giới hạn bùng lên khối quá tải cục bộ nhận áp lực quá giới hạn (tiếp nhận thông tin gọi là Hotspot).

## IV. Kết luận

Mô hình thiết kế kiến trúc thông tin vận hành từ các cụm cơ sở dữ liệu phân tán (Polyglot Persistence) nêu bật những khía cạnh đánh đổi (trade-offs) khác biệt có thể xảy ra trong việc lựa chọn giữa hệ sinh thái lưu lượng. Nắm rõ được nguyên lý và giới hạn năng lực giúp hệ lưu trữ của ứng dụng vận hành được định chuẩn giải pháp bền vững an toàn tại mức quản lý phức hợp khi kết cấu liên dịch vụ tương tác trên các nền tảng hệ điều hướng (Database Driver).

# references
## 0
### alias
StarCi — Database Scaling (repo 4.3)
### url
https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/database-scaling
## 1
### alias
Bitnami — postgresql-ha chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/postgresql-ha
## 2
### alias
Bitnami — redis-cluster chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/redis-cluster
## 3
### alias
Bitnami — mongodb-sharded
### url
https://github.com/bitnami/charts/tree/main/bitnami/mongodb-sharded
## 4
### alias
Bitnami — cassandra chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/cassandra

# minutesRead
38
