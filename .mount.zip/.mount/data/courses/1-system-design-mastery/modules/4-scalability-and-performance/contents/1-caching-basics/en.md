# title
Caching Basics: Shielding the Database from Read Storms

# description
Four layers of deep defense cache in the system — Nginx Microcaching at the edge, manual Cache-Aside, TypeORM query cache, and NestJS Response Cache. The application tier integrates a Keyv multi-tier store (in-process LRU + Redis) with a strict invalidation strategy to ensure you never serve stale data; perfectly scalable via Kubernetes.

# body

## I. Introduction

Your app scales out to **20 instances**. Everything runs smoothly — until a celebrity tweets about one of your products. Suddenly **5 million requests** hammer the exact **same** product page. All 20 instances fire the same query — `SELECT * FROM products WHERE id = 1` — at the **single database**. Read locks pile up, CPU hits **100%**, the database freezes.

The application tier is fine; the bottleneck is the storage tier being asked the same question millions of times. If the answer has not changed since one millisecond ago, why ask the database again? **Caching** is the art of remembering recent answers in extremely fast memory so the DB does not have to bear unnecessary load. A well-placed cache can absorb **more than 90%** of all read traffic right at the gates — and in practice, you rarely stop at **one** layer: traffic flows through **Nginx → in-process LRU → Redis shared → Database**, with each layer blocking a slice of the traffic.

## II. Visual Demo and Hands-on

The **repo** below implements **four cache patterns** (4 cache layers) simultaneously on the same sample **Product** dataset:

- **Nginx Microcaching** — completely blocks repeated requests at the network edge using `proxy_cache`. This is the outermost defense layer.
- **NestJS Response cache** via `CacheInterceptor` — stops requests at the application edge, caching the entire JSON body.
- **TypeORM Query-level cache** — chaining `.cache(id, ttl)` on the `QueryBuilder` caches the resulting **SQL** operations.
- **Manual Cache-Aside** via `@Inject(CACHE_MANAGER)` — the application manually handles `get/set/del` on `product:{id}` keys.

Deep inside the Node.js application, the CacheModule is configured as **multi-tier**: tier 1 is an **in-memory LRU** local to each process, tier 2 is a shared **Redis**. The destination is **Postgres**, which is forced to sleep for **300 ms** (using `pg_sleep(0.3)`) to simulate slow queries. This exact setup helps measure the true DB cost without getting skewed by VM overhead.

**Clone** here: [Caching Basics — demo](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/caching-basics)

| Component | Port | Tech | Responsibility |
|-----------|------|------|----------------|
| **Nginx** | **8080** | **Nginx** | Layer 1: Edge Proxy blocking repeated network traffic via Microcaching |
| **cache-app** | **3000** | **NestJS** + **TypeORM** | Layers 2, 3, 4: `GET`, `PUT` API — Internal application cache interception |
| **Postgres** | **5432** | **PostgreSQL 16** | The `products` table — Source of Truth; simulates high latency |
| **Redis** | **6379** | **Redis 7** | Tier-2 cache shared across all pods for the multi-tier system |

![Architecture of four cache layers with Nginx at the edge, LRU in-process and shared Redis](https://starci.org/system-design-mastery/caching-basics/0.svg)

*Figure 1. Read traffic flows through: Nginx → LRU → Redis → Postgres; Write traffic flows the other way and strictly invalidates caches.*

### 1. Environment setup and run

#### 1.0. Kubernetes (recommended for this module)

Assume **kubectl** is configured against a cluster (**Minikube**, **kind**, or **Docker Desktop**). The same **`starci183`** namespace already publishes pull-and-run images — for example `starci183/scalibity-postgres-app:latest` and `starci183/scalibity-sqlite-app:latest` from the scalability fundamentals lab — so you are not forced to build everything from scratch to learn the workflow. For this caching lab, check `image` in `cache-app-deployment.yaml`: you can use a published tag (for example `starci183/caching-cache-app:latest` after it is pushed) instead of a local build.

**Optional: build** the `cache-app` image when you are changing code or no public tag is published yet:

```
cd example-backend
docker compose -f docker-compose.yaml build
docker push starci183/caching-cache-app:latest
```

From the demo repo root, apply manifests layer by layer:

```
kubectl apply -f postgres-pod.yaml
kubectl apply -f postgres-service.yaml
kubectl apply -f redis-pod.yaml
kubectl apply -f redis-service.yaml
kubectl apply -f cache-app-deployment.yaml
kubectl apply -f cache-app-service.yaml
kubectl apply -f nginx-configmap.yaml
kubectl apply -f nginx-deployment.yaml
kubectl apply -f nginx-service.yaml
```

Wait until pods are ready:

```
kubectl wait --for=condition=Ready pod/postgres-pod --timeout=120s
kubectl wait --for=condition=Ready pod/redis-pod --timeout=120s
kubectl rollout status deploy/cache-app --timeout=120s
kubectl rollout status deploy/nginx-cache --timeout=120s
```

Check status:

```
kubectl get pods -o wide
kubectl get services
```

The `nginx-cache-service` exposes **NodePort 30080** for clients outside the cluster; `cache-app-service`, `redis-service`, and `postgres-service` stay **ClusterIP**. To hit the app directly (bypassing Nginx) for latency comparison:

```
kubectl port-forward svc/cache-app-service 3000:3000
```

**Expected result:** `postgres-pod`, `redis-pod`, and `nginx-cache-*` are `Running`; `cache-app` shows `2/2 READY`. Through Nginx: `curl -s http://<NODE_IP>:30080/products/health` returns `{ "pod": "...", "ok": true }`. Through port-forward, `http://localhost:3000/products/health` returns the same JSON.

#### 1.1. Docker Compose (local stack only)

If you prefer a single-node stack with **Docker** only, from **`example-backend/`** bring up Nginx, Postgres, Redis, and cache-app:

```
cd example-backend
docker compose up --build -d
```

Verify via the Nginx frontend:

```
docker compose ps
curl -s http://localhost:8080/products/health
```

**Expected result:** four containers `caching-nginx`, `caching-postgres`, `caching-redis`, and `caching-cache-app` are `Up`. The health endpoint returns `{ "pod": "...", "ok": true }`. The stack seeds 50 sample products. Read tests below use port `8080`.

#### 1.2. From lab Nginx to Nginx Ingress in production

When you move this lab to a shared cluster, the local Nginx container is often replaced by an **Nginx Ingress Controller** with `proxy_cache` enabled: StatefulSets (or managed services) for **Postgres** and **Redis** behind ClusterIP, several `cache-app` replicas, and Ingress annotations to turn on edge microcaching while keeping the same four-layer caching story.

### 2. Nginx Microcaching — Layer 1: The Outermost Shield

**Nginx Microcaching** stands as a robust barrier right at the perimeter of the network. If dynamic requests present minimal changes, you configure caching on Nginx. It instantly serves responses from its dedicated memory block. Your NestJS application "literally has no idea" a request even occurred.

**Equivalent `curl` command** — observe the Headers using `-D`:

```
curl -s -D - http://localhost:8080/products/stats/summary
curl -s -D - http://localhost:8080/products/stats/summary
```

On the first ping, watch for: `X-Proxy-Cache: MISS`. Followed immediately on the second request by an instantaneous `X-Proxy-Cache: HIT`.

**Expected result:** Astronomical speeds (~**0.1 ms**). Blocking garbage requests and duplicate traffic at the Edge Controller significantly reduces cloud computation costs. Pro tip: simply setting an extremely brief TTL (**1 to 5 seconds**) is sufficient to suppress 99% of a Thundering Herd incident with minimal chance of serving stale data.

### 3. NestJS Response Cache — Layer 2: Application Boundary

Once past Nginx, the internal `GET /products/stats/summary` hits `@UseInterceptors(CacheInterceptor)`. The framework aggressively intercepts the logic, stuffing the full JSON output into memory.

Analysis: At this depth, the TCP socket directly enters the V8 Engine process inside NodeJS. While it consumes JS engine memory capacity, it forcefully prevents resource-heavy Logic/Controller functions from executing. Still massively cheaper than executing database scans.

### 4. TypeORM Query-level Cache — Layer 3: Database Query Level

Deep inside at the ORM layer, TypeORM specifies `cache: { type: 'redis', ... }`, operating alongside chained functions like `.cache('products:1', 30_000)` via the `QueryBuilder`.

```
curl -s http://localhost:8080/products
```

On request 1, we get `"source": "db", "durationMs": 45...`
Request 2 responds near-instantly with `"source": "typeorm-cache"`. The heavy SQL translation overhead is completely bypassed. This methodology dominates scenarios involving read-heavy Leaderboards and E-commerce homepages.

### 5. Multi-tier Cache-Aside — Layer 4: The Fundamental Core

When request patterns are purely unpredictable, you must write direct Cache-Aside routines with logic conditions via `get/set` (i.e. manually managed through `@Inject(CACHE_MANAGER)`). This effectively taps into the Multi-Tier architecture.

- **Storage Miss** (Lagging ~300ms from pg_sleep): miss -> hit DB -> sync LRU & Redis.
- **Fast Hit** (~ 1-3ms): Reads directly from local process LRU cache. Refuses to even initiate TCP payload delivery out to Redis.

However, this layer commands the brutal reality of Caching Invalidation.
When pricing elements update (PUT request):

```
curl -X PUT http://localhost:8080/products/1/price -H "Content-Type: application/json" -d "{\"price\": 1099}"
```

Result output: `"invalidated": ["product:1", "products:stats-summary", "products:cheapest"]`. Upon update completion, our internal application logic must strictly **fan-out and purge all three internal layers** (Layers 2, 3, and 4). (The outer Nginx edge proxy remains untouched, letting the brutally short TTL window auto-resolve).

## III. Advanced Theory and Conclusion

### 1. The Superiority of RAM

Relative to modern tech, the latency differential is massive:
**Wait times from Disk SSD (Postgres Cache Miss):** heavy 10–100 ms.
**Wait times across Network via Redis (TCP Hit):** slow 0.3–1 ms.
**In-Process RAM (Local LRU hit):** near-instant < 0.001 ms.
**Edge Microcache (Nginx Hit):** < 0.1 ms fully bypassing NodeJS IO.
Stack the caching planes properly, and your single-node system casually absorbs x100 traffic volume.

### 2. Pain Points of Invalidation Strategies

- **Write-Through / Broadcast:** Ensure you obliterate old cache fragments via Redis Pub/Sub messaging across local Pod nodes locally.
- **Preventing Cache Avalanche:** Strategically inject a percentage of Jitter variables (±10% to the TTL lifespan). Stagger their expiration effectively shielding against synchronized stampedes that annihilate Database power.
- **Preventing Cache Penetration:** Cache "missing keys" directly as `null` with a lightning fast TTL and protect empty lookups with powerful Bloom Filters.

### 3. Ultimate Caching Patterns

| Sentinel Tier | Essential Characteristics |
|---------------|---------------------------|
| **Nginx Edge proxy** | Ruthless request blockade. Very complicated to manually purge or trigger invalidations. |
| **Response Cache** | Fully hijacks Application controllers. Best for endpoints with high processing but limited variance. |
| **Query Cache** | Excellent for avoiding Database driver translations and massive query sort algorithms. |
| **Cache Aside** | Highly flexible and standard default. Opens doors to lethal "Stale Output" coding errors. |

Those specific `"durationMs"` console measurements exist purely to validate this ruthless, surgical removal of unnecessary milliseconds within your distributed system architecture.

# references
## 0
### alias
Redis — Caching Architecture Guidelines
### url
https://redis.io/learn/howtos/solutions/caching-architecture
## 1
### alias
AWS — Cache-Aside Design
### url
https://docs.aws.amazon.com/prescriptive-guidance/latest/cloud-design-patterns/cache-aside.html
## 2
### alias
NestJS — Caching Setup
### url
https://docs.nestjs.com/techniques/caching
## 3
### alias
Nginx — Microcaching Pattern
### url
https://www.nginx.com/blog/benefits-of-microcaching-nginx/
## 4
### alias
Kubernetes — Ingress Implementation
### url
https://kubernetes.io/docs/concepts/services-networking/ingress/

# minutesRead
30
