# title
Database Scaling: The Polyglot Battlefield on Kubernetes

# description
There is no "silver bullet" or universal playbook that cures every scaling disease. This lesson drags you into the brutal reality of architecture: A single NestJS service forced to communicate, survive, and parallel-scale across four tyrant families of Storage (PostgreSQL HA, Redis Cluster, MongoDB Sharded, and Cassandra).

# body

## I. Introduction

Once you have fortified the application behind a Load Balancer shield and deflected read storms with 4 layers of Caching, your system looks "immortal." But it's just an illusion until the **WRITE** traffic hits. Millions of financial transactions, order histories, and user profiles... bypassing all caches and slamming directly into the final Storage tier. Locks stack up and scream, Disk I/O catches fire, Database CPU artificially hits **100%**, and your system crumbles before your eyes.

I apologize, but this argument is cold and decisive: **there is no magical recipe called "Scale the Database" for every corner of the system.** Inexperienced "beta" coders often naively assume that simply "adding replicas" solves everything. However:
- **Postgres-class (OLTP)** systems speak in Primaries, Standbys, and Connection Poolers.
- **MongoDB (Document)** shards using Replica Sets, Routers (`mongos`), and precise Shard Keys.
- **Redis (In-memory/Key-value)** hashes data across exactly 16,384 Hash Slots in a Cluster.
- **Cassandra (Wide-column)** lines up in a Ring Topology, managed via Consistency Levels (CL) and Replication Factors (RF).

Taking that cheap "read-replica" logic from SQL and casually applying it to the NoSQL family without understanding system Semantics guarantees massive data loss and eventual bankruptcy via server costs. In this lesson, we will get our hands dirty wrestling the **four greatest Database families** on a single Kubernetes cluster.

## II. Visual Demo and Hands-on: Polyglot Nightmare

This practice repo isn't making some toy app. In module **4.3**, we implement the brutal truth of Distributed Architecture (Polyglot Persistence): **four** storage instances launched simultaneously via Helm (Bitnami OCI), with a lone **NestJS** backend straining to speak four distinct driver "languages" to interoperate with them.

**Architecture Diagram (refer to `0.drawio` included)**

![Architecture diagram of a Polyglot app calling 4 families of Databases](https://starci.org/system-design-mastery/database-scaling/0.svg)

*Figure 1. Polyglot Persistence Architecture: One application forced to shoulder four complex Topologies. That is the necessary price of ultimate optimization (Cognitive Tax).*

**Clone the lab source right here:** [Database Scaling — Module 4.3](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/database-scaling)

The layout you must face:
```
database-scaling/
├── helm/                 # postgresql-ha, redis-cluster, mongodb-sharded, cassandra
├── example-backend/      # NestJS — TypeORM, Mongoose, ioredis Cluster, cassandra-driver
└── README.md
```

### 1. Summoning 4 Storage Tyrants into Kubernetes

**Vital Prerequisites:** Readied Kubernetes Cluster, Helm 3.8+ (OCI) installed. The Charts intentionally override to `bitnamilegacy` images for environmental stability. No excuses, run these directly on Linux/macOS:

```
cd helm/postgresql-ha && ./run.sh && cd ../..
cd helm/redis-cluster   && ./run.sh && cd ../..
cd helm/mongodb-sharded && ./run.sh && cd ../..
cd helm/cassandra       && ./run.sh && cd ../..
```

*(Soldiers on Windows, use PowerShell to execute `run.ps1`. No whining).*

**Battlefield Cleanup (After tests):**
```
helm uninstall postgresql-ha redis-cluster mongodb-sharded cassandra -n database
kubectl delete pvc --all -n database
kubectl delete namespace database
```

### 2. Forward the ports and fire up `example-backend`

Our application defaults to blindly pinging internal cluster DNS natively. To run this Locally, puncture the wall with Port-forwards:

```
kubectl port-forward -n database svc/postgresql-ha-pgpool 5432:5432
kubectl port-forward -n database svc/redis-cluster 6379:6379
kubectl port-forward -n database svc/mongodb-sharded-mongodb-sharded 27017:27017
kubectl port-forward -n database svc/cassandra 9042:9042
```

Next, boot NestJS, aim `.env` to host `127.0.0.1`, and spark the machine:

```
cd example-backend
npm install
cp .env.example .env
npx nest start --watch
```

### 3. Life-and-Death API Checks

The absolute truth emerges via these endpoints:
- **`GET /health`** — Ensure the app is breathing.
- **`GET /integrations`** — The lethal Ping command sent **in parallel** to Postgres (via Pgpool), Redis Cluster, Mongo (via mongos), and Cassandra. Emits `{ ok, ms, detail }` results. Fails explicitly smash your screen so you know instantly which cluster just imploded.
- **`POST /integrations/demo-write`** — A multi-pronged assault: Writes payloads to MongoDB + Cassandra whilst concurrently advancing an atomic counter inside Redis.

```
curl -s http://localhost:3000/integrations
curl -X POST http://localhost:3000/integrations/demo-write -H "Content-Type: application/json" -d "{\"message\":\"Polyglot bloodline\"}"
```

**Bloody Conclusion:** Wiring a single sophisticated multi-platform backend explodes your codebase to incorporate 4 isolated clients, 4 error-handling scopes, and 4 absolute scaling schemas. Do not boast about employing Microservices until you taste Polyglot Persistence!

---

## III. Dissecting the Scale Structures of the 4 Database Families

With everything running, sit down and internalize this architectural blueprint before wandering out and wrecking someone else's Production stack:

| Family | "Read Scaling" Playbook | "Write / Capacity" Heavy Artillery | Destruction Traps |
|--------|-------------------------|------------------------------------|-------------------|
| **Relational OLTP** (Postgres, MySQL…) | Sync/Async Replicas, load balancer Poolers (Pgpool) | Spend cash on massive VMs (Scale-up); Hardcode Application-tier Sharding. | **Replication Lag**: Hitting stale reads on Replicas; Catastrophic Cross-table `JOIN` costs. |
| **Document** (MongoDB…) | Add Secondaries in the Replica Set | **Sharded cluster**, `mongos` traffic routers, intentional Shard Keys | Choosing a foolish Shard Key → Suffer lethal **Scatter/Gather** execution times. |
| **Key-Value** (Redis…) | Break off separate Read Replicas | **Redis Cluster** allocating 16,384 Hash slots | Data evicting via expired TTLs. Fails as primary System of Record DB. |
| **Wide-Column** (Cassandra…) | Ring Topology layout, Modulate CL on reads | Dump extra Hardware (Scale-out); Construct Partition Keys on query behaviors | Foolishly calibrating RF/CL resulting in ghost datasets. |

### 1. PostgreSQL HA + Pgpool: Noble Armor
The `postgresql-ha` demo heavily forbids the application from speaking to instances manually. Apps consult the **Pgpool** Mask. Pgpool violently directs Read-heavy traffic to Standby Nodes and spears Write traffic dead onto the Primary (master).
Does Pgpool save you from **Replication Lag**? No. Rows take roughly 10ms to replicate. If a user Updates Profile and spams F5 instantly, routing to a slow Replica flashes stale profile info. Elite-tier code forces strict `Read-after-Write` behavior right to the Master.

### 2. Redis Cluster: The 16,384 Hash Slot Matrix
Scaling Redis involves mathematical wizardry across exactly 16,384 algorithmic Slots. Scale-out actions dictate pulling active slots from old Masters and porting into the new Master (Slot Migration). The app dynamically pings the Cluster continuously refreshing its geographic internal Token maps.

### 3. MongoDB Sharded: The Mongos Illusion
Pampered developers adore **Mongos** because it entirely masks physical topology. MongoDB seamlessly scatters data horizontally inside Shard chunks.
"Seamless scattering" sounds magical, until you issue queries completely lacking the Shard Key. In that event, Mongos fires a Broadcast to essentially wake up the entire available Cluster networks (**Scatter/Gather** anomaly). The demo inserts the `bucket` field purposely exposing you to logic-based Sharding semantics.
To violently awake, open mongosh and input:
```javascript
sh.enableSharding("demo");
sh.shardCollection("demo.integration_events", { bucket: 1 });
```

### 4. Cassandra: The Dark Ring
Within this laboratory environment, the configuration utilizes `RF=1` (Replication Factor = 1) for lazy convenience. Massive monolithic Production environments aggressively increase RF to 3, with Consistency Quorums = 2. Want to scale Writes? Just violently toss another Server node into the visual Ring Topology. The Native Consistent Hashing logic auto-balances data disks without downtime. But insert foolish Partition Keys, and it aggregates pure fire (Hotspots) entirely melting a single physical chassis under the load.

## IV. The Core of High-End Scaling

Dividing multi-tiered Storage unveils tyrannical pain upon naive software engineers. A veteran architect inherently knows to "Inject the right Storage Primitive matching the targeted Access Pattern". Do not wield a butcher knife (Cassandra) to merely chop up an Admin User table (Postgres). Lab 4.3 aggressively hands you the Helm blueprints, compelling you to experience the anguish of a NodeJS App completely surrounded by distributed "War Gods."

# references
## 0
### alias
StarCi — Database Scaling (Repo 4.3)
### url
https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/database-scaling
## 1
### alias
Bitnami — postgresql-ha chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/postgresql-ha
## 2
### alias
Bitnami — redis-cluster chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/redis-cluster
## 3
### alias
Bitnami — mongodb-sharded
### url
https://github.com/bitnami/charts/tree/main/bitnami/mongodb-sharded
## 4
### alias
Bitnami — cassandra chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/cassandra

# minutesRead
38
