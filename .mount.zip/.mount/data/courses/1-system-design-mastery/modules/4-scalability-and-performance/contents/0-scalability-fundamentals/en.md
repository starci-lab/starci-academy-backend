# title
What is Scalability? Bottlenecks During Traffic Spikes

# description
The core concept of scalability and why systems usually break at the stateful layer rather than the application when user traffic suddenly spikes — demonstrated on Kubernetes with two NestJS apps: one stateless (Postgres) that scales cleanly, and one stateful (SQLite) that fractures on scale-out — then a deep dive into the Single Point of Failure at the state layer and how to mitigate it.

# body

## I. Introduction

In interviews the question *"If traffic spikes **10×**, what do you do?"* separates those who understand distributed architecture from those who do not. Most jump straight to *"add more **RAM**"* or *"spin up more **instances**."* But what if the system is still stuck at the **database** layer after you doubled the hardware? The real problem is not any single component — it is that **stateful** resources (databases, session stores, anything that must persist between requests) become the bottleneck whenever load grows, while **stateless** compute can scale freely. Worse, the stateful tier is usually a **Single Point of Failure** — a single **Postgres** dying takes down the entire **API**, even with **50 app replicas** running on top.

This lesson hands you the mental model: when requests spike, where exactly the system **breaks**, what makes a component scalable or not, and how to dodge **SPOF** at the state layer — then you prove it on a running **Kubernetes** cluster.

## II. Visual Demo and Hands-on

The **repo** below is a **NestJS** **monorepo** containing **two apps** that share the exact same **TypeORM** entity (`Note`) and controller. The only difference is **where they store state**:

- **`postgres-app`** — connects to a **shared Postgres Pod** via a **ClusterIP Service** → from the app's perspective the process is **stateless**, because all pods read and write the same database.
- **`sqlite-app`** — writes to a **local SQLite file** inside each pod's own `emptyDir` → each pod holds its **own state**, making the app **stateful**.

Both apps are deployed as **Kubernetes Deployments** exposed via **ClusterIP Services** — not open to the outside. To hit them from the host we use **`kubectl port-forward`** to tunnel the internal cluster port down to our local machine.

**Clone** here: [Scalability Fundamental — demo (Kubernetes)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/scalibity-fundamental)

| Component | Internal port (ClusterIP) | Local port (port-forward) | Tech | Responsibility |
|-----------|------|------|------|----------------|
| **postgres-app** | **3000** | **3001** | **NestJS** + **TypeORM** (pg driver) | `POST /notes`, `GET /notes` — writes to **shared Postgres** |
| **sqlite-app** | **3000** | **3002** | **NestJS** + **TypeORM** (sqlite3 driver) | `POST /notes`, `GET /notes` — writes to **local SQLite file** per pod |
| **Postgres Pod** | **5432** (ClusterIP) | — | **PostgreSQL** | Shared state store for `postgres-app` |

![Architecture diagram of stateless and stateful applications deployed on Kubernetes](https://starci.org/system-design-mastery/scalability-fundamentals/1.svg)

*Figure 1. System architecture diagram from the source above.*

The architecture illustrates two independent **Deployments**: `postgres-app` stores state in a shared **Postgres Pod** (rendering the app completely **stateless**), while `sqlite-app` writes data directly to each Pod's local `emptyDir` volume (making it **stateful**).

### 1. Environment setup and deploy

Assumes **kubectl** is connected to a cluster (**Minikube**, **kind**, or **Docker Desktop**). You can use the pre-built registry images (`starci183/scalibity-postgres-app:latest`, `starci183/scalibity-sqlite-app:latest`), or build them yourself to see how the codebase is containerized.

From the **`example-backend/`** directory inside the repo, build and push both images:

```shell
cd example-backend
docker compose -f apps/postgres-app/docker-compose.yaml build
docker push starci183/scalibity-postgres-app:latest
docker compose -f apps/sqlite-app/docker-compose.yaml build
docker push starci183/scalibity-sqlite-app:latest
```

Back at the demo repo root, apply all manifests:

```
kubectl apply -f postgres-pod.yaml
kubectl apply -f postgres-service.yaml
kubectl apply -f postgres-app-deployment.yaml
kubectl apply -f postgres-app-service.yaml
kubectl apply -f sqlite-app-deployment.yaml
kubectl apply -f sqlite-app-service.yaml
```

Wait for everything to be ready:

```
kubectl wait --for=condition=Ready pod/postgres-pod --timeout=120s
kubectl rollout status deploy/postgres-app --timeout=120s
kubectl rollout status deploy/sqlite-app   --timeout=120s
```

Verify:

```
kubectl get pods -o wide
kubectl get services
```

Both **Services** are **ClusterIP** (internal port **3000**) — not exposed outside the cluster. To reach them from your host, open **two separate terminals** and run **`kubectl port-forward`** (keep them alive for the whole demo):

```
kubectl port-forward svc/postgres-app-service 3001:3000
```

```
kubectl port-forward svc/sqlite-app-service 3002:3000
```

These commands open ports **3001** and **3002** on your host and tunnel them into the corresponding in-cluster **Service**. Kubernetes still round-robins requests across the pods behind each Service as usual.

**Expected result**

All Pods are `Running`. The two `port-forward` terminals print `Forwarding from 127.0.0.1:3001 -> 3000` and the equivalent for **3002**. From the host, `curl http://localhost:3001/notes` and `curl http://localhost:3002/notes` both work.

**Conclusion**

Two identical codebases (same entity, same controller) are running on the cluster, reachable only via **port-forward**. The **only** difference is the storage backend: one uses a shared **Postgres** Pod, the other writes to a local **SQLite** file. This is the setup needed to prove that scalability lives or dies at the **state** layer.

### 2. Stateless scales — postgres-app

Scale the **stateless** app to **5** replicas:

```
kubectl scale deploy/postgres-app --replicas=5
kubectl rollout status deploy/postgres-app --timeout=120s
```

Create **6 notes** through the port-forward:

```
for i in 1 2 3 4 5 6; do
  curl -s -X POST http://localhost:3001/notes \
    -H "Content-Type: application/json" \
    -d "{\"content\":\"note-$i\"}"
  echo
done
```

Read them back:

```
curl -s http://localhost:3001/notes
```

**Expected result**

Every `GET /notes` returns **all 6 notes** with `count=6`. Note: `kubectl port-forward svc/...` pins the connection to **one pod** for the whole session — so `createdByPod` may resolve to the same pod. To observe multiple pods writing, open **several parallel port-forward sessions**, or `exec` curl from inside a different pod in the cluster. The core claim still holds: **any pod reads the full dataset** because they all share **Postgres**.

Scale back down to verify data persists:

```
kubectl scale deploy/postgres-app --replicas=1
kubectl rollout status deploy/postgres-app --timeout=60s
curl -s http://localhost:3001/notes
```

**Expected result**

Still **6 notes**. Pods come and go but the data lives in **Postgres** — the app is truly **stateless**.

**Conclusion**

When state is externalized to a dedicated service (**Postgres**), the app tier can scale horizontally without losing data or consistency. The **Service** round-robins freely because every replica is identical and disposable.

### 3. Stateful breaks — sqlite-app

Scale the **stateful** app to **3** replicas:

```
kubectl scale deploy/sqlite-app --replicas=3
kubectl rollout status deploy/sqlite-app --timeout=120s
```

Create **9 notes**:

```
for i in $(seq 1 9); do
  curl -s -X POST http://localhost:3002/notes \
    -H "Content-Type: application/json" \
    -d "{\"content\":\"sqlite-$i\"}"
  echo
done
```

Read multiple times:

```
for i in 1 2 3 4 5 6; do
  curl -s http://localhost:3002/notes
  echo
done
```

**Expected result**

Running **multiple parallel `kubectl port-forward svc/sqlite-app-service 3002:3000`** sessions (each pinned to a different pod) makes each session return a **different** `count` — `3`, `2`, `4`, … — because every pod only sees the notes that **it** received. The `id` values even collide (each SQLite auto-increments from 1 independently). In other words: with a real **Load Balancer** in front (or with Service round-robin when the caller sits inside the cluster), users see the data **jumping around** between calls.

Scale down:

```
kubectl scale deploy/sqlite-app --replicas=1
curl -s http://localhost:3002/notes
```

**Expected result**

Two pods were deleted → their `emptyDir` volumes were destroyed → **two SQLite files with their notes are gone forever**. A rolling update produces the same disaster: new pod = new `emptyDir` = blank database.

**Conclusion**

When state lives inside the pod (local filesystem), **horizontal scaling fractures the data** and **scale-down loses it permanently**. This is the classic **stateful anti-pattern** in container orchestration. If state must live in a pod, the minimum requirement is a **StatefulSet** with **PersistentVolumeClaim** — but even then, it is not true horizontal scaling in the classical sense.

### 4. The Postgres Pod is a Single Point of Failure — kill it and watch

Scale `postgres-app` back to **5 replicas** for "strength":

```
kubectl scale deploy/postgres-app --replicas=5
kubectl rollout status deploy/postgres-app --timeout=60s
```

Confirm the app can still read data:

```
curl -s http://localhost:3001/notes
```

Now **delete** the only Postgres pod holding state:

```
kubectl delete pod postgres-pod
```

Immediately retry the requests:

```
curl -s -X POST http://localhost:3001/notes \
  -H "Content-Type: application/json" \
  -d "{\"content\":\"after-db-down\"}"
curl -s http://localhost:3001/notes
```

**Expected result**

**All 5 `postgres-app` pods are still `Running` and healthy**, yet every request returns **500** / **ECONNREFUSED** — the app has nothing to read from or write to. Check:

```
kubectl get pods
kubectl logs deploy/postgres-app --tail=20
```

App logs are flooded with connection errors to **`postgres-service:5432`**. The entire **API** sits behind a **single service** at the state tier — this is the **Single Point of Failure**, even though the compute tier scales horizontally just fine.

Wait for Kubernetes to recreate the Postgres pod (roughly **10–30s**):

```
kubectl wait --for=condition=Ready pod -l app=postgres --timeout=120s
curl -s http://localhost:3001/notes
```

**Expected result**

The new `postgres-pod` is `Running`, the API is live again — but because this is a single **Pod** with an `emptyDir` volume, **all 6 previous notes are gone**. To preserve data across restarts, you need a **StatefulSet** + **PersistentVolumeClaim**; to avoid the tens-of-seconds downtime when the pod dies, you need **multiple replicas** + **automatic failover**.

**Conclusion**

**Making the app stateless only solves half the problem** — the underlying state tier can still be a **SPOF**. In this demo, the **single Postgres Pod** is a hard failure point: when it goes down, all **5 app replicas** are useless. Section **III.3** below covers how this SPOF is dodged in practice.

## III. Advanced Theory and Conclusion

### 1. What Scalability really means

**Scalability** is not "throw money at more servers." It is the ability of a system to **maintain or improve** performance (throughput, latency) **proportionally** as you add resources. If you double the hardware of a badly designed system and capacity only grows **20%**, that system is **not scalable**.

- **Example:** The **`postgres-app`** Deployment scales nearly linearly — add a fifth replica, handle roughly a fifth more request throughput. The ceiling is wherever the shared state lives: in this case, the **Postgres** Pod.
- **Example:** The **`sqlite-app`** Deployment adds replicas, but the result is **worse** than not scaling at all: data fractures, reads become inconsistent, and scale-down causes permanent data loss.

### 2. Vertical vs Horizontal Scaling

When load exceeds capacity you face two families of response:

- **Scale Up (Vertical Scaling):** Upgrade the current machine — more **RAM**, faster CPU, bigger SSD. Zero code changes, fast to apply. The ceiling is absolute hardware limits and a **single point of failure**: if that one bigger machine dies, everything dies.
- **Scale Out (Horizontal Scaling):** Add more small machines and distribute the work. This is the superpower of distributed architecture — in theory the ceiling keeps rising as you add nodes. The trade-off is operational complexity: you need a **Load Balancer** (or a **Kubernetes Service**), you must ensure the app is **stateless**, and data consistency across nodes becomes a real engineering problem.

The demo above shows why **horizontal scaling** demands a **stateless** application. The `postgres-app` works at any replica count because state has been externalized to **Postgres**; the `sqlite-app` breaks the instant a second replica appears.

### 3. Single Point of Failure at the state tier — and how to mitigate it

A **SPOF** is any component where "if it dies, the whole system dies." In the demo above, the **single Postgres Pod** is exactly that: **5 healthy replicas** of `postgres-app` cannot save anything when that Pod goes down. The general rule: **making the app stateless just pushes the SPOF down to the state tier**, it does not eliminate it — you need the right technique to dodge it.

A few mitigations, in increasing order of complexity:

- **Persistent volume — prevents data loss, not downtime.** Switch `postgres-pod.yaml` to a **StatefulSet** + **PersistentVolumeClaim**. If the pod dies, Kubernetes recreates it and **reattaches the same volume** → data survives. But during the restart, the API is still **down for tens of seconds**.
- **Primary-Replica + automatic failover — prevents downtime.** Run **at least 2 Postgres nodes** with **streaming replication**, fronted by a coordinator (**Patroni** + **etcd**, **pg_auto_failover**, or the **CloudNativePG operator** on Kubernetes). If the primary dies, a replica is promoted to new primary within **seconds**, and the app reconnects via DNS/virtual IP. This is "lose the primary, keep the service."
- **Read Replicas — dodge SPOF on the read path and offload reads.** Replicate read-only copies for `SELECT` queries. When the primary dies, replicas still serve reads (degraded mode) while failover is in flight.
- **Managed databases** (**RDS**, **Cloud SQL**, **Neon**, **Supabase**…) — the provider handles replication, backups, and failover. More expensive but removes most operational burden; a sensible default for most product teams.
- **Health checks + retries + circuit breaker on the client side** — the app must **treat the DB connection as potentially broken at any time**: short timeouts, backoff retries, and never let a single DB error block the event loop. Without this, no matter how fast the infrastructure fails over, users still see raw errors.
- **Apply the same logic system-wide:** every tier (API Gateway, cache, message broker, DNS, load balancer) can be a SPOF. The rule "**no single replica of anything critical**" applies universally — always run ≥2 instances with automatic failover.

Back to the lesson context: the demo uses **one Postgres Pod with `emptyDir`** for pedagogical reasons — it exposes the SPOF plainly. **Nobody** runs production like that; the following lessons (**Database Scaling**, **Horizontal Scaling & Load Balancing**) dive into each of these techniques in depth.

### 4. Where the bottleneck really lives

A useful mental model: trace the path of a request and look for the **stateful** component that cannot be freely replicated.

- **API layer** — typically stateless, scales horizontally behind a **Kubernetes Service** or **Load Balancer**.
- **Cache layer** (**Redis**, **Memcached**) — shared state, but purpose-built to handle extreme read throughput; can be clustered.
- **Database layer** — the final stateful frontier. Writes must go to a single primary (or a coordinated shard group). When write load exceeds what one node can handle, you need **Read Replicas** (offload reads) or **Sharding** (split writes across multiple nodes) — both carry serious trade-offs.

### 5. Key takeaways

- **State decides scalability.** Same codebase, different state location → flipping from scalable to not.
- **Apps must be stateless; push state to dedicated state services** (**Postgres**, **Redis**, **S3** …).
- **`Deployment` + local filesystem = anti-pattern.** If state must live in a pod, use **StatefulSet** + **PersistentVolumeClaim** — but that is still not "horizontal scaling."
- **Service round-robin cannot save local state** — users see results jumping around, exactly like the `sqlite-app` demo.
- **A stateless app does not eliminate SPOF — it pushes SPOF down to the state tier.** Mitigate with **replication + automatic failover**, **PersistentVolumeClaim**, or a **managed database**.
- **The real ceiling is the stateful tier.** When traffic increases **10×**, `postgres-app` scales linearly; the bottleneck lands squarely on **Postgres** — and that is when techniques like **Read Replicas**, **Sharding**, and **Caching** become necessary.

# references
## 0
### alias
The Twelve-Factor App — Processes
### url
https://12factor.net/processes
## 1
### alias
Kubernetes — Deployments
### url
https://kubernetes.io/docs/concepts/workloads/controllers/deployment/
## 2
### alias
Kubernetes — Services
### url
https://kubernetes.io/docs/concepts/services-networking/service/
## 3
### alias
Kubernetes — StatefulSets
### url
https://kubernetes.io/docs/concepts/workloads/controllers/statefulset/
## 4
### alias
CloudNativePG — PostgreSQL Operator for Kubernetes
### url
https://cloudnative-pg.io/

# minutesRead
30
