# title
Microservices & Kubernetes Fundamentals

# description
An introduction to Microservices and Kubernetes at a foundational level. Learn when to split services, what you gain and lose versus a monolith, and how Kubernetes helps run and scale modern systems.

# previewContents
## 0
### text
What are Microservices? Compare with a Monolith architecture.
## 1
### text
Why large systems often need to be split into multiple services.
## 2
### text
Pros and cons of Microservices.
## 3
### text
What is Kubernetes and what problems it solves in operations.
## 4
### text
Core Kubernetes concepts: Pod, Deployment, Service.
## 5
### text
How Microservices and Kubernetes work together in real systems.
## 6
### text
When to choose Microservices vs Monolith.
## 7
### text
The role of Kubernetes in managing and scaling systems.
## 8
### text
Foundation to implement basic distributed systems.
## 9
### text
Ready to move into practical design and implementation modules next.
