# title
Kubernetes on Cloud: Practical Deployment with DigitalOcean

# description
Deploy a NestJS backend + MySQL + Redis to DigitalOcean Kubernetes (DOKS) with NGINX Ingress Controller, Cert-Manager, and Let's Encrypt — real domain, automated HTTPS, Load Balancer with sticky sessions.

# body

## I. Introduction

Running **Kubernetes** on a laptop with **Minikube** is a solid playground, but no **Senior Backend** interviewer asks *"how do you run **kubectl port-forward** to localhost?"*. The real question is: *"deploy this backend to **production**, a user in **Singapore** types **api.domain.com** — what path does the request take, how is **HTTPS** issued, who catches a dying Pod?"*. Anyone who has never stood this up end-to-end will fumble: mixing up **Ingress** and **Service**, not knowing where the **Load Balancer** comes from, assuming **SSL** must be bought from a provider and rotated manually every year.

Standing up a **Kubernetes cluster** on **bare-metal** or raw **VMs** is heavy: install **`kubeadm`**, operate **`etcd`**, manage internal **TLS** certificates, patch the **kernel**, ensure **high availability** for the **Control Plane** — weeks of work before a single business line of code. **Managed Kubernetes** (**DOKS**, **EKS**, **GKE**, **AKS**) pre-builds the **Control Plane** and bolts in the surrounding cloud infra: **Load Balancer**, **Block Storage**, **VPC**, **firewall**. You only pay for **Worker Nodes** and focus on what matters — **deploying workloads** + configuring the controllers you actually need. The only way to truly grasp this is to open a real provider and go from an empty cluster to a public **HTTPS** domain by hand — which is exactly what the next part does.

## II. Deploying the NestJS Backend to DOKS with Automated HTTPS

Target architecture: **Internet** → **DigitalOcean Load Balancer** → **NGINX Ingress Controller** → **example-backend-service** (NodePort) → 3 **Backend Pods** → **mysql-service** / **redis-service** (ClusterIP). **Cert-Manager** sits alongside and talks to **Let's Encrypt** to issue and renew TLS certs for your domain.

**Clone** here: [kubernetes-on-cloud](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/kubernetes-on-cloud)

| Component | Technology | Role | Port / Namespace |
|---|---|---|---|
| Cluster | **DOKS** (DigitalOcean Kubernetes) | Managed K8s, 2 **node pools**: `ingress-pool` + `system-pool` | — |
| CLI | **doctl** + **kubectl** + **helm** | Connect to cluster, apply **Manifests**, install **Helm charts** | — |
| Ingress Controller | **NGINX Ingress Controller** (Bitnami chart, `bitnamilegacy/*` images) | Route HTTPS traffic into cluster, auto-provision **DO Load Balancer** | **80** / **443** (namespace `ingress-nginx`) |
| Cert Manager | **Cert-Manager** (Bitnami chart) | Auto-issue + renew **TLS** certs via **Let's Encrypt** | namespace `cert-manager` |
| ClusterIssuer | **Let's Encrypt** (prod + staging) | ACME server issuing certs via **HTTP-01 challenge** | cluster-scope |
| Backend | **NestJS** (image `starci183/example-backend:latest`) | API Server, 3 replicas via **Deployment** | **3000** (NodePort **30000**) |
| Database | **MySQL 8.0** | Data storage, standalone **Pod** | **3306** (ClusterIP) |
| Cache | **Redis 7** | Item list cache, TTL **60s** | **6379** (ClusterIP) |

![k8s-on-cloud-architecture](https://starci.org/system-design-mastery/kubernetes-on-cloud/1.svg)

*Figure 1. DOKS deployment: DO Load Balancer → NGINX Ingress → backend Deployment, with Cert-Manager handling TLS via Let's Encrypt.*

### 1. Setup and Run Environment

Assumes you have a **DigitalOcean** account, a real **domain** to point **DNS** at (e.g. `api.your-domain.com`), and **`doctl`**, **`kubectl`**, **`helm`** installed locally (Linux / macOS / WSL2).

1. Create the **DOKS cluster** via the DigitalOcean UI, pick a **region** close to your users (Singapore / Frankfurt / NYC…), and a **stable** K8s version. Configure **two node pools** with distinct **labels**:

| Node Pool | Purpose | Label |
|---|---|---|
| `ingress-pool` | Run NGINX Ingress Controller + Default Backend | `doks.digitalocean.com/node-pool: ingress-pool` |
| `system-pool` | Run Cert-Manager and system workloads | `doks.digitalocean.com/node-pool: system-pool` |

2. Connect **`kubectl`** to the new cluster:

```bash
doctl kubernetes cluster kubeconfig save <cluster-name>
kubectl get nodes
```

Expected result: a list of real **Worker Nodes** on DigitalOcean in **Ready** state, each tagged with its node pool **label**.

3. Install **Cert-Manager** via **Helm** (Bitnami chart, `bitnamilegacy/*` images). From the repo, enter the `cert-manager` directory and run the script:

```bash
cd cert-manager
chmod +x run.sh && ./run.sh
```

The script runs `helm upgrade --install cert-manager` into namespace `cert-manager`, enables `installCRDs: true` (creates **Certificate**, **Issuer**, **ClusterIssuer** CRDs), then waits until controller / webhook / cainjector Pods are **Running**.

```bash
kubectl get pods -n cert-manager
kubectl get crds | grep cert-manager
```

Expected result: 3 Pods (`cert-manager-*`, `cert-manager-webhook-*`, `cert-manager-cainjector-*`) all **1/1 Running**, and CRDs `certificates.cert-manager.io`, `issuers.cert-manager.io`, `clusterissuers.cert-manager.io` present.

4. Install **NGINX Ingress Controller** — also a Bitnami chart, with **LoadBalancer** service enabled and DigitalOcean **annotations**:

```bash
cd ../nginx-ingress-controller
chmod +x run.sh && ./run.sh
```

The `values.yaml` in the repo already sets:
- `replicaCount: 2`, `nodeSelector: doks.digitalocean.com/node-pool: ingress-pool` — pin the controller to its dedicated pool.
- `service.type: LoadBalancer` + annotations: `do-loadbalancer-size-unit: "1"` (smallest LB), `do-loadbalancer-type: "REGIONAL_NETWORK"` (high-performance network LB), **sticky sessions** via **cookie** TTL **300s**.
- `ingressClassResource.default: true` — any **Ingress** without an explicit class flows through here.

Wait for DigitalOcean to assign an **External IP** to the **LoadBalancer Service**:

```bash
kubectl get svc -n ingress-nginx -w
```

Expected result: after **1–2 minutes**, the `EXTERNAL-IP` column for `nginx-ingress-nginx-ingress-controller` shows a public IP. Save it for the DNS step.

5. Point a **DNS A record** for your domain to the External IP:

| Type | Name | Value | TTL |
|---|---|---|---|
| A | `api` | `<EXTERNAL_IP>` | 300 |

Verify propagation:

```bash
nslookup api.your-domain.com
```

Expected result: returns the External IP from step 4. If DNS has not propagated, the **HTTP-01 challenge** will fail during cert issuance.

6. Update the email in `cluster-issuer.yaml` (required — Let's Encrypt uses it for expiry notifications), then apply:

```bash
kubectl apply -f cluster-issuer.yaml
kubectl get clusterissuer
```

Expected result: both `letsencrypt-prod` and `letsencrypt-staging` show **READY=True**. Both use the `http01` **solver** via Ingress class `nginx`.

7. Apply the data layer and backend:

```bash
kubectl apply -f mysql-pod.yaml
kubectl apply -f mysql-service.yaml
kubectl apply -f redis-pod.yaml
kubectl apply -f redis-service.yaml
kubectl apply -f backend-deployment.yaml
kubectl apply -f backend-service.yaml
```

8. Update the domain in `ingress.yaml` (replace `api.example.com` with the real one), then apply — this triggers Cert-Manager:

```bash
kubectl apply -f ingress.yaml
kubectl get ingress
```

**Expected Result**

- `kubectl get pods` shows `mysql-pod`, `redis-pod` **Running**; **Deployment** `example-backend` at **3/3 READY**.
- `kubectl get ingress` returns `backend-ingress` with host `api.your-domain.com`, ADDRESS set to the External IP.
- Cert-Manager auto-creates a **Certificate** `backend-tls-secret`, via the chain **CertificateRequest** → **Order** → **Challenge** HTTP-01: Cert-Manager spins up a temporary Ingress rule for `/.well-known/acme-challenge/...`, and Let's Encrypt hits it to verify domain ownership.

**Conclusion:** The whole stack on **DOKS** is live using only the **Manifests** and **Helm charts** from the repo — no hardcoded IPs, no SSL purchase. The three new layers versus **Minikube**: **Managed Control Plane** (DigitalOcean runs `kube-apiserver` / `etcd`), **Cloud Load Balancer** (DO provisions one automatically when a `LoadBalancer` Service is created), and **Cert-Manager + ClusterIssuer** (automating the TLS lifecycle).

### 2. Verifying HTTPS and the Real Request Flow

**Step 1 — Confirm the Certificate is ready:** Cert-Manager typically takes **30s–2 minutes** to complete the **HTTP-01 challenge**.

```bash
kubectl get certificate
kubectl describe certificate backend-tls-secret
```

Expected result: `backend-tls-secret` shows **READY=True**, with `Events` lines such as *"Issuing certificate"* → *"Created temporary Certificate"* → *"Issued temporary certificate"* → *"Certificate is up to date and has not expired"*. If **READY=False** lingers, check `kubectl get challenge` and Cert-Manager logs — 90% of the time it is wrong **DNS** or a firewall blocking port **80**.

**Step 2 — Health Check over HTTPS:**

Send **GET** `https://api.your-domain.com/health`

```bash
curl https://api.your-domain.com/health
```

Expected result:

```json
{
  "mysql": { "status": "connected", "itemCount": 0 },
  "redis": { "status": "connected" }
}
```

The browser shows the **green padlock** (certificate signed by Let's Encrypt R3 / R10, trusted by every browser). Plain HTTP requests to `http://api.your-domain.com/health` redirect to HTTPS thanks to the `nginx.ingress.kubernetes.io/ssl-redirect: "true"` annotation in `ingress.yaml`.

**Step 3 — Create data:**

Send **POST** `https://api.your-domain.com/items` with body `{ "name": "digitalocean" }`.

```bash
curl -X POST https://api.your-domain.com/items \
  -H "Content-Type: application/json" \
  -d '{"name":"digitalocean"}'
```

Expected result: Backend returns the created item with an `id`, cache key `items:all` in **Redis** is invalidated (`app.service.ts` — `await this.redis.del('items:all')`).

**Step 4 — Read data (cache flow):**

```bash
curl https://api.your-domain.com/items
curl https://api.your-domain.com/items
```

- **First call:** Cache miss → backend queries **MySQL**, caches result in **Redis** with TTL **60s** (`app.service.ts` — `this.redis.set(cacheKey, JSON.stringify(items), 'EX', 60)`).
- **Second call (within 60s):** Cache hit → backend serves from **Redis**, no MySQL query.

With **sticky sessions** on the DO Load Balancer (cookie `cookie`, TTL 300s), each client pins to one Ingress replica — handy for protocols that need session affinity (e.g. WebSockets), but has no effect on the shared Redis cache.

**Conclusion:** The full flow: **Client (api.your-domain.com)** → **DO Load Balancer (REGIONAL_NETWORK, sticky cookie)** → **NGINX Ingress Controller (:443, host match `api.your-domain.com`)** → **example-backend-service (NodePort 30000)** → one of 3 **Backend Pods** → **mysql-service** / **redis-service** via internal DNS. The certificate was minted by **Cert-Manager** and will auto-renew once there are **30 days** left — no manual touch required.

The system runs on a real domain with HTTPS, but going to serious production raises a few more questions: why split `ingress-pool` and `system-pool`, what Cert-Manager actually does at the controller layer, and the "death traps" when scaling for real.

## III. Architectural Essence and Production Considerations

### 1. Managed Kubernetes — You Pay So You Don't Have to Worry

**Managed K8s** (**DOKS**, **EKS**, **GKE**, **AKS**) share a common promise: the provider runs the **Control Plane** (`kube-apiserver`, `etcd`, `kube-scheduler`, `kube-controller-manager`) and wires it into the rest of their cloud infrastructure. You pay for **Worker Nodes** + some LB / storage, and in return skip `etcd` upgrades and `kube-apiserver` patching.

- **Example 1 — Cloud Load Balancer auto-provisioning:** When you apply `Service type: LoadBalancer` with `service.beta.kubernetes.io/do-loadbalancer-*` annotations, DigitalOcean's **Cloud Controller Manager** calls the DO API to spin up a real Load Balancer (REGIONAL_NETWORK in this demo). A different cluster (EKS) would create an ELB / NLB — **same** Manifest, **different** provider.
- **Example 2 — Block Storage via PersistentVolume:** Declare a `PersistentVolumeClaim` with `storageClassName: do-block-storage` and DO provisions a **block volume** attached to a Node. When the Pod reschedules to another Node, the volume auto-detaches and reattaches — the foundation for running MySQL / Redis as a production **StatefulSet**.
- **Example 3 — Node Pools splitting responsibility:** The repo creates two pools `ingress-pool` and `system-pool`, wired via `nodeSelector` in NGINX Ingress and Cert-Manager `values.yaml`. Benefit: edge traffic (Ingress) and system workloads no longer fight for CPU with business backends; scaling Ingress to 10 replicas only scales `ingress-pool`, not the whole cluster.

Trade-off: tighter coupling to the provider (`doks.digitalocean.com/node-pool` is DO-specific), higher Control Plane + LB cost than self-hosted. For small teams without a dedicated SRE, that cost is almost always worth it.

### 2. Ingress vs Service — Why You Need Another Layer

The previous lesson already had **Services** (ClusterIP / NodePort) for Pods to talk to each other internally. But **Service** alone is not enough when the system has multiple domains, needs **TLS**, or wants **path-based routing**.

- **Example 1 — One LB for many domains:** Without **Ingress**, every **LoadBalancer Service** provisions its own DO LB — **10** backend services mean **10** LBs, hundreds of dollars per month. With **Ingress**, a single **DO LB** fronts the **NGINX Ingress Controller**, which routes by `host` / `path` — `api.a.com` to backend A, `api.b.com` to backend B.
- **Example 2 — TLS termination at Ingress:** The backend does not need to know HTTPS. Ingress terminates TLS with `backend-tls-secret` created by **Cert-Manager**, then forwards plain HTTP internally to `example-backend-service:3000` — simpler app config, TLS burden moved to the edge.
- **Example 3 — Annotations drive NGINX behavior:** `nginx.ingress.kubernetes.io/ssl-redirect: "true"` forces HTTP→HTTPS; `nginx.ingress.kubernetes.io/proxy-body-size: "50m"` allows larger uploads; `nginx.ingress.kubernetes.io/proxy-read-timeout: "60"` prevents premature disconnects with slow backends. These annotations are **not** standardized K8s — they belong to the **NGINX Ingress Controller**.

### 3. Cert-Manager and the ACME Lifecycle — Automating TLS

**Cert-Manager** is an in-cluster **controller** watching CRDs `Certificate` / `CertificateRequest` / `Order` / `Challenge` and driving the **ACME protocol** against **Let's Encrypt**.

- **ClusterIssuer vs Issuer:** `ClusterIssuer` is cluster-scoped (usable from any namespace), while `Issuer` is namespace-scoped. The demo uses `ClusterIssuer letsencrypt-prod` so Ingress in any namespace can request certs.
- **HTTP-01 Challenge (this demo):** Cert-Manager spins up a temporary Ingress rule for `/.well-known/acme-challenge/<token>`, and Let's Encrypt hits your domain over port **80**. For it to work: DNS must be correct, port 80 open, Ingress class matching (`solvers[].http01.ingress.class: nginx`).
- **DNS-01 Challenge (when you need wildcards):** For a **`*.your-domain.com`** cert, Let's Encrypt requires validation via a DNS TXT record. `cluster-issuer.yaml` contains a commented block for the `digitalocean` DNS provider — you'd create a **Secret** holding a **DO API token** and uncomment the block.
- **Let's Encrypt rate limits:** The production issuer caps at **50 certs/week/domain**; repeatedly failed issuance can get the cluster blocked. When testing new configs, use `letsencrypt-staging` (no rate limit, untrusted by browsers but fine for pipeline verification).

### 4. Production Death Traps

- **Data loss when MySQL/Redis Pods die:** The demo still runs MySQL / Redis as standalone Pods — same as the previous lesson. Production requires **StatefulSet** + **PersistentVolumeClaim** with `storageClassName: do-block-storage`; or better, move the DB out to a **Managed Database** (DO Databases for MySQL / Redis) so you skip backups and version patching entirely.
- **No Resource Limits:** The backend Deployment in the repo sets no `resources.requests` / `resources.limits`. Production must declare them — a memory-leaking Pod can **OOM kill** every other Pod on its Node if uncapped.
- **Secrets hardcoded in YAML:** `root123` / `MYSQL_PASSWORD` sit plainly in `backend-deployment.yaml` — fine for a demo, but production must move to **Secret** objects (and ideally **External Secrets Operator** + **Vault** / a cloud secret manager).
- **No Readiness / Liveness probes:** Without a **Readiness Probe**, Ingress sends traffic into a Pod that hasn't finished connecting to MySQL → 502 during rolling updates. Production adds a `readinessProbe` hitting `/health` and a `livenessProbe` so K8s knows when to restart a wedged Pod.
- **Single DNS record, no fallback:** If the DO LB goes down (rare, but possible), the domain is gone. Beyond 99.9% uptime you want **multi-region** + **DNS-based failover** (Route53 health checks; DO has no built-in equivalent).

**Conclusion:** Moving from **Minikube** to **DOKS** does not mean rewriting YAML — most Manifests stay the same, you simply layer on **Ingress Controller**, **Cert-Manager**, and **ClusterIssuer** to handle edge traffic + TLS. The key insight: **the Kubernetes API is uniform**, cloud-specific behavior hides inside **annotations** or **CRDs**. Once you grasp these three layers — **Managed K8s** (who owns the Control Plane), **Ingress + Cert-Manager** (who owns edge + TLS), **StatefulSet + PV** (who owns stateful data) — you have a solid foundation to deploy real backends for real users, not just localhost.

# references
## 0
### alias
DigitalOcean Kubernetes (DOKS) Docs
### url
https://docs.digitalocean.com/products/kubernetes/
## 1
### alias
NGINX Ingress Controller Guide
### url
https://kubernetes.github.io/ingress-nginx/deploy/
## 2
### alias
Cert-Manager Documentation
### url
https://cert-manager.io/docs/
## 3
### alias
Let's Encrypt — How It Works
### url
https://letsencrypt.org/how-it-works/
## 4
### alias
DigitalOcean Load Balancer Annotations
### url
https://docs.digitalocean.com/products/kubernetes/how-to/configure-load-balancers/

# minutesRead
30
