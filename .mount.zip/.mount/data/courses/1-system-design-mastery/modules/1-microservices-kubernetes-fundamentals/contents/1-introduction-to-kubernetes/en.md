# title
Introduction to Kubernetes (K8s) and Minikube

# description
Understand how Kubernetes orchestrates containers at cluster scale, install Minikube and kubectl locally, then practice applying Pods via YAML manifests and port-forwarding them for testing.

# body

## I. Introduction

In a **Senior Backend** interview, you get asked: *"You run **100 containers** across **10 servers**, one container dies — how do you keep users from seeing the error?"*. Most **beta** engineers answer something like **`docker run --restart unless-stopped`** or *"I'll write a cron to health-check and restart manually"* — and the interviewer instantly knows you haven't touched **real infrastructure** at scale.

Production is even more painful: traffic triples, you want to scale backend from **3** replicas to **10** — you **SSH** into each **Node**, run **`docker-compose up --scale`**, then update **Nginx upstream** by hand. One Node drops off the network and health checks go stale, requests hit dead containers, logs flood with retries. This is exactly **"Container Chaos"** — the **Bash script** and **`docker run`** mindset isn't enough anymore.

You need a layer above that knows: who is running where, which container just died and must be respawned, which Pod is eating more **CPU** than allowed, which endpoint needs load balancing. That's **Kubernetes** — an open-source **Orchestrator** that turns hundreds of scattered containers into a cluster that **self-heals** to the exact **Desired State** you declare.

Reading a definition of **orchestrator** on paper stays abstract — to see what it actually does, you need a cluster already running on your machine so you can **apply** a **Pod**, watch **K8s** place it somewhere, then `port-forward` into it — which is exactly what the next part does.

## II. Provisioning Minikube and Deploying the First Pods

We will provision a **single-node cluster** using **Minikube** on a local machine, apply three standalone **Pods** (**MySQL**, **Nginx**, **Game 2048**) to see how **K8s** orchestrates containers via **YAML files**, then `port-forward` each Pod locally for testing.

The three **Manifest** files (`mysql-pod.yaml`, `nginx-pod.yaml`, `game-2048-pod.yaml`) live **inside this lesson folder** — no external repo to clone, just open the folder.

| Component | Technology | Role | Port |
|---|---|---|---|
| Cluster | **Minikube** (driver `docker`) | Simulates a single-node K8s cluster on the local machine | — |
| CLI | **kubectl** | Sends **Manifests** (YAML) and admin commands to the cluster | — |
| Pod 1 | **MySQL 8.0** | Sample database, standalone **Pod** | **3306** (port-forward to `3307` locally) |
| Pod 2 | **Nginx** | Static web server, standalone **Pod** | **80** (port-forward to `8080` locally) |
| Pod 3 | **Game 2048** | Demo web app, standalone **Pod** | **80** (port-forward to `8081` locally) |

![introduction-to-kubernetes-architecture](https://starci.org/system-design-mastery/introduction-to-kubernetes/0.svg)

*Figure 1. Single-node Minikube with three standalone Pods applied via `kubectl`.*

The client uses `kubectl port-forward` to open a local → Pod channel; there is no **Service** or **Ingress** at this stage — just **raw Pods** so you can feel the lifecycle of the smallest object in **Kubernetes**.

### 1. Setup and Run Environment

Assumes you are on a machine with **Docker Desktop** or an equivalent container engine (Linux / macOS / WSL2).

1. Install **Docker Desktop** (as Minikube driver): [docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop/).
2. Install **Minikube** per your OS: [minikube.sigs.k8s.io/docs/start](https://minikube.sigs.k8s.io/docs/start/).
3. Install **kubectl**: [kubernetes.io/docs/tasks/tools](https://kubernetes.io/docs/tasks/tools/).
4. Start the single-node cluster:

```bash
minikube start --driver=docker
```

5. Verify the cluster is ready:

```bash
kubectl cluster-info
kubectl get nodes
```

6. From this lesson folder, apply the three Pod **Manifests**:

```bash
kubectl apply -f mysql-pod.yaml
kubectl apply -f nginx-pod.yaml
kubectl apply -f game-2048-pod.yaml
```

**Expected Result**

- `kubectl get nodes` returns the `minikube` node in **Ready** state.
- `kubectl get pods -o wide` shows three Pods `mysql-pod`, `nginx-pod`, `game-2048-pod` all **Running**, each with its own cluster-internal IP.

**Conclusion:** The **Minikube** cluster is up and three Pods are running independently from just a few YAML files — this is the core of **Infrastructure as Code**: describe **desired state** instead of typing commands on each Node.

### 2. Inspecting Pods and Port-forwarding for Testing

**Step 1 — Inspect Pod details:** Check the runtime configuration K8s is using for `mysql-pod`.

```bash
kubectl describe pod mysql-pod
```

Expected result: fields like `Containers:`, `Image:`, `State: Running`, and especially **`Events:`** — the scheduler history (pull image, start, restart…). When a Pod fails, this is the first place to look.

**Step 2 — Read logs:** Stream the stdout/stderr of the container inside the Pod.

```bash
kubectl logs game-2048-pod
```

Expected result: the application's startup log lines. This is the quick **debug** path when a Pod is **Running** but the app won't respond.

**Step 3 — Port-forward Nginx:** Open a local `:8080` channel to port **80** of the Pod.

```bash
kubectl port-forward pod/nginx-pod 8080:80
```

Send **GET** `http://localhost:8080`:

```bash
curl http://localhost:8080
```

Expected result: HTTP **200** with the default **Nginx** welcome HTML.

**Step 4 — Port-forward Game 2048:** Open `:8081` to port **80** of the Pod (run in another terminal so both channels stay alive).

```bash
kubectl port-forward pod/game-2048-pod 8081:80
```

Expected result: visiting `http://localhost:8081` in a browser shows the **2048** game UI.

**Step 5 — Port-forward MySQL:** Open `:3307` to port **3306** of the Pod so you can connect from a local **MySQL client** (root password declared in `mysql-pod.yaml` is `root123`).

```bash
kubectl port-forward pod/mysql-pod 3307:3306
```

Equivalent verification command — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```bash
mysql -h 127.0.0.1 -P 3307 -uroot -proot123 -e "SHOW DATABASES;"
```

Expected result: connection succeeds and the default MySQL database list is printed.

**Conclusion:** `kubectl port-forward` turns a **Pod** — which otherwise only has a cluster-internal IP — into something you can call directly from your laptop. Great for **debugging**, but **not** a replacement for **Service** / **Ingress** when you want to expose Pods to real clients outside the cluster.

Now that you have seen Pods running and handled real requests, the natural next question is: what risks do raw Pods carry in production, and what layers will the theory section show as the minimum wrapping around a Pod?

## III. The Essence of Kubernetes and the Limits of Raw Pods

### 1. What Kubernetes Is and Why Desired State Matters

**Kubernetes** is an open-source container orchestration platform, but its core difference from `docker run` or **Bash scripts** is the **Desired State** philosophy: you declare *"I want N containers like this running"* and K8s is responsible for keeping that count, regardless of Node crashes, container failures, or image pull errors.

- **Example 1 — Self-healing:** Declare a **Deployment** with `replicas: 3` for backend. K8s schedules 3 Pods onto Nodes; if one Pod dies, a **controller** detects the drift between **Desired State** and **Actual State** and spins up a new Pod.
- **Example 2 — Scheduling:** Want to scale to **10**? Just change `replicas: 10` and `kubectl apply`. K8s finds Nodes with enough **CPU** / **RAM** and provisions 7 more Pods — you don't need to know which Node each Pod lands on.

The shift from the old mindset: instead of describing **steps** (imperative — `docker run`, `systemctl start`), you describe the **outcome** (declarative — **YAML**). That's why **YAML files** are K8s's primary interface, and why this lesson opens with `kubectl apply -f ...` rather than procedural commands.

### 2. Minikube, Managed Kubernetes, and When to Use Which

The same set of **YAML Manifests** runs from a laptop to a multi-region cloud — the power of K8s's standardized **API**. But where the cluster runs depends on the use case.

- **Example 1 — Minikube (local dev):** A single-node cluster on a personal machine, running in a **VM** or **container** (drivers `docker`, `hyperkit`, `kvm2`…). No hosting cost; ideal for learning K8s, verifying **YAML** before shipping to staging, experimenting with **Ingress** / **ConfigMap** / **Secret** locally. Limit: **single node**, cannot simulate **multi-node scheduling** or **zone failover**.
- **Example 2 — Managed K8s (production):** **EKS** (AWS), **GKE** (Google), **AKS** (Azure), **DOKS** (DigitalOcean)… the provider manages the **Control Plane** (`kube-apiserver`, `etcd`, `controller-manager`, `scheduler`). You just pay and take care of **Worker Nodes** + workloads. Trade-off: higher cost and tighter coupling to the cloud ecosystem, but in return you get a **high availability Control Plane** across zones, **auto-scaling node pools**, and built-in integration with **IAM** / **Load Balancer** / Object Storage.
- **Example 3 — Self-managed (kubeadm, k3s, RKE2):** You stand up the **Control Plane** yourself. Maximum flexibility, but you own patches, `etcd` upgrades, **TLS** certificates — typically chosen only under regulatory constraints or **on-premise** deployments.

This course uses **Minikube** because the lab must run on your machine, but every **Manifest** in the repo can be applied directly to **EKS** / **GKE** with little to no change.

### 3. Raw Pods and Their Production Limits

A **Pod** is the smallest unit K8s schedules, but **raw Pods** (applying `kind: Pod` directly as in the demo above) are only appropriate at the concept-learning stage. Production almost always wraps Pods with a **controller** (**Deployment**, **StatefulSet**, or **Job** / **CronJob**).

- **No self-healing when a Pod dies:** A raw Pod has no controller behind it. `kubectl delete pod mysql-pod` wipes it out — K8s **will not** recreate it, and there is no standby replica.
- **Data loss on Pod restart:** The container inside a Pod has an **ephemeral** rootfs — remove the Pod and data is gone. Stateful workloads like **MySQL** / **Redis** need **PersistentVolume** + **PersistentVolumeClaim** (typically via **StatefulSet**) so data survives restarts and reschedules.
- **No stable endpoint for clients:** `kubectl port-forward` is for **debugging** only. Each Pod restart brings a new cluster-internal IP and the forward dies — for a stable **DNS endpoint** so the backend can reach MySQL / Redis, you need a **Service** layer in front of the Pods.
- **Without Resource Limits, one Pod can crash a Node:** By default Pods have **no** CPU / RAM limit; a memory-leaking container can **OOM kill** every other Pod on the same Node. Production requires explicit `resources.requests` and `resources.limits` for every Pod.

**Conclusion:** **Kubernetes** does not make systems less complex — it makes that complexity **manageable** by moving you from "SSH into each Node to tweak manually" to "describe **Desired State** in YAML". **Minikube** is a sufficient playground for this lesson: a single-node cluster, three **Pods** applied via `kubectl`, `port-forward` for hands-on testing. Once you understand the lifecycle of a raw Pod and its limits, you have the foundation to gradually layer **controllers** and **Services** on top whenever the real system needs to survive crashes and scale with load.

# references
## 0
### alias
Kubernetes Documentation
### url
https://kubernetes.io/docs/concepts/overview/what-is-kubernetes/
## 1
### alias
Minikube Official Guide
### url
https://minikube.sigs.k8s.io/docs/start/
## 2
### alias
Pod — Kubernetes Concepts
### url
https://kubernetes.io/docs/concepts/workloads/pods/

# minutesRead
15
