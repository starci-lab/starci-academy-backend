# title
Kubernetes trên Cloud: Triển khai thực tế với DigitalOcean

# description
Triển khai NestJS backend + MySQL + Redis lên DigitalOcean Kubernetes (DOKS) với NGINX Ingress Controller, Cert-Manager và Let's Encrypt — domain thật, HTTPS tự động, Load Balancer gắn sticky sessions.

# body

## I. Lời mở đầu

Chạy **Kubernetes** trên máy cá nhân bằng **Minikube** là sân tập tốt, nhưng đi phỏng vấn **Senior Backend** không ai hỏi *"em chạy **kubectl port-forward** ra localhost thế nào"*. Câu hỏi thật là: *"anh deploy backend này lên **production**, user ở **Singapore** gõ **api.domain.com** thì request đi qua những đâu, **HTTPS** cấp thế nào, Pod chết thì ai hứng?"*. Người chưa tự tay dựng qua một lần sẽ trả lời lủng củng: nhầm giữa **Ingress** và **Service**, không biết **Load Balancer** ở đâu ra, tưởng **SSL** phải mua từ provider và update tay mỗi năm.

Tự dựng **Kubernetes cluster** trên **bare-metal** hay **VM** thuần thì nặng: phải cài **`kubeadm`**, quản **`etcd`**, chứng chỉ **TLS** nội bộ, vá **kernel**, lo **high availability** cho **Control Plane** — mất hàng tuần trước khi chạm đến một dòng nghiệp vụ. **Managed Kubernetes** (**DOKS**, **EKS**, **GKE**, **AKS**) dựng sẵn **Control Plane** và dán vào sẵn các mảnh hạ tầng: **Load Balancer**, **Block Storage**, **VPC**, **firewall**. Bạn chỉ trả tiền cho **Worker Nodes** và tập trung đúng việc cần làm — **deploy workload** + cấu hình các **controller** cần thiết. Muốn nắm thì phải mở một provider, gõ tay từ lúc cluster còn trống tới lúc domain thật lên được **HTTPS** — đúng là việc ở phần ngay sau.

## II. Triển khai NestJS Backend lên DOKS với HTTPS tự động

Kiến trúc đích: **Internet** → **DigitalOcean Load Balancer** → **NGINX Ingress Controller** → **example-backend-service** (NodePort) → 3 **Backend Pod** → **mysql-service** / **redis-service** (ClusterIP). **Cert-Manager** đứng bên cạnh, bắt tay với **Let's Encrypt** để sinh và gia hạn TLS cert cho domain của bạn.

**Clone** ở đây: [kubernetes-on-cloud](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/kubernetes-on-cloud)

| Thành phần | Công nghệ | Vai trò | Cổng / Namespace |
|---|---|---|---|
| Cluster | **DOKS** (DigitalOcean Kubernetes) | Managed K8s, 2 **node pool**: `ingress-pool` + `system-pool` | — |
| CLI | **doctl** + **kubectl** + **helm** | Kết nối cluster, apply **Manifest**, cài **Helm chart** | — |
| Ingress Controller | **NGINX Ingress Controller** (Bitnami chart, `bitnamilegacy/*` images) | Điều phối traffic HTTPS vào cluster, tự tạo **DO Load Balancer** | **80** / **443** (namespace `ingress-nginx`) |
| Cert Manager | **Cert-Manager** (Bitnami chart) | Tự cấp + renew **TLS** cert qua **Let's Encrypt** | namespace `cert-manager` |
| ClusterIssuer | **Let's Encrypt** (prod + staging) | ACME server sinh cert qua **HTTP-01 challenge** | cluster-scope |
| Backend | **NestJS** (image `starci183/example-backend:latest`) | API Server, 3 replicas qua **Deployment** | **3000** (NodePort **30000**) |
| Database | **MySQL 8.0** | Lưu trữ dữ liệu, standalone **Pod** | **3306** (ClusterIP) |
| Cache | **Redis 7** | Cache danh sách item, TTL **60s** | **6379** (ClusterIP) |

![k8s-on-cloud-architecture](https://starci.org/system-design-mastery/kubernetes-on-cloud/1.svg)

*Hình 1. Sơ đồ triển khai DOKS: DO Load Balancer → NGINX Ingress → backend Deployment, Cert-Manager lo TLS qua Let's Encrypt.*

### 1. Chuẩn bị và chạy môi trường

Giả định bạn đã có tài khoản **DigitalOcean**, một **domain** thật để trỏ **DNS** (ví dụ `api.your-domain.com`), và đã cài **`doctl`**, **`kubectl`**, **`helm`** trên máy (Linux / macOS / WSL2).

1. Tạo **DOKS cluster** trên UI DigitalOcean, chọn **region** gần người dùng (Singapore / Frankfurt / NYC…), phiên bản K8s **stable**. Cấu hình **hai node pool** với **label** phân biệt:

| Node Pool | Mục đích | Label |
|---|---|---|
| `ingress-pool` | Chạy NGINX Ingress Controller + Default Backend | `doks.digitalocean.com/node-pool: ingress-pool` |
| `system-pool` | Chạy Cert-Manager và các workload hệ thống | `doks.digitalocean.com/node-pool: system-pool` |

2. Kết nối **`kubectl`** với cluster vừa tạo:

```bash
doctl kubernetes cluster kubeconfig save <cluster-name>
kubectl get nodes
```

Kết quả mong đợi: danh sách các **Worker Node** thật trên DigitalOcean ở trạng thái **Ready**, kèm **label** node pool tương ứng.

3. Cài **Cert-Manager** qua **Helm** (chart Bitnami, image `bitnamilegacy/*`). Từ repo, vào thư mục `cert-manager` và chạy script:

```bash
cd cert-manager
chmod +x run.sh && ./run.sh
```

Script sẽ `helm upgrade --install cert-manager` vào namespace `cert-manager`, bật `installCRDs: true` (tạo **Certificate**, **Issuer**, **ClusterIssuer** CRDs), rồi chờ cho tới khi các Pod controller / webhook / cainjector **Running**.

```bash
kubectl get pods -n cert-manager
kubectl get crds | grep cert-manager
```

Kết quả mong đợi: 3 Pod (`cert-manager-*`, `cert-manager-webhook-*`, `cert-manager-cainjector-*`) đều **1/1 Running**, và có các CRD `certificates.cert-manager.io`, `issuers.cert-manager.io`, `clusterissuers.cert-manager.io`.

4. Cài **NGINX Ingress Controller** — cũng Bitnami chart, bật **LoadBalancer** service và gắn các **annotation** DigitalOcean:

```bash
cd ../nginx-ingress-controller
chmod +x run.sh && ./run.sh
```

File `values.yaml` trong repo đã set:
- `replicaCount: 2`, `nodeSelector: doks.digitalocean.com/node-pool: ingress-pool` — ép controller chạy đúng pool riêng.
- `service.type: LoadBalancer` + annotations: `do-loadbalancer-size-unit: "1"` (LB nhỏ nhất), `do-loadbalancer-type: "REGIONAL_NETWORK"` (network LB hiệu năng cao), **sticky sessions** qua **cookie** TTL **300s**.
- `ingressClassResource.default: true` — mọi **Ingress** không khai báo class đều đi qua đây.

Chờ cho tới khi DigitalOcean cấp **External IP** cho **LoadBalancer Service**:

```bash
kubectl get svc -n ingress-nginx -w
```

Kết quả mong đợi: sau **1–2 phút**, cột `EXTERNAL-IP` của service `nginx-ingress-nginx-ingress-controller` hiện một IP công khai. Ghi lại IP này để trỏ DNS.

5. Trỏ **DNS A record** cho domain về External IP:

| Type | Name | Value | TTL |
|---|---|---|---|
| A | `api` | `<EXTERNAL_IP>` | 300 |

Kiểm tra propagation:

```bash
nslookup api.your-domain.com
```

Kết quả mong đợi: trả đúng External IP vừa lấy ở bước 4. DNS chưa propagate thì **HTTP-01 challenge** sẽ fail ở bước cấp cert.

6. Sửa email trong `cluster-issuer.yaml` (bắt buộc — Let's Encrypt dùng email này để cảnh báo cert sắp hết hạn) rồi apply:

```bash
kubectl apply -f cluster-issuer.yaml
kubectl get clusterissuer
```

Kết quả mong đợi: `letsencrypt-prod` và `letsencrypt-staging` đều **READY=True**. Cả hai dùng **solver** `http01` qua Ingress class `nginx`.

7. Apply tầng dữ liệu và backend:

```bash
kubectl apply -f mysql-pod.yaml
kubectl apply -f mysql-service.yaml
kubectl apply -f redis-pod.yaml
kubectl apply -f redis-service.yaml
kubectl apply -f backend-deployment.yaml
kubectl apply -f backend-service.yaml
```

8. Sửa domain trong `ingress.yaml` (thay `api.example.com` thành domain thật) rồi apply — đây là bước kích hoạt Cert-Manager:

```bash
kubectl apply -f ingress.yaml
kubectl get ingress
```

**Kết quả mong đợi**

- `kubectl get pods` cho thấy `mysql-pod`, `redis-pod` **Running**; **Deployment** `example-backend` **3/3 READY**.
- `kubectl get ingress` trả về `backend-ingress` với host `api.your-domain.com`, ADDRESS là External IP.
- Cert-Manager tự sinh **Certificate** `backend-tls-secret`, qua trung gian **CertificateRequest** → **Order** → **Challenge** HTTP-01: Cert-Manager tạo tạm một Ingress rule cho path `/.well-known/acme-challenge/...`, Let's Encrypt gõ vào và xác minh domain ownership.

**Kết luận:** Toàn bộ stack trên **DOKS** đã lên bằng đúng các **Manifest** và **Helm chart** từ repo — không hardcode IP, không mua SSL. Ba mảnh mới so với **Minikube** là: **Managed Control Plane** (DigitalOcean lo `kube-apiserver` / `etcd`), **Cloud Load Balancer** (DO tự cấp khi Service kiểu `LoadBalancer` được tạo), và **Cert-Manager + ClusterIssuer** (tự động hoá vòng đời TLS).

### 2. Kiểm tra HTTPS và luồng hoạt động thực

**Bước 1 — Xác nhận Certificate đã cấp xong:** Cert-Manager mất khoảng **30s–2 phút** để hoàn tất **HTTP-01 challenge**.

```bash
kubectl get certificate
kubectl describe certificate backend-tls-secret
```

Kết quả mong đợi: `backend-tls-secret` **READY=True**, `Events` hiện các dòng *"Issuing certificate"* → *"Created temporary Certificate"* → *"Issued temporary certificate"* → *"Certificate is up to date and has not expired"*. Nếu **READY=False** quá lâu, xem `kubectl get challenge` và log Cert-Manager — 90% do **DNS** chưa trỏ đúng hoặc domain bị firewall chặn cổng **80**.

**Bước 2 — Health Check qua HTTPS:**

Gửi **GET** `https://api.your-domain.com/health`

```bash
curl https://api.your-domain.com/health
```

Kết quả mong đợi:

```json
{
  "mysql": { "status": "connected", "itemCount": 0 },
  "redis": { "status": "connected" }
}
```

Trình duyệt sẽ hiện **khóa xanh** (certificate ký bởi Let's Encrypt R3 / R10, trust sẵn trong mọi browser). Request HTTP `http://api.your-domain.com/health` tự redirect sang HTTPS nhờ annotation `nginx.ingress.kubernetes.io/ssl-redirect: "true"` trong `ingress.yaml`.

**Bước 3 — Tạo dữ liệu:**

Gửi **POST** `https://api.your-domain.com/items` với body `{ "name": "digitalocean" }`.

```bash
curl -X POST https://api.your-domain.com/items \
  -H "Content-Type: application/json" \
  -d '{"name":"digitalocean"}'
```

Kết quả mong đợi: Backend trả item vừa tạo kèm `id`, cache key `items:all` trong **Redis** bị invalidate (`app.service.ts` — `await this.redis.del('items:all')`).

**Bước 4 — Đọc dữ liệu (cache flow):**

```bash
curl https://api.your-domain.com/items
curl https://api.your-domain.com/items
```

- **Lần 1:** Cache miss → backend query **MySQL**, cache kết quả vào **Redis** TTL **60s** (`app.service.ts` — `this.redis.set(cacheKey, JSON.stringify(items), 'EX', 60)`).
- **Lần 2 (trong 60s):** Cache hit → backend trả từ **Redis**, không query MySQL.

Nhờ **sticky sessions** trên DO Load Balancer (cookie `cookie` TTL 300s), mỗi client sẽ dính vào một Ingress replica — tiện khi Ingress cần giữ state cho một số protocol (ví dụ WebSocket), nhưng không ảnh hưởng đến cache Redis vì cache dùng chung.

**Kết luận:** Luồng đầy đủ: **Client (api.your-domain.com)** → **DO Load Balancer (REGIONAL_NETWORK, sticky cookie)** → **NGINX Ingress Controller (:443, match host `api.your-domain.com`)** → **example-backend-service (NodePort 30000)** → 1 trong 3 **Backend Pod** → **mysql-service** / **redis-service** qua DNS nội bộ. Certificate do **Cert-Manager** sinh và sẽ tự renew khi còn **30 ngày** trước hạn — bạn không cần động tay lại.

Vậy là một hệ thống chạy được trên domain thật với HTTPS, nhưng đi vào production nghiêm túc thì còn vài góc cần hiểu rõ: vì sao tách `ingress-pool` và `system-pool`, Cert-Manager thực ra làm gì ở tầng controller, và đâu là những "hố tử thần" khi scale thật.

## III. Bản chất kiến trúc và những lưu ý production

### 1. Managed Kubernetes — bạn trả tiền để không phải lo gì

**Managed K8s** (**DOKS**, **EKS**, **GKE**, **AKS**) có điểm chung: nhà cung cấp quản **Control Plane** (`kube-apiserver`, `etcd`, `kube-scheduler`, `kube-controller-manager`) và tích hợp sẵn với hạ tầng cloud khác. Bạn chỉ trả tiền **Worker Nodes** + một phần LB / storage, đổi lại khỏi phải lo upgrade `etcd` hay vá `kube-apiserver`.

- **Ví dụ 1 — Cloud Load Balancer tự sinh:** Khi apply `Service type: LoadBalancer` với các annotation `service.beta.kubernetes.io/do-loadbalancer-*`, **Cloud Controller Manager** của DigitalOcean gọi API DO để tạo một Load Balancer vật lý thật (REGIONAL_NETWORK trong demo). Cluster khác (EKS) sẽ tạo ELB / NLB — **cùng** Manifest, **khác** provider.
- **Ví dụ 2 — Block Storage qua PersistentVolume:** Khai `PersistentVolumeClaim` với `storageClassName: do-block-storage`, DO tự cấp một **volume block** gắn vào Node. Pod reschedule qua Node khác thì volume tự detach / attach — đây là nền tảng để MySQL / Redis chạy **StatefulSet** production.
- **Ví dụ 3 — Node Pool tách trách nhiệm:** Repo tạo hai pool `ingress-pool` và `system-pool`, cấu hình `nodeSelector` trong `values.yaml` của NGINX Ingress và Cert-Manager. Lợi ích: traffic edge (Ingress) và workload hệ thống không tranh CPU với backend nghiệp vụ; khi cần scale Ingress lên 10 replica, chỉ scale `ingress-pool` thay vì cả cluster.

Trade-off: khóa chặt vào provider (`doks.digitalocean.com/node-pool` là annotation riêng của DO), chi phí Control Plane + LB cao hơn self-hosted. Với team nhỏ chưa có SRE chuyên trách, chi phí đó gần như luôn đáng.

### 2. Ingress vs Service — vì sao cần thêm một lớp

Bài 2 đã có **Service** kiểu ClusterIP / NodePort để các Pod gọi nhau nội bộ. Nhưng **Service** một mình không đủ khi hệ thống có nhiều domain, cần **TLS**, cần **path-based routing**.

- **Ví dụ 1 — Một LB cho nhiều domain:** Không có **Ingress**, mỗi **Service** LoadBalancer sinh một DO LB riêng — **10** service backend là **10** LB, tiền trăm đô mỗi tháng. Với **Ingress**, một **DO LB** duy nhất đứng trước **NGINX Ingress Controller**, rồi Ingress phân tuyến theo `host` / `path` — `api.a.com` đi backend A, `api.b.com` đi backend B.
- **Ví dụ 2 — TLS termination ở Ingress:** Backend không cần biết HTTPS. Ingress terminate TLS bằng `backend-tls-secret` do **Cert-Manager** tạo, rồi forward HTTP nội bộ xuống backend qua Service `example-backend-service:3000` — đơn giản hoá cấu hình ứng dụng, chuyển gánh nặng TLS lên edge.
- **Ví dụ 3 — Annotation điều khiển NGINX hành vi:** `nginx.ingress.kubernetes.io/ssl-redirect: "true"` bắt HTTP redirect sang HTTPS; `nginx.ingress.kubernetes.io/proxy-body-size: "50m"` cho upload file lớn; `nginx.ingress.kubernetes.io/proxy-read-timeout: "60"` tránh cắt kết nối sớm khi backend chậm. Các annotation này **không** chuẩn hoá K8s — chúng thuộc về **NGINX Ingress Controller**.

### 3. Cert-Manager và vòng đời ACME — tự động hoá TLS

**Cert-Manager** là một **controller** đứng bên trong cluster, theo dõi các CRD `Certificate` / `CertificateRequest` / `Order` / `Challenge` và điều khiển **ACME protocol** nói chuyện với **Let's Encrypt**.

- **ClusterIssuer vs Issuer:** `ClusterIssuer` có phạm vi cluster (mọi namespace đều dùng được), `Issuer` giới hạn một namespace. Demo dùng `ClusterIssuer letsencrypt-prod` để cấp cert cho Ingress ở mọi namespace.
- **HTTP-01 Challenge (demo):** Cert-Manager tạo tạm một Ingress rule cho path `/.well-known/acme-challenge/<token>`, Let's Encrypt gõ vào domain của bạn qua cổng **80**. Muốn fire phải: DNS trỏ đúng, cổng 80 không bị chặn, Ingress class khớp (`solvers[].http01.ingress.class: nginx`).
- **DNS-01 Challenge (nếu cần wildcard):** Với cert **`*.your-domain.com`**, Let's Encrypt bắt buộc xác minh qua DNS TXT record. `cluster-issuer.yaml` có block comment sẵn cho `digitalocean` DNS provider — bạn cần tạo **Secret** chứa **DO API token** rồi uncomment.
- **Rate limit của Let's Encrypt:** Production issuer có limit **50 cert/tuần/domain**, cấp sai nhiều lần là cluster bị chặn cấp mới. Khi test cấu hình mới, dùng `letsencrypt-staging` (không rate limit, cert không được trust bởi browser nhưng đủ để verify pipeline).

### 4. Những rủi ro khi lên production thật

- **Data loss khi Pod MySQL/Redis chết:** Demo vẫn chạy Pod trần cho MySQL / Redis — giống bài 2. Production bắt buộc **StatefulSet** + **PersistentVolumeClaim** với `storageClassName: do-block-storage`; hoặc tốt hơn, tách DB ra **Managed Database** của DO (DO Databases cho MySQL / Redis) để khỏi quản backup, patch version.
- **Không có Resource Limits:** Backend Deployment trong repo chưa set `resources.requests` / `resources.limits`. Production phải khai rõ — một Pod memory-leak có thể **OOM kill** cả Node nếu không bị chặn.
- **Secret hardcode trong YAML:** `root123` / `MYSQL_PASSWORD` nằm trong `backend-deployment.yaml` dạng plain text — demo OK nhưng production phải chuyển sang **Secret** (và tốt hơn là **External Secrets Operator** + **Vault** / cloud secret manager).
- **Không có Readiness / Liveness probe:** Không có **Readiness Probe** → Ingress gửi traffic vào Pod chưa kết nối xong MySQL → lỗi 502 khi rolling update. Production thêm `readinessProbe` gọi `/health`, `livenessProbe` để K8s biết khi nào restart Pod.
- **Chỉ một DNS record, không fallback:** Pod DO LB rớt (rất hiếm nhưng vẫn có) là domain mất. Production khi cần cao hơn 99.9% uptime nên xem **multi-region** + **DNS-based failover** (Route53 health check, DO không hỗ trợ sẵn).

**Kết luận:** Chuyển từ **Minikube** lên **DOKS** không phải đổi YAML — phần lớn Manifest giữ nguyên, chỉ cộng thêm ba lớp **Ingress Controller**, **Cert-Manager** và **ClusterIssuer** để lo edge traffic + TLS. Điểm đáng nhớ: **Kubernetes API là đồng nhất**, còn hành vi cloud-specific được nhét vào các **annotation** hoặc **CRD**. Nắm chắc ba tầng này — **Managed K8s** (ai lo Control Plane), **Ingress + Cert-Manager** (ai lo edge + TLS), **StatefulSet + PV** (ai lo stateful data) — bạn có đủ nền để deploy thật một backend phục vụ user ngoài đời, không chỉ localhost.

# references
## 0
### alias
DigitalOcean Kubernetes (DOKS) Docs
### url
https://docs.digitalocean.com/products/kubernetes/
## 1
### alias
NGINX Ingress Controller Guide
### url
https://kubernetes.github.io/ingress-nginx/deploy/
## 2
### alias
Cert-Manager Documentation
### url
https://cert-manager.io/docs/
## 3
### alias
Let's Encrypt — How It Works
### url
https://letsencrypt.org/how-it-works/
## 4
### alias
DigitalOcean Load Balancer Annotations
### url
https://docs.digitalocean.com/products/kubernetes/how-to/configure-load-balancers/

# minutesRead
30
