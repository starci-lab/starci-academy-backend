# title
Monolith vs Microservices

# description
So sánh kiến trúc Monolith và Microservices ở bản chất tổ chức và kỹ thuật, phân tích các tình huống tải và vận hành khiến Monolith bó tay, rồi chốt khi nào thật sự nên chuyển sang Microservices.

# body

## I. Lời mở đầu

Đi phỏng vấn vị trí **Senior Backend** ở công ty có sản phẩm thật, câu hỏi gần như chắc chắn sẽ rơi vào kiểu: *"Hệ thống **Shopee** có hàng nghìn kĩ sư cùng commit, tại sao họ không dùng một **codebase duy nhất** cho gọn? Nếu em là **tech lead**, khi nào em quyết định tách một **monolith** thành nhiều **service**?"*. Nhiều **beta** sẽ trả lời kiểu **"vì microservices scale tốt hơn"** — đáp án này gần đúng trên slide nhưng sai ở đời thật: **Monolith** scale **ngang** được rất tốt cho đến ngưỡng vài triệu user, và **Microservices** không tự nhiên "scale tốt hơn" mà thậm chí còn **tốn tài nguyên hơn** do **overhead mạng** giữa các service.

Câu trả lời **nghề** phải chạm được hai tầng: **tổ chức con người** (bao nhiêu team cùng sở hữu code, ai deploy vào giờ nào) và **ranh giới nghiệp vụ** (**bounded context** đã rõ chưa, hay vẫn đang dò). Nhiều startup đã **chết** vì áp dụng **Microservices** quá sớm — vỡ **distributed tracing**, nợ kỹ thuật **data consistency**, CI/CD nhân lên **N** pipeline khi team chỉ có **5 người**. Ngược lại, **Facebook** vẫn chạy phần lớn luồng chính trên một **Monolith PHP** khổng lồ (Hack/HHVM) vì với họ, ranh giới team và công cụ đã tối ưu cho hình thái đó. Bài học cần hiểu ở đây là: **không có kiến trúc tốt nhất**, chỉ có kiến trúc **phù hợp với quy mô, tổ chức, và giai đoạn sản phẩm** — và để chọn được, trước hết phải thấy rõ **hai hình thái thực sự hỏng như thế nào** dưới các loại tải khác nhau.

## II. Quan sát hai kiến trúc dưới tình huống thực tế

Thay vì đọc định nghĩa trên slide, chúng ta đặt một hệ thống **E-commerce** giả định vào bốn kịch bản hay gặp nhất trên production để xem từng hình thái phản ứng ra sao.

### 1. Khi một module bị quá tải cục bộ

Giả sử hệ thống có các module **User**, **Product**, **Search**, **Order**, **Payment**. Vào đợt **Flash Sale**, chỉ riêng module **Search** bị tải gấp **50 lần** bình thường, các module khác vẫn ở mức tải thông thường.

- **Hành vi trên Monolith:** Toàn bộ **User / Product / Search / Order / Payment** đóng gói chung thành một **image Docker** duy nhất chạy trên một **pod** hoặc một **VM**. Muốn scale **Search**, bạn buộc phải **nhân bản toàn bộ pod** — kể cả phần **Payment** đang chỉ dùng **5% CPU** cũng được nhân lên.
- **Sự cố:** Để đỡ **100.000 RPS** vào **Search**, bạn scale từ **3 pod** lên **30 pod**. Mỗi pod ăn **2GB RAM** cho cả **5 module** gộp lại. Tổng RAM cluster đội lên **60GB** chỉ vì **Search**, trong khi **Payment** vẫn chỉ cần vài trăm MB. Chi phí cloud tăng **10 lần** dù tải thực tế chỉ tăng ở một module.
- **Hành vi trên Microservices:** **Search Service** là một **deployment** riêng, chỉ **Search** được scale từ **3** lên **30 replica**. **Payment Service** vẫn giữ **2 pod**, **User Service** giữ **4 pod** — không ai bị ảnh hưởng.
- **Kết quả mong đợi:** Cùng một đợt tải, **Microservices** tốn thêm ~**60GB RAM** cho riêng Search (thay vì cộng dồn cả stack). Bài toán **scaling granularity** (mức tinh của scale) trở thành lý do kỹ thuật **mạnh nhất** để tách.
- **Kết luận:** Khi tải **không đều** giữa các module và sự chênh lệch đủ lớn (ví dụ **10x** trở lên trong giờ cao điểm), **Monolith** trả chi phí **lãng phí tài nguyên** tuyến tính theo module to nhất. Đây là tín hiệu rõ để cân nhắc tách **service**.

### 2. Khi một bug ở module phụ kéo sập toàn hệ thống

Module **Báo cáo** (**Reporting**) chỉ chạy cron **1 lần/ngày** để xuất file PDF, không quan trọng bằng **Payment**.

- **Hành vi trên Monolith:** Một ngày lập trình viên **Reporting** commit một đoạn code sinh **report** lớn — bị **rò rỉ bộ nhớ** (**memory leak**). Vì **Reporting** nằm **cùng process** với **Payment**, khi **heap** của pod đạt **OOM**, **Kubernetes kill** cả pod. **Payment** chết theo dù **code Payment** không có lỗi.
- **Sự cố:** Người dùng đang thanh toán giữa chừng bị **502**, một số **đã trừ tiền nhưng order chưa ghi** — dẫn đến **tranh chấp**, hoàn tiền thủ công, mất **uy tín thương hiệu**.
- **Hành vi trên Microservices:** **Reporting Service** chạy process riêng, container riêng, resource limit riêng. Khi **Reporting Pod** bị **OOM kill**, **Payment Pod** vẫn sống bình thường. Hệ thống chỉ mất khả năng xuất report — một chức năng **không cấp thiết**.
- **Kết quả mong đợi:** **Microservices** cách ly **bán kính ảnh hưởng** (**blast radius**) của một bug về đúng **một service**. **Monolith** không có ranh giới này — **process boundary** chính là **fault boundary**.
- **Kết luận:** Khi hệ thống có cả module **critical** (**Payment**, **Order**) lẫn module **non-critical** (**Reporting**, **Email Notification**), đặt chung một process là chấp nhận việc module phụ có thể kéo chết cả luồng chính.

### 3. Khi tốc độ deploy bị nghẽn cổ chai tổ chức

Công ty tăng từ **10** lên **300** kĩ sư trong **2 năm**. Chia thành **15 team** sản phẩm, mỗi team sở hữu một **domain**.

- **Hành vi trên Monolith:** Tất cả **15 team** cùng commit vào **một repo**. Pipeline CI chạy **tất cả test suite** (**4.500 test**, **40 phút**) cho mọi Pull Request — kể cả khi chỉ đổi **một icon** trong phần **Profile**. Deploy production cần **code freeze** cho cả công ty, chạy **smoke test** toàn hệ thống, mất **2–3 giờ** mỗi lần release.
- **Sự cố:** Team **Payment** cần deploy gấp một **bug fix** về **3D Secure** trong **2 giờ** — nhưng cùng lúc team **Search** đang deploy một bản refactor lớn, pipeline đang lock. **Payment** phải **chờ**. Release khẩn cấp mất **6 giờ** thay vì **20 phút**. Số lần release mỗi tuần rơi từ **15** xuống **2–3**.
- **Hành vi trên Microservices:** Mỗi team một repo, pipeline riêng. Team **Payment** deploy **Payment Service** **5 lần/ngày** mà không ảnh hưởng team **Search**. Độ phủ test cục bộ ~**500 test**, **3 phút** mỗi PR.
- **Kết quả mong đợi:** **Microservices** trả về **autonomy deploy** cho từng team — **independent deployability** là lợi ích **lớn nhất** của kiến trúc này (thậm chí lớn hơn cả scaling). Amazon gọi đây là nguyên tắc **"Two-pizza team"**: mỗi service do một team đủ nhỏ (**≤ 8 người**, hai pizza ăn được no) sở hữu trọn vẹn.
- **Kết luận:** Khi số team vượt ngưỡng mà **merge conflict** và **pipeline lock** bắt đầu xuất hiện hàng ngày, lý do tách service là **tổ chức con người**, không phải **kỹ thuật** — đây là ý nằm sau câu nói của **Conway**: *"Tổ chức thiết kế hệ thống thường cho ra hệ thống có hình dáng giống cấu trúc giao tiếp của chính tổ chức đó"*.

### 4. Khi Microservices trở thành gánh nặng

Một startup **15 kĩ sư**, sản phẩm mới **6 tháng**, domain chưa ổn định. Bị **hype** kéo đi, team chia sẵn **8 service** từ ngày đầu: **User**, **Auth**, **Product**, **Cart**, **Order**, **Payment**, **Notification**, **Search**.

- **Hành vi trên Microservices non-stop:** Một request **"Đặt hàng"** đi qua **5 service** (**Cart → Order → Payment → Notification → Search**). Lỗi xảy ra giữa chừng phải viết tay **Saga** và **compensation**; test end-to-end khó viết, khó chạy local. Nhân sự mới mất **2 tuần** mới dựng được môi trường vì phải clone **8 repo** + **Docker Compose** **25 container**.
- **Sự cố:** Domain thay đổi: **"Cart"** nghiệp vụ thực ra nên **gộp** với **"Order"** (chúng là cùng một **bounded context**), và **"Search"** nên **thuộc về** **"Product"**. Nhưng đã tách ra rồi — việc **gộp lại** một service khó hơn **tách mới** gấp nhiều lần, vì có **DB schema riêng**, **consumer đã tích hợp**, **event contract đã publish**.
- **Hành vi trên Monolith mà đáng ra nên dùng:** Cùng team **15 người**, cùng domain đang dò, một **codebase NestJS** duy nhất. Refactor **"Cart"** thành module của **"Order"** chỉ là di chuyển **vài file** và đổi **import**. Dev mới clone **một repo**, `npm install`, chạy **một câu lệnh** là có môi trường.
- **Kết quả mong đợi:** Với team nhỏ + domain chưa ổn định, **Microservices** biến thành **distributed monolith** — phức tạp của phân tán cộng với sự cứng nhắc của coupling ngầm qua contract. **Tốc độ phát triển tính năng giảm**, **nhân sự onboarding khó**, **bug cross-service** nhiều hơn bug trong một monolith gọn.
- **Kết luận:** **Microservices** **không miễn phí** — phải trả giá bằng **distributed tracing**, **data consistency phân tán**, **CI/CD x N**, **service discovery**, **observability**. Trả giá đó đáng khi lợi ích **vượt qua** chi phí; chưa đạt ngưỡng đó, **Monolith** là lựa chọn **khôn ngoan** hơn.

Sau bốn kịch bản này, **Microservices** rõ ràng không phải lời giải mặc định — nó là một **sự đánh đổi** trên trục **tổ chức × quy mô × độ ổn định domain**. Phần tiếp theo đặt tên cho các khái niệm vừa xuất hiện và liệt kê những **tín hiệu** cụ thể để quyết định khi nào chuyển.

## III. Bản chất kiến trúc và khi nào nên chuyển

### 1. Monolith — định nghĩa và đặc trưng thật

**Monolith** là kiến trúc trong đó **toàn bộ ứng dụng** — **UI**, **Business Logic**, **Data Access** — được đóng gói và **deploy** thành **một đơn vị** duy nhất. Điều này **không** đồng nghĩa với **code bẩn** hay **không có module**; một Monolith sạch vẫn chia thành **module** / **bounded context** rõ ràng trong cùng codebase (còn gọi là **Modular Monolith**).

- **Đặc trưng kỹ thuật:**
  - Một **process** duy nhất ở runtime; các module gọi nhau qua **function call** trong cùng memory space — **độ trễ gần như bằng 0**.
  - Một **database** chung — mọi **transaction** đều có thể dùng **ACID** của DBMS (ví dụ **PostgreSQL**) để giữ nhất quán mạnh.
  - Một **pipeline** CI/CD, một **artefact** build, một lần **deploy** cho cả hệ thống.
- **Ưu điểm:** Onboarding nhanh, **debug end-to-end** đơn giản (stack trace xuyên suốt trong một process), **không** phải xử lý **eventual consistency** cho phần lớn luồng, chi phí hạ tầng thấp (không cần **service mesh**, **distributed tracing**, **schema registry**).
- **Nhược điểm lộ rõ khi quy mô lớn:**
  - **Scaling granularity** kém — phải nhân cả khối dù chỉ một module cần nhiều tài nguyên.
  - **Fault isolation** yếu — một bug **memory leak** hoặc **deadlock** ở module phụ có thể kéo sập cả process.
  - **Deploy bottleneck** — mọi team phải đồng bộ lịch release.
  - **Codebase** phình to khó điều hướng; **build time** và **test time** tăng phi tuyến tính.

### 2. Microservices — định nghĩa và đặc trưng thật

**Microservices** là kiến trúc chia hệ thống thành **nhiều service nhỏ, độc lập**, mỗi service sở hữu **một bounded context** và **database riêng**, giao tiếp qua **mạng** (HTTP, gRPC, message broker).

- **Đặc trưng kỹ thuật:**
  - Mỗi service là **một process riêng** chạy trên **một container** riêng, có thể **scale độc lập**.
  - **Database per service** — không service nào đọc trực tiếp DB của service khác; đồng bộ dữ liệu qua **event** / **API**.
  - Giao tiếp qua **network** — mọi call đều có **latency** vài ms → vài chục ms, có thể **fail**, có thể **timeout**.
  - **Deploy độc lập** — mỗi service có pipeline, artefact, lịch release riêng.
- **Ưu điểm:**
  - **Scaling granularity** tinh — chỉ scale service đang quá tải.
  - **Fault isolation** mạnh — process boundary = fault boundary.
  - **Technology heterogeneity** — mỗi service có thể dùng stack phù hợp (Node.js cho API, Go cho tầng tốc độ cao, Python cho ML).
  - **Team autonomy** — mỗi team sở hữu trọn service từ **code** đến **deploy** đến **on-call**.
- **Nhược điểm cố hữu:**
  - **Distributed complexity**: **network partition**, **retry**, **timeout**, **idempotency**, **circuit breaker** — những thứ không tồn tại trong Monolith.
  - **Data consistency phân tán** — không còn **ACID** xuyên service; phải dùng **Saga**, **Outbox**, **eventual consistency**.
  - **Operational overhead** — cần **Kubernetes**, **service mesh** (Istio / Linkerd), **distributed tracing** (Jaeger / OpenTelemetry), **centralized logging**, **API Gateway**.
  - **Refactor ranh giới service khó** — đổi bounded context giữa hai service đã tách gần như viết lại cả hai.

### 3. Conway's Law và "Two-pizza team" — góc tổ chức con người

Kiến trúc phần mềm thường phản ánh cấu trúc giao tiếp của tổ chức xây ra nó — đây là nội dung của **Conway's Law** (1968) và vẫn đúng đến nay.

- **Ý nghĩa thực tế:** Một team **50 người** chia **5 nhóm nhỏ** giao tiếp qua **meeting tuần** sẽ tự nhiên sinh ra **5 module** hoặc **5 service** — dù ban đầu định làm Monolith. Nếu cố ép một **Monolith** cho tổ chức đã chia nhỏ, sẽ xảy ra **merge conflict** và **review bottleneck** liên tục.
- **Two-pizza team (Amazon):** Mỗi service nên do một team **đủ nhỏ để hai pizza ăn no** (~**6–8 người**) sở hữu. Team nhỏ giúp giữ **ownership rõ ràng**, giảm **overhead giao tiếp**, và giúp service có **kích thước hợp lý** — không to đến mức một team không hiểu hết, cũng không nhỏ đến mức chi phí vận hành vượt lợi ích.
- **Inverse Conway Maneuver:** Khi muốn đạt một kiến trúc đích (ví dụ microservices), **thiết kế tổ chức** trước theo hình đó (chia team theo domain) rồi để cấu trúc code tự điều chỉnh — thay vì ngược lại.

### 4. Bounded Context và Database-per-Service

**Bounded Context** (khái niệm từ **Domain-Driven Design** của Eric Evans) là **ranh giới nghiệp vụ** trong đó một **mô hình domain** có nghĩa đồng nhất. Tách service mà **không** tôn trọng bounded context sẽ tạo ra **distributed monolith**.

- **Dấu hiệu bounded context đã rõ:** Khi có sự kiện *"Order đã thanh toán"*, nếu bạn biết chính xác **Order Service** phát event, **Inventory Service** trừ kho, **Notification Service** gửi email — và không ai cần **share DB table** của ai — thì ranh giới rõ. Nếu bạn thấy **cart, order, payment** cùng đọc-ghi vào bảng `order_items` thì ranh giới **chưa** rõ, tách là **hại nhiều hơn lợi**.
- **Database-per-service là ranh giới cứng:** Mỗi service có **DB schema riêng**, không service khác được **JOIN** hoặc **query trực tiếp**. Muốn đọc dữ liệu chéo → gọi **API** hoặc **consume event**. Đây là quy tắc **kỷ luật** quan trọng nhất của Microservices — vi phạm nó thì dù đã chia process, bạn vẫn có một **distributed monolith** coupling qua DB.

### 5. Khi nào nên khởi đầu bằng Monolith, khi nào nên chuyển

Quy tắc **heuristic** phổ biến trong ngành (Martin Fowler gọi là **"Monolith First"**):

- **Bắt đầu bằng Monolith (Modular Monolith) khi:**
  - Sản phẩm **< 1 năm tuổi**, chưa đạt **product-market fit** — domain còn thay đổi nhiều tuần / tháng.
  - Team **< 20 kĩ sư** — một team còn đủ đồng bộ qua meeting + chat.
  - Chưa có **DevOps / SRE** chuyên trách — chưa đủ năng lực vận hành hạ tầng phân tán.
- **Tín hiệu thật sự cần chuyển sang Microservices:**
  - Đội phát triển vượt **~30–50 kĩ sư**, **deploy** bắt đầu cần **code freeze** cho cả công ty.
  - **Scaling requirements** chênh lệch **≥ 10x** giữa các module (ví dụ **Search** hoặc **Video Transcoding** cần tài nguyên rất khác phần còn lại).
  - **Compliance** yêu cầu cô lập một module (ví dụ **Payment** cần đi **PCI-DSS** tách hạ tầng).
  - **Domain đã ổn định** — các **bounded context** gần như không đổi trong 6–12 tháng.
- **Tín hiệu KHÔNG nên chuyển dù có vẻ "đúng thời điểm":**
  - Domain còn thay đổi hàng tháng — rủi ro tách sai bounded context.
  - Team chưa có kinh nghiệm **distributed systems** — debug một bug **cross-service** mất nhiều hơn lợi ích có được.
  - Lãnh đạo đòi chuyển vì **"microservices nghe hiện đại"** chứ không có vấn đề cụ thể đang đau.

### 6. Con đường trung dung — Modular Monolith và Strangler Fig

Không phải lúc nào cũng Monolith thuần hay Microservices thuần. Có hai mẫu trung gian thường được dùng:

- **Modular Monolith:** Vẫn một process, một DB, nhưng **code** được chia thành **module độc lập** với **quy ước giao tiếp tường minh** (ví dụ **port/adapter** của Hexagonal Architecture). Khi cần tách, bạn chỉ việc "cắt" một module ra thành service — ranh giới đã rõ sẵn. Đây là cách **Shopify**, **GitHub**, **Basecamp** đã chọn trong nhiều năm.
- **Strangler Fig (Martin Fowler):** Chuyển dần từ Monolith sang Microservices bằng cách **bọc** Monolith phía sau một **API Gateway**, rồi **trích** từng tính năng ra thành service mới, redirect traffic sang service mới cho đến khi Monolith còn rỗng. Cách này **an toàn** hơn nhiều so với **rewrite toàn bộ** — một chiến lược "big bang" mà **Netflix** đã mất **7 năm** để hoàn thành.

**Kết luận:** **Monolith** và **Microservices** không phải hai lựa chọn tốt-xấu, mà là hai điểm trên một **phổ đánh đổi**. Monolith tối ưu cho giai đoạn **tốc độ ra tính năng** khi domain chưa ổn định và team còn nhỏ; Microservices tối ưu cho giai đoạn **tốc độ mở rộng tổ chức** khi sản phẩm đã có chỗ đứng và team đông. Đa số hệ thống production tốt trong ngành **không** thuần một hình thái — chúng là **Modular Monolith** cho phần lõi cộng với một vài service tách ra vì lý do rất cụ thể (tải lệch, compliance, team riêng biệt). Câu hỏi đúng cần hỏi khi thiết kế không phải *"Monolith hay Microservices?"* mà là *"Ranh giới nghiệp vụ đã đủ rõ chưa, tổ chức đã đủ lớn để cần tách, và chi phí vận hành phân tán có đáng với lợi ích mang lại không?"*.

# references
## 0
### alias
Monolithic Architecture (microservices.io)
### url
https://microservices.io/patterns/monolithic.html
## 1
### alias
Microservices Pattern (microservices.io)
### url
https://microservices.io/patterns/microservices.html
## 2
### alias
Martin Fowler — Monolith First
### url
https://martinfowler.com/bliki/MonolithFirst.html
## 3
### alias
Martin Fowler — Strangler Fig Application
### url
https://martinfowler.com/bliki/StranglerFigApplication.html
## 4
### alias
Conway's Law
### url
https://www.melconway.com/Home/Conways_Law.html

# minutesRead
30
