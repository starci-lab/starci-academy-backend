# title
Kubernetes Core Concepts: Pod, Deployment và Service

# description
Làm chủ bộ ba nguyên tử Pod, Deployment và Service để triển khai, quản lý và kết nối hệ thống Backend, Database và Cache một cách bền bỉ trên Kubernetes.

# body

## I. Lời mở đầu

Nhiều lập trình viên **beta** thường tự hào: *"Ứng dụng của em chạy trên Local/Docker mượt lắm!"*. Nhưng khi ném lên một cụm máy chủ gồm hàng chục **Node**, mọi thứ bắt đầu "toang". Container bị sập, IP thay đổi, cần scale lên 10 bản sao để chịu tải — việc cấu hình thủ công trong file `.env` hay dùng IP tĩnh trở thành thảm họa.

Trong **System Design**, bạn không được phép tin vào sự "vĩnh cửu" của hạ tầng vật lý. Container có thể chết bất cứ lúc nào. **Kubernetes** giải quyết bài toán này không bằng cách cố giữ cho container sống mãi, mà bằng cách trừu tượng hóa chúng thành các đối tượng có khả năng **Self-healing** và **Service Discovery**. Để trèo lên mức **Senior Backend**, bạn bắt buộc phải hiểu sâu cách phối hợp bộ ba: **Pod**, **Deployment** và **Service**.

## II. Triển khai hệ sinh thái trên Kubernetes

Chúng ta sẽ triển khai một hệ thống gồm **Backend** (**NestJS**), **Database** (**MySQL**) và **Cache** (**Redis**) lên cụm **Kubernetes**, rồi quan sát cách các thành phần tìm thấy nhau và phối hợp hoạt động.

**Clone** ở đây: [kubernetes-core-concepts](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/kubernetes-core-concepts)

| Thành phần | Công nghệ | Vai trò | Cổng |
|---|---|---|---|
| Backend | **NestJS** (image `starci183/example-backend:latest`) | API Server, 3 replicas qua **Deployment** | **3000** (ClusterIP, truy cập qua `port-forward`) |
| Database | **MySQL 8.0** | Lưu trữ dữ liệu, chạy dạng **Pod** đơn | **3306** (ClusterIP) |
| Cache | **Redis 7** | Cache danh sách item, TTL **60s**, chạy dạng **Pod** đơn | **6379** (ClusterIP) |

![k8s-core-concepts-architecture](https://starci.org/system-design-mastery/kubernetes-core-concepts/0.svg)

*Hình 1. Sơ đồ kiến trúc hệ thống Backend — MySQL — Redis trên Kubernetes.*

### 1. Chuẩn bị và chạy môi trường

Giả định bạn đã cài **Minikube** (hoặc một cụm K8s) và **kubectl**. Image backend đã có sẵn trên **Docker Hub** (`starci183/example-backend:latest`). Nếu image chưa tồn tại hoặc bạn muốn dùng registry riêng, tự build và push từ thư mục `example-backend` trong repo:

```bash
cd example-backend
npm install
npm run build
docker compose build
docker login
docker tag starci183/example-backend:latest <your-registry>/example-backend:latest
docker push <your-registry>/example-backend:latest
```

Sau đó sửa trường `image` trong `backend-deployment.yaml` thành `<your-registry>/example-backend:latest`.

1. Triển khai tầng dữ liệu trước (MySQL và Redis phải sẵn sàng trước khi Backend khởi động):

```bash
kubectl apply -f mysql-pod.yaml
kubectl apply -f mysql-service.yaml
kubectl apply -f redis-pod.yaml
kubectl apply -f redis-service.yaml
```

2. Triển khai Backend (Deployment 3 replicas + ClusterIP Service):

```bash
kubectl apply -f backend-deployment.yaml
kubectl apply -f backend-service.yaml
```

3. Mở cổng truy cập từ máy local vào Service bên trong cụm bằng **port-forward**:

```bash
kubectl port-forward service/example-backend-service 3000:3000
```

Lệnh này ánh xạ cổng **3000** trên máy bạn đến cổng **3000** của **ClusterIP Service** bên trong cụm. Giữ terminal này mở trong suốt quá trình thử nghiệm.

4. Kiểm tra trạng thái toàn bộ (mở terminal khác):

```bash
kubectl get pods -o wide
kubectl get services
kubectl get deployments
```

**Kết quả mong đợi**

- `mysql-pod` và `redis-pod` ở trạng thái **Running**.
- Deployment `example-backend` hiển thị **3/3 READY**.
- Service `example-backend-service` hiển thị **ClusterIP** với cổng `3000`.

**Kết luận:** Ba thành phần đã chạy độc lập trong cụm. Backend kết nối MySQL và Redis hoàn toàn qua **DNS nội bộ** của K8s — không hề hardcode IP.

### 2. Thử nghiệm luồng hoạt động

**Bước 1 — Health Check:** Kiểm tra backend đã kết nối được MySQL và Redis.

Gửi **GET** `http://localhost:3000/health`

```bash
curl http://localhost:3000/health
```

Kết quả mong đợi:

```json
{
  "mysql": { "status": "connected", "itemCount": 0 },
  "redis": { "status": "connected" }
}
```

**Bước 2 — Tạo dữ liệu:** Ghi một item mới vào MySQL.

Gửi **POST** `http://localhost:3000/items` với body:

```json
{ "name": "kubernetes" }
```
**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:
```bash
curl -X POST http://localhost:3000/items \
  -H "Content-Type: application/json" \
  -d '{"name":"kubernetes"}'
```

Kết quả mong đợi: Backend trả về item vừa tạo kèm `id`. Đồng thời cache key `items:all` trong **Redis** bị xóa (invalidate) bởi file `app.service.ts` — dòng `await this.redis.del('items:all')`.

**Bước 3 — Đọc dữ liệu (Cache flow):**

Gửi **GET** `http://localhost:3000/items`

```bash
curl http://localhost:3000/items
```

- **Lần 1:** Cache miss — Backend truy vấn **MySQL**, lưu kết quả vào **Redis** với TTL **60 giây** (`app.service.ts` — dòng `await this.redis.set(cacheKey, JSON.stringify(items), 'EX', 60)`).
- **Lần 2 (trong vòng 60s):** Cache hit — Backend trả kết quả từ **Redis**, không query MySQL.

**Kết luận:** Luồng **Write** (POST) ghi vào **MySQL** và invalidate cache. Luồng **Read** (GET) ưu tiên **Redis** cache, fallback về **MySQL** khi cache miss. Đây là pattern **Cache-Aside** cơ bản.

Luồng hoạt động: **Client** gửi request qua `kubectl port-forward` đến **Service** `example-backend-service` `:3000` → **Service** phân phối đến 1 trong 3 **Backend Pod** → Backend gọi **MySQL** qua DNS nội bộ `mysql-service.default.svc.cluster.local:3306` và **Redis** qua `redis-service.default.svc.cluster.local:6379`.

Sau khi quan sát luồng hoạt động trơn tru, câu hỏi tiếp theo là: từng mảnh ghép **Pod**, **Deployment**, **Service** thực sự hoạt động ra sao bên dưới, và đâu là những "hố tử thần" khi đưa lên production?


## III. Bản chất kiến trúc và Những lưu ý vận hành

### 1. Pod — Đơn vị nhỏ nhất và mong manh nhất
**Pod** là đối tượng nhỏ nhất trong **Kubernetes**. Một Pod chứa một hoặc nhiều container chia sẻ mạng và lưu trữ. Trong repo, `mysql-pod.yaml` và `redis-pod.yaml` đều là Pod đơn lẻ — nghĩa là **nếu Pod chết, không có gì tự tạo lại**.

- **Ví dụ:** Chạy `kubectl delete pod mysql-pod`. Pod bị xóa và mất hoàn toàn. IP cũ biến mất. Dữ liệu trong container bị xóa sạch (vì không có **PersistentVolume**). Đây là lý do bạn **không bao giờ** chạy database trên Pod đơn lẻ trong production.

### 2. Service — Điểm neo DNS ổn định
**Service** cung cấp một **ClusterIP** (IP ảo cố định) và tên miền DNS nội bộ cho một nhóm Pod. Trong repo:
- `mysql-service.yaml`: loại **ClusterIP**, selector `app: mysql`, expose cổng **3306** → Backend gọi qua `mysql-service.default.svc.cluster.local`.
- `redis-service.yaml`: loại **ClusterIP**, selector `app: redis`, expose cổng **6379**.
- `backend-service.yaml`: loại **ClusterIP**, selector `app: example-backend`, expose cổng **3000** nội bộ — truy cập từ bên ngoài cụm bằng `kubectl port-forward`.

- **Ví dụ:** Dù Pod MySQL bị xóa và tạo lại (IP mới hoàn toàn), tên miền `mysql-service` vẫn giữ nguyên. Backend không cần restart hay đổi config.

### 3. Deployment — Self-healing và Rolling Update
**Deployment** quản lý **Desired State**: "Luôn phải có N bản sao đang chạy". Trong `backend-deployment.yaml`: `replicas: 3`, image `starci183/example-backend:latest`, `imagePullPolicy: Always`.

- **Ví dụ 1 — Self-healing:** Xóa 1 trong 3 Backend Pod bằng `kubectl delete pod <pod-name>`. K8s lập tức tạo lại Pod mới để đảm bảo luôn đủ 3.
- **Ví dụ 2 — Scaling:** `kubectl scale deployment example-backend --replicas=10`. Hệ thống mở rộng từ 3 lên 10 Pod trong vài giây, Service tự động cân bằng tải cho cả 10.


### 4. Những rủi ro khi lên Production
Demo chạy local thì không sao; trên production bạn sẽ gặp:
- **Mất dữ liệu khi Pod chết:** MySQL/Redis trong repo chạy Pod đơn, không có **PersistentVolume**. Production cần **StatefulSet** + **PersistentVolumeClaim** để dữ liệu sống sót qua các lần restart.
- **Pod "ngốn" tài nguyên Node:** Nếu không set **Resource Limits** (`resources.limits.cpu`, `resources.limits.memory`), một Pod bị memory leak có thể kéo sập tất cả Pod khác trên cùng Node.
- **Traffic đến Pod chưa sẵn sàng:** Không có **Readiness Probe** → K8s gửi request vào Pod đang loading DB → lỗi. Không có **Liveness Probe** → Pod bị deadlock nhưng K8s không biết để restart.

**Kết luận:** **Kubernetes** không làm cho ứng dụng của bạn không bao giờ hỏng — nó làm cho hệ thống **vẫn hoạt động tốt ngay cả khi các thành phần bên dưới đang hỏng hóc**. **Pod** cung cấp môi trường chạy, **Deployment** đảm bảo số lượng và sự tồn tại, **Service** đảm bảo khả năng kết nối. Khi làm chủ được bộ ba này, bạn có thể tự tin triển khai bất kỳ hệ thống phân tán nào lên nền tảng K8s.

# references
## 0
### alias
Kubernetes Objects Concepts
### url
https://kubernetes.io/docs/concepts/overview/working-with-objects/kubernetes-objects/
## 1
### alias
Services, Load Balancing, and Networking
### url
https://kubernetes.io/docs/concepts/services-networking/service/

# minutesRead
20