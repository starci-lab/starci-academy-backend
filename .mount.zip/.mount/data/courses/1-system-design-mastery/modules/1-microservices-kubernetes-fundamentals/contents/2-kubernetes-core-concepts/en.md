# title
Kubernetes Core Concepts: Pod, Deployment, and Service

# description
Master the atomic trio of Pod, Deployment, and Service to deploy, manage, and connect Backend, Database, and Cache systems resiliently on Kubernetes.

# body

## I. Introduction

Many **beta** developers often boast: *"My app runs perfectly on Local/Docker!"*. But the moment it is thrown into a cluster of dozens of **Nodes**, everything starts to fall apart. Containers crash, IPs change, scaling to 10 replicas to handle load requires manual configuration in `.env` files or static IPs — a total catastrophe.

In **System Design**, you are not allowed to believe in the "eternity" of physical infrastructure. Containers can die at any time. **Kubernetes** solves this problem not by trying to keep containers alive forever, but by abstracting them into objects with **Self-healing** and **Service Discovery** capabilities. To reach the **Senior Backend** level, you must deeply understand how the trio of **Pod**, **Deployment**, and **Service** work together.

## II. Deploying an Ecosystem on Kubernetes

We will deploy a system consisting of **Backend** (**NestJS**), **Database** (**MySQL**), and **Cache** (**Redis**) onto a **Kubernetes** cluster, then observe how the components discover each other and coordinate.

**Clone** here: [kubernetes-core-concepts](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/kubernetes-core-concepts)

| Component | Technology | Role | Port |
|---|---|---|---|
| Backend | **NestJS** (image `starci183/example-backend:latest`) | API Server, 3 replicas via **Deployment** | **3000** (ClusterIP, accessed via `port-forward`) |
| Database | **MySQL 8.0** | Data storage, standalone **Pod** | **3306** (ClusterIP) |
| Cache | **Redis 7** | Item list cache, TTL **60s**, standalone **Pod** | **6379** (ClusterIP) |

![k8s-core-concepts-architecture](https://starci.org/system-design-mastery/kubernetes-core-concepts/0.svg)

*Figure 1. System architecture for Backend — MySQL — Redis on Kubernetes.*


### 1. Setup and Run Environment

Assuming you have **Minikube** (or a K8s cluster) and **kubectl** installed. The backend image is already available on **Docker Hub** (`starci183/example-backend:latest`). If the image doesn't exist or you want to use your own registry, build and push from the `example-backend` directory in the repo:

```bash
cd example-backend
npm install
npm run build
docker compose build
docker login
docker tag starci183/example-backend:latest <your-registry>/example-backend:latest
docker push <your-registry>/example-backend:latest
```

Then update the `image` field in `backend-deployment.yaml` to `<your-registry>/example-backend:latest`.

1. Deploy the data layer first (MySQL and Redis must be ready before Backend starts):

```bash
kubectl apply -f mysql-pod.yaml
kubectl apply -f mysql-service.yaml
kubectl apply -f redis-pod.yaml
kubectl apply -f redis-service.yaml
```

2. Deploy Backend (Deployment with 3 replicas + ClusterIP Service):

```bash
kubectl apply -f backend-deployment.yaml
kubectl apply -f backend-service.yaml
```

3. Open access from your local machine to the Service inside the cluster via **port-forward**:

```bash
kubectl port-forward service/example-backend-service 3000:3000
```

This maps port **3000** on your machine to port **3000** of the **ClusterIP Service** inside the cluster. Keep this terminal open throughout the experiment.

4. Verify overall status (open another terminal):

```bash
kubectl get pods -o wide
kubectl get services
kubectl get deployments
```

**Expected Result**

- `mysql-pod` and `redis-pod` are in **Running** state.
- Deployment `example-backend` shows **3/3 READY**.
- Service `example-backend-service` shows **ClusterIP** with port `3000`.

**Conclusion:** All three components are running independently in the cluster. Backend connects to MySQL and Redis entirely through K8s **internal DNS** — no hardcoded IPs.

### 2. Try It Out

**Step 1 — Health Check:** Verify backend has connected to MySQL and Redis.

Send **GET** `http://localhost:3000/health`

```bash
curl http://localhost:3000/health
```

Expected result:

```json
{
  "mysql": { "status": "connected", "itemCount": 0 },
  "redis": { "status": "connected" }
}
```

**Step 2 — Create Data:** Write a new item to MySQL.

Send **POST** `http://localhost:3000/items` with body:

```json
{ "name": "kubernetes" }
```

```bash
curl -X POST http://localhost:3000/items \
  -H "Content-Type: application/json" \
  -d '{"name":"kubernetes"}'
```

Expected result: Backend returns the created item with an `id`. Simultaneously, cache key `items:all` in **Redis** is invalidated by `app.service.ts` — line `await this.redis.del('items:all')`.

**Step 3 — Read Data (Cache flow):**

Send **GET** `http://localhost:3000/items`

```bash
curl http://localhost:3000/items
```

- **First call:** Cache miss — Backend queries **MySQL**, stores result in **Redis** with TTL **60 seconds** (`app.service.ts` — line `await this.redis.set(cacheKey, JSON.stringify(items), 'EX', 60)`).
- **Second call (within 60s):** Cache hit — Backend returns result from **Redis**, no MySQL query.

**Conclusion:** The **Write** flow (POST) writes to **MySQL** and invalidates cache. The **Read** flow (GET) prioritizes **Redis** cache, falls back to **MySQL** on cache miss. This is the basic **Cache-Aside** pattern.

System flow: **Client** sends request via `kubectl port-forward` to **Service** `example-backend-service` `:3000` → **Service** distributes to 1 of 3 **Backend Pods** → Backend calls **MySQL** via internal DNS `mysql-service.default.svc.cluster.local:3306` and **Redis** via `redis-service.default.svc.cluster.local:6379`.

After observing the smooth operational flow, the next question is: how do **Pod**, **Deployment**, and **Service** actually work under the hood, and what are the "death traps" when going to production?


## III. Architectural Essence and Operational Considerations

### 1. Pod — The Smallest and Most Fragile Unit
A **Pod** is the smallest object in **Kubernetes**. A Pod contains one or more containers sharing network and storage. In the repo, `mysql-pod.yaml` and `redis-pod.yaml` are both standalone Pods — meaning **if a Pod dies, nothing automatically recreates it**.

- **Example:** Run `kubectl delete pod mysql-pod`. The Pod is deleted and gone completely. The old IP disappears. Data inside the container is wiped clean (since there is no **PersistentVolume**). This is why you should **never** run a database on a standalone Pod in production.

### 2. Service — A Stable DNS Anchor
A **Service** provides a **ClusterIP** (fixed virtual IP) and internal DNS name for a group of Pods. In the repo:
- `mysql-service.yaml`: type **ClusterIP**, selector `app: mysql`, exposes port **3306** → Backend calls via `mysql-service.default.svc.cluster.local`.
- `redis-service.yaml`: type **ClusterIP**, selector `app: redis`, exposes port **6379**.
- `backend-service.yaml`: type **ClusterIP**, selector `app: example-backend`, exposes port **3000** internally — accessed from outside the cluster via `kubectl port-forward`.

- **Example:** Even if the MySQL Pod is deleted and recreated (with a completely new IP), the domain `mysql-service` remains unchanged. Backend needs no restart or config change.

### 3. Deployment — Self-healing and Rolling Update
A **Deployment** manages the **Desired State**: "There must always be N replicas running." In `backend-deployment.yaml`: `replicas: 3`, image `starci183/example-backend:latest`, `imagePullPolicy: Always`.

- **Example 1 — Self-healing:** Delete 1 of 3 Backend Pods with `kubectl delete pod <pod-name>`. K8s immediately creates a new Pod to ensure there are always 3.
- **Example 2 — Scaling:** `kubectl scale deployment example-backend --replicas=10`. The system scales from 3 to 10 Pods in seconds, Service automatically load-balances across all 10.


### 4. Production "Death Traps"
The demo runs fine locally; in production you will encounter:
- **Data loss when Pods die:** MySQL/Redis in the repo run as standalone Pods without **PersistentVolume**. Production needs **StatefulSet** + **PersistentVolumeClaim** so data survives restarts.
- **Pods devouring Node resources:** Without **Resource Limits** (`resources.limits.cpu`, `resources.limits.memory`), a Pod with a memory leak can crash all other Pods on the same Node.
- **Traffic hitting unready Pods:** No **Readiness Probe** → K8s sends requests to Pods still loading DB → errors. No **Liveness Probe** → Pod is deadlocked but K8s doesn't know to restart it.

**Conclusion:** **Kubernetes** doesn't make your app never fail; it makes your system **run well even when underlying components are failing**. **Pod** provides the runtime, **Deployment** ensures quantity and existence, **Service** ensures connectivity. Once you master this trio, you can confidently deploy any distributed system on K8s.

# references
## 0
### alias
Kubernetes Objects Concepts
### url
https://kubernetes.io/docs/concepts/overview/working-with-objects/kubernetes-objects/
## 1
### alias
Services, Load Balancing, and Networking
### url
https://kubernetes.io/docs/concepts/services-networking/service/

# minutesRead
20