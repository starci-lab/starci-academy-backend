# title
Làm quen với Kubernetes (K8s) và Minikube

# description
Hiểu vai trò điều phối container của Kubernetes ở quy mô cụm, cài Minikube và kubectl trên máy cá nhân, rồi thực hành apply Pod qua file YAML và port-forward ra kiểm thử.

# body

## I. Lời mở đầu

Đi phỏng vấn **Senior Backend**, bạn gặp câu: *"Anh chạy **100 container** trên **10 server**, một container chết thì anh làm thế nào để user không thấy lỗi?"*. Đa số **beta** sẽ trả lời kiểu **`docker run --restart unless-stopped`** hoặc viết **cron** kiểm tra rồi **restart** bằng tay — người phỏng vấn nghe xong là biết bạn chưa chạm vào **hạ tầng** quy mô thật.

Ra đời thật còn đau hơn: **traffic** tăng gấp **3**, bạn muốn scale backend từ **3** bản lên **10** bản — **SSH** vào từng **Node**, chạy **`docker-compose up --scale`**, rồi cập nhật **Nginx upstream** bằng tay. Một **Node** rớt mạng là **health check** lệch, request đánh vào container đã chết, log tràn vì retry. Đây là lúc **"Container Chaos"** xuất hiện — tư duy **Bash script** và **`docker run`** không còn đủ.

Bạn cần một lớp bên trên biết: ai đang chạy ở đâu, container nào vừa chết và phải sinh lại, Pod nào đang ngốn **CPU** hơn mức cho phép, ai cần phân phối tải. Đó chính là việc của **Kubernetes** — một **Orchestrator** mã nguồn mở biến hàng trăm container rải rác thành một cụm **tự phục hồi** theo đúng **Desired State** bạn khai báo.

Đọc định nghĩa **orchestrator** bằng chữ thì mơ hồ — muốn thấy nó thật sự làm gì, phải có một cụm bật sẵn trên máy để **apply** thử một **Pod**, xem **K8s** sinh nó ra ở đâu rồi `port-forward` gọi vào — đúng là việc ở phần ngay sau.

## II. Dựng cụm Minikube và triển khai Pod đầu tiên

Chúng ta sẽ dựng một **single-node cluster** bằng **Minikube** trên máy cá nhân, apply ba **Pod** độc lập (**MySQL**, **Nginx**, **Game 2048**) để thấy cách **K8s** điều phối container qua **file YAML**, rồi `port-forward` từng Pod ra local để kiểm thử.

Ba file **Manifest** (`mysql-pod.yaml`, `nginx-pod.yaml`, `game-2048-pod.yaml`) nằm **ngay trong thư mục bài học** — không cần clone repo ngoài, mở thư mục là thấy.

| Thành phần | Công nghệ | Vai trò | Cổng |
|---|---|---|---|
| Cluster | **Minikube** (driver `docker`) | Giả lập single-node K8s cluster trên máy cá nhân | — |
| CLI | **kubectl** | Gửi **Manifest** (YAML) và lệnh quản trị tới cluster | — |
| Pod 1 | **MySQL 8.0** | Database mẫu, standalone **Pod** | **3306** (port-forward `3307` local) |
| Pod 2 | **Nginx** | Web server tĩnh, standalone **Pod** | **80** (port-forward `8080` local) |
| Pod 3 | **Game 2048** | Ứng dụng web demo, standalone **Pod** | **80** (port-forward `8081` local) |

![introduction-to-kubernetes-architecture](https://starci.org/system-design-mastery/introduction-to-kubernetes/0.svg)

*Hình 1. Sơ đồ Minikube single-node với ba Pod độc lập được apply qua `kubectl`.*

Client dùng `kubectl port-forward` để mở một kênh local → Pod; ở bước này chưa có **Service** hay **Ingress** — chỉ là **Pod trần** để bạn cảm được vòng đời của đối tượng nhỏ nhất trong **Kubernetes**.

### 1. Chuẩn bị và chạy môi trường

Giả định bạn đang ở máy có **Docker Desktop** hoặc một engine container tương đương (Linux / macOS / WSL2).

1. Cài **Docker Desktop** (làm driver cho Minikube): [docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop/).
2. Cài **Minikube** theo hệ điều hành: [minikube.sigs.k8s.io/docs/start](https://minikube.sigs.k8s.io/docs/start/).
3. Cài **kubectl**: [kubernetes.io/docs/tasks/tools](https://kubernetes.io/docs/tasks/tools/).
4. Khởi chạy single-node cluster:

```bash
minikube start --driver=docker
```

5. Xác nhận cụm đã sẵn sàng:

```bash
kubectl cluster-info
kubectl get nodes
```

6. Từ thư mục bài học, apply ba **Manifest** Pod:

```bash
kubectl apply -f mysql-pod.yaml
kubectl apply -f nginx-pod.yaml
kubectl apply -f game-2048-pod.yaml
```

**Kết quả mong đợi**

- `kubectl get nodes` trả về node `minikube` ở trạng thái **Ready**.
- `kubectl get pods -o wide` hiển thị ba Pod `mysql-pod`, `nginx-pod`, `game-2048-pod` đều **Running**, mỗi Pod có **IP cluster-internal** riêng.

**Kết luận:** Cụm **Minikube** đã lên và ba Pod chạy độc lập chỉ bằng vài file YAML — đây là cốt lõi của **Infrastructure as Code**: mô tả **trạng thái mong muốn** thay vì gõ từng lệnh trên từng Node.

### 2. Quan sát Pod và port-forward ra kiểm thử

**Bước 1 — Xem chi tiết Pod:** Kiểm tra cấu hình thực tế mà K8s đang chạy cho `mysql-pod`.

```bash
kubectl describe pod mysql-pod
```

Kết quả mong đợi: in ra các trường `Containers:`, `Image:`, `State: Running` và đặc biệt là **`Events:`** — lịch sử lập lịch container (pull image, start, restart…). Khi Pod lỗi, đây là chỗ đầu tiên phải nhìn.

**Bước 2 — Xem logs:** Đọc output stdout/stderr của container trong Pod.

```bash
kubectl logs game-2048-pod
```

Kết quả mong đợi: các dòng log khởi động của ứng dụng. Đây là đường **debug** nhanh khi Pod **Running** nhưng ứng dụng không phản hồi.

**Bước 3 — Port-forward Nginx:** Mở kênh local `:8080` tới cổng **80** của Pod.

```bash
kubectl port-forward pod/nginx-pod 8080:80
```

Gửi **GET** `http://localhost:8080`:

```bash
curl http://localhost:8080
```

Kết quả mong đợi: HTTP **200** kèm HTML chào mặc định của **Nginx**.

**Bước 4 — Port-forward Game 2048:** Mở kênh `:8081` tới cổng **80** của Pod (chạy trong terminal khác để giữ cả hai kênh sống).

```bash
kubectl port-forward pod/game-2048-pod 8081:80
```

Kết quả mong đợi: truy cập `http://localhost:8081` trên trình duyệt thấy giao diện game **2048**.

**Bước 5 — Port-forward MySQL:** Mở kênh `:3307` tới cổng **3306** của Pod để kết nối từ **MySQL client** local (password `root` khai báo trong `mysql-pod.yaml` là `root123`).

```bash
kubectl port-forward pod/mysql-pod 3307:3306
```

Câu lệnh kiểm thử tương đương — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```bash
mysql -h 127.0.0.1 -P 3307 -uroot -proot123 -e "SHOW DATABASES;"
```

Kết quả mong đợi: kết nối thành công, danh sách database mặc định của MySQL hiện ra.

**Kết luận:** `kubectl port-forward` biến một **Pod** vốn chỉ có **IP nội bộ cluster** thành thứ bạn gọi được trực tiếp từ máy cá nhân — cực tiện cho **debug**, nhưng **không** thay thế được **Service** / **Ingress** khi muốn expose Pod cho client thật ngoài cluster.

Sau khi đã thấy Pod chạy thật và gọi request thật, câu hỏi tiếp theo là: Pod trần như vậy có rủi ro gì khi lên production, và vì sao phần lý thuyết sẽ chỉ ra ngay những lớp bọc cần thiết quanh Pod thay vì apply Pod thuần?

## III. Bản chất của Kubernetes và ranh giới của Pod trần

### 1. Kubernetes là gì và vì sao Desired State quan trọng

**Kubernetes** là nền tảng mã nguồn mở điều phối container, nhưng khác biệt cốt lõi với `docker run` hay **Bash script** nằm ở triết lý **Desired State**: bạn khai báo *"tôi muốn có N container như thế này đang chạy"*, K8s có trách nhiệm duy trì đúng số đó bất chấp Node chết, container crash hay image pull lỗi.

- **Ví dụ 1 — Self-healing:** Khai một **Deployment** với `replicas: 3` cho backend. K8s lập lịch 3 Pod lên các Node; nếu một Pod chết, **controller** phát hiện lệch giữa **Desired State** và **Actual State** rồi tự tạo Pod mới.
- **Ví dụ 2 — Scheduling:** Bạn muốn scale lên **10**, chỉ cần sửa `replicas: 10` rồi `kubectl apply`. K8s tự tìm Node còn đủ **CPU** / **RAM** rồi khởi tạo thêm 7 Pod — bạn không cần biết Pod nằm Node nào.

Khác biệt với tư duy cũ: thay vì mô tả **từng bước** (imperative — `docker run`, `systemctl start`), bạn mô tả **kết quả** (declarative — **YAML**). Đây là lý do **file YAML** là giao diện chính của K8s, và cũng là lý do bài này mở đầu bằng `kubectl apply -f ...` thay vì gõ lệnh thủ tục.

### 2. Minikube, Managed Kubernetes và khi nào dùng cái nào

Cùng một bộ **Manifest** YAML chạy được từ laptop tới cloud đa vùng — đó là sức mạnh của **API** chuẩn hóa của K8s. Nhưng cluster chạy ở đâu thì tùy mục đích sử dụng.

- **Ví dụ 1 — Minikube (local dev):** Cluster single-node trên máy cá nhân bằng **VM** hoặc **container** (driver `docker`, `hyperkit`, `kvm2`…). Không tốn tiền thuê server, hợp với học K8s, verify **YAML** trước khi đẩy lên staging, thử nghiệm **Ingress** / **ConfigMap** / **Secret** cục bộ. Điểm yếu: **một node**, không mô phỏng được **multi-node scheduling** và **zone failover**.
- **Ví dụ 2 — Managed K8s (production):** **EKS** (AWS), **GKE** (Google), **AKS** (Azure), **DOKS** (DigitalOcean)… nhà cung cấp quản hộ **Control Plane** (`kube-apiserver`, `etcd`, `controller-manager`, `scheduler`). Bạn chỉ cần trả tiền và lo **Worker Nodes** + workload. Đánh đổi: chi phí cao hơn, gắn chặt hơn với hệ sinh thái cloud, đổi lại có **high availability Control Plane** đa vùng, **auto-scaling node pool**, tích hợp **IAM** / **Load Balancer** / Object Storage sẵn.
- **Ví dụ 3 — Self-managed (kubeadm, k3s, RKE2):** Bạn tự dựng cả **Control Plane**. Linh hoạt tối đa nhưng phải tự lo bản vá, upgrade `etcd`, chứng chỉ **TLS** — thường chỉ chọn khi có ràng buộc regulatory hoặc triển khai **on-premise**.

Trong khoá này dùng **Minikube** vì lab phải chạy được trên máy bạn, nhưng mọi **Manifest** trong repo có thể apply thẳng lên **EKS** / **GKE** mà gần như không phải đổi.

### 3. Pod trần và giới hạn khi đụng production

**Pod** là đơn vị nhỏ nhất K8s lập lịch, nhưng **Pod trần** (apply trực tiếp `kind: Pod` như demo trên) chỉ phù hợp ở mức học khái niệm. Production gần như luôn bọc Pod bằng một **controller** (**Deployment**, **StatefulSet**, hoặc **Job** / **CronJob**).

- **Không có self-healing khi Pod chết:** Pod trần không có controller đứng sau. `kubectl delete pod mysql-pod` là mất sạch — K8s **không** tự tạo Pod mới, không có replica dự phòng.
- **Mất dữ liệu khi Pod restart:** Container trong Pod có rootfs **ephemeral** — Pod gỡ là data biến mất. Stateful workload như **MySQL** / **Redis** cần **PersistentVolume** + **PersistentVolumeClaim** (thường đi cùng **StatefulSet**) thì dữ liệu mới sống sót qua restart và reschedule.
- **Không có endpoint ổn định cho client:** `kubectl port-forward` chỉ dùng để **debug**. Mỗi lần Pod restart là IP cluster-internal đổi, kênh forward đứt — muốn một **endpoint DNS ổn định** cho backend gọi MySQL / Redis, bắt buộc có lớp **Service** đứng trước Pod.
- **Không có Resource Limits thì một Pod có thể kéo sập Node:** Mặc định Pod **không** giới hạn CPU / RAM; một container memory-leak có thể gây **OOM kill** cho toàn bộ Pod cùng Node. Production yêu cầu `resources.requests` và `resources.limits` rõ ràng cho mọi Pod.

**Kết luận:** **Kubernetes** không làm hệ thống bớt phức tạp — nó làm cho sự phức tạp **quản lý được** bằng cách chuyển bạn từ "SSH vào từng Node chỉnh tay" sang "mô tả **Desired State** bằng YAML". **Minikube** là sân tập đủ cho bài này: một cụm single-node, ba **Pod** apply qua `kubectl`, `port-forward` để sờ tận tay. Khi đã nắm vòng đời của Pod trần và những giới hạn của nó, bạn đã có nền để ghép dần các lớp **controller** và **Service** lên trên khi hệ thống thật cần khả năng sống sót qua crash và scale theo tải.

# references
## 0
### alias
Kubernetes Documentation
### url
https://kubernetes.io/docs/concepts/overview/what-is-kubernetes/
## 1
### alias
Minikube Official Guide
### url
https://minikube.sigs.k8s.io/docs/start/
## 2
### alias
Pod — Kubernetes Concepts
### url
https://kubernetes.io/docs/concepts/workloads/pods/

# minutesRead
15
