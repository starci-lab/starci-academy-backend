# title
Complex Applications and Helm Charts

# description
Deploy three production-grade database clusters on Kubernetes with a single Helm command: MongoDB Sharded, PostgreSQL HA, and Redis Cluster — using Bitnami Helm Charts over the OCI registry with real High Availability.

# body

## I. Introduction

Running **MySQL** as a bare **Pod** and **NestJS** as a few-replica **Deployment** is enough for a demo, but any **Senior Backend** interview will immediately ask: *"production has **3 MongoDB nodes** forming a **replica set** plus **sharding** by **shard key** — when the **Primary** dies, how long does **failover** take?"*, then *"now add **PostgreSQL** with **Primary–Standby** and **Redis** as a **6-node cluster** with slot sharding — how many **Manifests** do you hand-write?"*. Writing your own **StatefulSet** + **Headless Service** + **init containers** + **ConfigMap** + **Secret** for a database cluster takes an afternoon, and 90% of the time you miss a **hostname resolution** detail between replicas or forget `volumeClaimTemplates` so data evaporates with the Pod.

The industry solved this with a K8s-native package manager: **Helm**. Like `brew` for macOS or `npm` for Node.js, **Helm** packages dozens of **Manifests** into a **Chart** with overridable **values** — one `helm install` and the whole cluster stands itself up in the community-proven shape. Within this ecosystem, **Bitnami** is the most widely used database-chart vendor: **MongoDB Sharded**, **PostgreSQL HA**, and **Redis Cluster** all ship **production-ready** charts with **StatefulSet**, **PersistentVolumeClaim**, health checks, and metrics exporters pre-wired. The only real way to internalize **Helm** is to open all three charts and apply them in one sitting — which is exactly what the next part does.

## II. Deploying Three Production Database Clusters with Bitnami Helm Charts

All three clusters live in the `database` namespace on Minikube or DOKS. Each exposes a stable endpoint via **Kubernetes DNS** for the backend to call.

**Clone** here: [complex-applications-and-helm-charts](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/complex-applications-and-helm-charts)

| Cluster | OCI Chart | Components | Total Pods | In-cluster Endpoint |
|---|---|---|---|---|
| **MongoDB Sharded** | `bitnamicharts/mongodb-sharded` | 2 Shards × 3 data nodes + 3 ConfigServers + 2 Mongos | **11** | `mongodb-sharded-mongodb-sharded.database.svc.cluster.local:27017` |
| **PostgreSQL HA** | `bitnamicharts/postgresql-ha` | 3 `postgresql-repmgr` (1 Primary + 2 Standby) + 2 Pgpool | **5** | `postgresql-ha-pgpool.database.svc.cluster.local:5432` |
| **Redis Cluster** | `bitnamicharts/redis-cluster` | 6 Redis nodes (3 Master + 3 Slave, auto-sharded) | **6** | `redis-cluster.database.svc.cluster.local:6379` |

*Each cluster has its own architecture diagram inline with its deployment step below.*

### 1. Setup and Run Environment

Assumes you have a **Kubernetes cluster** (Minikube from lesson 1 or DOKS from lesson 4) and `kubectl get nodes` returns **Ready** nodes. The cluster needs a default **StorageClass** for automatic **PersistentVolumeClaim** provisioning (Minikube uses `standard`, DOKS uses `do-block-storage`).

1. Install **Helm** ≥ **3.8** (required for **OCI registry** support):

| OS | Install command |
|---|---|
| macOS | `brew install helm` |
| Windows (Chocolatey) | `choco install kubernetes-helm` |
| Windows (Winget) | `winget install Helm.Helm` |
| Linux (Snap) | `sudo snap install helm --classic` |

Verify versions:

```bash
kubectl version --client
helm version
```

Expected result: `helm version` returns `v3.8.x` or newer (line containing `GitVersion:"v3.x"`); `kubectl version` matches the server.

2. **Clone** the repo and enter the lesson directory:

```bash
git clone https://github.com/StarCi-Academy/resources.git
cd resources/system-design-mastery/complex-applications-and-helm-charts
```

Each subdirectory (`mongodb-sharded`, `postgresql-ha`, `redis-cluster`) contains exactly 4 files: **`values.origin.yaml`** (untouched copy from Bitnami's GitHub for reference), **`values.yaml`** (override — only the lines that change, mostly swapping `bitnami/*` for `bitnamilegacy/*` after Docker Hub policy changes in November 2024), **`run.sh`** / **`run.ps1`** (deploy script).

3. Deploy **MongoDB Sharded**:

![mongodb-sharded-architecture](https://starci.org/system-design-mastery/complex-applications-and-helm-charts/mongodb-sharded-0.svg)

*Figure 1. MongoDB Sharded — client → Mongos router → Config Server holds the shard map → 2 shards (3 data nodes each), routing by **hashed(_id)**.*

```bash
cd mongodb-sharded
chmod +x run.sh && ./run.sh
```

The script does three things: create namespace `database` (idempotent via `kubectl create --dry-run=client ... | apply`), run `helm upgrade --install mongodb-sharded oci://registry-1.docker.io/bitnamicharts/mongodb-sharded -n database --values values.yaml --wait`, then print Pod status + endpoint + password.

Per `values.yaml`: `shards: 2`, `configsvr.replicaCount: 3`, `mongos.replicaCount: 2`, `shardsvr.dataNode.replicaCount: 3`, `auth.rootPassword: "root123"`.

```bash
kubectl get pods -n database -l app.kubernetes.io/instance=mongodb-sharded
```

Expected result: **11 Pods** with prefix `mongodb-sharded-*`: `mongodb-sharded-configsvr-0..2`, `mongodb-sharded-mongos-<hash>-...` (2 replicas), `mongodb-sharded-shard0-data-0..2`, `mongodb-sharded-shard1-data-0..2`, all **1/2 or 2/2 Running** (metrics exporter sidecar). `--wait` keeps the script blocked until every Pod is **Ready**, so you don't have to watch manually.

4. Deploy **PostgreSQL HA**:

![postgresql-ha-architecture](https://starci.org/system-design-mastery/complex-applications-and-helm-charts/postgresql-ha-0.svg)

*Figure 2. PostgreSQL HA — client → Pgpool (writes → Primary, reads → Standby) → 3 PostgreSQL-Repmgr nodes with streaming replication, failover in ~10–20s.*

```bash
cd ../postgresql-ha
chmod +x run.sh && ./run.sh
```

Per `values.yaml`: `postgresql.replicaCount: 3` (1 Primary + 2 Standby via **Repmgr**), `pgpool.replicaCount: 2` (connection pooling + load balancing), credentials `postgres/postgres123`, database `demo_db`.

```bash
kubectl get pods -n database -l app.kubernetes.io/instance=postgresql-ha
```

Expected result: **5 Pods**: `postgresql-ha-postgresql-0..2` (StatefulSet) + `postgresql-ha-pgpool-<hash>-...` (2 Deployment replicas). Watch Pgpool logs to see it discover the Primary and route traffic:

```bash
kubectl logs -n database -l app.kubernetes.io/component=pgpool --tail=20
```

Key line: `find primary node: postgresql-ha-postgresql-0` — Pgpool handshakes with **Repmgr** and learns who the Primary is.

5. Deploy **Redis Cluster**:

![redis-cluster-architecture](https://starci.org/system-design-mastery/complex-applications-and-helm-charts/redis-cluster-0.svg)

*Figure 3. Redis Cluster 6 nodes — 3 masters split **16384 slots** via CRC16, 3 slaves async replicate; nodes gossip over Cluster Bus (:16379) for auto-failover.*

```bash
cd ../redis-cluster
chmod +x run.sh && ./run.sh
```

Per `values.yaml`: `cluster.nodes: 6`, `cluster.replicas: 1` (each master has 1 slave → 3 masters + 3 slaves), `usePassword: true`, `password: "redis123"`.

```bash
kubectl get pods -n database -l app.kubernetes.io/instance=redis-cluster
```

Expected result: **6 Pods** `redis-cluster-0..5`. Once the chart finishes, a Job `redis-cluster-cluster-create` runs `redis-cli --cluster create ...` to assign **slots** (`0-5460`, `5461-10922`, `10923-16383`) to the 3 masters and pair them with slaves. Verify:

```bash
kubectl exec -it -n database redis-cluster-0 -- redis-cli -a redis123 cluster info | head -5
```

Expected result: `cluster_state:ok`, `cluster_slots_assigned:16384`, `cluster_known_nodes:6`, `cluster_size:3`.

**Overall Expected Result**

- `kubectl get pods -n database` shows **22 Pods** (11 + 5 + 6) all **Ready**.
- `kubectl get pvc -n database` shows 8Gi **PersistentVolumeClaims** for each database node in **Bound** state — data survives Pod restarts.
- `kubectl get svc -n database` lists **Headless Services** (`-headless`) for StatefulSets plus main **ClusterIP Services** per release.

**Conclusion:** Three production database clusters on a single cluster after just **three `run.sh` runs**. No handwritten StatefulSet Manifests — Bitnami bundled them. The biggest difference versus bare Pods in previous lessons: every release now uses **StatefulSet** (stable identity) + **PVC** (durable data) + **liveness/readiness probes** + **metrics exporter**, meeting production bar.

### 2. Verifying Connection Flow and Survivability

**Step 1 — Connect to MongoDB Sharded via Mongos:**

```bash
kubectl run mongo-client --rm -it --image=bitnamilegacy/mongodb-sharded:8.0.13-debian-12-r0 \
  -n database -- mongosh \
  mongodb://root:root123@mongodb-sharded-mongodb-sharded:27017/admin
```

In the `mongosh` shell:

```javascript
sh.status()
use demo
sh.shardCollection("demo.orders", { _id: "hashed" })
for (let i = 0; i < 1000; i++) db.orders.insertOne({ _id: i, name: "item" + i })
db.orders.getShardDistribution()
```

Expected result: `sh.status()` shows 2 shards `shard0`, `shard1`; after inserting 1000 documents, `getShardDistribution()` shows data spread fairly evenly across both shards — proof that **hashed sharding** works.

**Step 2 — Connect to PostgreSQL HA via Pgpool and test failover:**

```bash
kubectl run pg-client --rm -it --image=bitnamilegacy/postgresql-repmgr:17.6.0-debian-12-r2 \
  -n database --env="PGPASSWORD=postgres123" -- \
  psql -h postgresql-ha-pgpool -U postgres -d demo_db -c "SELECT inet_server_addr(), version();"
```

Expected result: returns the internal IP of the Primary (`postgresql-ha-postgresql-0`) + PostgreSQL 17.6 version. Now kill the Primary to test failover:

```bash
kubectl delete pod -n database postgresql-ha-postgresql-0
kubectl get pods -n database -l app.kubernetes.io/component=postgresql -w
```

Within **10–20 seconds**: **Repmgr** detects the missing Primary → promotes `postgresql-ha-postgresql-1` to Primary → **Pgpool** reloads its node list. Re-run the `psql` command above; `inet_server_addr()` now returns the new node's IP — the application **never changed its connection string**, only the Primary underneath changed.

**Step 3 — Connect to Redis Cluster and witness MOVED redirects:**

```bash
kubectl exec -it -n database redis-cluster-0 -- redis-cli -a redis123 -c \
  SET "user:100" "alice"
kubectl exec -it -n database redis-cluster-0 -- redis-cli -a redis123 -c \
  GET "user:100"
```

The `-c` flag enables **cluster mode** in `redis-cli`. Key `user:100` hashes to slot `9842`, owned by master 2. If you hit the wrong master, the server replies **`-MOVED 9842 <ip>:6379`** → `redis-cli -c` auto-follows the redirect and fetches the value. Without `-c`, a naive client would fail on `MOVED` and the user would have to route manually.

**Step 4 — See Persistent Volume Claim (PVC):**

```bash
kubectl get pvc -n database
kubectl delete pod -n database redis-cluster-0
kubectl exec -it -n database redis-cluster-0 -- redis-cli -a redis123 GET "user:100"
```

Expected result: Pod `redis-cluster-0` is deleted, the **StatefulSet** re-creates a Pod with the same name, reattaches the original **PVC** → the `user:100` value is still there. This is exactly what bare Pods from lesson 1 could not do.

**Conclusion:** These three flows highlight the real value of HA charts: **MongoDB Sharded** distributes writes by hashed shard key, **PostgreSQL HA** auto-failovers without app-side changes, **Redis Cluster** persists through Pod deletion thanks to **PVC** + **StatefulSet**. The stable Service DNS (`*.database.svc.cluster.local`) acts as the abstraction layer — the backend only needs a name, unaware of which node is currently Primary.

Running three clusters is one thing; the deeper question is why Bitnami designs each chart this way, what separates `values.origin.yaml` from `values.yaml`, and where the "death traps" hide in real production.

## III. The Essence of Helm, Bitnami, and Production Considerations

### 1. Helm — The Package Manager for Kubernetes

**Helm** is a client-side tool: it reads a **Chart** (a directory / tarball of Go template files), merges it with your **`values.yaml`**, renders the final Manifest, and pushes it to **`kube-apiserver`**. Since Helm 3, there is no in-cluster Helm daemon — release state lives in a per-namespace **Secret** as revision history.

- **Template engine:** Inside a chart, `deployment.yaml` is not raw YAML but a template like `replicas: {{ .Values.replicaCount }}`. When you run `helm install --values values.yaml`, Helm fills in the placeholders and applies. That is why the same chart runs on Minikube, EKS, DOKS with the same command — only `values.yaml` differs.
- **Release & rollback:** Each `helm install` creates a **release** (here `mongodb-sharded`, `postgresql-ha`, `redis-cluster`). `helm list -n database` shows the current revision; `helm rollback <release> <revision>` reverts in seconds. With raw Manifests you'd have to keep git history and re-apply manually.
- **OCI registry (Helm 3.8+):** Instead of classic `helm repo add`, charts now live inside an **OCI registry** (Docker Hub, GHCR, ECR). `oci://registry-1.docker.io/bitnamicharts/mongodb-sharded` flows through the same image pipeline — reusing cache, signing, authentication. The demo repo uses this, so `helm upgrade --install` does not require `helm repo update`.
- **When NOT to use Helm:** An app with only 1–2 Manifests (like the Pod + Service from lesson 1) is not worth wrapping in Helm — template overhead outweighs the benefit. Helm shines when the chart covers **≥ 10 related Manifests** needing coordinated configuration.

### 2. Bitnami and the `values.origin.yaml` / `values.yaml` Pair

**Bitnami** (now under **VMware** / **Broadcom**) maintains what is effectively the industry reference set of database charts: wide test matrix, security hardening, built-in Prometheus metrics. Calling it the "gold standard" is not marketing — inherit a production cluster from another team with Bitnami charts and 80% of the time the config is sane.

- **Why `bitnamilegacy/*`?** Starting late **2024**, Docker Hub enforced rate limits on the `bitnami/*` namespace. Bitnami created the `bitnamilegacy/*` mirror on Docker Hub so the open-source community could keep pulling for free. The `values.yaml` in the repo only overrides `image.repository` — all other logic stays identical to the official chart.
- **Why keep `values.origin.yaml`?** That file is the raw **`helm show values`** output (~60–110KB, thousands of config keys). Keeping it next to `values.yaml` serves two purposes: (1) **local grep** when you want to flip an obscure option (`architecture`, `tls.enabled`, `networkPolicy`...) without opening a browser, (2) **diff** to measure how far you've drifted from the upstream chart.
- **Minimal-override principle:** The demo `values.yaml` is only ~60 lines — swap images and a few replicas / passwords. Do not copy `values.origin.yaml` and edit it wholesale: new chart versions add keys, your copy drops them, upgrades explode. The smaller the override, the smoother `helm upgrade` stays.

### 3. StatefulSet, Headless Service, and Stable Identity

Why do MongoDB / PostgreSQL / Redis Cluster require **StatefulSet** instead of **Deployment**? Because they are stateful — each replica needs **stable identity** (to know who is Primary, who is slave-of-whom) and **durable disk** (so data survives Pod reschedules).

- **Stable Pod names:** `mongodb-sharded-shard0-data-0`, `postgresql-ha-postgresql-1`, `redis-cluster-3` — fixed indices, not random hashes like Deployment. Replica `postgresql-ha-postgresql-0` is always the first node in the cluster, even after delete/re-create.
- **Headless Service + per-Pod DNS:** In addition to the main Service, the chart creates one with `clusterIP: None`. DNS then does **not** load balance but returns the **IP of each Pod**: `mongodb-sharded-shard0-data-0.mongodb-sharded-headless.database.svc.cluster.local`. That is how Repmgr / MongoDB replicas communicate by stable hostname rather than ephemeral IP.
- **PersistentVolumeClaim template:** StatefulSet exposes `volumeClaimTemplates` — each replica gets its own PVC named `<pvc-name>-<statefulset>-<index>`. Pod `postgresql-ha-postgresql-1` always remounts its exact **PVC** `data-postgresql-ha-postgresql-1`, even when rescheduled to another Node. Bare Pods in lesson 1 had no such guarantee.
- **Reverse-order rolling updates:** StatefulSet upgrades from the **highest index down**, waiting for each Pod to be **Ready** before moving to the next. For PostgreSQL this guarantees Standbys upgrade before the Primary, minimizing outage.

### 4. Production Death Traps

- **Plain-text passwords in `values.yaml`:** `root123`, `postgres123`, `redis123` sit openly in the file — fine for a demo, production must move to **Secret** references (`auth.existingSecret`) managed via **External Secrets Operator** + **Vault** or a cloud secret manager.
- **PVC 8Gi does not auto-expand:** `persistence.size: 8Gi` is fixed. When data exceeds 8Gi, you cannot resize on an existing Pod — you need a **StorageClass** with `allowVolumeExpansion: true` (DO `do-block-storage` has it, Minikube `standard` has it), `kubectl edit pvc`, then a Pod restart. Better: size correctly up-front and alert when disk usage crosses 70%.
- **Insufficient default resource requests/limits:** `values.origin.yaml` ships with `resources.preset: "none"` or `nano` — lab-appropriate, production-insufficient. A production MongoDB shard data node needs **≥ 2 CPU, 4Gi RAM**; a PostgreSQL Primary **≥ 2 CPU, 2Gi RAM**. Without limits, a heavy query can **OOM kill** the node and take the whole cluster down.
- **Only 1 replica factor for MongoDB shard data nodes:** The demo has `shardsvr.dataNode.replicaCount: 3` but the chart does not auto-enable a **replica set** within each shard. Production must provision per-shard replica sets to avoid data loss when one node dies. Read `values.origin.yaml` under `shardsvr.dataNode.replicas` carefully.
- **Metrics exporters enabled but no Prometheus:** All three charts enable `metrics.enabled: true`, but you have not installed **Prometheus + Grafana** to scrape them yet. Production typically pairs with the **kube-prometheus-stack** Helm chart — which is why people say *"Helm is the gateway to K8s production"*: one chart drags in many others.
- **Namespace `database` lacks a NetworkPolicy:** By default every Pod in the cluster can talk to the databases. Production must write a **NetworkPolicy** restricting it: only the backend namespace may reach ports 3306/5432/6379/27017.

**Conclusion:** The three database clusters in this lesson are a real slice of modern production architecture: **Helm** is the package manager, **Bitnami** delivers canned best-practice, and K8s **StatefulSet + PVC + Headless Service** form the substrate for stateful workloads. The memorable principle is **minimal override** — keep `values.yaml` as close to the upstream chart as possible for smooth upgrades. Once you can spin up these three clusters with a single script, wiring them to a backend in a real cloud environment becomes just a matter of swapping hostnames.

# references
## 0
### alias
Helm — The Package Manager for Kubernetes
### url
https://helm.sh/docs/
## 1
### alias
Helm OCI Registry Support
### url
https://helm.sh/docs/topics/registries/
## 2
### alias
Bitnami Charts on GitHub
### url
https://github.com/bitnami/charts
## 3
### alias
Kubernetes StatefulSet Documentation
### url
https://kubernetes.io/docs/concepts/workloads/controllers/statefulset/
## 4
### alias
Bitnami Legacy Images on Docker Hub
### url
https://hub.docker.com/u/bitnamilegacy

# minutesRead
28
