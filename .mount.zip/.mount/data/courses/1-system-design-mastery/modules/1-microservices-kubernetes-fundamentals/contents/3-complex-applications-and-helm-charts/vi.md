# title
Ứng dụng phức tạp và Helm Chart

# description
Triển khai ba cụm database chuẩn production trên Kubernetes chỉ bằng một lệnh Helm: MongoDB Sharded, PostgreSQL HA và Redis Cluster — sử dụng Bitnami Helm Charts qua OCI registry, cấu hình High Availability thật sự.

# body

## I. Lời mở đầu

Chạy **MySQL** bằng một **Pod** trần và **NestJS** bằng một **Deployment** vài replica là đủ để demo, nhưng đi phỏng vấn **Senior Backend** sẽ bị hỏi ngay: *"production của em có **3 node MongoDB** làm **replica set** + **sharding** theo **shard key**, **Primary** chết thì **failover** trong bao lâu?"*, rồi *"thêm **PostgreSQL** với **Primary–Standby**, **Redis** dạng **cluster 6 node** chia slot — một cụm bạn gõ tay bao nhiêu **Manifest**?"*. Tự viết **StatefulSet** + **Headless Service** + **init container** + **ConfigMap** + **Secret** cho một cụm database — một buổi chiều chưa xong, và 90% khả năng sai **hostname resolution** giữa các replica hoặc quên field `volumeClaimTemplates` khiến dữ liệu bay theo Pod.

Ngành đã giải quyết chỗ này bằng một package manager chuyên cho K8s: **Helm**. Giống như `brew` cho macOS hay `npm` cho Node.js, **Helm** đóng gói hàng chục **Manifest** thành một **Chart** có **values** để override — chạy `helm install`, toàn bộ cụm tự dựng lên theo đúng kiến trúc đã được cộng đồng kiểm chứng. Trong hệ sinh thái này, **Bitnami** là đơn vị bán chart database được dùng nhiều nhất thế giới: **MongoDB Sharded**, **PostgreSQL HA**, **Redis Cluster** đều có chart **production-ready** với **StatefulSet**, **PersistentVolumeClaim**, health check, metrics exporter cài sẵn. Muốn nắm **Helm** thật sự không có cách nào ngoài mở ba chart đó ra apply một lượt và quan sát — đúng là việc ở phần ngay sau.

## II. Triển khai ba cụm Database Production với Bitnami Helm Charts

Ba cụm cùng nằm trong namespace `database` trên cluster Minikube hoặc DOKS. Mỗi cụm có endpoint cố định qua **Kubernetes DNS** để backend gọi vào.

**Clone** ở đây: [complex-applications-and-helm-charts](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/complex-applications-and-helm-charts)

| Cụm | Chart OCI | Thành phần | Tổng Pod | Endpoint trong cluster |
|---|---|---|---|---|
| **MongoDB Sharded** | `bitnamicharts/mongodb-sharded` | 2 Shard × 3 data node + 3 ConfigServer + 2 Mongos | **11** | `mongodb-sharded-mongodb-sharded.database.svc.cluster.local:27017` |
| **PostgreSQL HA** | `bitnamicharts/postgresql-ha` | 3 `postgresql-repmgr` (1 Primary + 2 Standby) + 2 Pgpool | **5** | `postgresql-ha-pgpool.database.svc.cluster.local:5432` |
| **Redis Cluster** | `bitnamicharts/redis-cluster` | 6 node Redis (3 Master + 3 Slave, shard tự động) | **6** | `redis-cluster.database.svc.cluster.local:6379` |

*Mỗi cụm có sơ đồ kiến trúc riêng ở phần triển khai tương ứng bên dưới.*

### 1. Chuẩn bị và chạy môi trường

Giả định bạn đã có **Kubernetes cluster** (Minikube từ bài 1, hoặc DOKS ở bài 4) và `kubectl get nodes` đã **Ready**. Cluster cần có **StorageClass** default để cấp **PersistentVolumeClaim** tự động (Minikube dùng `standard`, DOKS dùng `do-block-storage`).

1. Cài **Helm** ≥ **3.8** (bắt buộc để dùng **OCI registry**):

| OS | Lệnh cài |
|---|---|
| macOS | `brew install helm` |
| Windows (Chocolatey) | `choco install kubernetes-helm` |
| Windows (Winget) | `winget install Helm.Helm` |
| Linux (Snap) | `sudo snap install helm --classic` |

Kiểm tra phiên bản:

```bash
kubectl version --client
helm version
```

Kết quả mong đợi: `helm version` trả `v3.8.x` trở lên (có dòng `GitVersion:"v3.x"`), `kubectl version` khớp với server.

2. **Clone** repo và vào thư mục bài học:

```bash
git clone https://github.com/StarCi-Academy/resources.git
cd resources/system-design-mastery/complex-applications-and-helm-charts
```

Mỗi thư mục con (`mongodb-sharded`, `postgresql-ha`, `redis-cluster`) có đúng 4 file: **`values.origin.yaml`** (bản sao nguyên vẹn từ Bitnami GitHub để tham chiếu), **`values.yaml`** (override — chỉ chứa những dòng cần đổi, chủ yếu là đổi `bitnami/*` sang `bitnamilegacy/*` do DockerHub đổi chính sách từ tháng 11/2024), **`run.sh`** / **`run.ps1`** (script deploy).

3. Deploy **MongoDB Sharded**:

![mongodb-sharded-architecture](https://starci.org/system-design-mastery/complex-applications-and-helm-charts/mongodb-sharded-0.svg)

*Hình 1. MongoDB Sharded — client qua Mongos router → Config Server giữ shard map → 2 shard (mỗi shard 3 data node), định tuyến theo **hashed(_id)**.*

```bash
cd mongodb-sharded
chmod +x run.sh && ./run.sh
```

Script làm 3 việc: tạo namespace `database` (idempotent qua `kubectl create --dry-run=client ... | apply`), chạy `helm upgrade --install mongodb-sharded oci://registry-1.docker.io/bitnamicharts/mongodb-sharded -n database --values values.yaml --wait`, rồi in trạng thái Pod + endpoint + password.

Theo `values.yaml`: `shards: 2`, `configsvr.replicaCount: 3`, `mongos.replicaCount: 2`, `shardsvr.dataNode.replicaCount: 3`, `auth.rootPassword: "root123"`.

```bash
kubectl get pods -n database -l app.kubernetes.io/instance=mongodb-sharded
```

Kết quả mong đợi: **11 Pod** đang chạy với tên có prefix `mongodb-sharded-*`: `mongodb-sharded-configsvr-0..2`, `mongodb-sharded-mongos-<hash>-...` (2 replica), `mongodb-sharded-shard0-data-0..2`, `mongodb-sharded-shard1-data-0..2`, tất cả **1/2 hoặc 2/2 Running** (có metrics exporter sidecar). `--wait` làm script chỉ thoát khi toàn bộ Pod **Ready**, nên không phải chờ tay.

4. Deploy **PostgreSQL HA**:

![postgresql-ha-architecture](https://starci.org/system-design-mastery/complex-applications-and-helm-charts/postgresql-ha-0.svg)

*Hình 2. PostgreSQL HA — client qua Pgpool (routes write → Primary, read → Standby) → 3 node PostgreSQL-Repmgr với streaming replication, failover ~10–20s.*

```bash
cd ../postgresql-ha
chmod +x run.sh && ./run.sh
```

Theo `values.yaml`: `postgresql.replicaCount: 3` (1 Primary + 2 Standby qua **Repmgr**), `pgpool.replicaCount: 2` (connection pooling + load balancing), credentials `postgres/postgres123`, database `demo_db`.

```bash
kubectl get pods -n database -l app.kubernetes.io/instance=postgresql-ha
```

Kết quả mong đợi: **5 Pod**: `postgresql-ha-postgresql-0..2` (StatefulSet) + `postgresql-ha-pgpool-<hash>-...` (2 Deployment replica). Xem log Pgpool để thấy nó phát hiện Primary và route traffic:

```bash
kubectl logs -n database -l app.kubernetes.io/component=pgpool --tail=20
```

Dòng quan trọng: `find primary node: postgresql-ha-postgresql-0` — Pgpool đã bắt tay với **Repmgr** và biết ai đang là Primary.

5. Deploy **Redis Cluster**:

![redis-cluster-architecture](https://starci.org/system-design-mastery/complex-applications-and-helm-charts/redis-cluster-0.svg)

*Hình 3. Redis Cluster 6 node — 3 master chia **16384 slot** theo CRC16, 3 slave async replicate; các node gossip qua Cluster Bus (:16379) để tự failover.*

```bash
cd ../redis-cluster
chmod +x run.sh && ./run.sh
```

Theo `values.yaml`: `cluster.nodes: 6`, `cluster.replicas: 1` (nghĩa là mỗi master có 1 slave → 3 master + 3 slave), `usePassword: true`, `password: "redis123"`.

```bash
kubectl get pods -n database -l app.kubernetes.io/instance=redis-cluster
```

Kết quả mong đợi: **6 Pod** `redis-cluster-0..5`. Khi chart khởi động xong sẽ có thêm một Job `redis-cluster-cluster-create` chạy lệnh `redis-cli --cluster create ...` để gán **slot** (`0-5460`, `5461-10922`, `10923-16383`) cho 3 master và ghép pair với slave. Kiểm tra:

```bash
kubectl exec -it -n database redis-cluster-0 -- redis-cli -a redis123 cluster info | head -5
```

Kết quả mong đợi: `cluster_state:ok`, `cluster_slots_assigned:16384`, `cluster_known_nodes:6`, `cluster_size:3`.

**Kết quả mong đợi chung**

- `kubectl get pods -n database` trả về **22 Pod** (11 + 5 + 6) đều **Ready**.
- `kubectl get pvc -n database` cho thấy các **PersistentVolumeClaim** 8Gi cho từng node database đã được `Bound` — dữ liệu sống sót qua restart Pod.
- `kubectl get svc -n database` hiện các **Headless Service** (`-headless`) cho StatefulSet + **ClusterIP Service** chính cho từng release.

**Kết luận:** Ba cụm database sản xuất lên cùng một cluster chỉ với **ba lần chạy `run.sh`**. Không phải viết một dòng StatefulSet tay nào — Bitnami đã đóng gói sẵn. Khác biệt lớn nhất với các Pod trần ở bài trước: mỗi release giờ dùng **StatefulSet** (định danh bền vững) + **PVC** (dữ liệu bền vững) + **liveness/readiness probe** + **metrics exporter**, đủ tiêu chuẩn production.

### 2. Kiểm tra luồng kết nối và khả năng sống sót

**Bước 1 — Kết nối MongoDB Sharded qua Mongos:**

```bash
kubectl run mongo-client --rm -it --image=bitnamilegacy/mongodb-sharded:8.0.13-debian-12-r0 \
  -n database -- mongosh \
  mongodb://root:root123@mongodb-sharded-mongodb-sharded:27017/admin
```

Trong shell `mongosh`:

```javascript
sh.status()
use demo
sh.shardCollection("demo.orders", { _id: "hashed" })
for (let i = 0; i < 1000; i++) db.orders.insertOne({ _id: i, name: "item" + i })
db.orders.getShardDistribution()
```

Kết quả mong đợi: `sh.status()` hiện 2 shard `shard0`, `shard1`; sau khi insert 1000 doc, `getShardDistribution()` cho thấy dữ liệu được chia tương đối đều giữa hai shard — minh chứng **hashed sharding** đã hoạt động.

**Bước 2 — Kết nối PostgreSQL HA qua Pgpool và test failover:**

```bash
kubectl run pg-client --rm -it --image=bitnamilegacy/postgresql-repmgr:17.6.0-debian-12-r2 \
  -n database --env="PGPASSWORD=postgres123" -- \
  psql -h postgresql-ha-pgpool -U postgres -d demo_db -c "SELECT inet_server_addr(), version();"
```

Kết quả mong đợi: trả về IP nội bộ của Primary (`postgresql-ha-postgresql-0`) + phiên bản PostgreSQL 17.6. Bây giờ xóa Primary để test failover:

```bash
kubectl delete pod -n database postgresql-ha-postgresql-0
kubectl get pods -n database -l app.kubernetes.io/component=postgresql -w
```

Trong **10–20 giây**: **Repmgr** phát hiện mất Primary → promote `postgresql-ha-postgresql-1` lên Primary → **Pgpool** reload danh sách node. Chạy lại lệnh `psql` ở trên, `inet_server_addr()` giờ trả IP của node mới — ứng dụng **không đổi connection string**, chỉ đổi Primary bên dưới.

**Bước 3 — Kết nối Redis Cluster và thấy MOVED redirect:**

```bash
kubectl exec -it -n database redis-cluster-0 -- redis-cli -a redis123 -c \
  SET "user:100" "alice"
kubectl exec -it -n database redis-cluster-0 -- redis-cli -a redis123 -c \
  GET "user:100"
```

Flag `-c` bật **cluster mode** trong `redis-cli`. Key `user:100` hash ra slot `9842`, thuộc dải master 2. Nếu bạn gõ vào master sai, server trả **`-MOVED 9842 <ip>:6379`** → `redis-cli -c` tự follow redirect và lấy dữ liệu. Không có `-c`, client thường sẽ lỗi `MOVED` và user phải tự route tay.

**Bước 4 — Xem Persistent Volume Claim (PVC)**

```bash
kubectl get pvc -n database
kubectl delete pod -n database redis-cluster-0
kubectl exec -it -n database redis-cluster-0 -- redis-cli -a redis123 GET "user:100"
```

Kết quả mong đợi: Pod `redis-cluster-0` bị xóa, **StatefulSet** re-create một Pod cùng tên, gắn lại đúng **PVC** cũ → dữ liệu `user:100` vẫn còn. Đây là điều Pod trần ở bài 1 không làm được.

**Kết luận:** Ba luồng trên cho thấy đúng giá trị của các chart HA: **MongoDB Sharded** phân phối ghi theo shard key hashed, **PostgreSQL HA** tự failover mà không cần đổi cấu hình app, **Redis Cluster** giữ liên tục qua delete Pod nhờ **PVC** + **StatefulSet**. Các Service DNS cố định (`*.database.svc.cluster.local`) đóng vai trò lớp trừu tượng — backend chỉ cần biết tên, không quan tâm node nào đang là Primary.

Đã chạy được ba cụm, nhưng điều quan trọng hơn là hiểu tại sao Bitnami lại thiết kế từng chart như vậy, khác biệt giữa `values.origin.yaml` và `values.yaml`, và đâu là những "hố tử thần" khi đi thật vào production.

## III. Bản chất của Helm, Bitnami và những lưu ý production

### 1. Helm — Package Manager cho Kubernetes

**Helm** là một công cụ client-side: đọc **Chart** (một thư mục / tarball chứa các file template Go), trộn với **`values.yaml`** của bạn, render ra Manifest cuối cùng và gửi lên **`kube-apiserver`**. Không có daemon nào của Helm chạy trong cluster kể từ Helm 3 — toàn bộ state lưu trong **Secret** của namespace dưới dạng release history.

- **Template engine:** Trong chart, `deployment.yaml` không phải Manifest thuần, mà là template kiểu `replicas: {{ .Values.replicaCount }}`. Khi bạn chạy `helm install --values values.yaml`, Helm đổ giá trị vào đúng chỗ rồi apply. Đây là lý do một chart có thể chạy được trên Minikube, EKS, DOKS với cùng command — chỉ khác `values.yaml`.
- **Release & rollback:** Mỗi `helm install` tạo một **release** (ở đây là `mongodb-sharded`, `postgresql-ha`, `redis-cluster`). `helm list -n database` hiện revision hiện tại; `helm rollback <release> <revision>` quay về bản cũ trong vài giây. Với Manifest thuần, bạn phải tự giữ git history + apply lại.
- **OCI registry (Helm 3.8+):** Thay vì `helm repo add` kiểu cũ, giờ chart nằm ngay trong **OCI registry** (Docker Hub, GHCR, ECR). `oci://registry-1.docker.io/bitnamicharts/mongodb-sharded` đi qua đúng pipeline image — tận dụng cache, signing, authentication chung với image. Repo demo dùng đường này nên lệnh `helm upgrade --install` không cần `helm repo update`.
- **Khi nào KHÔNG nên dùng Helm:** Một ứng dụng chỉ có 1–2 Manifest (ví dụ một Pod + một Service ở bài 1) không đáng bọc Helm — overhead template lớn hơn lợi ích. Helm thực sự toả sáng khi chart có **≥ 10 Manifest liên quan** cần config đồng bộ.

### 2. Bitnami và cặp `values.origin.yaml` / `values.yaml`

**Bitnami** (giờ thuộc **VMware** / **Broadcom**) duy trì bộ chart database được coi là tham chiếu công nghiệp: test matrix rộng, security hardening, hỗ trợ Prometheus metrics sẵn. Gọi là "tiêu chuẩn vàng" không quá — nếu bạn nhận một cluster production từ team khác mà thấy chart Bitnami, 80% khả năng cấu hình ổn.

- **Tại sao `bitnamilegacy/*`?** Từ cuối **2024**, Docker Hub đổi chính sách giới hạn pull rate với namespace `bitnami/*`. Bitnami tạo mirror `bitnamilegacy/*` trên Docker Hub để cộng đồng open-source tiếp tục dùng miễn phí. `values.yaml` trong repo chỉ override mỗi phần `image.repository` — tất cả logic khác giữ nguyên từ chart chính thức.
- **Tại sao tách `values.origin.yaml`?** File này là bản **`helm show values`** gốc (~60–110KB, hàng nghìn key cấu hình). Giữ nguyên bên cạnh `values.yaml` để hai tác dụng: (1) **grep tra cứu** khi muốn đổi một option lạ (`architecture`, `tls.enabled`, `networkPolicy`...) mà không cần mở browser, (2) **diff** để ước lượng bạn đã lệch chart gốc bao nhiêu.
- **Nguyên tắc override tối thiểu:** `values.yaml` demo chỉ có ~60 dòng — đổi image và vài replica / password là xong. Đừng copy cả `values.origin.yaml` rồi sửa: version chart mới sẽ bổ sung key, bản copy của bạn bị thiếu → upgrade là nổ. Override càng nhỏ, `helm upgrade` càng êm.

### 3. StatefulSet, Headless Service và định danh bền vững

Tại sao MongoDB / PostgreSQL / Redis Cluster bắt buộc dùng **StatefulSet** thay vì **Deployment**? Vì chúng là stateful — mỗi replica phải có **identity ổn định** (để biết ai là Primary, ai là slave của ai) và **disk bền vững** (để không mất dữ liệu khi Pod re-schedule).

- **Tên Pod cố định:** `mongodb-sharded-shard0-data-0`, `postgresql-ha-postgresql-1`, `redis-cluster-3` — index cố định, không random hash như Deployment. Replica `postgresql-ha-postgresql-0` luôn là node đầu tiên trong cluster, kể cả khi Pod bị delete và re-create.
- **Headless Service + per-Pod DNS:** Ngoài Service chính, chart tạo thêm Service với `clusterIP: None`. DNS khi đó **không** cân bằng tải mà trả về **IP của từng Pod**: `mongodb-sharded-shard0-data-0.mongodb-sharded-headless.database.svc.cluster.local`. Đây là cơ sở để Repmgr / MongoDB replica nói chuyện với nhau bằng hostname ổn định, không lo IP đổi.
- **PersistentVolumeClaim template:** StatefulSet có field `volumeClaimTemplates` — mỗi replica tự sinh một PVC tên `<pvc-name>-<statefulset>-<index>`. Pod `postgresql-ha-postgresql-1` luôn mount đúng **PVC** `data-postgresql-ha-postgresql-1`, kể cả khi reschedule sang Node khác. Đây là thứ Pod trần ở bài 1 không có.
- **Rolling update thứ tự nghịch:** StatefulSet upgrade từ replica có index **cao nhất xuống thấp nhất**, chờ từng Pod **Ready** mới qua Pod tiếp theo. Với PostgreSQL, điều này bảo đảm Standby upgrade trước, Primary upgrade cuối — hạn chế thời gian outage.

### 4. Những rủi ro khi lên production thật

- **Password plain-text trong `values.yaml`:** `root123`, `postgres123`, `redis123` nằm thẳng trong file — demo OK, production phải chuyển sang **Secret** tham chiếu (`auth.existingSecret`) rồi quản secret qua **External Secrets Operator** + **Vault** hoặc cloud secret manager.
- **PVC 8Gi không tự mở rộng:** `persistence.size: 8Gi` là cứng. Khi dữ liệu vượt 8Gi, bạn không resize được Pod cũ — phải dùng **StorageClass** có `allowVolumeExpansion: true` (DO `do-block-storage` có, Minikube `standard` có) và chạy `kubectl edit pvc` + restart Pod. Tốt nhất set size đúng ngay từ đầu + bật alert khi disk > 70%.
- **Không có resource requests/limits mặc định đủ:** `values.origin.yaml` có cấu hình `resources.preset: "none"` hoặc `nano` — đủ cho lab, không đủ cho production. Với MongoDB shard production, mỗi data node cần **≥ 2 CPU, 4Gi RAM**; PostgreSQL Primary **≥ 2 CPU, 2Gi RAM**. Không set limits → một query nặng có thể **OOM kill** node kéo sập cả cụm.
- **Chỉ 1 replica factor cho MongoDB shard data node:** Demo có `shardsvr.dataNode.replicaCount: 3` nhưng chart không auto-enable **replica set** bên trong từng shard. Production bắt buộc dựng **replica set** mỗi shard để tránh mất dữ liệu khi mất 1 node. Xem `values.origin.yaml` mục `shardsvr.dataNode.replicas` để đọc kỹ.
- **Metrics exporter bật nhưng chưa có Prometheus:** Cả ba chart đều bật `metrics.enabled: true`, nhưng bạn chưa cài **Prometheus + Grafana** để scrape. Production cần đi kèm **kube-prometheus-stack** Helm chart — và đó là lý do người ta nói *"Helm là cửa ngõ vào K8s production"*: một chart kéo theo nhiều chart khác.
- **Namespace `database` không có NetworkPolicy:** Mặc định mọi Pod trong cluster đều gọi được database. Production phải viết **NetworkPolicy** giới hạn: chỉ namespace backend mới được gọi port 3306/5432/6379/27017.

**Kết luận:** Ba cụm database trong bài là một lát cắt thật của kiến trúc production hiện đại: **Helm** đóng vai trò package manager, **Bitnami** cung cấp "best practice đóng hộp", và **StatefulSet + PVC + Headless Service** của K8s là nền hạ tầng cho stateful workload. Điểm đáng nhớ là nguyên tắc **override tối thiểu** — giữ `values.yaml` càng gần chart gốc càng tốt để nâng cấp êm. Khi đã chạy được ba cụm này bằng đúng một script, việc ghép chúng với backend ở môi trường cloud thật sẽ chỉ còn là chuyện đổi hostname.

# references
## 0
### alias
Helm — The Package Manager for Kubernetes
### url
https://helm.sh/docs/
## 1
### alias
Helm OCI Registry Support
### url
https://helm.sh/docs/topics/registries/
## 2
### alias
Bitnami Charts on GitHub
### url
https://github.com/bitnami/charts
## 3
### alias
Kubernetes StatefulSet Documentation
### url
https://kubernetes.io/docs/concepts/workloads/controllers/statefulset/
## 4
### alias
Bitnami Legacy Images on Docker Hub
### url
https://hub.docker.com/u/bitnamilegacy

# minutesRead
28
