# title
Monolith vs Microservices

# description
Compare Monolith and Microservices architectures at both the organizational and technical level, analyze the load and operational scenarios where Monolith breaks down, and pin down when it is actually worth moving to Microservices.

# body

## I. Introduction

In any **Senior Backend** interview at a company with a real product, a question in this shape is almost guaranteed: *"**Shopee** has thousands of engineers committing every day — why do they not use a **single codebase** to keep things simple? If you were the **tech lead**, when would you decide to split a **monolith** into multiple **services**?"*. Many junior engineers will reach for *"because microservices scale better"* — a slide-deck answer that falls apart in the real world: **Monolith** scales **horizontally** very well up to several million users, and **Microservices** are not intrinsically "more scalable" — they actually **consume more resources** because of the **network overhead** between services.

A professional answer must touch two layers: **human organization** (how many teams own the code, who deploys when) and **business boundaries** (are the **bounded contexts** actually stable, or still drifting). Many startups have **died** by adopting **Microservices** too early — breaking their **distributed tracing**, piling on **data-consistency** tech debt, and multiplying CI/CD by **N** when they only had **5 engineers**. On the other end, **Facebook** still runs most of its core request path through a giant **PHP monolith** (Hack/HHVM) because, for them, the team structure and tooling are optimized for that shape. The key lesson: **there is no best architecture** — only one that **fits your scale, organization, and product stage** — and to choose well you first have to see clearly **how each shape actually fails** under different kinds of load.

## II. Observing the Two Architectures Under Real Scenarios

Rather than reading slide definitions, we drop a hypothetical **E-commerce** system into the four most common production scenarios and watch each shape react.

### 1. When one module gets hit with uneven load

Suppose the system has modules **User**, **Product**, **Search**, **Order**, **Payment**. During a **Flash Sale**, only **Search** gets **50×** its normal load; the rest stays roughly flat.

- **Behavior in a Monolith:** **User / Product / Search / Order / Payment** are packaged into a single **Docker image** running on one **pod** or **VM**. To scale **Search**, you must **replicate the entire pod** — including **Payment**, which only uses **5% CPU**.
- **Incident:** To absorb **100,000 RPS** on **Search**, you scale from **3 pods** to **30 pods**. Each pod consumes **2GB RAM** for all **5 modules** together. Cluster RAM balloons to **60GB** just for **Search**, while **Payment** only needed a few hundred MB. Cloud cost rises **10×** despite load growing in only one module.
- **Behavior in Microservices:** **Search Service** is its own **deployment**; only it scales from **3** to **30 replicas**. **Payment Service** stays at **2 pods**, **User Service** at **4 pods** — nobody else is affected.
- **Expected outcome:** Under the same surge, **Microservices** spends roughly **60GB RAM** just on Search instead of on the entire stack. **Scaling granularity** becomes the **strongest technical reason** to split.
- **Conclusion:** When load is **uneven** across modules and the gap is large enough (say **10×** or more at peak), **Monolith** pays a **resource waste** cost that scales linearly with the largest module. That is a clear signal to consider extracting services.

### 2. When a bug in a secondary module takes down the whole system

The **Reporting** module only runs a cron once a day to export PDFs — nowhere near as critical as **Payment**.

- **Behavior in a Monolith:** A Reporting engineer ships code that generates a large report — with a **memory leak**. Because **Reporting** lives in the **same process** as **Payment**, when heap hits **OOM**, **Kubernetes** kills the whole pod. **Payment** dies with it, even though its own code is fine.
- **Incident:** Users in the middle of checkout hit **502**; some are **charged but the order never persists** — leading to **disputes**, manual refunds, and brand damage.
- **Behavior in Microservices:** **Reporting Service** runs in its own process, container, and resource limit. When **Reporting Pod** OOM-kills, **Payment Pod** keeps serving. The system only loses report generation — a **non-essential** feature.
- **Expected outcome:** **Microservices** contain the **blast radius** of a bug to a single service. **Monolith** has no such boundary — the **process boundary is the fault boundary**.
- **Conclusion:** When the system mixes **critical** modules (**Payment**, **Order**) with **non-critical** ones (**Reporting**, **Email Notification**), putting them in one process accepts the risk that the secondary will drag the critical path down.

### 3. When deploy velocity is bottlenecked by organizational structure

The company grows from **10** to **300** engineers in **2 years**, split into **15** product teams, each owning a **domain**.

- **Behavior in a Monolith:** All **15 teams** commit to **one repo**. The CI pipeline runs the **full test suite** (**4,500 tests**, **40 minutes**) for every Pull Request — even when only an icon in **Profile** changes. Production deploys require a **company-wide code freeze**, full-system **smoke tests**, taking **2–3 hours** per release.
- **Incident:** The **Payment** team needs to ship a **3D Secure bug fix** in **2 hours** — but **Search** is deploying a massive refactor at the same time and the pipeline is locked. **Payment** waits. A critical release takes **6 hours** instead of **20 minutes**. Weekly release count drops from **15** to **2–3**.
- **Behavior in Microservices:** Each team has its own repo and pipeline. The **Payment** team deploys **Payment Service** **5 times a day** without touching **Search**. Local test coverage is ~**500 tests**, **3 minutes** per PR.
- **Expected outcome:** **Microservices** hand **deploy autonomy** back to each team — **independent deployability** is the **single biggest** benefit of this architecture (arguably larger than scaling). Amazon calls this the **"Two-pizza team"** principle: each service is owned by a team small enough (**≤ 8 people**) that two pizzas can feed it.
- **Conclusion:** Once team count crosses the threshold where **merge conflicts** and **pipeline locks** become daily occurrences, the reason to split is **human organization**, not **technology** — exactly the point behind **Conway's Law**: *"Organizations that design systems tend to produce designs which are copies of their own communication structures."*

### 4. When Microservices become a burden

A **15-engineer** startup, product only **6 months old**, domain still unstable. Caught up in hype, the team splits into **8 services** from day one: **User**, **Auth**, **Product**, **Cart**, **Order**, **Payment**, **Notification**, **Search**.

- **Behavior in aggressive Microservices:** A **"Place Order"** request now crosses **5 services** (**Cart → Order → Payment → Notification → Search**). Mid-chain failures require hand-written **Saga** and **compensation**; end-to-end tests are hard to write and run locally. A new hire spends **2 weeks** just setting up the dev environment — **8 repos** plus a **Docker Compose** with **25 containers**.
- **Incident:** The domain shifts. **"Cart"** turns out to really belong **together with** **"Order"** (same **bounded context**), and **"Search"** should be part of **"Product"**. But the split is already live — **merging** two services back together is many times harder than **splitting** one, because there are now separate **DB schemas**, **integrated consumers**, and **published event contracts**.
- **Behavior in the Monolith it should have been:** The same **15 people**, the same shifting domain, but a single **NestJS** codebase. Refactoring **"Cart"** into an **"Order"** module is moving **a few files** and fixing **imports**. A new dev clones **one repo**, runs `npm install`, and a single command gives a full environment.
- **Expected outcome:** With a small team and an unsettled domain, **Microservices** degenerates into a **distributed monolith** — distributed-system complexity plus hidden coupling through contracts. **Feature velocity drops**, **onboarding is painful**, and **cross-service bugs** appear more often than bugs in a clean monolith ever would.
- **Conclusion:** **Microservices** are **not free** — they cost you **distributed tracing**, **distributed data consistency**, **CI/CD × N**, **service discovery**, and **observability**. That price is worth paying when the benefits exceed it; before that threshold, **Monolith** is the **wiser** default.

After these four scenarios, **Microservices** clearly is not the default answer — it is a **trade-off** along the axis of **organization × scale × domain stability**. The next part names the concepts that emerged above and lists the concrete **signals** for when to make the switch.

## III. Architectural Essence and When to Switch

### 1. Monolith — real definition and characteristics

A **Monolith** is an architecture in which the **entire application** — **UI**, **Business Logic**, **Data Access** — is packaged and **deployed** as a **single unit**. It does **not** mean **messy code** or **no modules**; a clean Monolith still splits into clear **modules** / **bounded contexts** inside the same codebase (known as a **Modular Monolith**).

- **Technical characteristics:**
  - One runtime **process**; modules call each other via **function calls** inside the same memory space — **essentially zero latency**.
  - One shared **database** — transactions can lean on the DBMS's **ACID** guarantees (e.g. **PostgreSQL**) for strong consistency.
  - One CI/CD **pipeline**, one build **artefact**, one **deploy** for the whole system.
- **Upsides:** Fast onboarding, straightforward **end-to-end debugging** (stack traces stay within one process), **no** need to wrestle **eventual consistency** for most flows, low infra cost (no **service mesh**, **distributed tracing**, or **schema registry**).
- **Downsides that surface at scale:**
  - Poor **scaling granularity** — you replicate the whole block even when only one module needs more resources.
  - Weak **fault isolation** — a **memory leak** or **deadlock** in a secondary module can take the whole process down.
  - **Deploy bottleneck** — every team must synchronize release schedules.
  - **Codebase** grows unwieldy; **build** and **test time** grow non-linearly.

### 2. Microservices — real definition and characteristics

**Microservices** split a system into **many small, independent services**, each owning **one bounded context** and its **own database**, communicating over the **network** (HTTP, gRPC, message broker).

- **Technical characteristics:**
  - Each service is a **separate process** in a **separate container**, independently **scalable**.
  - **Database per service** — no service reads another service's DB directly; data is synchronized via **events** or **APIs**.
  - Communication goes over the **network** — every call has **latency** from a few ms to tens of ms, can **fail**, can **time out**.
  - **Independent deploy** — each service has its own pipeline, artefact, and release cadence.
- **Upsides:**
  - Fine-grained **scaling granularity** — scale only the service under load.
  - Strong **fault isolation** — process boundary = fault boundary.
  - **Technology heterogeneity** — each service can use the right stack (Node.js for APIs, Go for hot paths, Python for ML).
  - **Team autonomy** — each team owns a service end-to-end from **code** to **deploy** to **on-call**.
- **Inherent downsides:**
  - **Distributed complexity**: **network partitions**, **retries**, **timeouts**, **idempotency**, **circuit breakers** — none of these exist in a Monolith.
  - **Distributed data consistency** — no more cross-service **ACID**; you reach for **Saga**, **Outbox**, **eventual consistency**.
  - **Operational overhead** — you now need **Kubernetes**, a **service mesh** (Istio / Linkerd), **distributed tracing** (Jaeger / OpenTelemetry), **centralized logging**, an **API Gateway**.
  - **Boundary refactors are expensive** — shifting a bounded context between two already-split services is nearly a rewrite of both.

### 3. Conway's Law and "Two-pizza teams" — the organizational lens

Software architecture tends to mirror the communication structure of the organization that builds it — the content of **Conway's Law** (1968), still true today.

- **Practical meaning:** A **50-person team** split into **5 sub-teams** communicating via **weekly meetings** will naturally produce **5 modules** or **5 services** — even if you meant to ship a Monolith. Forcing a **Monolith** on an already-fragmented org yields constant **merge conflicts** and **review bottlenecks**.
- **Two-pizza team (Amazon):** Each service should be owned by a team **small enough that two pizzas feed it** (~**6–8 people**). Small teams keep **ownership clear**, **communication overhead low**, and help each service land at a **sensible size** — not so big that one team cannot understand it, not so small that its operational cost outweighs its value.
- **Inverse Conway Maneuver:** If you want a particular target architecture (e.g. microservices), **design the org** to match it first (teams aligned to domains) and let code follow — rather than the other way around.

### 4. Bounded Context and Database-per-Service

**Bounded Context** (from **Domain-Driven Design** by Eric Evans) is the **business boundary** within which a **domain model** has a single consistent meaning. Splitting services **without** respecting bounded contexts creates a **distributed monolith**.

- **Signs the boundary is clear:** When an *"Order Paid"* event fires, you know exactly that **Order Service** publishes it, **Inventory Service** debits stock, **Notification Service** sends email — and no one needs to **share DB tables** with anyone else. If you see **cart, order, payment** all reading and writing the same `order_items` table, the boundary is **not** clear and splitting will hurt more than help.
- **Database-per-service is a hard boundary:** Each service has its **own schema** that no one else may **JOIN** or **query directly**. Cross-service reads happen via **APIs** or **event consumption**. This is the **most important discipline** of Microservices — violating it gives you a **distributed monolith** coupled through the database.

### 5. When to start with Monolith and when to switch

The common industry heuristic (Martin Fowler's **"Monolith First"**):

- **Start with a Monolith (Modular Monolith) when:**
  - The product is **less than a year old**, without **product-market fit** — the domain still shifts every few weeks.
  - The team is **under 20 engineers** — small enough to stay aligned via meetings and chat.
  - There is no dedicated **DevOps / SRE** function — not yet the muscle to run distributed infra.
- **Real signals to move toward Microservices:**
  - The engineering org crosses **~30–50 people**; **deploys** now require **company-wide code freezes**.
  - **Scaling requirements** differ by **≥ 10×** between modules (e.g. **Search** or **Video Transcoding** need very different resources from the rest).
  - **Compliance** demands isolating a module (e.g. **Payment** going **PCI-DSS** needs separate infra).
  - **The domain has stabilized** — **bounded contexts** have not meaningfully changed for 6–12 months.
- **Signals NOT to switch even though it feels "right":**
  - The domain still shifts monthly — high risk of splitting along wrong bounded contexts.
  - The team lacks **distributed-systems** experience — debugging a cross-service bug will cost more than the architecture buys you.
  - Leadership wants to switch because **"microservices sounds modern"**, not because of a concrete pain point.

### 6. Middle-ground paths — Modular Monolith and Strangler Fig

It is rarely pure Monolith or pure Microservices. Two intermediate patterns are commonly used:

- **Modular Monolith:** Still one process, one DB, but the **code** is divided into **independent modules** with **explicit communication contracts** (e.g. **ports/adapters** from Hexagonal Architecture). When you eventually need to split, you "cut" one module into a service — the boundary is already there. **Shopify**, **GitHub**, and **Basecamp** have chosen this path for years.
- **Strangler Fig (Martin Fowler):** Migrate gradually from Monolith to Microservices by wrapping the Monolith behind an **API Gateway**, then **extracting** one feature at a time into a new service and redirecting traffic to it until the Monolith is empty. This is **far safer** than a full **rewrite** — a "big bang" strategy that took **Netflix 7 years** to complete.

**Conclusion:** **Monolith** and **Microservices** are not good vs bad — they are two points on a **spectrum of trade-offs**. Monolith optimizes for **feature velocity** while the domain is still unstable and the team is small; Microservices optimize for **organizational scalability** once the product has traction and the team is large. Most production-grade systems in the industry are **not** purely one shape — they are a **Modular Monolith** core with a handful of services carved out for very specific reasons (uneven load, compliance, a dedicated team). The right question at design time is not *"Monolith or Microservices?"* but *"Is my business boundary clear enough, is my organization large enough to need the split, and is the operational cost of distribution worth the benefits I get?"*.

# references
## 0
### alias
Monolithic Architecture (microservices.io)
### url
https://microservices.io/patterns/monolithic.html
## 1
### alias
Microservices Pattern (microservices.io)
### url
https://microservices.io/patterns/microservices.html
## 2
### alias
Martin Fowler — Monolith First
### url
https://martinfowler.com/bliki/MonolithFirst.html
## 3
### alias
Martin Fowler — Strangler Fig Application
### url
https://martinfowler.com/bliki/StranglerFigApplication.html
## 4
### alias
Conway's Law
### url
https://www.melconway.com/Home/Conways_Law.html

# minutesRead
30
