# title
Microservices & Kubernetes Fundamentals

# description
Giới thiệu Microservices và Kubernetes ở mức nền tảng.

# previewContents
## 0
### text
Microservices là gì? So sánh với kiến trúc Monolith.
## 1
### text
Tại sao hệ thống lớn lại cần chia nhỏ thành nhiều service.
## 2
### text
Ưu và nhược điểm của kiến trúc Microservices.
## 3
### text
Kubernetes là gì và giải quyết vấn đề gì trong vận hành.
## 4
### text
Các khái niệm cơ bản trong k8s: Pod, Deployment, Service.
## 5
### text
Cách Microservices và Kubernetes phối hợp với nhau trong thực tế.
## 6
### text
Hiểu rõ tư duy thiết kế hệ thống theo hướng chia nhỏ service.
## 7
### text
Biết khi nào nên dùng Microservices thay vì Monolith.
## 8
### text
Nắm được vai trò của Kubernetes trong việc quản lý và scale hệ thống.
## 9
### text
Có nền tảng để triển khai các hệ thống phân tán ở mức cơ bản.
## 10
### text
Sau khi hoàn tất module: hiểu cách hệ thống hiện đại được chia nhỏ và vận hành production, sẵn sàng cho các module thực chiến tiếp theo.
