# title
Deploy NestJS on Cloud Kubernetes with NGINX Ingress and HTTPS

# description
Deploy a NestJS application to a Managed Kubernetes cluster on cloud, configure NGINX Ingress Controller for traffic routing, and set up Cert-Manager to automatically provision SSL/TLS certificates for HTTPS.

# requirements
Deploy a NestJS application to a cloud Kubernetes cluster (DigitalOcean, AWS, or GCP). Install **NGINX Ingress Controller** to route external traffic into the cluster. Install **Cert-Manager** and configure a **Let's Encrypt ClusterIssuer** to automatically provision SSL certificates. Create an **Ingress resource** with TLS termination so the application is accessible via HTTPS. Submit both a GitHub repository (source code + manifests) and a Google Docs document (architecture and process documentation).

# prerequisites
- Cloud provider account with a Managed Kubernetes cluster created
- kubectl connected to the cluster
- Helm CLI installed
- A domain name (can use free from Freenom or purchase a domain)
- Node.js >= 18 and NestJS CLI
- Completed challenge kubernetes-on-cloud-easy

# steps

## 0
### title
Prepare NestJS application and push Docker image
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project:
    ```bash
    nest new kubernetes-on-cloud-medium
    cd kubernetes-on-cloud-medium
    ```
  - Step 2: Create endpoints:
    - `GET /` returns `{ service: "kubernetes-on-cloud-medium", status: "running" }`.
    - `GET /health` returns `{ status: "ok", timestamp: new Date().toISOString() }`.
    - `GET /info` returns `{ hostname: os.hostname(), version: "1.0.0" }`.
  - Step 3: Create a Dockerfile with multi-stage build.
  - Step 4: Build and push image to a container registry (Docker Hub, DigitalOcean Container Registry, AWS ECR, or GCP Artifact Registry):
    ```bash
    docker build -t <registry>/k8s-cloud-medium:v1 .
    docker push <registry>/k8s-cloud-medium:v1
    ```
- **Expected result:** Docker image has been pushed to the container registry, ready for Kubernetes to pull.
- **Conclusion:** The application is ready to deploy on the cloud Kubernetes cluster.

## 1
### title
Deploy application and install NGINX Ingress Controller
### body
- **Steps to follow:**
  - Step 1: Create Kubernetes manifests for the application:
    - Deployment (2 replicas).
    - ClusterIP Service (port 80 -> targetPort 3000).
  - Step 2: Apply manifests:
    ```bash
    kubectl apply -f deployment.yaml
    kubectl apply -f service.yaml
    ```
  - Step 3: Install NGINX Ingress Controller with Helm:
    ```bash
    helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
    helm repo update
    helm install nginx-ingress ingress-nginx/ingress-nginx --set controller.publishService.enabled=true
    ```
  - Step 4: Wait for the Ingress Controller to receive an External IP (LoadBalancer):
    ```bash
    kubectl get services -l app.kubernetes.io/name=ingress-nginx -w
    ```
  - Step 5: Record the External IP and point the domain/subdomain to this IP (create an A record in DNS management).
- **Expected result:** Application deployed successfully, NGINX Ingress Controller has an External IP, domain points to the IP.
- **Conclusion:** NGINX Ingress Controller serves as the single entry point for external traffic into the cluster.

## 2
### title
Install Cert-Manager and configure Let's Encrypt
### body
- **Steps to follow:**
  - Step 1: Install Cert-Manager with Helm:
    ```bash
    helm repo add jetstack https://charts.jetstack.io
    helm repo update
    helm install cert-manager jetstack/cert-manager --namespace cert-manager --create-namespace --set crds.enabled=true
    ```
  - Step 2: Verify Cert-Manager is running:
    ```bash
    kubectl get pods -n cert-manager
    ```
  - Step 3: Create a ClusterIssuer for Let's Encrypt (file `cluster-issuer.yaml`):
    ```yaml
    apiVersion: cert-manager.io/v1
    kind: ClusterIssuer
    metadata:
      name: letsencrypt-prod
    spec:
      acme:
        server: https://acme-v02.api.letsencrypt.org/directory
        email: your-email@example.com
        privateKeySecretRef:
          name: letsencrypt-prod-key
        solvers:
          - http01:
              ingress:
                class: nginx
    ```
  - Step 4: Apply ClusterIssuer:
    ```bash
    kubectl apply -f cluster-issuer.yaml
    ```
- **Expected result:** Cert-Manager is running, ClusterIssuer `letsencrypt-prod` is created successfully.
- **Conclusion:** Cert-Manager is ready to automatically provision and renew SSL certificates from Let's Encrypt.

## 3
### title
Create Ingress resource with TLS and test HTTPS
### body
- **Steps to follow:**
  - Step 1: Create file `ingress.yaml`:
    ```yaml
    apiVersion: networking.k8s.io/v1
    kind: Ingress
    metadata:
      name: nestjs-ingress
      annotations:
        cert-manager.io/cluster-issuer: "letsencrypt-prod"
        nginx.ingress.kubernetes.io/ssl-redirect: "true"
    spec:
      ingressClassName: nginx
      tls:
        - hosts:
            - your-domain.com
          secretName: nestjs-tls-secret
      rules:
        - host: your-domain.com
          http:
            paths:
              - path: /
                pathType: Prefix
                backend:
                  service:
                    name: nestjs-service
                    port:
                      number: 80
    ```
  - Step 2: Apply Ingress:
    ```bash
    kubectl apply -f ingress.yaml
    ```
  - Step 3: Check that the Certificate is created and issued:
    ```bash
    kubectl get certificate
    kubectl describe certificate nestjs-tls-secret
    ```
  - Step 4: Wait for the certificate to reach `Ready: True` status (may take a few minutes).
  - Step 5: Access the application via HTTPS:
    ```bash
    curl https://your-domain.com
    curl https://your-domain.com/health
    curl https://your-domain.com/info
    ```
  - Step 6: Confirm HTTP automatically redirects to HTTPS:
    ```bash
    curl -I http://your-domain.com
    ```
    Confirm it returns 308 redirect to HTTPS.
  - Step 7: Verify SSL certificate in browser: access the domain and confirm the lock icon is present, certificate is issued by Let's Encrypt.
- **Expected result:**
  - HTTPS works with a valid Let's Encrypt certificate.
  - HTTP automatically redirects to HTTPS.
  - All endpoints are accessible via HTTPS.
- **Conclusion:** The application has been deployed securely with HTTPS on cloud Kubernetes, using NGINX Ingress and Cert-Manager.

## 4
### title
Write architecture and process documentation
### body
- **Steps to follow:**
  - Step 1: Draw an overall architecture diagram: Client -> DNS -> LoadBalancer -> NGINX Ingress -> Service -> Deployment (Pods).
  - Step 2: Describe the role of each component: Ingress Controller, Cert-Manager, ClusterIssuer, Certificate, Ingress resource.
  - Step 3: Document the entire deployment process in order.
  - Step 4: Describe how Cert-Manager automatically renews certificates.
  - Step 5: Add a troubleshooting section: common errors and how to resolve them (certificate not issued, DNS not pointing correctly, Ingress not working).
- **Expected result:** Complete Google Docs document with architecture diagram, deployment process, and troubleshooting guide.
- **Conclusion:** The documentation helps the team understand the architecture and enables re-deploying the system at any time.

# references
## 0
### alias
NGINX Ingress Controller
### url
https://kubernetes.github.io/ingress-nginx/
## 1
### alias
Cert-Manager Documentation
### url
https://cert-manager.io/docs/
## 2
### alias
Let's Encrypt Getting Started
### url
https://letsencrypt.org/getting-started/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing NestJS source code, Dockerfile, and all Kubernetes manifests (deployment, service, ingress, cluster-issuer).
### score
18
### prompts
#### 0
##### title
Deployment and NGINX Ingress configured correctly
##### score
6
##### promptText
NestJS Deployment has 2 replicas with ClusterIP Service. NGINX Ingress Controller is installed, Ingress resource correctly routes traffic to the Service.
#### 1
##### title
Cert-Manager and HTTPS work
##### score
6
##### promptText
Cert-Manager is installed, ClusterIssuer configured with Let's Encrypt, Certificate is issued successfully, HTTPS works with a valid certificate.
#### 2
##### title
HTTP redirect and endpoints work
##### score
6
##### promptText
HTTP automatically redirects to HTTPS (308). All endpoints (`/`, `/health`, `/info`) are accessible via HTTPS and return correct responses.
## 1
### type
googleDocsUrl
### title
Architecture and Deployment Process Documentation
### description
Submit a Google Docs link describing system architecture, deployment process, and troubleshooting guide.
### score
12
### prompts
#### 0
##### title
Architecture diagram and component descriptions
##### score
6
##### promptText
Document has an overall architecture diagram (Client -> DNS -> LB -> Ingress -> Service -> Pods), clearly describes the role of each component.
#### 1
##### title
Deployment process and troubleshooting
##### score
6
##### promptText
Fully documents the deployment process in order, includes a troubleshooting section for common errors and how to resolve them.

# difficulty
medium

# score
30
