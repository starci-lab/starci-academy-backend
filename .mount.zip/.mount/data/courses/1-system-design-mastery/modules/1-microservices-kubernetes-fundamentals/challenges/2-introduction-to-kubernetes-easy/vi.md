# title
Triển khai NestJS Backend trên Minikube với Pod và Port-Forward

# description
Cài đặt Minikube, viết YAML manifest để deploy một ứng dụng NestJS backend dưới dạng Pod trên Kubernetes, và sử dụng port-forward để kiểm tra ứng dụng hoạt động từ máy local.

# requirements
Cài đặt và khởi động Minikube. Đóng gói ứng dụng NestJS thành Docker image. Viết file YAML manifest để tạo Pod chạy ứng dụng NestJS. Sử dụng `kubectl port-forward` để truy cập ứng dụng từ máy local và xác nhận endpoint hoạt động đúng.

# prerequisites
- Node.js >= 18
- Docker Desktop
- Minikube và kubectl đã cài đặt
- NestJS CLI
- Kiến thức cơ bản về Docker

# steps

## 0
### title
Cài đặt Minikube và kiểm tra môi trường
### body
- **Các bước thực hiện:**
  - Bước 1: Cài đặt Minikube theo hướng dẫn chính thức (https://minikube.sigs.k8s.io/docs/start/).
  - Bước 2: Khởi động Minikube:
    ```bash
    minikube start
    ```
  - Bước 3: Kiểm tra Minikube đã chạy thành công:
    ```bash
    minikube status
    ```
  - Bước 4: Kiểm tra kubectl kết nối được đến cluster:
    ```bash
    kubectl get nodes
    ```
- **Kết quả mong đợi:** Minikube khởi động thành công, `kubectl get nodes` hiển thị node có trạng thái `Ready`.
- **Kết luận:** Môi trường Kubernetes local đã sẵn sàng để deploy ứng dụng.

## 1
### title
Tạo ứng dụng NestJS và đóng gói Docker image
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS mới:
    ```bash
    nest new introduction-to-kubernetes-easy
    cd introduction-to-kubernetes-easy
    ```
  - Bước 2: Tạo endpoint `GET /health` trong `AppController` trả về `{ status: "ok", timestamp: new Date().toISOString() }`.
  - Bước 3: Tạo `Dockerfile` ở thư mục gốc:
    ```dockerfile
    FROM node:18-alpine
    WORKDIR /app
    COPY package*.json ./
    RUN npm ci
    COPY . .
    RUN npm run build
    EXPOSE 3000
    CMD ["node", "dist/main"]
    ```
  - Bước 4: Cấu hình Docker daemon của Minikube để build image trực tiếp:
    ```bash
    eval $(minikube docker-env)
    ```
  - Bước 5: Build Docker image:
    ```bash
    docker build -t intro-k8s-nestjs:latest .
    ```
- **Kết quả mong đợi:** Docker image `intro-k8s-nestjs:latest` được build thành công trong Minikube Docker environment.
- **Kết luận:** Ứng dụng đã được đóng gói thành Docker image, sẵn sàng để deploy lên Kubernetes.

## 2
### title
Viết YAML manifest và tạo Pod
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `pod.yaml` với nội dung:
    ```yaml
    apiVersion: v1
    kind: Pod
    metadata:
      name: nestjs-app
      labels:
        app: nestjs-app
    spec:
      containers:
        - name: nestjs-app
          image: intro-k8s-nestjs:latest
          imagePullPolicy: Never
          ports:
            - containerPort: 3000
    ```
  - Bước 2: Apply manifest lên cluster:
    ```bash
    kubectl apply -f pod.yaml
    ```
  - Bước 3: Kiểm tra Pod đã chạy:
    ```bash
    kubectl get pods
    ```
  - Bước 4: Xem logs của Pod:
    ```bash
    kubectl logs nestjs-app
    ```
- **Kết quả mong đợi:** Pod `nestjs-app` ở trạng thái `Running`, logs hiển thị NestJS đã khởi động thành công.
- **Kết luận:** Ứng dụng NestJS đã được deploy thành công lên Kubernetes dưới dạng Pod.

## 3
### title
Sử dụng port-forward và kiểm thử
### body
- **Các bước thực hiện:**
  - Bước 1: Thiết lập port-forward từ máy local đến Pod:
    ```bash
    kubectl port-forward pod/nestjs-app 3000:3000
    ```
  - Bước 2: Mở terminal khác và gọi endpoint mặc định:
    ```bash
    curl http://localhost:3000
    ```
  - Bước 3: Gọi endpoint health check:
    ```bash
    curl http://localhost:3000/health
    ```
    Xác nhận trả về `{ status: "ok", timestamp: "..." }`.
  - Bước 4: Kiểm tra thông tin chi tiết của Pod:
    ```bash
    kubectl describe pod nestjs-app
    ```
  - Bước 5: Dọn dẹp tài nguyên:
    ```bash
    kubectl delete pod nestjs-app
    ```
- **Kết quả mong đợi:**
  - Port-forward hoạt động, truy cập được ứng dụng tại `localhost:3000`.
  - `GET /health` trả về response đúng.
  - `kubectl describe pod` hiển thị chi tiết cấu hình Pod.
- **Kết luận:** Ứng dụng NestJS đã được deploy và truy cập thành công trên Minikube thông qua port-forward.

# references
## 0
### alias
Minikube Start Guide
### url
https://minikube.sigs.k8s.io/docs/start/
## 1
### alias
Kubernetes Pods Documentation
### url
https://kubernetes.io/docs/concepts/workloads/pods/
## 2
### alias
kubectl Port-Forward
### url
https://kubernetes.io/docs/tasks/access-application-cluster/port-forward-access-application-cluster/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code NestJS, Dockerfile và file YAML manifest.
### score
20
### prompts
#### 0
##### title
Docker image và YAML manifest đúng
##### score
10
##### promptText
Project NestJS có Dockerfile hợp lệ, file pod.yaml đúng cú pháp Kubernetes, image được build và Pod chạy thành công trên Minikube.
#### 1
##### title
Port-forward và endpoint hoạt động
##### score
10
##### promptText
Sử dụng `kubectl port-forward` truy cập được ứng dụng, endpoint `GET /health` trả về response đúng format `{ status, timestamp }`.

# difficulty
easy

# score
20
