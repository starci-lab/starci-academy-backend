# title
Tài liệu hóa quy trình thiết lập Managed Kubernetes trên Cloud

# description
Nghiên cứu và viết tài liệu chi tiết về quy trình thiết lập một Managed Kubernetes cluster trên một cloud provider (DigitalOcean, AWS EKS hoặc GCP GKE), bao gồm cấu hình Node Pool và kết nối kubectl từ máy local.

# requirements
Viết tài liệu Google Docs mô tả đầy đủ quy trình thiết lập Managed Kubernetes cluster trên một cloud provider tự chọn. Tài liệu phải bao gồm: so sánh các managed K8s offerings (DigitalOcean DOKS, AWS EKS, GCP GKE), hướng dẫn từng bước tạo cluster với screenshots hoặc mô tả chi tiết, cấu hình Node Pool (số lượng nodes, spec máy, auto-scaling), cách tải kubeconfig và kết nối kubectl từ máy local, và kiểm tra cluster hoạt động.

# prerequisites
- Tài khoản trên một cloud provider (DigitalOcean, AWS hoặc GCP)
- kubectl đã cài đặt trên máy local
- Kiến thức cơ bản về Kubernetes từ các challenge trước

# steps

## 0
### title
Nghiên cứu và so sánh các Managed Kubernetes offerings
### body
- **Các bước thực hiện:**
  - Bước 1: Nghiên cứu 3 dịch vụ Managed Kubernetes phổ biến:
    - **DigitalOcean Kubernetes (DOKS)**: giá cả, giới hạn, tính năng.
    - **AWS Elastic Kubernetes Service (EKS)**: giá cả, tính năng, độ phức tạp.
    - **Google Kubernetes Engine (GKE)**: giá cả, tính năng, free tier.
  - Bước 2: So sánh theo các tiêu chí: chi phí control plane, chi phí worker nodes, độ dễ sử dụng, tích hợp ecosystem, hỗ trợ auto-scaling.
  - Bước 3: Chọn một provider để thực hiện các bước tiếp theo và giải thích lý do chọn.
- **Kết quả mong đợi:** Bảng so sánh 3 providers với các tiêu chí rõ ràng, có kết luận chọn provider và lý do.
- **Kết luận:** Hiểu rõ sự khác biệt giữa các managed K8s offerings để đưa ra quyết định phù hợp.

## 1
### title
Tài liệu hóa quy trình tạo Kubernetes cluster
### body
- **Các bước thực hiện:**
  - Bước 1: Đăng nhập vào cloud provider console/dashboard.
  - Bước 2: Mô tả chi tiết từng bước tạo cluster:
    - Đặt tên cluster.
    - Chọn region/datacenter.
    - Chọn Kubernetes version.
    - Cấu hình Node Pool: số lượng nodes (bắt đầu với 2 nodes), spec máy (2 vCPU, 4GB RAM), auto-scaling (min 2, max 5 nếu hỗ trợ).
  - Bước 3: Chụp screenshot hoặc mô tả chi tiết giao diện tại mỗi bước.
  - Bước 4: Ghi lại thời gian tạo cluster (thông thường 5-10 phút).
  - Bước 5: Mô tả các tùy chọn nâng cao (nếu có): VPC, network policy, monitoring.
- **Kết quả mong đợi:** Tài liệu có hướng dẫn từng bước rõ ràng để bất kỳ ai cũng có thể tạo được cluster theo.
- **Kết luận:** Quy trình tạo cluster đã được ghi lại đầy đủ, có thể tái sử dụng cho các project khác.

## 2
### title
Tài liệu hóa kết nối kubectl và kiểm tra cluster
### body
- **Các bước thực hiện:**
  - Bước 1: Mô tả cách tải kubeconfig từ cloud provider:
    - DigitalOcean: `doctl kubernetes cluster kubeconfig save <cluster-name>`
    - AWS EKS: `aws eks update-kubeconfig --name <cluster-name> --region <region>`
    - GCP GKE: `gcloud container clusters get-credentials <cluster-name> --zone <zone>`
  - Bước 2: Mô tả cách cài đặt CLI tool của provider (doctl, aws-cli, gcloud).
  - Bước 3: Xác nhận kết nối từ máy local:
    ```bash
    kubectl cluster-info
    kubectl get nodes
    ```
  - Bước 4: Mô tả output mong đợi: thông tin cluster endpoint, danh sách nodes với trạng thái Ready, version Kubernetes.
  - Bước 5: Deploy một Pod thử nghiệm để xác nhận cluster hoạt động:
    ```bash
    kubectl run test-nginx --image=nginx --port=80
    kubectl get pods
    kubectl delete pod test-nginx
    ```
- **Kết quả mong đợi:** Tài liệu mô tả đầy đủ quy trình từ tải kubeconfig đến xác nhận cluster hoạt động.
- **Kết luận:** Người đọc có thể thực hiện theo tài liệu để kết nối và sử dụng Managed Kubernetes cluster từ máy local.

## 3
### title
Tổng hợp tài liệu và phân tích chi phí
### body
- **Các bước thực hiện:**
  - Bước 1: Tổng hợp tài liệu thành một Google Docs hoàn chỉnh với cấu trúc rõ ràng: Giới thiệu, So sánh providers, Hướng dẫn tạo cluster, Kết nối kubectl, Kiểm tra hoạt động.
  - Bước 2: Thêm phần phân tích chi phí ước tính cho cấu hình cluster đã chọn (chi phí hàng tháng cho control plane + worker nodes).
  - Bước 3: Thêm phần khuyến nghị: khi nào nên dùng managed K8s vs tự quản lý, cách tối ưu chi phí (spot instances, auto-scaling).
  - Bước 4: Review lại toàn bộ tài liệu đảm bảo độ chính xác và tính đầy đủ.
- **Kết quả mong đợi:** Tài liệu hoàn chỉnh, chuyên nghiệp, có thể dùng làm tham khảo cho team.
- **Kết luận:** Tài liệu thiết lập Managed Kubernetes là tài sản giá trị cho team, giúp chuẩn hóa quy trình và giảm thời gian onboarding.

# references
## 0
### alias
DigitalOcean Kubernetes Documentation
### url
https://docs.digitalocean.com/products/kubernetes/
## 1
### alias
AWS EKS Documentation
### url
https://docs.aws.amazon.com/eks/latest/userguide/what-is-eks.html
## 2
### alias
Google Kubernetes Engine Documentation
### url
https://cloud.google.com/kubernetes-engine/docs

# submissions
## 0
### type
googleDocsUrl
### title
Tài liệu thiết lập Managed Kubernetes
### description
Nộp link Google Docs chứa tài liệu chi tiết về quy trình thiết lập Managed Kubernetes cluster trên cloud.
### score
20
### prompts
#### 0
##### title
So sánh providers và hướng dẫn tạo cluster
##### score
10
##### promptText
Tài liệu có bảng so sánh ít nhất 3 managed K8s providers với các tiêu chí rõ ràng. Hướng dẫn tạo cluster chi tiết từng bước, có mô tả cấu hình Node Pool (số nodes, spec, auto-scaling).
#### 1
##### title
Kết nối kubectl và phân tích chi phí
##### score
10
##### promptText
Mô tả đầy đủ cách tải kubeconfig và kết nối kubectl từ máy local, có lệnh kiểm tra cluster hoạt động. Có phần phân tích chi phí ước tính và khuyến nghị sử dụng.

# difficulty
easy

# score
20
