# title
Deploy Backend + MySQL + Redis on Minikube with Deployments and Services

# description
Deploy a complete system consisting of a NestJS backend, MySQL database, and Redis cache on Minikube using Deployments and Services, with components communicating via Kubernetes internal DNS.

# requirements
Deploy 3 components on Minikube: **NestJS backend** (Deployment with 2 replicas + ClusterIP Service), **MySQL 8** (Deployment with 1 replica + ClusterIP Service), **Redis 7** (Deployment with 1 replica + ClusterIP Service). NestJS connects to MySQL via TypeORM and to Redis via `ioredis`. Services communicate through Kubernetes internal DNS (e.g., `mysql-service`, `redis-service`). Implement a caching pattern: `GET /products` reads from Redis cache first; on cache miss, reads from MySQL and stores in Redis.

# prerequisites
- Node.js >= 18
- Docker Desktop
- Minikube and kubectl installed
- NestJS CLI
- Basic knowledge of MySQL, Redis, and TypeORM
- Completed challenge kubernetes-core-concepts-easy

# steps

## 0
### title
Create a NestJS application with MySQL and Redis
### body
- **Steps to follow:**
  - Step 1: Create a new NestJS project:
    ```bash
    nest new kubernetes-core-concepts-medium
    cd kubernetes-core-concepts-medium
    ```
  - Step 2: Install dependencies:
    ```bash
    npm install @nestjs/typeorm typeorm mysql2 @nestjs/config ioredis
    ```
  - Step 3: Create a `Product` entity (id, name, price, description, createdAt) and `ProductModule` with CRUD: `GET /products`, `GET /products/:id`, `POST /products`.
  - Step 4: Configure TypeORM to read from environment variables: `MYSQL_HOST`, `MYSQL_PORT`, `MYSQL_DATABASE`, `MYSQL_USER`, `MYSQL_PASSWORD`.
  - Step 5: Create a `RedisService` wrapper connecting to Redis from environment variables `REDIS_HOST`, `REDIS_PORT`. Implement `get(key)`, `set(key, value, ttl)`, `del(key)`.
  - Step 6: In `ProductService`, implement a caching pattern for `GET /products`:
    - Check Redis cache with key `products:all`.
    - If cache exists, return from Redis.
    - If not, read from MySQL, store in Redis with TTL 60 seconds, then return.
  - Step 7: When `POST /products`, delete cache key `products:all` to ensure fresh data.
  - Step 8: Create Dockerfile and build image:
    ```bash
    eval $(minikube docker-env)
    docker build -t k8s-core-medium:latest .
    ```
- **Expected result:** Docker image is built successfully, application reads MySQL and Redis configuration from environment variables.
- **Conclusion:** NestJS application has integrated MySQL and Redis, ready to deploy on Kubernetes.

## 1
### title
Create Kubernetes manifests for MySQL and Redis
### body
- **Steps to follow:**
  - Step 1: Create file `mysql-deployment.yaml` with a Deployment (1 replica, image `mysql:8.0`, environment variables for root password and database name) and a ClusterIP Service (port 3306).
  - Step 2: Create file `redis-deployment.yaml` with a Deployment (1 replica, image `redis:7-alpine`) and a ClusterIP Service (port 6379).
  - Step 3: Create ConfigMap and Secret for configuration:
    ```yaml
    apiVersion: v1
    kind: ConfigMap
    metadata:
      name: app-config
    data:
      MYSQL_HOST: "mysql-service"
      MYSQL_PORT: "3306"
      MYSQL_DATABASE: "productdb"
      REDIS_HOST: "redis-service"
      REDIS_PORT: "6379"
    ---
    apiVersion: v1
    kind: Secret
    metadata:
      name: db-secret
    type: Opaque
    stringData:
      MYSQL_USER: "root"
      MYSQL_PASSWORD: "rootpassword123"
      MYSQL_ROOT_PASSWORD: "rootpassword123"
    ```
  - Step 4: Apply all resources:
    ```bash
    kubectl apply -f mysql-deployment.yaml
    kubectl apply -f redis-deployment.yaml
    kubectl apply -f configmap.yaml
    ```
- **Expected result:** MySQL and Redis Deployments are running, Services are created with ClusterIP.
- **Conclusion:** Infrastructure layer (database + cache) is ready on Kubernetes.

## 2
### title
Deploy NestJS backend and verify DNS connectivity
### body
- **Steps to follow:**
  - Step 1: Create file `nestjs-deployment.yaml` with a Deployment (2 replicas) and a ClusterIP Service (port 80 -> targetPort 3000). Pod template references ConfigMap and Secret via `envFrom`.
  - Step 2: Apply NestJS Deployment:
    ```bash
    kubectl apply -f nestjs-deployment.yaml
    ```
  - Step 3: Verify all Deployments and Services:
    ```bash
    kubectl get deployments
    kubectl get services
    kubectl get pods
    ```
  - Step 4: Verify NestJS Pod can resolve DNS for MySQL and Redis:
    ```bash
    kubectl exec -it <nestjs-pod-name> -- nslookup mysql-service
    kubectl exec -it <nestjs-pod-name> -- nslookup redis-service
    ```
- **Expected result:** All Deployments are in READY state, Services have ClusterIP, DNS resolution succeeds.
- **Conclusion:** Components can communicate with each other through Kubernetes internal DNS.

## 3
### title
Test caching pattern and the entire system
### body
- **Steps to follow:**
  - Step 1: Port-forward to NestJS Service:
    ```bash
    kubectl port-forward service/nestjs-service 8080:80
    ```
  - Step 2: Create a product:
    ```bash
    curl -X POST http://localhost:8080/products -H "Content-Type: application/json" -d "{\"name\": \"Laptop\", \"price\": 999, \"description\": \"Gaming laptop\"}"
    ```
  - Step 3: Call `GET /products` first time (cache miss, reads from MySQL):
    ```bash
    curl http://localhost:8080/products
    ```
  - Step 4: Call `GET /products` second time (cache hit, reads from Redis, faster):
    ```bash
    curl http://localhost:8080/products
    ```
  - Step 5: Verify Redis has cached data by exec into Redis Pod:
    ```bash
    kubectl exec -it <redis-pod-name> -- redis-cli GET "products:all"
    ```
  - Step 6: Create another product and confirm cache is invalidated:
    ```bash
    curl -X POST http://localhost:8080/products -H "Content-Type: application/json" -d "{\"name\": \"Phone\", \"price\": 599, \"description\": \"Smartphone\"}"
    curl http://localhost:8080/products
    ```
    Confirm the list has 2 products (cache has been invalidated).
  - Step 7: Clean up:
    ```bash
    kubectl delete -f nestjs-deployment.yaml
    kubectl delete -f mysql-deployment.yaml
    kubectl delete -f redis-deployment.yaml
    kubectl delete -f configmap.yaml
    ```
- **Expected result:**
  - CRUD products works correctly with MySQL.
  - Caching pattern works: cache miss reads MySQL, cache hit reads Redis.
  - Cache invalidation works when creating a new product.
- **Conclusion:** The Backend + MySQL + Redis system works completely on Kubernetes with DNS-based connectivity and caching pattern.

# references
## 0
### alias
Kubernetes DNS for Services
### url
https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/
## 1
### alias
Kubernetes Deployments
### url
https://kubernetes.io/docs/concepts/workloads/controllers/deployment/
## 2
### alias
Redis Caching Pattern
### url
https://redis.io/docs/manual/patterns/caching/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing NestJS source code, Dockerfile, and all YAML manifests (deployments, services, configmap, secret).
### score
30
### prompts
#### 0
##### title
3 Deployments and Services configured correctly
##### score
10
##### promptText
NestJS (2 replicas), MySQL (1 replica), Redis (1 replica) all have Deployment and ClusterIP Service, DNS connectivity between services works.
#### 1
##### title
TypeORM and Redis connected successfully
##### score
10
##### promptText
NestJS connects to MySQL via TypeORM and Redis via ioredis, CRUD products works correctly, data is stored in MySQL.
#### 2
##### title
Caching pattern works
##### score
10
##### promptText
`GET /products` reads from Redis cache when available, reads from MySQL on cache miss, cache is invalidated when creating a new product.

# difficulty
medium

# score
30
