# title
Deploy PostgreSQL HA and Redis Cluster with Bitnami Helm Charts

# description
Use Bitnami Helm Charts to deploy a PostgreSQL High Availability cluster and a Redis cluster on Minikube, customizing configuration through separate values.yaml files for each chart.

# requirements
Deploy 2 systems on Minikube using Bitnami Helm Charts: **PostgreSQL HA** (using chart `bitnami/postgresql-ha` with 1 primary + 1 replica) and **Redis Cluster** (using chart `bitnami/redis` with 1 master + 2 replicas). Each chart must have its own `values.yaml` file for custom configuration. Verify replication works, connect a NestJS application to both systems.

# prerequisites
- Docker Desktop
- Minikube and kubectl installed (start with at least 4GB RAM and 2 CPUs)
- Helm CLI
- NestJS CLI and Node.js >= 18
- Completed challenge complex-applications-and-helm-charts-easy

# steps

## 0
### title
Prepare Minikube and Helm
### body
- **Steps to follow:**
  - Step 1: Start Minikube with sufficient resources:
    ```bash
    minikube start --cpus=2 --memory=4096
    ```
  - Step 2: Confirm Helm and Bitnami repo are ready:
    ```bash
    helm version
    helm repo update
    ```
  - Step 3: Search for the required charts:
    ```bash
    helm search repo bitnami/postgresql-ha
    helm search repo bitnami/redis
    ```
- **Expected result:** Minikube starts with enough resources, Helm charts are ready to install.
- **Conclusion:** The environment meets the requirements for deploying HA systems.

## 1
### title
Deploy PostgreSQL HA with custom values
### body
- **Steps to follow:**
  - Step 1: Create file `postgresql-ha-values.yaml`:
    ```yaml
    postgresql:
      replicaCount: 2
      password: "hapassword123"
      database: "hadb"
    pgpool:
      adminPassword: "pgpooladmin123"
    persistence:
      size: 1Gi
    ```
  - Step 2: Install the chart:
    ```bash
    helm install my-pg-ha bitnami/postgresql-ha -f postgresql-ha-values.yaml
    ```
  - Step 3: Wait for Pods to be ready:
    ```bash
    kubectl get pods -l app.kubernetes.io/instance=my-pg-ha -w
    ```
  - Step 4: Verify primary and replica Pods exist:
    ```bash
    kubectl get pods -l app.kubernetes.io/instance=my-pg-ha
    ```
  - Step 5: Check Services created:
    ```bash
    kubectl get services -l app.kubernetes.io/instance=my-pg-ha
    ```
- **Expected result:** PostgreSQL HA cluster starts with Pgpool, primary and replica Pods are all Running, Services (pgpool, postgresql) are created.
- **Conclusion:** PostgreSQL HA has been deployed successfully with replication through Helm chart.

## 2
### title
Deploy Redis cluster with custom values
### body
- **Steps to follow:**
  - Step 1: Create file `redis-values.yaml`:
    ```yaml
    architecture: replication
    auth:
      password: "redispassword123"
    master:
      persistence:
        size: 512Mi
    replica:
      replicaCount: 2
      persistence:
        size: 512Mi
    ```
  - Step 2: Install the chart:
    ```bash
    helm install my-redis bitnami/redis -f redis-values.yaml
    ```
  - Step 3: Wait for Pods to be ready:
    ```bash
    kubectl get pods -l app.kubernetes.io/instance=my-redis -w
    ```
  - Step 4: Verify master and replica Pods:
    ```bash
    kubectl get pods -l app.kubernetes.io/instance=my-redis
    ```
  - Step 5: Check Redis Services:
    ```bash
    kubectl get services -l app.kubernetes.io/instance=my-redis
    ```
- **Expected result:** Redis cluster with 1 master and 2 replicas are all Running, Services (master, replicas) are created.
- **Conclusion:** Redis replication has been deployed successfully via Helm chart.

## 3
### title
Verify replication and connect from application
### body
- **Steps to follow:**
  - Step 1: Verify PostgreSQL replication by connecting through Pgpool:
    ```bash
    kubectl port-forward service/my-pg-ha-pgpool 5432:5432
    ```
    Connect and create a test table, confirm data can be read.
  - Step 2: Verify Redis replication:
    ```bash
    kubectl exec -it my-redis-master-0 -- redis-cli -a redispassword123 INFO replication
    ```
    Confirm `connected_slaves:2`.
  - Step 3: Set a value on master and read from replica:
    ```bash
    kubectl exec -it my-redis-master-0 -- redis-cli -a redispassword123 SET testkey "hello-ha"
    kubectl exec -it my-redis-replicas-0 -- redis-cli -a redispassword123 GET testkey
    ```
  - Step 4: Create a simple NestJS project that connects to both PostgreSQL (via Pgpool Service) and Redis (via master Service), create a Dockerfile and build image in Minikube.
  - Step 5: Deploy NestJS on Minikube with environment variables pointing to Helm Services, port-forward and call endpoints to confirm connectivity.
  - Step 6: Clean up:
    ```bash
    helm uninstall my-pg-ha
    helm uninstall my-redis
    ```
- **Expected result:**
  - PostgreSQL HA replication works, data is consistent between primary and replica.
  - Redis replication works, data replicates from master to replicas.
  - NestJS connects successfully to both systems via Kubernetes Services.
- **Conclusion:** Bitnami Helm Charts enable deploying complex HA systems with just custom values.yaml files, saving time and ensuring standardized configuration.

# references
## 0
### alias
Bitnami PostgreSQL HA Helm Chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/postgresql-ha
## 1
### alias
Bitnami Redis Helm Chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/redis
## 2
### alias
Helm Values Files
### url
https://helm.sh/docs/chart_template_guide/values_files/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing values.yaml files, NestJS source code connecting to PostgreSQL HA and Redis, and README documenting the steps performed.
### score
30
### prompts
#### 0
##### title
PostgreSQL HA deployed and replication works
##### score
10
##### promptText
Chart `bitnami/postgresql-ha` is installed with custom values, has primary + replica Pods, Pgpool Service works, replication has been verified.
#### 1
##### title
Redis cluster deployed and replication works
##### score
10
##### promptText
Chart `bitnami/redis` is installed with replication architecture, has 1 master and 2 replicas, data replicates successfully from master to replicas.
#### 2
##### title
NestJS connects successfully to both systems
##### score
10
##### promptText
NestJS connects to PostgreSQL via Pgpool Service and Redis via master Service, endpoints work correctly on Minikube.

# difficulty
medium

# score
30
