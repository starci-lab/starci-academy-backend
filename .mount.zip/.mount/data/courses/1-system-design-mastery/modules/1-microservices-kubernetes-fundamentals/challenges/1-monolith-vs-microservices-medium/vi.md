# title
Tách Monolith thành 3 Microservices với Database độc lập và Docker Compose

# description
Refactor một ứng dụng monolith thành 3 microservices độc lập, mỗi service có database riêng (database-per-service pattern), sử dụng Docker Compose để orchestrate toàn bộ hệ thống, và viết tài liệu mô tả bounded contexts.

# requirements
Tách ứng dụng e-commerce thành 3 microservices: **user-service**, **product-service**, **order-service**. Mỗi service có database PostgreSQL riêng biệt. Order-service giao tiếp với user-service và product-service qua HTTP để xác minh dữ liệu. Toàn bộ hệ thống được orchestrate bằng Docker Compose (3 NestJS containers + 3 PostgreSQL containers). Nộp kèm tài liệu Google Docs mô tả bounded contexts, lý do tách service, và communication pattern đã chọn.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Docker và Docker Compose
- Kiến thức cơ bản về PostgreSQL và TypeORM
- Hoàn thành challenge monolith-vs-microservices-easy

# steps

## 0
### title
Thiết kế bounded contexts và khởi tạo các project
### body
- **Các bước thực hiện:**
  - Bước 1: Xác định 3 bounded contexts:
    - **User Context**: quản lý thông tin người dùng (id, name, email).
    - **Product Context**: quản lý sản phẩm (id, name, price, stock).
    - **Order Context**: quản lý đơn hàng (id, userId, productId, quantity, status, createdAt).
  - Bước 2: Tạo 3 project NestJS riêng biệt:
    ```bash
    nest new user-service
    nest new product-service
    nest new order-service
    ```
  - Bước 3: Trong mỗi project, cài đặt TypeORM và PostgreSQL driver:
    ```bash
    npm install @nestjs/typeorm typeorm pg
    ```
- **Kết quả mong đợi:** 3 project NestJS độc lập đã được tạo, mỗi project có các dependency cần thiết.
- **Kết luận:** Bounded contexts đã được xác định rõ ràng, mỗi service sẽ quản lý một phần dữ liệu riêng biệt.

## 1
### title
Cài đặt database-per-service với TypeORM
### body
- **Các bước thực hiện:**
  - Bước 1: Trong `user-service`, tạo entity `User` (id, name, email) và cấu hình TypeORM kết nối đến PostgreSQL trên port 5433.
  - Bước 2: Trong `product-service`, tạo entity `Product` (id, name, price, stock) và cấu hình TypeORM kết nối đến PostgreSQL trên port 5434.
  - Bước 3: Trong `order-service`, tạo entity `Order` (id, userId, productId, quantity, status, createdAt) và cấu hình TypeORM kết nối đến PostgreSQL trên port 5435. Lưu ý: chỉ lưu userId và productId dạng number, không tạo foreign key vì database tách biệt.
  - Bước 4: Mỗi service triển khai CRUD cơ bản: user-service có `GET /users`, `GET /users/:id`, `POST /users`; product-service có `GET /products`, `GET /products/:id`, `POST /products`; order-service có `GET /orders`, `POST /orders`.
- **Kết quả mong đợi:** Mỗi service kết nối được đến database PostgreSQL riêng, CRUD cơ bản hoạt động độc lập.
- **Kết luận:** Pattern database-per-service đã được áp dụng, đảm bảo mỗi service quản lý dữ liệu độc lập.

## 2
### title
Thiết lập giao tiếp HTTP giữa các services
### body
- **Các bước thực hiện:**
  - Bước 1: Trong `order-service`, cài đặt HttpModule:
    ```bash
    npm install @nestjs/axios axios
    ```
  - Bước 2: Khi `POST /orders` nhận request, order-service gọi `GET http://user-service:3001/users/:userId` để kiểm tra user tồn tại.
  - Bước 3: Tiếp tục gọi `GET http://product-service:3002/products/:productId` để kiểm tra product tồn tại và còn hàng (stock > 0).
  - Bước 4: Nếu cả hai hợp lệ, tạo order và trả về kết quả. Nếu không, trả lời 404 với thông báo cụ thể.
  - Bước 5: Xử lý trường hợp service không khả dụng: bắt lỗi kết nối và trả 503 Service Unavailable.
- **Kết quả mong đợi:** Order-service xác minh dữ liệu từ 2 service khác trước khi tạo order, xử lý lỗi giao tiếp rõ ràng.
- **Kết luận:** Giao tiếp HTTP giữa các microservices đã được thiết lập với xử lý lỗi đầy đủ.

## 3
### title
Thiết lập Docker Compose cho toàn bộ hệ thống
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `Dockerfile` cho mỗi service sử dụng multi-stage build (build stage và production stage).
  - Bước 2: Tạo file `docker-compose.yml` ở thư mục gốc với 6 containers:
    - `user-db` (PostgreSQL, port 5433)
    - `product-db` (PostgreSQL, port 5434)
    - `order-db` (PostgreSQL, port 5435)
    - `user-service` (port 3001, depends_on user-db)
    - `product-service` (port 3002, depends_on product-db)
    - `order-service` (port 3000, depends_on order-db)
  - Bước 3: Cấu hình environment variables cho mỗi service để kết nối đến database tương ứng qua Docker network (sử dụng service name làm hostname).
  - Bước 4: Thêm health check cho các database containers.
  - Bước 5: Khởi động toàn bộ hệ thống:
    ```bash
    docker-compose up --build
    ```
- **Kết quả mong đợi:** Tất cả 6 containers khởi động thành công, các service giao tiếp được với nhau qua Docker network nội bộ.
- **Kết luận:** Docker Compose orchestrate thành công toàn bộ hệ thống microservices với database độc lập.

## 4
### title
Kiểm thử và viết tài liệu bounded contexts
### body
- **Các bước thực hiện:**
  - Bước 1: Khởi động hệ thống bằng Docker Compose:
    ```bash
    docker-compose up --build
    ```
  - Bước 2: Tạo user:
    ```bash
    curl -X POST http://localhost:3001/users -H "Content-Type: application/json" -d "{\"name\": \"Alice\", \"email\": \"alice@test.com\"}"
    ```
  - Bước 3: Tạo product:
    ```bash
    curl -X POST http://localhost:3002/products -H "Content-Type: application/json" -d "{\"name\": \"Laptop\", \"price\": 999, \"stock\": 10}"
    ```
  - Bước 4: Tạo order thành công:
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d "{\"userId\": 1, \"productId\": 1, \"quantity\": 1}"
    ```
  - Bước 5: Test các trường hợp lỗi (userId/productId không tồn tại, service không khả dụng).
  - Bước 6: Viết tài liệu Google Docs gồm: sơ đồ bounded contexts, lý do tách từng service, communication pattern (synchronous HTTP), ưu/nhược điểm của cách tiếp cận, và các vấn đề tiềm ẩn (data consistency, network latency).
- **Kết quả mong đợi:**
  - Toàn bộ luồng tạo user -> tạo product -> tạo order hoạt động đúng.
  - Các trường hợp lỗi trả response phù hợp.
  - Tài liệu mô tả đầy đủ bounded contexts và quyết định thiết kế.
- **Kết luận:** Hệ thống microservices đã được chứng minh hoạt động end-to-end, tài liệu thiết kế giúp người đọc hiểu rõ lý do và cách thức tách service.

# references
## 0
### alias
Database per Service Pattern
### url
https://microservices.io/patterns/data/database-per-service.html
## 1
### alias
Docker Compose Documentation
### url
https://docs.docker.com/compose/
## 2
### alias
Bounded Context - Martin Fowler
### url
https://martinfowler.com/bliki/BoundedContext.html

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code 3 microservices, Dockerfile và docker-compose.yml.
### score
20
### prompts
#### 0
##### title
3 microservices với database độc lập
##### score
7
##### promptText
3 service riêng biệt (user-service, product-service, order-service) mỗi service có database PostgreSQL riêng, entity và CRUD cơ bản hoạt động đúng.
#### 1
##### title
Docker Compose orchestration
##### score
7
##### promptText
File docker-compose.yml cấu hình đúng 6 containers (3 app + 3 db), hệ thống khởi động bằng `docker-compose up --build` và các service giao tiếp được với nhau.
#### 2
##### title
Giao tiếp HTTP và xử lý lỗi
##### score
6
##### promptText
Order-service gọi HTTP sang user-service và product-service, xử lý đúng trường hợp user/product không tồn tại (404) và service không khả dụng (503).
## 1
### type
googleDocsUrl
### title
Tài liệu Bounded Contexts
### description
Nộp link Google Docs mô tả bounded contexts, lý do tách service và communication pattern.
### score
10
### prompts
#### 0
##### title
Mô tả bounded contexts và quyết định thiết kế
##### score
10
##### promptText
Tài liệu mô tả rõ 3 bounded contexts, lý do tách mỗi service, communication pattern đã chọn (synchronous HTTP), và phân tích ưu/nhược điểm của kiến trúc.

# difficulty
medium

# score
30
