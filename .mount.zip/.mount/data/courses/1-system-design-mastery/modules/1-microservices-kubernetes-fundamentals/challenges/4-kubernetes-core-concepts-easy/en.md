# title
Deployment with Replicas, ClusterIP Service, and Rolling Update

# description
Create a Deployment with 2 replicas for a NestJS application, expose it with a ClusterIP Service, and perform a rolling update to demonstrate that Kubernetes can update the application with zero downtime.

# requirements
Write YAML manifests to create a **Deployment** with 2 replicas running a NestJS application. Create a **ClusterIP Service** to expose the Deployment internally within the cluster. Perform a **rolling update** by changing the application version and observe the update process. Use `kubectl` to confirm replicas, Service, and rolling update work correctly.

# prerequisites
- Node.js >= 18
- Docker Desktop
- Minikube and kubectl installed
- NestJS CLI
- Basic understanding of Kubernetes Pods

# steps

## 0
### title
Create a NestJS application with version endpoint
### body
- **Steps to follow:**
  - Step 1: Create a new NestJS project:
    ```bash
    nest new kubernetes-core-concepts-easy
    cd kubernetes-core-concepts-easy
    ```
  - Step 2: Create endpoint `GET /version` in `AppController` returning `{ version: "1.0.0", hostname: os.hostname() }` (import `os` from Node.js). Hostname helps distinguish between replicas.
  - Step 3: Create endpoint `GET /health` returning `{ status: "ok" }`.
  - Step 4: Create Dockerfile and build image version 1:
    ```bash
    eval $(minikube docker-env)
    docker build -t k8s-core-nestjs:v1 .
    ```
- **Expected result:** Docker image `k8s-core-nestjs:v1` is built successfully.
- **Conclusion:** Application v1 is ready to deploy with a Deployment.

## 1
### title
Create a Deployment with 2 replicas
### body
- **Steps to follow:**
  - Step 1: Create file `deployment.yaml`:
    ```yaml
    apiVersion: apps/v1
    kind: Deployment
    metadata:
      name: nestjs-deployment
    spec:
      replicas: 2
      selector:
        matchLabels:
          app: nestjs-app
      template:
        metadata:
          labels:
            app: nestjs-app
        spec:
          containers:
            - name: nestjs-app
              image: k8s-core-nestjs:v1
              imagePullPolicy: Never
              ports:
                - containerPort: 3000
    ```
  - Step 2: Apply the Deployment:
    ```bash
    kubectl apply -f deployment.yaml
    ```
  - Step 3: Verify Deployment and Pods:
    ```bash
    kubectl get deployment nestjs-deployment
    kubectl get pods -l app=nestjs-app
    ```
  - Step 4: Confirm exactly 2 Pods are running.
- **Expected result:** Deployment `nestjs-deployment` has 2/2 replicas READY, both Pods are in `Running` state.
- **Conclusion:** The Deployment successfully manages 2 replicas of the application.

## 2
### title
Create a ClusterIP Service
### body
- **Steps to follow:**
  - Step 1: Create file `service.yaml`:
    ```yaml
    apiVersion: v1
    kind: Service
    metadata:
      name: nestjs-service
    spec:
      type: ClusterIP
      selector:
        app: nestjs-app
      ports:
        - port: 80
          targetPort: 3000
    ```
  - Step 2: Apply the Service:
    ```bash
    kubectl apply -f service.yaml
    ```
  - Step 3: Verify the Service:
    ```bash
    kubectl get service nestjs-service
    ```
  - Step 4: Port-forward through the Service and call endpoints multiple times:
    ```bash
    kubectl port-forward service/nestjs-service 8080:80
    ```
  - Step 5: Call the version endpoint multiple times to see hostname changes (load balancing between 2 replicas):
    ```bash
    curl http://localhost:8080/version
    curl http://localhost:8080/version
    curl http://localhost:8080/version
    ```
- **Expected result:** Service is created successfully, requests are distributed between 2 replicas (different hostnames in response).
- **Conclusion:** ClusterIP Service works as an internal load balancer, distributing traffic to replicas.

## 3
### title
Perform a rolling update
### body
- **Steps to follow:**
  - Step 1: Modify endpoint `GET /version` to return `{ version: "2.0.0", hostname: os.hostname() }`.
  - Step 2: Build image version 2:
    ```bash
    eval $(minikube docker-env)
    docker build -t k8s-core-nestjs:v2 .
    ```
  - Step 3: Update the Deployment to use the new image:
    ```bash
    kubectl set image deployment/nestjs-deployment nestjs-app=k8s-core-nestjs:v2
    ```
  - Step 4: Watch the rolling update progress:
    ```bash
    kubectl rollout status deployment/nestjs-deployment
    ```
  - Step 5: Confirm the new version:
    ```bash
    kubectl port-forward service/nestjs-service 8080:80
    curl http://localhost:8080/version
    ```
    Confirm it returns `version: "2.0.0"`.
  - Step 6: View rollout history:
    ```bash
    kubectl rollout history deployment/nestjs-deployment
    ```
  - Step 7: Clean up:
    ```bash
    kubectl delete deployment nestjs-deployment
    kubectl delete service nestjs-service
    ```
- **Expected result:**
  - Rolling update completes successfully with zero downtime.
  - Endpoint returns version 2.0.0 after the update.
  - Rollout history shows 2 revisions.
- **Conclusion:** Rolling updates allow updating applications on Kubernetes without affecting service availability.

# references
## 0
### alias
Kubernetes Deployments
### url
https://kubernetes.io/docs/concepts/workloads/controllers/deployment/
## 1
### alias
Kubernetes Services
### url
https://kubernetes.io/docs/concepts/services-networking/service/
## 2
### alias
Performing a Rolling Update
### url
https://kubernetes.io/docs/tutorials/kubernetes-basics/update/update-intro/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing NestJS source code, Dockerfile, and YAML manifest files (deployment, service).
### score
20
### prompts
#### 0
##### title
Deployment and Service configured correctly
##### score
10
##### promptText
Deployment has 2 replicas, selector matches correct labels. ClusterIP Service targets the Deployment correctly, port mapping is accurate.
#### 1
##### title
Rolling update works
##### score
10
##### promptText
Image is updated from v1 to v2 successfully, `kubectl rollout status` confirms completion, endpoint returns the new version.

# difficulty
easy

# score
20
