# title
Install Helm and Deploy PostgreSQL with Bitnami Chart

# description
Install the Helm package manager, use a Bitnami Helm chart to deploy a PostgreSQL instance on Minikube, and verify connectivity from a client application.

# requirements
Install Helm CLI. Add the Bitnami Helm repository. Use the `bitnami/postgresql` chart to deploy a PostgreSQL instance on Minikube with custom parameters (password, database name). Verify connectivity using `psql` client or a simple NestJS application.

# prerequisites
- Docker Desktop
- Minikube and kubectl installed
- Helm CLI
- Basic knowledge of Kubernetes Services

# steps

## 0
### title
Install Helm and add Bitnami repository
### body
- **Steps to follow:**
  - Step 1: Install Helm following the official guide (https://helm.sh/docs/intro/install/).
  - Step 2: Verify Helm version:
    ```bash
    helm version
    ```
  - Step 3: Add the Bitnami Helm repository:
    ```bash
    helm repo add bitnami https://charts.bitnami.com/bitnami
    ```
  - Step 4: Update the repository:
    ```bash
    helm repo update
    ```
  - Step 5: Search for the PostgreSQL chart:
    ```bash
    helm search repo bitnami/postgresql
    ```
- **Expected result:** Helm is installed, Bitnami repo is added, chart `bitnami/postgresql` appears in search results.
- **Conclusion:** Helm and Bitnami repository are ready for deploying applications.

## 1
### title
Deploy PostgreSQL using Bitnami Helm chart
### body
- **Steps to follow:**
  - Step 1: Create file `postgresql-values.yaml` to customize configuration:
    ```yaml
    auth:
      postgresPassword: "helmpassword123"
      database: "helmdb"
    primary:
      persistence:
        size: 1Gi
    ```
  - Step 2: Install the chart with custom values:
    ```bash
    helm install my-postgresql bitnami/postgresql -f postgresql-values.yaml
    ```
  - Step 3: Check release status:
    ```bash
    helm list
    ```
  - Step 4: Verify Pods and Services created:
    ```bash
    kubectl get pods
    kubectl get services
    ```
  - Step 5: Read the connection instructions from Helm output (usually displayed after install).
- **Expected result:** Release `my-postgresql` is in `deployed` status, PostgreSQL Pod is `Running`, Service is created with ClusterIP.
- **Conclusion:** PostgreSQL has been deployed successfully via Helm chart with just a few simple commands.

## 2
### title
Verify connectivity to PostgreSQL
### body
- **Steps to follow:**
  - Step 1: Get the password from Kubernetes Secret:
    ```bash
    kubectl get secret my-postgresql -o jsonpath="{.data.postgres-password}" | base64 -d
    ```
  - Step 2: Port-forward to PostgreSQL Service:
    ```bash
    kubectl port-forward service/my-postgresql 5432:5432
    ```
  - Step 3: Connect using psql (separate terminal):
    ```bash
    psql -h localhost -U postgres -d helmdb
    ```
  - Step 4: Run some SQL commands to verify:
    ```sql
    CREATE TABLE test_table (id SERIAL PRIMARY KEY, name VARCHAR(50));
    INSERT INTO test_table (name) VALUES ('helm-test');
    SELECT * FROM test_table;
    ```
  - Step 5: Check resources created by Helm:
    ```bash
    kubectl get all -l app.kubernetes.io/instance=my-postgresql
    ```
- **Expected result:** PostgreSQL connection succeeds, table creation and insert/select operations work correctly.
- **Conclusion:** PostgreSQL deployed via Helm chart works perfectly and can be used for real applications.

## 3
### title
Manage release and clean up
### body
- **Steps to follow:**
  - Step 1: View release details:
    ```bash
    helm status my-postgresql
    ```
  - Step 2: View current values:
    ```bash
    helm get values my-postgresql
    ```
  - Step 3: Try upgrading with new values (e.g., increase persistence size):
    ```bash
    helm upgrade my-postgresql bitnami/postgresql -f postgresql-values.yaml --set primary.persistence.size=2Gi
    ```
  - Step 4: View revision history:
    ```bash
    helm history my-postgresql
    ```
  - Step 5: Uninstall the release:
    ```bash
    helm uninstall my-postgresql
    ```
  - Step 6: Confirm all resources have been cleaned up:
    ```bash
    kubectl get pods
    kubectl get services
    kubectl get pvc
    ```
- **Expected result:**
  - Helm status, values, history work correctly.
  - Upgrade creates a new revision.
  - Uninstall removes all Kubernetes resources of the release.
- **Conclusion:** Helm provides a complete lifecycle management for applications on Kubernetes: install, upgrade, rollback, uninstall.

# references
## 0
### alias
Helm Installation Guide
### url
https://helm.sh/docs/intro/install/
## 1
### alias
Bitnami PostgreSQL Helm Chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/postgresql
## 2
### alias
Helm Quickstart Guide
### url
https://helm.sh/docs/intro/quickstart/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing `postgresql-values.yaml` and documentation of commands executed (README.md).
### score
20
### prompts
#### 0
##### title
Helm and Bitnami chart used correctly
##### score
10
##### promptText
Helm is installed, Bitnami repo is added, chart `bitnami/postgresql` is installed with custom values file, release is in deployed status.
#### 1
##### title
Connectivity and release management
##### score
10
##### promptText
PostgreSQL connectivity succeeds via port-forward, SQL operations work. Helm upgrade and uninstall work correctly.

# difficulty
easy

# score
20
