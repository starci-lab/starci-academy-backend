# title
Deploy NestJS và PostgreSQL trên Minikube với ConfigMap và Secret

# description
Deploy nhiều Pods trên Minikube gồm một ứng dụng NestJS và một PostgreSQL database, sử dụng ConfigMap và Secret để quản lý cấu hình và thông tin nhạy cảm, đảm bảo ứng dụng kết nối được đến database.

# requirements
Tạo YAML manifests để deploy 2 Pods trên Minikube: **nestjs-app** (ứng dụng NestJS với TypeORM) và **postgres-db** (PostgreSQL 15). Sử dụng **ConfigMap** để lưu cấu hình không nhạy cảm (DB_HOST, DB_PORT, DB_NAME) và **Secret** để lưu thông tin nhạy cảm (DB_USERNAME, DB_PASSWORD). Ứng dụng NestJS đọc các biến môi trường từ ConfigMap/Secret và kết nối đến PostgreSQL. Tạo endpoint `GET /health/db` để kiểm tra kết nối database.

# prerequisites
- Node.js >= 18
- Docker Desktop
- Minikube và kubectl đã cài đặt
- NestJS CLI
- Kiến thức cơ bản về PostgreSQL và TypeORM
- Hoàn thành challenge introduction-to-kubernetes-easy

# steps

## 0
### title
Tạo ứng dụng NestJS với TypeORM và đóng gói Docker image
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS mới:
    ```bash
    nest new introduction-to-kubernetes-medium
    cd introduction-to-kubernetes-medium
    ```
  - Bước 2: Cài đặt TypeORM và PostgreSQL driver:
    ```bash
    npm install @nestjs/typeorm typeorm pg @nestjs/config
    ```
  - Bước 3: Tạo entity `Task` (id, title, completed, createdAt) và `TaskModule` với CRUD cơ bản (`GET /tasks`, `POST /tasks`).
  - Bước 4: Cấu hình TypeORM trong `AppModule` đọc từ biến môi trường: `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USERNAME`, `DB_PASSWORD`.
  - Bước 5: Tạo endpoint `GET /health/db` kiểm tra kết nối database bằng cách chạy một query đơn giản (`SELECT 1`), trả về `{ status: "connected" }` hoặc `{ status: "disconnected", error: "..." }`.
  - Bước 6: Tạo Dockerfile và build image:
    ```bash
    eval $(minikube docker-env)
    docker build -t intro-k8s-medium:latest .
    ```
- **Kết quả mong đợi:** Docker image `intro-k8s-medium:latest` được build thành công, ứng dụng đọc cấu hình từ biến môi trường.
- **Kết luận:** Ứng dụng đã sẵn sàng để deploy lên Kubernetes với cấu hình linh hoạt qua environment variables.

## 1
### title
Tạo ConfigMap và Secret
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `configmap.yaml`:
    ```yaml
    apiVersion: v1
    kind: ConfigMap
    metadata:
      name: app-config
    data:
      DB_HOST: "postgres-db"
      DB_PORT: "5432"
      DB_NAME: "taskdb"
    ```
  - Bước 2: Tạo file `secret.yaml`:
    ```yaml
    apiVersion: v1
    kind: Secret
    metadata:
      name: db-secret
    type: Opaque
    stringData:
      DB_USERNAME: "postgres"
      DB_PASSWORD: "secretpassword123"
    ```
  - Bước 3: Apply ConfigMap và Secret:
    ```bash
    kubectl apply -f configmap.yaml
    kubectl apply -f secret.yaml
    ```
  - Bước 4: Kiểm tra ConfigMap và Secret đã tạo:
    ```bash
    kubectl get configmap app-config
    kubectl get secret db-secret
    ```
- **Kết quả mong đợi:** ConfigMap `app-config` và Secret `db-secret` được tạo thành công trên cluster.
- **Kết luận:** Cấu hình và thông tin nhạy cảm đã được tách riêng thành Kubernetes resources, sẵn sàng để mount vào Pods.

## 2
### title
Tạo YAML manifests cho PostgreSQL Pod và NestJS Pod
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `postgres-pod.yaml` deploy PostgreSQL 15, sử dụng environment variables từ Secret:
    ```yaml
    apiVersion: v1
    kind: Pod
    metadata:
      name: postgres-db
      labels:
        app: postgres-db
    spec:
      containers:
        - name: postgres
          image: postgres:15-alpine
          ports:
            - containerPort: 5432
          env:
            - name: POSTGRES_USER
              valueFrom:
                secretKeyRef:
                  name: db-secret
                  key: DB_USERNAME
            - name: POSTGRES_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: db-secret
                  key: DB_PASSWORD
            - name: POSTGRES_DB
              valueFrom:
                configMapKeyRef:
                  name: app-config
                  key: DB_NAME
    ```
  - Bước 2: Tạo file `nestjs-pod.yaml` deploy ứng dụng NestJS, tham chiếu ConfigMap và Secret:
    ```yaml
    apiVersion: v1
    kind: Pod
    metadata:
      name: nestjs-app
      labels:
        app: nestjs-app
    spec:
      containers:
        - name: nestjs-app
          image: intro-k8s-medium:latest
          imagePullPolicy: Never
          ports:
            - containerPort: 3000
          envFrom:
            - configMapRef:
                name: app-config
            - secretRef:
                name: db-secret
    ```
  - Bước 3: Apply PostgreSQL Pod trước:
    ```bash
    kubectl apply -f postgres-pod.yaml
    ```
  - Bước 4: Đợi PostgreSQL sẵn sàng rồi apply NestJS Pod:
    ```bash
    kubectl wait --for=condition=Ready pod/postgres-db --timeout=60s
    kubectl apply -f nestjs-pod.yaml
    ```
- **Kết quả mong đợi:** Cả hai Pods đều ở trạng thái `Running`, NestJS Pod đọc được cấu hình từ ConfigMap và Secret.
- **Kết luận:** Hai Pods đã được deploy với cấu hình được quản lý tập trung qua ConfigMap và Secret.

## 3
### title
Kiểm thử kết nối và CRUD
### body
- **Các bước thực hiện:**
  - Bước 1: Port-forward đến NestJS Pod:
    ```bash
    kubectl port-forward pod/nestjs-app 3000:3000
    ```
  - Bước 2: Kiểm tra kết nối database:
    ```bash
    curl http://localhost:3000/health/db
    ```
    Xác nhận trả về `{ status: "connected" }`.
  - Bước 3: Tạo task mới:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\": \"Learn Kubernetes\", \"completed\": false}"
    ```
  - Bước 4: Lấy danh sách tasks:
    ```bash
    curl http://localhost:3000/tasks
    ```
    Xác nhận task vừa tạo xuất hiện trong danh sách.
  - Bước 5: Xem logs của cả hai Pods:
    ```bash
    kubectl logs nestjs-app
    kubectl logs postgres-db
    ```
  - Bước 6: Dọn dẹp tài nguyên:
    ```bash
    kubectl delete pod nestjs-app postgres-db
    kubectl delete configmap app-config
    kubectl delete secret db-secret
    ```
- **Kết quả mong đợi:**
  - Database health check trả `connected`.
  - CRUD operations hoạt động đúng, dữ liệu được lưu trong PostgreSQL.
  - Logs của cả hai Pods không có lỗi.
- **Kết luận:** Hệ thống NestJS + PostgreSQL hoạt động đúng trên Minikube, ConfigMap và Secret được sử dụng để quản lý cấu hình an toàn.

# references
## 0
### alias
Kubernetes ConfigMaps
### url
https://kubernetes.io/docs/concepts/configuration/configmap/
## 1
### alias
Kubernetes Secrets
### url
https://kubernetes.io/docs/concepts/configuration/secret/
## 2
### alias
TypeORM NestJS Integration
### url
https://docs.nestjs.com/techniques/database

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code NestJS, Dockerfile và các file YAML manifests (configmap, secret, pods).
### score
30
### prompts
#### 0
##### title
ConfigMap và Secret cấu hình đúng
##### score
10
##### promptText
ConfigMap chứa các biến không nhạy cảm (DB_HOST, DB_PORT, DB_NAME), Secret chứa thông tin nhạy cảm (DB_USERNAME, DB_PASSWORD), cả hai được tham chiếu đúng trong Pod manifests.
#### 1
##### title
Hai Pods deploy và kết nối thành công
##### score
10
##### promptText
PostgreSQL Pod và NestJS Pod đều chạy thành công trên Minikube, NestJS kết nối được đến PostgreSQL thông qua cấu hình từ ConfigMap/Secret.
#### 2
##### title
Health check và CRUD hoạt động
##### score
10
##### promptText
Endpoint `GET /health/db` trả về trạng thái kết nối database, CRUD tasks (`GET /tasks`, `POST /tasks`) hoạt động đúng với dữ liệu lưu trong PostgreSQL.

# difficulty
medium

# score
30
