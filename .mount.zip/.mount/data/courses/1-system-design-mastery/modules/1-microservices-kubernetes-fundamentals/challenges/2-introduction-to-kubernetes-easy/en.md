# title
Deploy a NestJS Backend on Minikube with Pod and Port-Forward

# description
Install Minikube, write a YAML manifest to deploy a NestJS backend application as a Pod on Kubernetes, and use port-forward to verify the application works from the local machine.

# requirements
Install and start Minikube. Package a NestJS application into a Docker image. Write a YAML manifest file to create a Pod running the NestJS application. Use `kubectl port-forward` to access the application from the local machine and confirm endpoints work correctly.

# prerequisites
- Node.js >= 18
- Docker Desktop
- Minikube and kubectl installed
- NestJS CLI
- Basic knowledge of Docker

# steps

## 0
### title
Install Minikube and verify the environment
### body
- **Steps to follow:**
  - Step 1: Install Minikube following the official guide (https://minikube.sigs.k8s.io/docs/start/).
  - Step 2: Start Minikube:
    ```bash
    minikube start
    ```
  - Step 3: Verify Minikube is running:
    ```bash
    minikube status
    ```
  - Step 4: Verify kubectl connects to the cluster:
    ```bash
    kubectl get nodes
    ```
- **Expected result:** Minikube starts successfully, `kubectl get nodes` shows a node with status `Ready`.
- **Conclusion:** The local Kubernetes environment is ready for deploying applications.

## 1
### title
Create a NestJS application and build a Docker image
### body
- **Steps to follow:**
  - Step 1: Create a new NestJS project:
    ```bash
    nest new introduction-to-kubernetes-easy
    cd introduction-to-kubernetes-easy
    ```
  - Step 2: Create endpoint `GET /health` in `AppController` returning `{ status: "ok", timestamp: new Date().toISOString() }`.
  - Step 3: Create a `Dockerfile` at the project root:
    ```dockerfile
    FROM node:18-alpine
    WORKDIR /app
    COPY package*.json ./
    RUN npm ci
    COPY . .
    RUN npm run build
    EXPOSE 3000
    CMD ["node", "dist/main"]
    ```
  - Step 4: Configure Minikube's Docker daemon to build images directly:
    ```bash
    eval $(minikube docker-env)
    ```
  - Step 5: Build the Docker image:
    ```bash
    docker build -t intro-k8s-nestjs:latest .
    ```
- **Expected result:** Docker image `intro-k8s-nestjs:latest` is built successfully in the Minikube Docker environment.
- **Conclusion:** The application has been packaged as a Docker image, ready to deploy on Kubernetes.

## 2
### title
Write a YAML manifest and create the Pod
### body
- **Steps to follow:**
  - Step 1: Create file `pod.yaml` with content:
    ```yaml
    apiVersion: v1
    kind: Pod
    metadata:
      name: nestjs-app
      labels:
        app: nestjs-app
    spec:
      containers:
        - name: nestjs-app
          image: intro-k8s-nestjs:latest
          imagePullPolicy: Never
          ports:
            - containerPort: 3000
    ```
  - Step 2: Apply the manifest to the cluster:
    ```bash
    kubectl apply -f pod.yaml
    ```
  - Step 3: Verify the Pod is running:
    ```bash
    kubectl get pods
    ```
  - Step 4: View Pod logs:
    ```bash
    kubectl logs nestjs-app
    ```
- **Expected result:** Pod `nestjs-app` is in `Running` state, logs show NestJS has started successfully.
- **Conclusion:** The NestJS application has been successfully deployed on Kubernetes as a Pod.

## 3
### title
Use port-forward and test
### body
- **Steps to follow:**
  - Step 1: Set up port-forward from local machine to the Pod:
    ```bash
    kubectl port-forward pod/nestjs-app 3000:3000
    ```
  - Step 2: Open another terminal and call the default endpoint:
    ```bash
    curl http://localhost:3000
    ```
  - Step 3: Call the health check endpoint:
    ```bash
    curl http://localhost:3000/health
    ```
    Confirm it returns `{ status: "ok", timestamp: "..." }`.
  - Step 4: Inspect Pod details:
    ```bash
    kubectl describe pod nestjs-app
    ```
  - Step 5: Clean up resources:
    ```bash
    kubectl delete pod nestjs-app
    ```
- **Expected result:**
  - Port-forward works, application is accessible at `localhost:3000`.
  - `GET /health` returns the correct response.
  - `kubectl describe pod` shows Pod configuration details.
- **Conclusion:** The NestJS application has been deployed and accessed successfully on Minikube via port-forward.

# references
## 0
### alias
Minikube Start Guide
### url
https://minikube.sigs.k8s.io/docs/start/
## 1
### alias
Kubernetes Pods Documentation
### url
https://kubernetes.io/docs/concepts/workloads/pods/
## 2
### alias
kubectl Port-Forward
### url
https://kubernetes.io/docs/tasks/access-application-cluster/port-forward-access-application-cluster/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing NestJS source code, Dockerfile, and YAML manifest file.
### score
20
### prompts
#### 0
##### title
Docker image and YAML manifest correct
##### score
10
##### promptText
NestJS project has a valid Dockerfile, pod.yaml uses correct Kubernetes syntax, image is built and Pod runs successfully on Minikube.
#### 1
##### title
Port-forward and endpoint work
##### score
10
##### promptText
Using `kubectl port-forward` to access the application works, endpoint `GET /health` returns response in correct format `{ status, timestamp }`.

# difficulty
easy

# score
20
