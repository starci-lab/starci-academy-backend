# title
Split Monolith into 3 Microservices with Independent Databases and Docker Compose

# description
Refactor a monolith application into 3 independent microservices, each with its own database (database-per-service pattern), use Docker Compose to orchestrate the entire system, and write documentation describing the bounded contexts.

# requirements
Split an e-commerce application into 3 microservices: **user-service**, **product-service**, **order-service**. Each service has its own PostgreSQL database. Order-service communicates with user-service and product-service via HTTP to verify data. The entire system is orchestrated with Docker Compose (3 NestJS containers + 3 PostgreSQL containers). Submit a Google Docs document describing bounded contexts, reasons for splitting services, and the chosen communication pattern.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Docker and Docker Compose
- Basic knowledge of PostgreSQL and TypeORM
- Completed challenge monolith-vs-microservices-easy

# steps

## 0
### title
Design bounded contexts and initialize projects
### body
- **Steps to follow:**
  - Step 1: Identify 3 bounded contexts:
    - **User Context**: manages user information (id, name, email).
    - **Product Context**: manages products (id, name, price, stock).
    - **Order Context**: manages orders (id, userId, productId, quantity, status, createdAt).
  - Step 2: Create 3 separate NestJS projects:
    ```bash
    nest new user-service
    nest new product-service
    nest new order-service
    ```
  - Step 3: In each project, install TypeORM and PostgreSQL driver:
    ```bash
    npm install @nestjs/typeorm typeorm pg
    ```
- **Expected result:** 3 independent NestJS projects created, each with necessary dependencies.
- **Conclusion:** Bounded contexts have been clearly defined, each service will manage its own data partition.

## 1
### title
Implement database-per-service with TypeORM
### body
- **Steps to follow:**
  - Step 1: In `user-service`, create a `User` entity (id, name, email) and configure TypeORM to connect to PostgreSQL on port 5433.
  - Step 2: In `product-service`, create a `Product` entity (id, name, price, stock) and configure TypeORM to connect to PostgreSQL on port 5434.
  - Step 3: In `order-service`, create an `Order` entity (id, userId, productId, quantity, status, createdAt) and configure TypeORM to connect to PostgreSQL on port 5435. Note: store userId and productId as numbers only, do not create foreign keys since databases are separate.
  - Step 4: Each service implements basic CRUD: user-service has `GET /users`, `GET /users/:id`, `POST /users`; product-service has `GET /products`, `GET /products/:id`, `POST /products`; order-service has `GET /orders`, `POST /orders`.
- **Expected result:** Each service connects to its own PostgreSQL database, basic CRUD works independently.
- **Conclusion:** Database-per-service pattern has been applied, ensuring each service manages data independently.

## 2
### title
Set up HTTP communication between services
### body
- **Steps to follow:**
  - Step 1: In `order-service`, install HttpModule:
    ```bash
    npm install @nestjs/axios axios
    ```
  - Step 2: When `POST /orders` receives a request, order-service calls `GET http://user-service:3001/users/:userId` to verify user existence.
  - Step 3: Then calls `GET http://product-service:3002/products/:productId` to verify product existence and availability (stock > 0).
  - Step 4: If both are valid, create the order and return the result. Otherwise, return 404 with a specific message.
  - Step 5: Handle service unavailability: catch connection errors and return 503 Service Unavailable.
- **Expected result:** Order-service verifies data from 2 other services before creating an order, handles communication errors clearly.
- **Conclusion:** HTTP communication between microservices has been established with comprehensive error handling.

## 3
### title
Set up Docker Compose for the entire system
### body
- **Steps to follow:**
  - Step 1: Create a `Dockerfile` for each service using multi-stage build (build stage and production stage).
  - Step 2: Create a `docker-compose.yml` file at the root directory with 6 containers:
    - `user-db` (PostgreSQL, port 5433)
    - `product-db` (PostgreSQL, port 5434)
    - `order-db` (PostgreSQL, port 5435)
    - `user-service` (port 3001, depends_on user-db)
    - `product-service` (port 3002, depends_on product-db)
    - `order-service` (port 3000, depends_on order-db)
  - Step 3: Configure environment variables for each service to connect to its corresponding database via Docker network (use service name as hostname).
  - Step 4: Add health checks for database containers.
  - Step 5: Start the entire system:
    ```bash
    docker-compose up --build
    ```
- **Expected result:** All 6 containers start successfully, services communicate with each other through the internal Docker network.
- **Conclusion:** Docker Compose successfully orchestrates the entire microservices system with independent databases.

## 4
### title
Test and write bounded contexts documentation
### body
- **Steps to follow:**
  - Step 1: Start the system with Docker Compose:
    ```bash
    docker-compose up --build
    ```
  - Step 2: Create a user:
    ```bash
    curl -X POST http://localhost:3001/users -H "Content-Type: application/json" -d "{\"name\": \"Alice\", \"email\": \"alice@test.com\"}"
    ```
  - Step 3: Create a product:
    ```bash
    curl -X POST http://localhost:3002/products -H "Content-Type: application/json" -d "{\"name\": \"Laptop\", \"price\": 999, \"stock\": 10}"
    ```
  - Step 4: Create an order successfully:
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d "{\"userId\": 1, \"productId\": 1, \"quantity\": 1}"
    ```
  - Step 5: Test error cases (non-existing userId/productId, unavailable service).
  - Step 6: Write a Google Docs document including: bounded contexts diagram, reasons for splitting each service, communication pattern (synchronous HTTP), pros/cons of the approach, and potential issues (data consistency, network latency).
- **Expected result:**
  - The entire flow of create user -> create product -> create order works correctly.
  - Error cases return appropriate responses.
  - Documentation fully describes bounded contexts and design decisions.
- **Conclusion:** The microservices system has been proven to work end-to-end, design documentation helps readers understand the reasoning and approach for splitting services.

# references
## 0
### alias
Database per Service Pattern
### url
https://microservices.io/patterns/data/database-per-service.html
## 1
### alias
Docker Compose Documentation
### url
https://docs.docker.com/compose/
## 2
### alias
Bounded Context - Martin Fowler
### url
https://martinfowler.com/bliki/BoundedContext.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing source code for all 3 microservices, Dockerfile, and docker-compose.yml.
### score
20
### prompts
#### 0
##### title
3 microservices with independent databases
##### score
7
##### promptText
3 separate services (user-service, product-service, order-service) each with its own PostgreSQL database, entities and basic CRUD work correctly.
#### 1
##### title
Docker Compose orchestration
##### score
7
##### promptText
docker-compose.yml correctly configures 6 containers (3 app + 3 db), system starts with `docker-compose up --build` and services communicate with each other.
#### 2
##### title
HTTP communication and error handling
##### score
6
##### promptText
Order-service calls user-service and product-service via HTTP, correctly handles cases where user/product does not exist (404) and service is unavailable (503).
## 1
### type
googleDocsUrl
### title
Bounded Contexts Documentation
### description
Submit a Google Docs link describing bounded contexts, reasons for splitting services, and communication pattern.
### score
10
### prompts
#### 0
##### title
Bounded contexts description and design decisions
##### score
10
##### promptText
Document clearly describes 3 bounded contexts, reasons for splitting each service, chosen communication pattern (synchronous HTTP), and analysis of pros/cons of the architecture.

# difficulty
medium

# score
30
