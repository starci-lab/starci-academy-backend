# title
Deploy NestJS trên Cloud Kubernetes với NGINX Ingress và HTTPS

# description
Deploy ứng dụng NestJS lên Managed Kubernetes cluster trên cloud, cấu hình NGINX Ingress Controller để định tuyến traffic, và thiết lập Cert-Manager để tự động cấp chứng chỉ SSL/TLS cho HTTPS.

# requirements
Deploy ứng dụng NestJS lên cloud Kubernetes cluster (DigitalOcean, AWS hoặc GCP). Cài đặt **NGINX Ingress Controller** để định tuyến traffic từ bên ngoài vào cluster. Cài đặt **Cert-Manager** và cấu hình **Let's Encrypt ClusterIssuer** để tự động cấp chứng chỉ SSL. Tạo **Ingress resource** với TLS termination để ứng dụng có thể truy cập qua HTTPS. Nộp cả GitHub repository (source code + manifests) và Google Docs (tài liệu kiến trúc và quy trình).

# prerequisites
- Tài khoản cloud provider với Managed Kubernetes cluster đã tạo
- kubectl kết nối được đến cluster
- Helm CLI đã cài đặt
- Một domain name (có thể dùng miễn phí từ Freenom hoặc mua domain)
- Node.js >= 18 và NestJS CLI
- Hoàn thành challenge kubernetes-on-cloud-easy

# steps

## 0
### title
Chuẩn bị ứng dụng NestJS và push Docker image
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS:
    ```bash
    nest new kubernetes-on-cloud-medium
    cd kubernetes-on-cloud-medium
    ```
  - Bước 2: Tạo các endpoints:
    - `GET /` trả về `{ service: "kubernetes-on-cloud-medium", status: "running" }`.
    - `GET /health` trả về `{ status: "ok", timestamp: new Date().toISOString() }`.
    - `GET /info` trả về `{ hostname: os.hostname(), version: "1.0.0" }`.
  - Bước 3: Tạo Dockerfile với multi-stage build.
  - Bước 4: Build và push image lên container registry (Docker Hub, DigitalOcean Container Registry, AWS ECR hoặc GCP Artifact Registry):
    ```bash
    docker build -t <registry>/k8s-cloud-medium:v1 .
    docker push <registry>/k8s-cloud-medium:v1
    ```
- **Kết quả mong đợi:** Docker image đã được push lên container registry, sẵn sàng để Kubernetes pull.
- **Kết luận:** Ứng dụng đã sẵn sàng để deploy lên cloud Kubernetes cluster.

## 1
### title
Deploy ứng dụng và cài đặt NGINX Ingress Controller
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo Kubernetes manifests cho ứng dụng:
    - Deployment (2 replicas).
    - ClusterIP Service (port 80 -> targetPort 3000).
  - Bước 2: Apply manifests:
    ```bash
    kubectl apply -f deployment.yaml
    kubectl apply -f service.yaml
    ```
  - Bước 3: Cài đặt NGINX Ingress Controller bằng Helm:
    ```bash
    helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
    helm repo update
    helm install nginx-ingress ingress-nginx/ingress-nginx --set controller.publishService.enabled=true
    ```
  - Bước 4: Đợi Ingress Controller nhận External IP (LoadBalancer):
    ```bash
    kubectl get services -l app.kubernetes.io/name=ingress-nginx -w
    ```
  - Bước 5: Ghi lại External IP và trỏ domain/subdomain đến IP này (tạo A record trong DNS management).
- **Kết quả mong đợi:** Ứng dụng deploy thành công, NGINX Ingress Controller có External IP, domain đã trỏ đến IP.
- **Kết luận:** NGINX Ingress Controller làm điểm vào duy nhất cho traffic từ bên ngoài vào cluster.

## 2
### title
Cài đặt Cert-Manager và cấu hình Let's Encrypt
### body
- **Các bước thực hiện:**
  - Bước 1: Cài đặt Cert-Manager bằng Helm:
    ```bash
    helm repo add jetstack https://charts.jetstack.io
    helm repo update
    helm install cert-manager jetstack/cert-manager --namespace cert-manager --create-namespace --set crds.enabled=true
    ```
  - Bước 2: Kiểm tra Cert-Manager đã chạy:
    ```bash
    kubectl get pods -n cert-manager
    ```
  - Bước 3: Tạo ClusterIssuer cho Let's Encrypt (file `cluster-issuer.yaml`):
    ```yaml
    apiVersion: cert-manager.io/v1
    kind: ClusterIssuer
    metadata:
      name: letsencrypt-prod
    spec:
      acme:
        server: https://acme-v02.api.letsencrypt.org/directory
        email: your-email@example.com
        privateKeySecretRef:
          name: letsencrypt-prod-key
        solvers:
          - http01:
              ingress:
                class: nginx
    ```
  - Bước 4: Apply ClusterIssuer:
    ```bash
    kubectl apply -f cluster-issuer.yaml
    ```
- **Kết quả mong đợi:** Cert-Manager đang chạy, ClusterIssuer `letsencrypt-prod` đã tạo thành công.
- **Kết luận:** Cert-Manager sẵn sàng tự động cấp và gia hạn chứng chỉ SSL từ Let's Encrypt.

## 3
### title
Tạo Ingress resource với TLS và kiểm thử HTTPS
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `ingress.yaml`:
    ```yaml
    apiVersion: networking.k8s.io/v1
    kind: Ingress
    metadata:
      name: nestjs-ingress
      annotations:
        cert-manager.io/cluster-issuer: "letsencrypt-prod"
        nginx.ingress.kubernetes.io/ssl-redirect: "true"
    spec:
      ingressClassName: nginx
      tls:
        - hosts:
            - your-domain.com
          secretName: nestjs-tls-secret
      rules:
        - host: your-domain.com
          http:
            paths:
              - path: /
                pathType: Prefix
                backend:
                  service:
                    name: nestjs-service
                    port:
                      number: 80
    ```
  - Bước 2: Apply Ingress:
    ```bash
    kubectl apply -f ingress.yaml
    ```
  - Bước 3: Kiểm tra Certificate được tạo và cấp phát:
    ```bash
    kubectl get certificate
    kubectl describe certificate nestjs-tls-secret
    ```
  - Bước 4: Đợi certificate ở trạng thái `Ready: True` (có thể mất vài phút).
  - Bước 5: Truy cập ứng dụng qua HTTPS:
    ```bash
    curl https://your-domain.com
    curl https://your-domain.com/health
    curl https://your-domain.com/info
    ```
  - Bước 6: Xác nhận HTTP tự động redirect sang HTTPS:
    ```bash
    curl -I http://your-domain.com
    ```
    Xác nhận trả về 308 redirect đến HTTPS.
  - Bước 7: Kiểm tra chứng chỉ SSL trong trình duyệt: truy cập domain và xác nhận có biểu tượng khóa, chứng chỉ do Let's Encrypt cấp.
- **Kết quả mong đợi:**
  - HTTPS hoạt động với chứng chỉ Let's Encrypt hợp lệ.
  - HTTP redirect tự động sang HTTPS.
  - Tất cả endpoints truy cập được qua HTTPS.
- **Kết luận:** Ứng dụng đã được deploy an toàn với HTTPS trên cloud Kubernetes, sử dụng NGINX Ingress và Cert-Manager.

## 4
### title
Viết tài liệu kiến trúc và quy trình
### body
- **Các bước thực hiện:**
  - Bước 1: Vẽ sơ đồ kiến trúc tổng quát: Client -> DNS -> LoadBalancer -> NGINX Ingress -> Service -> Deployment (Pods).
  - Bước 2: Mô tả vai trò của từng thành phần: Ingress Controller, Cert-Manager, ClusterIssuer, Certificate, Ingress resource.
  - Bước 3: Ghi lại toàn bộ quy trình triển khai theo thứ tự.
  - Bước 4: Mô tả cách Cert-Manager tự động gia hạn chứng chỉ.
  - Bước 5: Thêm phần troubleshooting: các lỗi thường gặp và cách xử lý (certificate không cấp được, DNS chưa trỏ đúng, Ingress không hoạt động).
- **Kết quả mong đợi:** Tài liệu Google Docs hoàn chỉnh với sơ đồ kiến trúc, quy trình triển khai và troubleshooting guide.
- **Kết luận:** Tài liệu giúp team hiểu rõ kiến trúc và có thể tái triển khai hệ thống bất cứ lúc nào.

# references
## 0
### alias
NGINX Ingress Controller
### url
https://kubernetes.github.io/ingress-nginx/
## 1
### alias
Cert-Manager Documentation
### url
https://cert-manager.io/docs/
## 2
### alias
Let's Encrypt Getting Started
### url
https://letsencrypt.org/getting-started/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code NestJS, Dockerfile và tất cả Kubernetes manifests (deployment, service, ingress, cluster-issuer).
### score
18
### prompts
#### 0
##### title
Deployment và NGINX Ingress đúng cấu hình
##### score
6
##### promptText
NestJS Deployment có 2 replicas và ClusterIP Service. NGINX Ingress Controller được cài đặt, Ingress resource định tuyến traffic đúng đến Service.
#### 1
##### title
Cert-Manager và HTTPS hoạt động
##### score
6
##### promptText
Cert-Manager được cài đặt, ClusterIssuer cấu hình Let's Encrypt, Certificate được cấp thành công, HTTPS hoạt động với chứng chỉ hợp lệ.
#### 2
##### title
HTTP redirect và endpoints hoạt động
##### score
6
##### promptText
HTTP tự động redirect sang HTTPS (308). Tất cả endpoints (`/`, `/health`, `/info`) truy cập được qua HTTPS và trả response đúng.
## 1
### type
googleDocsUrl
### title
Tài liệu kiến trúc và quy trình triển khai
### description
Nộp link Google Docs mô tả kiến trúc hệ thống, quy trình triển khai và troubleshooting guide.
### score
12
### prompts
#### 0
##### title
Sơ đồ kiến trúc và mô tả thành phần
##### score
6
##### promptText
Tài liệu có sơ đồ kiến trúc tổng quát (Client -> DNS -> LB -> Ingress -> Service -> Pods), mô tả rõ vai trò của từng thành phần.
#### 1
##### title
Quy trình triển khai và troubleshooting
##### score
6
##### promptText
Ghi lại đầy đủ quy trình triển khai theo thứ tự, có phần troubleshooting các lỗi thường gặp và cách xử lý.

# difficulty
medium

# score
30
