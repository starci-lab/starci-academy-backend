# title
Deploy PostgreSQL HA và Redis Cluster bằng Bitnami Helm Charts

# description
Sử dụng Bitnami Helm Charts để deploy một PostgreSQL High Availability cluster và một Redis cluster trên Minikube, tùy chỉnh cấu hình qua file values.yaml riêng cho từng chart.

# requirements
Deploy 2 hệ thống trên Minikube bằng Bitnami Helm Charts: **PostgreSQL HA** (sử dụng chart `bitnami/postgresql-ha` với 1 primary + 1 replica) và **Redis Cluster** (sử dụng chart `bitnami/redis` với 1 master + 2 replicas). Mỗi chart phải có file `values.yaml` riêng để tùy chỉnh cấu hình. Kiểm tra replication hoạt động, kết nối NestJS đến cả hai hệ thống.

# prerequisites
- Docker Desktop
- Minikube và kubectl đã cài đặt (khởi động với ít nhất 4GB RAM và 2 CPUs)
- Helm CLI
- NestJS CLI và Node.js >= 18
- Hoàn thành challenge complex-applications-and-helm-charts-easy

# steps

## 0
### title
Chuẩn bị Minikube và Helm
### body
- **Các bước thực hiện:**
  - Bước 1: Khởi động Minikube với tài nguyên đủ:
    ```bash
    minikube start --cpus=2 --memory=4096
    ```
  - Bước 2: Xác nhận Helm và Bitnami repo đã sẵn sàng:
    ```bash
    helm version
    helm repo update
    ```
  - Bước 3: Tìm kiếm các chart cần sử dụng:
    ```bash
    helm search repo bitnami/postgresql-ha
    helm search repo bitnami/redis
    ```
- **Kết quả mong đợi:** Minikube khởi động với đủ tài nguyên, Helm charts sẵn sàng để cài đặt.
- **Kết luận:** Môi trường đã đủ điều kiện để deploy các hệ thống HA.

## 1
### title
Deploy PostgreSQL HA với custom values
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `postgresql-ha-values.yaml`:
    ```yaml
    postgresql:
      replicaCount: 2
      password: "hapassword123"
      database: "hadb"
    pgpool:
      adminPassword: "pgpooladmin123"
    persistence:
      size: 1Gi
    ```
  - Bước 2: Cài đặt chart:
    ```bash
    helm install my-pg-ha bitnami/postgresql-ha -f postgresql-ha-values.yaml
    ```
  - Bước 3: Đợi các Pods sẵn sàng:
    ```bash
    kubectl get pods -l app.kubernetes.io/instance=my-pg-ha -w
    ```
  - Bước 4: Kiểm tra có primary và replica Pods:
    ```bash
    kubectl get pods -l app.kubernetes.io/instance=my-pg-ha
    ```
  - Bước 5: Kiểm tra Services được tạo:
    ```bash
    kubectl get services -l app.kubernetes.io/instance=my-pg-ha
    ```
- **Kết quả mong đợi:** PostgreSQL HA cluster khởi động với Pgpool, primary và replica Pods đều Running, Services (pgpool, postgresql) được tạo.
- **Kết luận:** PostgreSQL HA đã được deploy thành công với replication thông qua Helm chart.

## 2
### title
Deploy Redis cluster với custom values
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `redis-values.yaml`:
    ```yaml
    architecture: replication
    auth:
      password: "redispassword123"
    master:
      persistence:
        size: 512Mi
    replica:
      replicaCount: 2
      persistence:
        size: 512Mi
    ```
  - Bước 2: Cài đặt chart:
    ```bash
    helm install my-redis bitnami/redis -f redis-values.yaml
    ```
  - Bước 3: Đợi các Pods sẵn sàng:
    ```bash
    kubectl get pods -l app.kubernetes.io/instance=my-redis -w
    ```
  - Bước 4: Kiểm tra master và replica Pods:
    ```bash
    kubectl get pods -l app.kubernetes.io/instance=my-redis
    ```
  - Bước 5: Kiểm tra Redis Services:
    ```bash
    kubectl get services -l app.kubernetes.io/instance=my-redis
    ```
- **Kết quả mong đợi:** Redis cluster với 1 master và 2 replicas đều Running, Services (master, replicas) được tạo.
- **Kết luận:** Redis replication đã được deploy thành công qua Helm chart.

## 3
### title
Kiểm tra replication và kết nối từ ứng dụng
### body
- **Các bước thực hiện:**
  - Bước 1: Kiểm tra PostgreSQL replication bằng cách kết nối qua Pgpool:
    ```bash
    kubectl port-forward service/my-pg-ha-pgpool 5432:5432
    ```
    Kết nối và tạo bảng test, xác nhận dữ liệu có thể đọc được.
  - Bước 2: Kiểm tra Redis replication:
    ```bash
    kubectl exec -it my-redis-master-0 -- redis-cli -a redispassword123 INFO replication
    ```
    Xác nhận `connected_slaves:2`.
  - Bước 3: Set giá trị trên master và đọc từ replica:
    ```bash
    kubectl exec -it my-redis-master-0 -- redis-cli -a redispassword123 SET testkey "hello-ha"
    kubectl exec -it my-redis-replicas-0 -- redis-cli -a redispassword123 GET testkey
    ```
  - Bước 4: Tạo project NestJS đơn giản kết nối đến cả PostgreSQL (qua Pgpool Service) và Redis (qua master Service), tạo Dockerfile và build image trong Minikube.
  - Bước 5: Deploy NestJS lên Minikube với environment variables trỏ đến các Helm Services, port-forward và gọi endpoint để xác nhận kết nối.
  - Bước 6: Dọn dẹp:
    ```bash
    helm uninstall my-pg-ha
    helm uninstall my-redis
    ```
- **Kết quả mong đợi:**
  - PostgreSQL HA replication hoạt động, dữ liệu nhất quán giữa primary và replica.
  - Redis replication hoạt động, dữ liệu replicate từ master sang replicas.
  - NestJS kết nối thành công đến cả hai hệ thống qua Kubernetes Services.
- **Kết luận:** Bitnami Helm Charts cho phép deploy các hệ thống HA phức tạp chỉ với file values.yaml tùy chỉnh, tiết kiệm thời gian và đảm bảo cấu hình chuẩn.

# references
## 0
### alias
Bitnami PostgreSQL HA Helm Chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/postgresql-ha
## 1
### alias
Bitnami Redis Helm Chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/redis
## 2
### alias
Helm Values Files
### url
https://helm.sh/docs/chart_template_guide/values_files/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa các file values.yaml, source code NestJS kết nối đến PostgreSQL HA và Redis, và README ghi lại các bước thực hiện.
### score
30
### prompts
#### 0
##### title
PostgreSQL HA deploy và replication đúng
##### score
10
##### promptText
Chart `bitnami/postgresql-ha` được install với custom values, có primary + replica Pods, Pgpool Service hoạt động, replication đã được xác nhận.
#### 1
##### title
Redis cluster deploy và replication đúng
##### score
10
##### promptText
Chart `bitnami/redis` được install với architecture replication, có 1 master và 2 replicas, dữ liệu replicate thành công từ master sang replicas.
#### 2
##### title
NestJS kết nối thành công đến cả hai hệ thống
##### score
10
##### promptText
NestJS kết nối đến PostgreSQL qua Pgpool Service và Redis qua master Service, endpoints hoạt động đúng trên Minikube.

# difficulty
medium

# score
30
