# title
Deploy NestJS and PostgreSQL on Minikube with ConfigMap and Secret

# description
Deploy multiple Pods on Minikube consisting of a NestJS application and a PostgreSQL database, use ConfigMap and Secret to manage configuration and sensitive information, ensuring the application connects to the database successfully.

# requirements
Create YAML manifests to deploy 2 Pods on Minikube: **nestjs-app** (NestJS application with TypeORM) and **postgres-db** (PostgreSQL 15). Use **ConfigMap** to store non-sensitive configuration (DB_HOST, DB_PORT, DB_NAME) and **Secret** to store sensitive information (DB_USERNAME, DB_PASSWORD). The NestJS application reads environment variables from ConfigMap/Secret and connects to PostgreSQL. Create endpoint `GET /health/db` to check database connectivity.

# prerequisites
- Node.js >= 18
- Docker Desktop
- Minikube and kubectl installed
- NestJS CLI
- Basic knowledge of PostgreSQL and TypeORM
- Completed challenge introduction-to-kubernetes-easy

# steps

## 0
### title
Create a NestJS application with TypeORM and build Docker image
### body
- **Steps to follow:**
  - Step 1: Create a new NestJS project:
    ```bash
    nest new introduction-to-kubernetes-medium
    cd introduction-to-kubernetes-medium
    ```
  - Step 2: Install TypeORM and PostgreSQL driver:
    ```bash
    npm install @nestjs/typeorm typeorm pg @nestjs/config
    ```
  - Step 3: Create a `Task` entity (id, title, completed, createdAt) and `TaskModule` with basic CRUD (`GET /tasks`, `POST /tasks`).
  - Step 4: Configure TypeORM in `AppModule` to read from environment variables: `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USERNAME`, `DB_PASSWORD`.
  - Step 5: Create endpoint `GET /health/db` that checks database connectivity by running a simple query (`SELECT 1`), returns `{ status: "connected" }` or `{ status: "disconnected", error: "..." }`.
  - Step 6: Create Dockerfile and build image:
    ```bash
    eval $(minikube docker-env)
    docker build -t intro-k8s-medium:latest .
    ```
- **Expected result:** Docker image `intro-k8s-medium:latest` is built successfully, application reads configuration from environment variables.
- **Conclusion:** Application is ready to deploy on Kubernetes with flexible configuration via environment variables.

## 1
### title
Create ConfigMap and Secret
### body
- **Steps to follow:**
  - Step 1: Create file `configmap.yaml`:
    ```yaml
    apiVersion: v1
    kind: ConfigMap
    metadata:
      name: app-config
    data:
      DB_HOST: "postgres-db"
      DB_PORT: "5432"
      DB_NAME: "taskdb"
    ```
  - Step 2: Create file `secret.yaml`:
    ```yaml
    apiVersion: v1
    kind: Secret
    metadata:
      name: db-secret
    type: Opaque
    stringData:
      DB_USERNAME: "postgres"
      DB_PASSWORD: "secretpassword123"
    ```
  - Step 3: Apply ConfigMap and Secret:
    ```bash
    kubectl apply -f configmap.yaml
    kubectl apply -f secret.yaml
    ```
  - Step 4: Verify ConfigMap and Secret are created:
    ```bash
    kubectl get configmap app-config
    kubectl get secret db-secret
    ```
- **Expected result:** ConfigMap `app-config` and Secret `db-secret` are created successfully on the cluster.
- **Conclusion:** Configuration and sensitive information have been separated into Kubernetes resources, ready to mount into Pods.

## 2
### title
Create YAML manifests for PostgreSQL Pod and NestJS Pod
### body
- **Steps to follow:**
  - Step 1: Create file `postgres-pod.yaml` to deploy PostgreSQL 15, using environment variables from Secret:
    ```yaml
    apiVersion: v1
    kind: Pod
    metadata:
      name: postgres-db
      labels:
        app: postgres-db
    spec:
      containers:
        - name: postgres
          image: postgres:15-alpine
          ports:
            - containerPort: 5432
          env:
            - name: POSTGRES_USER
              valueFrom:
                secretKeyRef:
                  name: db-secret
                  key: DB_USERNAME
            - name: POSTGRES_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: db-secret
                  key: DB_PASSWORD
            - name: POSTGRES_DB
              valueFrom:
                configMapKeyRef:
                  name: app-config
                  key: DB_NAME
    ```
  - Step 2: Create file `nestjs-pod.yaml` to deploy the NestJS application, referencing ConfigMap and Secret:
    ```yaml
    apiVersion: v1
    kind: Pod
    metadata:
      name: nestjs-app
      labels:
        app: nestjs-app
    spec:
      containers:
        - name: nestjs-app
          image: intro-k8s-medium:latest
          imagePullPolicy: Never
          ports:
            - containerPort: 3000
          envFrom:
            - configMapRef:
                name: app-config
            - secretRef:
                name: db-secret
    ```
  - Step 3: Apply the PostgreSQL Pod first:
    ```bash
    kubectl apply -f postgres-pod.yaml
    ```
  - Step 4: Wait for PostgreSQL to be ready, then apply the NestJS Pod:
    ```bash
    kubectl wait --for=condition=Ready pod/postgres-db --timeout=60s
    kubectl apply -f nestjs-pod.yaml
    ```
- **Expected result:** Both Pods are in `Running` state, NestJS Pod reads configuration from ConfigMap and Secret.
- **Conclusion:** Two Pods have been deployed with configuration managed centrally via ConfigMap and Secret.

## 3
### title
Test connectivity and CRUD
### body
- **Steps to follow:**
  - Step 1: Port-forward to the NestJS Pod:
    ```bash
    kubectl port-forward pod/nestjs-app 3000:3000
    ```
  - Step 2: Check database connectivity:
    ```bash
    curl http://localhost:3000/health/db
    ```
    Confirm it returns `{ status: "connected" }`.
  - Step 3: Create a new task:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\": \"Learn Kubernetes\", \"completed\": false}"
    ```
  - Step 4: Get task list:
    ```bash
    curl http://localhost:3000/tasks
    ```
    Confirm the newly created task appears in the list.
  - Step 5: View logs of both Pods:
    ```bash
    kubectl logs nestjs-app
    kubectl logs postgres-db
    ```
  - Step 6: Clean up resources:
    ```bash
    kubectl delete pod nestjs-app postgres-db
    kubectl delete configmap app-config
    kubectl delete secret db-secret
    ```
- **Expected result:**
  - Database health check returns `connected`.
  - CRUD operations work correctly, data is stored in PostgreSQL.
  - Logs of both Pods show no errors.
- **Conclusion:** The NestJS + PostgreSQL system works correctly on Minikube, ConfigMap and Secret are used to manage configuration securely.

# references
## 0
### alias
Kubernetes ConfigMaps
### url
https://kubernetes.io/docs/concepts/configuration/configmap/
## 1
### alias
Kubernetes Secrets
### url
https://kubernetes.io/docs/concepts/configuration/secret/
## 2
### alias
TypeORM NestJS Integration
### url
https://docs.nestjs.com/techniques/database

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing NestJS source code, Dockerfile, and all YAML manifest files (configmap, secret, pods).
### score
30
### prompts
#### 0
##### title
ConfigMap and Secret configured correctly
##### score
10
##### promptText
ConfigMap contains non-sensitive variables (DB_HOST, DB_PORT, DB_NAME), Secret contains sensitive information (DB_USERNAME, DB_PASSWORD), both are correctly referenced in Pod manifests.
#### 1
##### title
Both Pods deployed and connected successfully
##### score
10
##### promptText
PostgreSQL Pod and NestJS Pod both run successfully on Minikube, NestJS connects to PostgreSQL through configuration from ConfigMap/Secret.
#### 2
##### title
Health check and CRUD work
##### score
10
##### promptText
Endpoint `GET /health/db` returns database connection status, CRUD tasks (`GET /tasks`, `POST /tasks`) work correctly with data stored in PostgreSQL.

# difficulty
medium

# score
30
