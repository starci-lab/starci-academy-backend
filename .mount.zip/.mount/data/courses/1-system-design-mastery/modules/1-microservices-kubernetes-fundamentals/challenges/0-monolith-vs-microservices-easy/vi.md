# title
Xây dựng Monolith NestJS và Tách thành Microservices

# description
Xây dựng một ứng dụng NestJS monolith đơn giản cho hệ thống e-commerce với 3 module (User, Product, Order) trong cùng một app, sau đó tách thành 2 microservices độc lập giao tiếp qua HTTP.

# requirements
Tạo project NestJS monolith với `UserModule`, `ProductModule`, `OrderModule`. Mỗi module có controller và service riêng. Endpoint `GET /users` trả danh sách user, `GET /products` trả danh sách product, `POST /orders` tạo order mới (tham chiếu userId và productId). Sau đó tách thành 2 service riêng biệt: **user-service** (quản lý User) và **order-service** (quản lý Product + Order), trong đó order-service gọi sang user-service qua HTTP để xác minh user tồn tại trước khi tạo order.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install
- Hiểu biết cơ bản về REST API

# steps

## 0
### title
Khởi tạo project monolith
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới:
    ```bash
    nest new monolith-vs-microservices-easy
    ```
  - Bước 2: Di chuyển vào thư mục project:
    ```bash
    cd monolith-vs-microservices-easy
    ```
  - Bước 3: Chạy thử ứng dụng:
    ```bash
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng khởi động thành công trên cổng 3000, terminal hiển thị log NestJS sẵn sàng nhận request.
- **Kết luận:** Môi trường nền đã sẵn sàng để xây dựng các module nghiệp vụ.

## 1
### title
Xây dựng UserModule, ProductModule và OrderModule trong monolith
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `UserModule`, `UserService`, `UserController`. Trong `UserService`, khởi tạo mảng dữ liệu mẫu gồm ít nhất 3 user với `id` và `name`. Cài đặt `findAll()` và `findById(id)`.
  - Bước 2: Tạo `ProductModule`, `ProductService`, `ProductController`. Trong `ProductService`, khởi tạo mảng dữ liệu mẫu gồm ít nhất 3 product với `id`, `name`, `price`. Cài đặt `findAll()` và `findById(id)`.
  - Bước 3: Tạo `OrderModule`, `OrderService`, `OrderController`. Trong `OrderService`, cài đặt `createOrder(userId, productId)` kiểm tra user và product tồn tại (gọi trực tiếp service trong cùng app), tạo order mới với `id`, `userId`, `productId`, `createdAt`.
  - Bước 4: Trong `OrderModule`, import `UserModule` và `ProductModule`. Đảm bảo `UserService` và `ProductService` được export để `OrderService` có thể inject.
  - Bước 5: Tạo endpoint `GET /users`, `GET /products`, `POST /orders` tương ứng.
- **Kết quả mong đợi:** Gọi `GET /users` trả mảng user, `GET /products` trả mảng product, `POST /orders` với body `{ userId, productId }` tạo order thành công hoặc trả lời 404 nếu user/product không tồn tại.
- **Kết luận:** Monolith hoạt động đúng với tất cả module trong cùng một ứng dụng, giao tiếp nội bộ qua DI.

## 2
### title
Tách thành 2 microservices độc lập
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project thứ hai cho **user-service**:
    ```bash
    nest new user-service
    ```
  - Bước 2: Chuyển `UserModule`, `UserService`, `UserController` sang project `user-service`. Cấu hình chạy trên cổng 3001.
  - Bước 3: Trong project gốc (đổi tên thành **order-service**), xóa `UserModule`. Giữ lại `ProductModule` và `OrderModule`.
  - Bước 4: Trong `OrderService` của order-service, thay thế việc inject `UserService` bằng việc gọi HTTP đến `http://localhost:3001/users/:id` để kiểm tra user tồn tại. Sử dụng `HttpModule` của NestJS (`@nestjs/axios`).
  - Bước 5: Cài đặt `@nestjs/axios` trong order-service:
    ```bash
    npm install @nestjs/axios axios
    ```
  - Bước 6: Cấu hình order-service chạy trên cổng 3000.
- **Kết quả mong đợi:** Hai service chạy độc lập trên 2 cổng khác nhau. Order-service gọi HTTP sang user-service để xác minh user trước khi tạo order.
- **Kết luận:** Hệ thống đã được tách từ monolith sang 2 microservices giao tiếp qua HTTP, mỗi service có thể deploy độc lập.

## 3
### title
Kiểm thử toàn bộ hệ thống microservices
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy user-service:
    ```bash
    cd user-service
    npm run start:dev
    ```
  - Bước 2: Chạy order-service (terminal khác):
    ```bash
    cd order-service
    npm run start:dev
    ```
  - Bước 3: Kiểm tra user-service hoạt động:
    ```bash
    curl http://localhost:3001/users
    ```
  - Bước 4: Tạo order thành công (userId tồn tại):
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d "{\"userId\": 1, \"productId\": 1}"
    ```
  - Bước 5: Tạo order với userId không tồn tại:
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d "{\"userId\": 999, \"productId\": 1}"
    ```
    Xác nhận trả lời 404.
  - Bước 6: Tắt user-service và thử tạo order, xác nhận order-service xử lý lỗi kết nối phù hợp (trả 500 hoặc 503).
- **Kết quả mong đợi:**
  - `GET /users` (cổng 3001) trả danh sách user.
  - `POST /orders` (cổng 3000) với userId hợp lệ tạo order thành công.
  - `POST /orders` với userId không tồn tại trả 404.
  - Khi user-service không chạy, order-service trả lời lỗi rõ ràng.
- **Kết luận:** Hệ thống microservices hoạt động đúng, giao tiếp HTTP giữa các service đã được chứng minh.

# references
## 0
### alias
NestJS HTTP Module
### url
https://docs.nestjs.com/techniques/http-module
## 1
### alias
NestJS Microservices Overview
### url
https://docs.nestjs.com/microservices/basics
## 2
### alias
Monolith vs Microservices - Martin Fowler
### url
https://martinfowler.com/articles/microservices.html

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn, bao gồm cả monolith ban đầu và 2 microservices sau khi tách.
### score
20
### prompts
#### 0
##### title
Monolith hoạt động đúng
##### score
7
##### promptText
Monolith có đủ 3 module (User, Product, Order), các endpoint `GET /users`, `GET /products`, `POST /orders` hoạt động đúng, OrderService kiểm tra user/product tồn tại trước khi tạo order.
#### 1
##### title
Tách microservices và giao tiếp HTTP
##### score
7
##### promptText
Hệ thống được tách thành 2 project riêng biệt (user-service và order-service), order-service gọi HTTP sang user-service để xác minh user, mỗi service chạy trên port riêng.
#### 2
##### title
Xử lý lỗi giao tiếp
##### score
6
##### promptText
Order-service xử lý đúng trường hợp user không tồn tại (404) và trường hợp user-service không khả dụng (500/503), trả response lỗi rõ ràng.

# difficulty
easy

# score
20
