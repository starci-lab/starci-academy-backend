# title
Document the Process of Setting Up Managed Kubernetes on Cloud

# description
Research and write detailed documentation about the process of setting up a Managed Kubernetes cluster on a cloud provider (DigitalOcean, AWS EKS, or GCP GKE), including Node Pool configuration and kubectl connection from the local machine.

# requirements
Write a Google Docs document describing the complete process of setting up a Managed Kubernetes cluster on a cloud provider of choice. The document must include: comparison of managed K8s offerings (DigitalOcean DOKS, AWS EKS, GCP GKE), step-by-step guide to create a cluster with screenshots or detailed descriptions, Node Pool configuration (number of nodes, machine specs, auto-scaling), how to download kubeconfig and connect kubectl from the local machine, and cluster verification.

# prerequisites
- Account on a cloud provider (DigitalOcean, AWS, or GCP)
- kubectl installed on local machine
- Basic knowledge of Kubernetes from previous challenges

# steps

## 0
### title
Research and compare Managed Kubernetes offerings
### body
- **Steps to follow:**
  - Step 1: Research 3 popular Managed Kubernetes services:
    - **DigitalOcean Kubernetes (DOKS)**: pricing, limits, features.
    - **AWS Elastic Kubernetes Service (EKS)**: pricing, features, complexity.
    - **Google Kubernetes Engine (GKE)**: pricing, features, free tier.
  - Step 2: Compare based on criteria: control plane cost, worker node cost, ease of use, ecosystem integration, auto-scaling support.
  - Step 3: Choose one provider for the following steps and explain the reasoning.
- **Expected result:** A comparison table of 3 providers with clear criteria, with a conclusion on the chosen provider and reasoning.
- **Conclusion:** Understanding the differences between managed K8s offerings enables making appropriate decisions.

## 1
### title
Document the cluster creation process
### body
- **Steps to follow:**
  - Step 1: Log in to the cloud provider console/dashboard.
  - Step 2: Describe in detail each step of creating a cluster:
    - Name the cluster.
    - Select region/datacenter.
    - Select Kubernetes version.
    - Configure Node Pool: number of nodes (start with 2 nodes), machine specs (2 vCPU, 4GB RAM), auto-scaling (min 2, max 5 if supported).
  - Step 3: Take screenshots or provide detailed descriptions of the interface at each step.
  - Step 4: Record the cluster creation time (typically 5-10 minutes).
  - Step 5: Describe advanced options (if available): VPC, network policy, monitoring.
- **Expected result:** Documentation has clear step-by-step instructions that anyone can follow to create a cluster.
- **Conclusion:** The cluster creation process has been fully documented and can be reused for other projects.

## 2
### title
Document kubectl connection and cluster verification
### body
- **Steps to follow:**
  - Step 1: Describe how to download kubeconfig from the cloud provider:
    - DigitalOcean: `doctl kubernetes cluster kubeconfig save <cluster-name>`
    - AWS EKS: `aws eks update-kubeconfig --name <cluster-name> --region <region>`
    - GCP GKE: `gcloud container clusters get-credentials <cluster-name> --zone <zone>`
  - Step 2: Describe how to install the provider's CLI tool (doctl, aws-cli, gcloud).
  - Step 3: Confirm connection from local machine:
    ```bash
    kubectl cluster-info
    kubectl get nodes
    ```
  - Step 4: Describe expected output: cluster endpoint information, list of nodes with Ready status, Kubernetes version.
  - Step 5: Deploy a test Pod to confirm the cluster works:
    ```bash
    kubectl run test-nginx --image=nginx --port=80
    kubectl get pods
    kubectl delete pod test-nginx
    ```
- **Expected result:** Documentation fully describes the process from downloading kubeconfig to confirming cluster operation.
- **Conclusion:** Readers can follow the documentation to connect to and use a Managed Kubernetes cluster from their local machine.

## 3
### title
Compile documentation and cost analysis
### body
- **Steps to follow:**
  - Step 1: Compile the document into a complete Google Docs with clear structure: Introduction, Provider Comparison, Cluster Creation Guide, kubectl Connection, Operation Verification.
  - Step 2: Add a cost analysis section with estimated costs for the chosen cluster configuration (monthly cost for control plane + worker nodes).
  - Step 3: Add a recommendations section: when to use managed K8s vs self-managed, how to optimize costs (spot instances, auto-scaling).
  - Step 4: Review the entire document for accuracy and completeness.
- **Expected result:** Complete, professional document that can be used as a reference for the team.
- **Conclusion:** The Managed Kubernetes setup documentation is a valuable asset for the team, helping standardize processes and reduce onboarding time.

# references
## 0
### alias
DigitalOcean Kubernetes Documentation
### url
https://docs.digitalocean.com/products/kubernetes/
## 1
### alias
AWS EKS Documentation
### url
https://docs.aws.amazon.com/eks/latest/userguide/what-is-eks.html
## 2
### alias
Google Kubernetes Engine Documentation
### url
https://cloud.google.com/kubernetes-engine/docs

# submissions
## 0
### type
googleDocsUrl
### title
Managed Kubernetes Setup Documentation
### description
Submit a Google Docs link containing detailed documentation about the process of setting up a Managed Kubernetes cluster on cloud.
### score
20
### prompts
#### 0
##### title
Provider comparison and cluster creation guide
##### score
10
##### promptText
Document has a comparison table of at least 3 managed K8s providers with clear criteria. Cluster creation guide is detailed step-by-step, with Node Pool configuration description (number of nodes, specs, auto-scaling).
#### 1
##### title
kubectl connection and cost analysis
##### score
10
##### promptText
Fully describes how to download kubeconfig and connect kubectl from local machine, with commands to verify cluster operation. Includes estimated cost analysis section and usage recommendations.

# difficulty
easy

# score
20
