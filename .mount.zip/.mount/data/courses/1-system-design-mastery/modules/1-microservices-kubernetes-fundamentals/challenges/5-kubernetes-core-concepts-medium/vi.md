# title
Deploy Backend + MySQL + Redis trên Minikube với Deployments và Services

# description
Triển khai hệ thống đầy đủ gồm NestJS backend, MySQL database và Redis cache trên Minikube sử dụng Deployments và Services, các thành phần giao tiếp với nhau qua DNS nội bộ của Kubernetes.

# requirements
Deploy 3 thành phần trên Minikube: **NestJS backend** (Deployment 2 replicas + ClusterIP Service), **MySQL 8** (Deployment 1 replica + ClusterIP Service), **Redis 7** (Deployment 1 replica + ClusterIP Service). NestJS kết nối đến MySQL qua TypeORM và đến Redis qua `ioredis`. Các service giao tiếp qua DNS nội bộ Kubernetes (ví dụ: `mysql-service`, `redis-service`). Triển khai caching pattern: `GET /products` đọc từ Redis cache trước, nếu cache miss thì đọc từ MySQL và lưu vào Redis.

# prerequisites
- Node.js >= 18
- Docker Desktop
- Minikube và kubectl đã cài đặt
- NestJS CLI
- Kiến thức cơ bản về MySQL, Redis và TypeORM
- Hoàn thành challenge kubernetes-core-concepts-easy

# steps

## 0
### title
Tạo ứng dụng NestJS với MySQL và Redis
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS mới:
    ```bash
    nest new kubernetes-core-concepts-medium
    cd kubernetes-core-concepts-medium
    ```
  - Bước 2: Cài đặt dependencies:
    ```bash
    npm install @nestjs/typeorm typeorm mysql2 @nestjs/config ioredis
    ```
  - Bước 3: Tạo entity `Product` (id, name, price, description, createdAt) và `ProductModule` với CRUD: `GET /products`, `GET /products/:id`, `POST /products`.
  - Bước 4: Cấu hình TypeORM đọc từ biến môi trường: `MYSQL_HOST`, `MYSQL_PORT`, `MYSQL_DATABASE`, `MYSQL_USER`, `MYSQL_PASSWORD`.
  - Bước 5: Tạo `RedisService` wrapper kết nối Redis đọc từ biến môi trường `REDIS_HOST`, `REDIS_PORT`. Implement `get(key)`, `set(key, value, ttl)`, `del(key)`.
  - Bước 6: Trong `ProductService`, triển khai caching pattern cho `GET /products`:
    - Kiểm tra Redis cache với key `products:all`.
    - Nếu có cache, trả về từ Redis.
    - Nếu không, đọc từ MySQL, lưu vào Redis với TTL 60 giây, rồi trả về.
  - Bước 7: Khi `POST /products`, xóa cache key `products:all` để đảm bảo dữ liệu mới nhất.
  - Bước 8: Tạo Dockerfile và build image:
    ```bash
    eval $(minikube docker-env)
    docker build -t k8s-core-medium:latest .
    ```
- **Kết quả mong đợi:** Docker image được build thành công, ứng dụng đọc cấu hình MySQL và Redis từ biến môi trường.
- **Kết luận:** Ứng dụng NestJS đã tích hợp MySQL và Redis, sẵn sàng deploy lên Kubernetes.

## 1
### title
Tạo Kubernetes manifests cho MySQL và Redis
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `mysql-deployment.yaml` với Deployment (1 replica, image `mysql:8.0`, environment variables cho root password và database name) và ClusterIP Service (port 3306).
  - Bước 2: Tạo file `redis-deployment.yaml` với Deployment (1 replica, image `redis:7-alpine`) và ClusterIP Service (port 6379).
  - Bước 3: Tạo ConfigMap và Secret cho cấu hình:
    ```yaml
    apiVersion: v1
    kind: ConfigMap
    metadata:
      name: app-config
    data:
      MYSQL_HOST: "mysql-service"
      MYSQL_PORT: "3306"
      MYSQL_DATABASE: "productdb"
      REDIS_HOST: "redis-service"
      REDIS_PORT: "6379"
    ---
    apiVersion: v1
    kind: Secret
    metadata:
      name: db-secret
    type: Opaque
    stringData:
      MYSQL_USER: "root"
      MYSQL_PASSWORD: "rootpassword123"
      MYSQL_ROOT_PASSWORD: "rootpassword123"
    ```
  - Bước 4: Apply tất cả:
    ```bash
    kubectl apply -f mysql-deployment.yaml
    kubectl apply -f redis-deployment.yaml
    kubectl apply -f configmap.yaml
    ```
- **Kết quả mong đợi:** MySQL và Redis Deployments đều chạy, Services được tạo với ClusterIP.
- **Kết luận:** Infrastructure layer (database + cache) đã sẵn sàng trên Kubernetes.

## 2
### title
Deploy NestJS backend và kiểm tra DNS connectivity
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `nestjs-deployment.yaml` với Deployment (2 replicas) và ClusterIP Service (port 80 -> targetPort 3000). Pod template tham chiếu ConfigMap và Secret qua `envFrom`.
  - Bước 2: Apply NestJS Deployment:
    ```bash
    kubectl apply -f nestjs-deployment.yaml
    ```
  - Bước 3: Kiểm tra tất cả Deployments và Services:
    ```bash
    kubectl get deployments
    kubectl get services
    kubectl get pods
    ```
  - Bước 4: Kiểm tra NestJS Pod có resolve được DNS của MySQL và Redis:
    ```bash
    kubectl exec -it <nestjs-pod-name> -- nslookup mysql-service
    kubectl exec -it <nestjs-pod-name> -- nslookup redis-service
    ```
- **Kết quả mong đợi:** Tất cả Deployments ở trạng thái READY, Services có ClusterIP, DNS resolve thành công.
- **Kết luận:** Các thành phần giao tiếp được với nhau qua DNS nội bộ Kubernetes.

## 3
### title
Kiểm thử caching pattern và toàn bộ hệ thống
### body
- **Các bước thực hiện:**
  - Bước 1: Port-forward đến NestJS Service:
    ```bash
    kubectl port-forward service/nestjs-service 8080:80
    ```
  - Bước 2: Tạo sản phẩm:
    ```bash
    curl -X POST http://localhost:8080/products -H "Content-Type: application/json" -d "{\"name\": \"Laptop\", \"price\": 999, \"description\": \"Gaming laptop\"}"
    ```
  - Bước 3: Gọi `GET /products` lần đầu (cache miss, đọc từ MySQL):
    ```bash
    curl http://localhost:8080/products
    ```
  - Bước 4: Gọi `GET /products` lần hai (cache hit, đọc từ Redis, nhanh hơn):
    ```bash
    curl http://localhost:8080/products
    ```
  - Bước 5: Kiểm tra Redis có dữ liệu cache bằng cách exec vào Redis Pod:
    ```bash
    kubectl exec -it <redis-pod-name> -- redis-cli GET "products:all"
    ```
  - Bước 6: Tạo thêm sản phẩm và xác nhận cache được xóa:
    ```bash
    curl -X POST http://localhost:8080/products -H "Content-Type: application/json" -d "{\"name\": \"Phone\", \"price\": 599, \"description\": \"Smartphone\"}"
    curl http://localhost:8080/products
    ```
    Xác nhận danh sách có 2 sản phẩm (cache đã được invalidate).
  - Bước 7: Dọn dẹp:
    ```bash
    kubectl delete -f nestjs-deployment.yaml
    kubectl delete -f mysql-deployment.yaml
    kubectl delete -f redis-deployment.yaml
    kubectl delete -f configmap.yaml
    ```
- **Kết quả mong đợi:**
  - CRUD products hoạt động đúng với MySQL.
  - Caching pattern hoạt động: cache miss đọc MySQL, cache hit đọc Redis.
  - Cache invalidation hoạt động khi tạo product mới.
- **Kết luận:** Hệ thống Backend + MySQL + Redis hoạt động hoàn chỉnh trên Kubernetes với DNS-based connectivity và caching pattern.

# references
## 0
### alias
Kubernetes DNS for Services
### url
https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/
## 1
### alias
Kubernetes Deployments
### url
https://kubernetes.io/docs/concepts/workloads/controllers/deployment/
## 2
### alias
Redis Caching Pattern
### url
https://redis.io/docs/manual/patterns/caching/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code NestJS, Dockerfile và tất cả YAML manifests (deployments, services, configmap, secret).
### score
30
### prompts
#### 0
##### title
3 Deployments và Services cấu hình đúng
##### score
10
##### promptText
NestJS (2 replicas), MySQL (1 replica), Redis (1 replica) đều có Deployment và ClusterIP Service, DNS connectivity giữa các service hoạt động.
#### 1
##### title
TypeORM và Redis kết nối thành công
##### score
10
##### promptText
NestJS kết nối MySQL qua TypeORM và Redis qua ioredis, CRUD products hoạt động đúng, dữ liệu lưu trong MySQL.
#### 2
##### title
Caching pattern hoạt động
##### score
10
##### promptText
`GET /products` đọc từ Redis cache khi có, đọc từ MySQL khi cache miss, cache được invalidate khi tạo product mới.

# difficulty
medium

# score
30
