# title
Build a NestJS Monolith and Split into Microservices

# description
Build a simple NestJS monolith application for an e-commerce system with 3 modules (User, Product, Order) in a single app, then split it into 2 independent microservices communicating via HTTP.

# requirements
Create a NestJS monolith project with `UserModule`, `ProductModule`, `OrderModule`. Each module has its own controller and service. Endpoint `GET /users` returns a list of users, `GET /products` returns a list of products, `POST /orders` creates a new order (referencing userId and productId). Then split into 2 separate services: **user-service** (manages User) and **order-service** (manages Product + Order), where order-service calls user-service via HTTP to verify the user exists before creating an order.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install
- Basic understanding of REST APIs

# steps

## 0
### title
Initialize the monolith project
### body
- **Steps to follow:**
  - Step 1: Create a new project:
    ```bash
    nest new monolith-vs-microservices-easy
    ```
  - Step 2: Navigate to the project directory:
    ```bash
    cd monolith-vs-microservices-easy
    ```
  - Step 3: Start the application:
    ```bash
    npm run start:dev
    ```
- **Expected result:** The application starts successfully on port 3000, terminal shows NestJS startup logs.
- **Conclusion:** The base environment is ready for building business modules.

## 1
### title
Build UserModule, ProductModule, and OrderModule in the monolith
### body
- **Steps to follow:**
  - Step 1: Create `UserModule`, `UserService`, `UserController`. In `UserService`, initialize a sample data array with at least 3 users having `id` and `name`. Implement `findAll()` and `findById(id)`.
  - Step 2: Create `ProductModule`, `ProductService`, `ProductController`. In `ProductService`, initialize a sample data array with at least 3 products having `id`, `name`, `price`. Implement `findAll()` and `findById(id)`.
  - Step 3: Create `OrderModule`, `OrderService`, `OrderController`. In `OrderService`, implement `createOrder(userId, productId)` that checks user and product existence (calling services directly within the same app), creates a new order with `id`, `userId`, `productId`, `createdAt`.
  - Step 4: In `OrderModule`, import `UserModule` and `ProductModule`. Ensure `UserService` and `ProductService` are exported so `OrderService` can inject them.
  - Step 5: Create endpoints `GET /users`, `GET /products`, `POST /orders` accordingly.
- **Expected result:** `GET /users` returns a user array, `GET /products` returns a product array, `POST /orders` with body `{ userId, productId }` creates an order successfully or returns 404 if user/product does not exist.
- **Conclusion:** The monolith works correctly with all modules in a single application, communicating internally via DI.

## 2
### title
Split into 2 independent microservices
### body
- **Steps to follow:**
  - Step 1: Create a second project for **user-service**:
    ```bash
    nest new user-service
    ```
  - Step 2: Move `UserModule`, `UserService`, `UserController` to the `user-service` project. Configure it to run on port 3001.
  - Step 3: In the original project (rename to **order-service**), remove `UserModule`. Keep `ProductModule` and `OrderModule`.
  - Step 4: In `OrderService` of order-service, replace the injected `UserService` with an HTTP call to `http://localhost:3001/users/:id` to verify user existence. Use NestJS `HttpModule` (`@nestjs/axios`).
  - Step 5: Install `@nestjs/axios` in order-service:
    ```bash
    npm install @nestjs/axios axios
    ```
  - Step 6: Configure order-service to run on port 3000.
- **Expected result:** Two services run independently on different ports. Order-service calls user-service via HTTP to verify users before creating orders.
- **Conclusion:** The system has been split from a monolith into 2 microservices communicating via HTTP, each service can be deployed independently.

## 3
### title
Test the entire microservices system
### body
- **Steps to follow:**
  - Step 1: Start user-service:
    ```bash
    cd user-service
    npm run start:dev
    ```
  - Step 2: Start order-service (separate terminal):
    ```bash
    cd order-service
    npm run start:dev
    ```
  - Step 3: Verify user-service works:
    ```bash
    curl http://localhost:3001/users
    ```
  - Step 4: Create an order successfully (existing userId):
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d "{\"userId\": 1, \"productId\": 1}"
    ```
  - Step 5: Create an order with non-existing userId:
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d "{\"userId\": 999, \"productId\": 1}"
    ```
    Confirm it returns 404.
  - Step 6: Stop user-service and try creating an order, confirm order-service handles the connection error properly (returns 500 or 503).
- **Expected result:**
  - `GET /users` (port 3001) returns user list.
  - `POST /orders` (port 3000) with valid userId creates order successfully.
  - `POST /orders` with non-existing userId returns 404.
  - When user-service is down, order-service returns a clear error response.
- **Conclusion:** The microservices system works correctly, HTTP communication between services has been verified.

# references
## 0
### alias
NestJS HTTP Module
### url
https://docs.nestjs.com/techniques/http-module
## 1
### alias
NestJS Microservices Overview
### url
https://docs.nestjs.com/microservices/basics
## 2
### alias
Monolith vs Microservices - Martin Fowler
### url
https://martinfowler.com/articles/microservices.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code, including both the initial monolith and the 2 microservices after splitting.
### score
20
### prompts
#### 0
##### title
Monolith works correctly
##### score
7
##### promptText
Monolith contains all 3 modules (User, Product, Order), endpoints `GET /users`, `GET /products`, `POST /orders` work correctly, OrderService checks user/product existence before creating an order.
#### 1
##### title
Microservices split and HTTP communication
##### score
7
##### promptText
System is split into 2 separate projects (user-service and order-service), order-service calls user-service via HTTP to verify users, each service runs on its own port.
#### 2
##### title
Error handling in communication
##### score
6
##### promptText
Order-service correctly handles cases where user does not exist (404) and user-service is unavailable (500/503), returns clear error responses.

# difficulty
easy

# score
20
