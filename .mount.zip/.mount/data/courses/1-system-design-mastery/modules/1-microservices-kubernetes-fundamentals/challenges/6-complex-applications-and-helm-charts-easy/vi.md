# title
Cài đặt Helm và Deploy PostgreSQL bằng Bitnami Chart

# description
Cài đặt Helm package manager, sử dụng Bitnami Helm chart để deploy một PostgreSQL instance trên Minikube, và xác nhận kết nối thành công từ ứng dụng client.

# requirements
Cài đặt Helm CLI. Thêm Bitnami Helm repository. Sử dụng chart `bitnami/postgresql` để deploy một PostgreSQL instance trên Minikube với các tham số tùy chỉnh (password, database name). Kiểm tra kết nối bằng `psql` client hoặc ứng dụng NestJS đơn giản.

# prerequisites
- Docker Desktop
- Minikube và kubectl đã cài đặt
- Helm CLI
- Kiến thức cơ bản về Kubernetes Services

# steps

## 0
### title
Cài đặt Helm và thêm Bitnami repository
### body
- **Các bước thực hiện:**
  - Bước 1: Cài đặt Helm theo hướng dẫn chính thức (https://helm.sh/docs/intro/install/).
  - Bước 2: Kiểm tra version Helm:
    ```bash
    helm version
    ```
  - Bước 3: Thêm Bitnami Helm repository:
    ```bash
    helm repo add bitnami https://charts.bitnami.com/bitnami
    ```
  - Bước 4: Cập nhật repository:
    ```bash
    helm repo update
    ```
  - Bước 5: Tìm kiếm chart PostgreSQL:
    ```bash
    helm search repo bitnami/postgresql
    ```
- **Kết quả mong đợi:** Helm đã cài đặt, Bitnami repo đã được thêm, chart `bitnami/postgresql` xuất hiện trong kết quả search.
- **Kết luận:** Helm và Bitnami repository đã sẵn sàng để deploy ứng dụng.

## 1
### title
Deploy PostgreSQL bằng Bitnami Helm chart
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `postgresql-values.yaml` để tùy chỉnh cấu hình:
    ```yaml
    auth:
      postgresPassword: "helmpassword123"
      database: "helmdb"
    primary:
      persistence:
        size: 1Gi
    ```
  - Bước 2: Cài đặt chart với custom values:
    ```bash
    helm install my-postgresql bitnami/postgresql -f postgresql-values.yaml
    ```
  - Bước 3: Kiểm tra trạng thái release:
    ```bash
    helm list
    ```
  - Bước 4: Kiểm tra Pods và Services được tạo:
    ```bash
    kubectl get pods
    kubectl get services
    ```
  - Bước 5: Đọc hướng dẫn kết nối từ output của Helm (thường hiển thị sau khi install).
- **Kết quả mong đợi:** Release `my-postgresql` ở trạng thái `deployed`, Pod PostgreSQL đang `Running`, Service được tạo với ClusterIP.
- **Kết luận:** PostgreSQL đã được deploy thành công qua Helm chart chỉ với vài lệnh đơn giản.

## 2
### title
Kiểm tra kết nối đến PostgreSQL
### body
- **Các bước thực hiện:**
  - Bước 1: Lấy password từ Kubernetes Secret:
    ```bash
    kubectl get secret my-postgresql -o jsonpath="{.data.postgres-password}" | base64 -d
    ```
  - Bước 2: Port-forward đến PostgreSQL Service:
    ```bash
    kubectl port-forward service/my-postgresql 5432:5432
    ```
  - Bước 3: Kết nối bằng psql (terminal khác):
    ```bash
    psql -h localhost -U postgres -d helmdb
    ```
  - Bước 4: Chạy một số lệnh SQL để xác nhận:
    ```sql
    CREATE TABLE test_table (id SERIAL PRIMARY KEY, name VARCHAR(50));
    INSERT INTO test_table (name) VALUES ('helm-test');
    SELECT * FROM test_table;
    ```
  - Bước 5: Kiểm tra các resources mà Helm đã tạo:
    ```bash
    kubectl get all -l app.kubernetes.io/instance=my-postgresql
    ```
- **Kết quả mong đợi:** Kết nối PostgreSQL thành công, tạo bảng và insert/select dữ liệu hoạt động đúng.
- **Kết luận:** PostgreSQL deploy qua Helm chart hoạt động hoàn toàn bình thường, có thể sử dụng cho ứng dụng thực tế.

## 3
### title
Quản lý release và dọn dẹp
### body
- **Các bước thực hiện:**
  - Bước 1: Xem chi tiết release:
    ```bash
    helm status my-postgresql
    ```
  - Bước 2: Xem các values đang sử dụng:
    ```bash
    helm get values my-postgresql
    ```
  - Bước 3: Thử upgrade với giá trị mới (ví dụ tăng persistence size):
    ```bash
    helm upgrade my-postgresql bitnami/postgresql -f postgresql-values.yaml --set primary.persistence.size=2Gi
    ```
  - Bước 4: Xem lịch sử revision:
    ```bash
    helm history my-postgresql
    ```
  - Bước 5: Gỡ cài đặt release:
    ```bash
    helm uninstall my-postgresql
    ```
  - Bước 6: Xác nhận tất cả resources đã được dọn dẹp:
    ```bash
    kubectl get pods
    kubectl get services
    kubectl get pvc
    ```
- **Kết quả mong đợi:**
  - Helm status, values, history hoạt động đúng.
  - Upgrade tạo revision mới.
  - Uninstall xóa sạch các Kubernetes resources của release.
- **Kết luận:** Helm cung cấp vòng đời quản lý đầy đủ cho ứng dụng trên Kubernetes: install, upgrade, rollback, uninstall.

# references
## 0
### alias
Helm Installation Guide
### url
https://helm.sh/docs/intro/install/
## 1
### alias
Bitnami PostgreSQL Helm Chart
### url
https://github.com/bitnami/charts/tree/main/bitnami/postgresql
## 2
### alias
Helm Quickstart Guide
### url
https://helm.sh/docs/intro/quickstart/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa file `postgresql-values.yaml` và tài liệu ghi lại các lệnh đã thực hiện (README.md).
### score
20
### prompts
#### 0
##### title
Helm và Bitnami chart sử dụng đúng
##### score
10
##### promptText
Helm đã cài đặt, Bitnami repo đã thêm, chart `bitnami/postgresql` được install với custom values file, release ở trạng thái deployed.
#### 1
##### title
Kết nối và quản lý release
##### score
10
##### promptText
Kết nối PostgreSQL thành công qua port-forward, thực hiện được SQL operations. Helm upgrade và uninstall hoạt động đúng.

# difficulty
easy

# score
20
