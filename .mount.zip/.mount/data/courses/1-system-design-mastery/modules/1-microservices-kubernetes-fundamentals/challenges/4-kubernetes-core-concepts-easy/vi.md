# title
Deployment với Replicas, ClusterIP Service và Rolling Update

# description
Tạo Deployment với 2 replicas cho ứng dụng NestJS, expose bằng ClusterIP Service, và thực hiện rolling update để chứng minh Kubernetes có thể cập nhật ứng dụng không downtime.

# requirements
Viết YAML manifest tạo **Deployment** với 2 replicas chạy ứng dụng NestJS. Tạo **ClusterIP Service** để expose Deployment nội bộ cluster. Thực hiện **rolling update** bằng cách thay đổi version của ứng dụng và quan sát quá trình cập nhật. Sử dụng `kubectl` để xác nhận replicas, Service và rolling update hoạt động đúng.

# prerequisites
- Node.js >= 18
- Docker Desktop
- Minikube và kubectl đã cài đặt
- NestJS CLI
- Hiểu biết cơ bản về Kubernetes Pod

# steps

## 0
### title
Tạo ứng dụng NestJS với version endpoint
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS mới:
    ```bash
    nest new kubernetes-core-concepts-easy
    cd kubernetes-core-concepts-easy
    ```
  - Bước 2: Tạo endpoint `GET /version` trong `AppController` trả về `{ version: "1.0.0", hostname: os.hostname() }` (import `os` từ Node.js). Hostname giúp phân biệt các replicas.
  - Bước 3: Tạo endpoint `GET /health` trả về `{ status: "ok" }`.
  - Bước 4: Tạo Dockerfile và build image version 1:
    ```bash
    eval $(minikube docker-env)
    docker build -t k8s-core-nestjs:v1 .
    ```
- **Kết quả mong đợi:** Docker image `k8s-core-nestjs:v1` được build thành công.
- **Kết luận:** Ứng dụng v1 đã sẵn sàng để deploy với Deployment.

## 1
### title
Tạo Deployment với 2 replicas
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `deployment.yaml`:
    ```yaml
    apiVersion: apps/v1
    kind: Deployment
    metadata:
      name: nestjs-deployment
    spec:
      replicas: 2
      selector:
        matchLabels:
          app: nestjs-app
      template:
        metadata:
          labels:
            app: nestjs-app
        spec:
          containers:
            - name: nestjs-app
              image: k8s-core-nestjs:v1
              imagePullPolicy: Never
              ports:
                - containerPort: 3000
    ```
  - Bước 2: Apply Deployment:
    ```bash
    kubectl apply -f deployment.yaml
    ```
  - Bước 3: Kiểm tra Deployment và Pods:
    ```bash
    kubectl get deployment nestjs-deployment
    kubectl get pods -l app=nestjs-app
    ```
  - Bước 4: Xác nhận có đúng 2 Pods đang chạy.
- **Kết quả mong đợi:** Deployment `nestjs-deployment` có 2/2 replicas READY, 2 Pods đều ở trạng thái `Running`.
- **Kết luận:** Deployment quản lý thành công 2 replicas của ứng dụng.

## 2
### title
Tạo ClusterIP Service
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `service.yaml`:
    ```yaml
    apiVersion: v1
    kind: Service
    metadata:
      name: nestjs-service
    spec:
      type: ClusterIP
      selector:
        app: nestjs-app
      ports:
        - port: 80
          targetPort: 3000
    ```
  - Bước 2: Apply Service:
    ```bash
    kubectl apply -f service.yaml
    ```
  - Bước 3: Kiểm tra Service:
    ```bash
    kubectl get service nestjs-service
    ```
  - Bước 4: Port-forward qua Service và gọi endpoint nhiều lần:
    ```bash
    kubectl port-forward service/nestjs-service 8080:80
    ```
  - Bước 5: Gọi endpoint version nhiều lần để thấy hostname thay đổi (load balancing giữa 2 replicas):
    ```bash
    curl http://localhost:8080/version
    curl http://localhost:8080/version
    curl http://localhost:8080/version
    ```
- **Kết quả mong đợi:** Service được tạo thành công, các request được phân phối giữa 2 replicas (hostname khác nhau trong response).
- **Kết luận:** ClusterIP Service hoạt động như load balancer nội bộ, phân phối traffic đến các replicas.

## 3
### title
Thực hiện rolling update
### body
- **Các bước thực hiện:**
  - Bước 1: Sửa endpoint `GET /version` trả về `{ version: "2.0.0", hostname: os.hostname() }`.
  - Bước 2: Build image version 2:
    ```bash
    eval $(minikube docker-env)
    docker build -t k8s-core-nestjs:v2 .
    ```
  - Bước 3: Cập nhật Deployment sử dụng image mới:
    ```bash
    kubectl set image deployment/nestjs-deployment nestjs-app=k8s-core-nestjs:v2
    ```
  - Bước 4: Quan sát quá trình rolling update:
    ```bash
    kubectl rollout status deployment/nestjs-deployment
    ```
  - Bước 5: Xác nhận version mới:
    ```bash
    kubectl port-forward service/nestjs-service 8080:80
    curl http://localhost:8080/version
    ```
    Xác nhận trả về `version: "2.0.0"`.
  - Bước 6: Xem lịch sử rollout:
    ```bash
    kubectl rollout history deployment/nestjs-deployment
    ```
  - Bước 7: Dọn dẹp:
    ```bash
    kubectl delete deployment nestjs-deployment
    kubectl delete service nestjs-service
    ```
- **Kết quả mong đợi:**
  - Rolling update hoàn thành thành công, không downtime.
  - Endpoint trả về version 2.0.0 sau khi cập nhật.
  - Rollout history hiển thị 2 revisions.
- **Kết luận:** Rolling update cho phép cập nhật ứng dụng trên Kubernetes mà không ảnh hưởng đến trạng thái phục vụ.

# references
## 0
### alias
Kubernetes Deployments
### url
https://kubernetes.io/docs/concepts/workloads/controllers/deployment/
## 1
### alias
Kubernetes Services
### url
https://kubernetes.io/docs/concepts/services-networking/service/
## 2
### alias
Performing a Rolling Update
### url
https://kubernetes.io/docs/tutorials/kubernetes-basics/update/update-intro/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code NestJS, Dockerfile và các file YAML manifests (deployment, service).
### score
20
### prompts
#### 0
##### title
Deployment và Service đúng cấu hình
##### score
10
##### promptText
Deployment có 2 replicas, selector match đúng labels. ClusterIP Service trỏ đúng đến Deployment, port mapping chính xác.
#### 1
##### title
Rolling update hoạt động
##### score
10
##### promptText
Image được cập nhật từ v1 sang v2 thành công, `kubectl rollout status` xác nhận hoàn thành, endpoint trả về version mới.

# difficulty
easy

# score
20
