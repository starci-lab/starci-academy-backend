# title
Nền tảng System Design

# description
Nền tảng về System Design: scalability, reliability, availability, consistency. Hiểu các khái niệm cơ bản và metrics quan trọng trong thiết kế hệ thống.

# previewContents
## 0
### text
Hiểu các khái niệm cơ bản: scalability, reliability, availability, consistency.
## 1
### text
Nắm vững các metrics quan trọng: latency, throughput, định lý CAP.
## 2
### text
Phân biệt vertical scaling vs horizontal scaling.
## 3
### text
Hiểu các trade-offs trong thiết kế hệ thống.
## 4
### text
Làm quen với quy trình thiết kế hệ thống từ requirements đến implementation.
## 5
### text
Có nền tảng vững chắc về các khái niệm System Design.
## 6
### text
Biết cách đánh giá và so sánh các giải pháp thiết kế.
## 7
### text
Hiểu các trade-offs và biết cách đưa ra quyết định phù hợp.
## 8
### text
Sẵn sàng bước vào phần thiết kế hệ thống cụ thể ở các module tiếp theo.
## 9
### text
Sau khi hoàn tất module: nền tảng vững để thiết kế các hệ thống phức tạp hơn.
