# title
Core Concepts & Performance Metrics

# description
Explore the dark side of designing large-scale systems through survive-or-die scenarios involving scalability, latency, and data consistency.

# body

## I. The Hook

Most **beta** coders join an architecture review or interview, they get hit with: "What if Shopee flash sale traffic spikes a thousandfold, or a data center blows up?". If a beta's mindset is still revolving around a single **DB** and a single **server**, they're pretty much done for. System Design isn’t about trying to build a perfect, no-bug system; it’s about dealing with things entirely invisible in a dev environment: **latency**, network failures, and data inconsistency. This is when you need to know how your system actually "survives" based on four core concepts and two golden metrics.

## II. Experiencing Hardware Limits

We will use a movie ticketing system as a real-world example to observe system behavior under various extreme conditions.

### 1. The Collapse of the Monolith Under High Traffic

Suppose you have a single **Node.js** cluster and one **MySQL** database running on the same server for cost-efficiency and easy management.

- **Behavior:** The first ten users buy tickets. The system records the transaction in the `Ticket` table smoothly within **50ms**. The experience is seamless.
- **Incident:** During a high-demand opening hour, 10,000 users storm the system at once. Global database locks occur, and CPU hits 100% because the hardware limits for RAM/CPU and disk read/write throughput have been reached.
- **Expected Result:** The 1,000th user sees an endless loading spinner, waiting for **10 seconds** or receiving a system error.
- **Conclusion:** **Latency** (latency) is pushed to its absolute peak. The system crashes completely because it has exceeded its maximum **Throughput** (throughput). To escape this bottleneck, we need to understand **Horizontal Scaling**.

### 2. Unavoidable Physical Risks

Imagine hosting your entire system in a single Data Center in a specific region.

- **Behavior:** The system is heavily specced out, and every transaction goes through flawlessly under automated monitoring.
- **Incident:** An unexpected disaster (such as a natural catastrophe, conflict, or massive power failure) paralyzes or destroys the entire Data Center.
- **Expected Result:** All efforts in code optimization are rendered meaningless when the physical infrastructure is wiped out. Users cannot access the system, and data is at high risk of being lost without a redundancy mechanism.
- **Conclusion:** Performance optimization is not enough if the system faces physical failure. To ensure resilience, **Multi-Region Deployment** and data backup strategies are critical survival factors.

## III. Core Concepts

After analyzing the issues above, you will realize that architectural thinking determines the survival of a system. Below are the 4 "backbone" concepts that every system architect must master.

### 1. Scalability

The system's ability to expand resources to handle traffic growth without sacrificing performance.
- **Vertical Scaling:** Increasing hardware power (RAM, CPU) for the current server. This approach is ultimately limited by physical hardware ceilings.
- **Horizontal Scaling:** Adding more servers running in parallel.

- **Example:** Instead of using one super-powerful server that crashes at 10,000 users, you distribute the load across 10 mid-tier servers behind a **Load Balancer**. Systems can scale dynamically using tools like **K8s** (Kubernetes).

### 2. Availability

Measures the actual uptime of the system compared to the required runtime. A High Availability (HA) system—typically targeting `**99.99%**` uptime (Four Nines)—almost never experiences downtime.

- **Example:** Implementing redundancy with 2 Databases located in different geographical regions (e.g., **AWS** and **GCP**). If one region fails, the system automatically redirects traffic to the other.

### 3. Reliability

While **Availability** asks, "Is the system running?", **Reliability** asks, "Is the system running correctly?". Reliability ensures the system performs its function as expected and prevents data loss or corruption even when individual components fail.

- **Example:** Two users click "Buy" for the last ticket at the exact same millisecond. A **Reliable** architecture must ensure transaction integrity: only one user gets the ticket, and the other isn't wrongly charged.

**Basic Reliability Mechanisms:**
- `**Retry**`: Automating attempts after temporary failures (e.g., network flickers).
- `**Timeout**`: Limiting wait times for responses to avoid hanging threads.
- `**Circuit Breaker**`: Automatically severing connections to a service that is failing repeatedly to protect the overall system.
- `**Replication**`: Backing up data/services across multiple instances to avoid a Single Point of Failure.
- `**Idempotency**`: Ensuring that redundant requests (due to retries or lag) only result in a single valid outcome.
- `**Monitoring & Alerting**`: Proactively tracking and alerting on early signs of trouble.
- `**Backup / Recovery**`: Having a seamless process to restore data after a disaster.

**Advanced Reliability Factors:**
- `**Rate Limiting**`: Restricting the number of requests from a single client to prevent localized overloading.
- `**Throttling**`: During overload, proactively rejecting or slowing down less critical requests (e.g., product recommendations) to save resources for core tasks (e.g., payments).
- `**Graceful Degradation**`: When a non-essential service fails, the system automatically downgrades features (e.g., using basic search instead of advanced or serving from cache) rather than failing the entire page.
- `**Data Integrity Checks**`: Using Checksum/Hash to ensure data isn't corrupted during transmission or storage.
- `**Self-Healing**`: The system automatically detects and restarts failed components (e.g., Liveness checks in **K8s**).

**Safe Deployment Strategies:**
- `**Canary Deployment**`: Deploying new code only to a tiny fraction of users (e.g., 1%). If no new issues arise, it is gradually rolled out to 100%.
- `**Chaos Engineering**`: Proactively injecting failures (crashing servers, cutting networks) in Staging/Production environments to test the system's resilience and recovery capabilities.

### 4. Consistency

The principle that ensures data remains identical across all nodes in a distributed system at any given point in time.

- **Example:** After a money transfer, the balance must be updated uniformly and immediately. Reading different balances from two separate servers is a critical violation of system integrity.
- **Strong Consistency:** Guarantees that every read following a write returns the latest data. This is mandatory for financial systems (**Banking**, **Payment**).

## IV. The Golden Indicators: Latency & Throughput

To quantify actual system health based on these architectural rules, we use two critical technical metrics.

### 1. Latency

Latency (latency) is the total time from when a user sends a request to when they receive a response from the system.
`Latency = Network Transmission Time + Processing Time at Server.`

- **Factors Increasing Latency:**
    - `**Network latency**`: Delay caused by geographical distance and network infrastructure.
    - `**Processing latency**`: Time taken to execute source code and algorithms at the server.
    - `**Disk latency**`: Read/write speeds of the hard drive and Database.
    - `**Queue latency**`: Time requests spend waiting in a queue when the system is busy.

- **Practical Measurement:** Focus on Worst-case values rather than simple averages.
    - `**P50 (Median)**`: The latency experienced by 50% of users.
    - `**P95 / P99**`: Critical for measuring the absolute worst-case experiences. For example, `P99 = 500ms` means 99% of requests are handled within 500ms.

- **Optimizing Latency:**
    - `**Cache (Redis)**`: Accessing data from RAM rather than Disk.
    - `**Database Indexing**`: Dramatically speeding up data lookups.
    - `**Optimize queries**`: Fetching only necessary fields to save resources.
    - `**Async processing**`: Using asynchronous tasks to avoid blocking the main request thread.
    - `**CDN**`: Distributing static assets physically closer to the user.

### 2. Throughput

Throughput (throughput) is the volume of requests a system can successfully process within a unit of time (usually Requests Per Second - RPS).

- 100 RPS: Suitable for small-scale or developing applications.
- 10,000 RPS: The standard for large-scale, enterprise-ready systems.

### 3. The Insight: Latency vs. Throughput

A common pitfall is assuming that reducing Latency automatically increases Throughput.
- **The Reality:** A system might handle individual requests very quickly (**Low Latency**) but still fail under heavy concurrency due to bandwidth or resource constraints (**Low Throughput**).
- **Design Goal:** A superior system architecture must optimize for both—maintaining fast responses while supporting massive concurrent volume.

# references
## 0
### alias
System Design Basics
### url
https://github.com/donnemartin/system-design-primer

# minutesRead
20