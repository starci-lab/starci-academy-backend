# title
Chiến lược mở rộng hệ thống (Scaling Strategies)

# description
Đập tan giới hạn vật lý của máy chủ đơn lẻ bằng tư duy Horizontal Scaling - con đường duy nhất để hệ thống của bạn "sống sót" trước hàng triệu người dùng.

# body

## I. Lời mở đầu

Hãy tưởng tượng bạn đang ngồi trong một buổi phỏng vấn vị trí Senior Backend. Người phỏng vấn đặt một câu hỏi gài: "Hệ thống đang chạy ổn định bỗng dưng chậm lại khi traffic tăng gấp 10 lần vào giờ cao điểm. Bạn sẽ xử lý thế nào?". Nếu câu trả lời đầu tiên nảy ra trong đầu bạn là "Em sẽ nâng cấp con server đó lên bản mạnh nhất, thêm thật nhiều RAM và CPU," thì xin chia buồn, bạn vừa rơi vào cái bẫy của tư duy **monolithic**.

Để trả lời câu này bạn cần hiểu về **Horizontal Scaling**. Đọc thêm để hiểu.

## II. Demo trực quan và thực hành

Dưới đây là demo sử dụng **Kubernetes** (qua **Minikube**) và **Nginx** để minh họa sự khác biệt giữa **Vertical Scaling** và **Horizontal Scaling** trên cùng một Deployment. Ban đầu hệ thống chạy 2 **Pod** với tài nguyên nhỏ; sau đó ta sẽ lần lượt: (1) **patch** tăng tài nguyên container (Vertical), (2) **scale** số lượng Pod (Horizontal) — và quan sát hành vi của hệ thống trong từng trường hợp.

**Clone** ở đây: [Scaling Strategies — demo (Nginx + K8s)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/scaling-strategies)

| Thành phần | Công nghệ | Vai trò |
|-------------|-----------|---------|
| **Container Runtime** | **Docker** | Chạy các container bên trong Minikube |
| **Orchestrator** | **Minikube** (Kubernetes local) | Quản lý cụm K8s trên máy cá nhân |
| **App** | **Nginx 1.27-alpine** | Web server mẫu để quan sát hành vi scale |
| **Config** | `nginx-deployment.yaml` | Deployment ban đầu: 2 replicas, CPU 50m/200m, RAM 64Mi/128Mi |
| **Patch** | `vertical-scale-patch.json` | JSON Patch tăng tài nguyên: CPU 100m/500m, RAM 128Mi/512Mi |

### 1. Chuẩn bị và chạy môi trường

Giả định máy đã cài **Docker** (Docker Desktop hoặc Docker Engine). Làm lần lượt các bước dưới đây.

1. **Cài Minikube** — công cụ chạy **Kubernetes** trên máy local. Chọn cách cài phù hợp hệ điều hành:

    - **macOS** (Homebrew):
    ```
    brew install minikube
    ```

    - **Linux** (amd64):
    ```
    curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
    sudo install minikube-linux-amd64 /usr/local/bin/minikube
    ```

    - **Windows** (PowerShell — quyền Admin):
    ```
    winget install Kubernetes.minikube
    ```

2. **Khởi động cụm Minikube** (dùng Docker driver):

    ```
    minikube start --driver=docker
    ```

3. **Clone repo** và di chuyển vào thư mục demo:

    ```
    git clone https://github.com/StarCi-Academy/resources.git
    cd resources/system-design-mastery/scaling-strategies
    ```

4. **Apply Deployment** — triển khai Nginx lên cụm K8s:

    ```
    kubectl apply -f nginx-deployment.yaml
    ```

5. Kiểm tra trạng thái đảm bảo các Pod đã sẵn sàng:

    ```
    kubectl get pods
    ```

    **Response** khoảng như sau (2 Pod ở trạng thái **Running**):

    ```
    NAME                                  READY   STATUS    RESTARTS   AGE
    nginx-scaling-demo-5d4f7b8c9-abc12   1/1     Running   0          30s
    nginx-scaling-demo-5d4f7b8c9-def34   1/1     Running   0          30s
    ```

**Kết quả mong đợi**

Cụm Minikube chạy, **Deployment** `nginx-scaling-demo` với **2 Pod** đang phục vụ, mỗi Pod được cấp CPU **50m–200m** và RAM **64Mi–128Mi**.

**Kết luận**

Đây là trạng thái ban đầu ổn định — hệ thống chạy tốt với tải thấp. Tiếp theo ta sẽ lần lượt thử hai chiến lược mở rộng.

### 2. Kịch bản 1: Vertical Scaling — tăng tài nguyên cho container

Khi tải tăng, phản xạ đầu tiên thường là "cho Pod nhiều CPU/RAM hơn". Ta sẽ dùng **JSON Patch** có sẵn trong repo để tăng tài nguyên container.

**Các bước thực hiện:**

**Bước 1:** Xem nội dung patch để hiểu thay đổi:

```
cat vertical-scale-patch.json
```

**Response:**

```json
[
  {
    "op": "replace",
    "path": "/spec/template/spec/containers/0/resources",
    "value": {
      "requests": { "cpu": "100m", "memory": "128Mi" },
      "limits": { "cpu": "500m", "memory": "512Mi" }
    }
  }
]
```

Patch này tăng CPU từ **50m→100m** (requests) và **200m→500m** (limits); RAM từ **64Mi→128Mi** và **128Mi→512Mi**.

**Bước 2:** Áp dụng patch lên Deployment:

```
kubectl patch deployment nginx-scaling-demo --type='json' --patch-file vertical-scale-patch.json
```

**Bước 3:** Quan sát hành vi Pod sau khi patch:

```
kubectl get pods -w
```

**Response** khoảng như sau — Pod cũ bị **Terminating**, Pod mới được tạo ra thay thế:

```
NAME                                  READY   STATUS        RESTARTS   AGE
nginx-scaling-demo-5d4f7b8c9-abc12   1/1     Terminating   0          5m
nginx-scaling-demo-5d4f7b8c9-def34   1/1     Terminating   0          5m
nginx-scaling-demo-7a8b9c0d1-ghi56   1/1     Running       0          10s
nginx-scaling-demo-7a8b9c0d1-jkl78   1/1     Running       0          8s
```

Nhấn **Ctrl+C** để thoát chế độ watch.

**Kết quả mong đợi**

Kubernetes **rollout** lại toàn bộ Pod để áp dụng cấu hình tài nguyên mới. Trong khoảng thời gian rollout, hệ thống có thể gặp tình trạng gián đoạn (**Downtime**) — đặc biệt nếu chỉ có 1 replica.

**Kết luận**

**Vertical Scaling** đơn giản nhưng luôn đi kèm rủi ro: Pod phải **restart** để nhận cấu hình mới, và dù bạn có tăng bao nhiêu thì vẫn bị giới hạn bởi **trần phần cứng** của node. Bạn không thể cắm vào mainboard một thanh RAM 1TB nếu nó không hỗ trợ.

### 3. Kịch bản 2: Horizontal Scaling — thêm Pod để chia tải

Thay vì cố nâng cấp từng "cá nhân", ta tuyển thêm "quân số" để gánh chung.

**Các bước thực hiện:**

**Bước 1:** Scale Deployment từ **2 Pod** lên **5 Pod**:

```
kubectl scale deployment nginx-scaling-demo --replicas=5
```

**Bước 2:** Kiểm tra kết quả:

```
kubectl get pods
```

**Response** khoảng như sau — 5 Pod đều ở trạng thái **Running**:

```
NAME                                  READY   STATUS    RESTARTS   AGE
nginx-scaling-demo-7a8b9c0d1-ghi56   1/1     Running   0          3m
nginx-scaling-demo-7a8b9c0d1-jkl78   1/1     Running   0          3m
nginx-scaling-demo-7a8b9c0d1-mno90   1/1     Running   0          15s
nginx-scaling-demo-7a8b9c0d1-pqr12   1/1     Running   0          15s
nginx-scaling-demo-7a8b9c0d1-stu34   1/1     Running   0          15s
```

**Bước 3:** (Tùy chọn) Thử xóa một Pod ngẫu nhiên để quan sát khả năng **tự phục hồi** (Self-healing) của Kubernetes:

```
kubectl delete pod nginx-scaling-demo-7a8b9c0d1-mno90
```

Sau vài giây, chạy lại `kubectl get pods` — Kubernetes tự động tạo Pod mới thay thế, tổng số vẫn giữ đúng **5 replicas**.

**Kết quả mong đợi**

Kubernetes lập tức khởi tạo thêm 3 Pod mới. Các Pod cũ **không bị restart** — **zero downtime**. Khi thiết kế đúng ngay từ đầu, hệ thống có thể **Scale Out** mượt mà bằng cách đơn giản thêm tài nguyên mà không cần sửa logic nghiệp vụ.

**Kết luận**

Bằng cách thêm "nhiều máy nhỏ", chúng ta đã giải quyết được bài toán mà một "máy lớn" không thể gánh nổi. Hệ thống giờ đây đạt được tính sẵn sàng cao (**High Availability**) và khả năng tự phục hồi (**Self-healing**).

## III. Các khái niệm cốt lõi

Sau khi trải nghiệm thực tế, chúng ta cần chuẩn hóa lại kiến thức để đưa ra quyết định kiến trúc chính xác.

### 1. Vertical Scaling (Scale Up)
Nâng cấp nội lực của máy chủ hiện có (Thêm RAM, CPU, SSD).
- **Ưu điểm:** Dễ thực hiện, không cần sửa code, không lo về đồng bộ dữ liệu giữa các node.
- **Nhược điểm:** Bị giới hạn vật lý, chi phí tăng vọt theo cấp số nhân ở phân khúc cao cấp, và là **Single Point of Failure (SPOF)**.

### 2. Horizontal Scaling (Scale Out)
Thêm nhiều máy chủ chạy song song để gánh tải.
- **Ưu điểm:** Khả năng mở rộng gần như vô hạn, tính sẵn sàng cao (một máy sập hệ thống vẫn chạy), tối ưu chi phí bằng phần cứng phổ thông.
- **Thách thức:** Cần bộ **Load Balancer** để điều phối và ứng dụng phải được thiết kế dạng **Stateless** (không lưu dữ liệu người dùng cục bộ).

### 3. Mô hình chi phí và Kiến trúc bền bỉ

Trong thiết kế hệ thống hiện đại, chúng ta áp dụng mô hình toán học về chi phí:
- **Vertical:** $Cost_{Vertical} = f(Resource^n)$ (Chi phí tăng vọt theo cấp số nhân do linh kiện đặc thù).
- **Horizontal:** $Cost_{Horizontal} \approx k \times NumberOfNodes$ (Chi phí tăng tuyến tính và dễ dự báo).

**Insight:** Tư duy của một kiến trúc sư phải chuyển dịch từ việc *"làm sao để máy này không sập"* sang *"làm sao để hệ thống vẫn chạy khi máy này sập"*.

# references
## 0
### alias
Scaling Patterns
### url
https://microservices.io/articles/scalecube.html

# minutesRead
15