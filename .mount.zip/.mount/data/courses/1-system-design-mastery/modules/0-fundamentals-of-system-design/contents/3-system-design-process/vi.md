# title
Quy trình Thiết kế Hệ thống chuẩn (System Design Process)

# description
Nắm quy trình thiết kế hệ thống từ đầu gồm bốn bước: làm rõ yêu cầu, ước lượng quy mô, phác thảo kiến trúc cấp cao và tinh chỉnh các điểm nghẽn.

# body

## I. Lời mở đầu

Sai lầm lớn nhất của nhiều lập trình viên khi đối mặt với một bài toán hệ thống lớn là lao ngay vào code hoặc chọn công nghệ "hot" nhất (**Kafka**, **Kubernetes**, **Microservices**) mà chưa hiểu rõ mình đang thực sự giải quyết vấn đề gì. Lối tư duy **"vừa chạy vừa xếp hàng"** này thường dẫn đến những kiến trúc chắp vá, khó mở rộng và tốn kém tài nguyên.

Hãy tưởng tượng buổi phỏng vấn: "Thiết kế một hệ thống thương mại điện tử xử lý **50.000 truy cập đồng thời** trong dịp flash sale." Nếu phản xạ đầu tiên là **"Dùng Kafka, chia Microservices, deploy lên K8s"** thì bạn đã sai ngay từ bước đầu — vì bạn chưa biết hệ thống cần gì, lớn cỡ nào, và đâu là điểm sẽ chết trước.

**System Design** không phải là bài trắc nghiệm về kiến thức công nghệ, mà là một quy trình giải quyết vấn đề có phương pháp. Nếu code là những viên gạch, thì **System Design** chính là **bản vẽ kiến trúc**. Một bản vẽ cẩu thả sẽ dẫn đến một tòa nhà sụp đổ ngay khi có cơn gió nhẹ. Bài này cung cấp cho bạn một bộ khung tư duy chuẩn bốn bước để tiếp cận mọi bài toán thiết kế.

## II. Walkthrough thiết kế từng bước

Chúng ta ví dụ một hệ thống **E-commerce** vào các tình huống flash sale thực tế để quan sát hành vi hệ thống.


### 1. Requirements Clarification (Làm rõ yêu cầu)

Sai lầm phổ biến nhất là bắt đầu xây dựng ngay khi chưa hiểu rõ đích đến. Bạn cần dành thời gian để làm rõ ba nhóm câu hỏi sau:

- **Yêu cầu chức năng (Functional Requirements):** Xác định các tính năng cốt lõi mà người dùng có thể thực hiện.
    - Ví dụ: Người dùng phải có thể **xem sản phẩm**, **thêm vào giỏ hàng** và **thanh toán**.

- **Yêu cầu phi chức năng (Non-functional Requirements):** Các tiêu chuẩn về chất lượng mà hệ thống phải đáp ứng.
    - Ví dụ: Tính **sẵn sàng cao** (**high availability**), độ trễ khi thanh toán phải dưới **500ms**, chịu được **50.000 truy cập đồng thời** vào các dịp khuyến mãi.

- **Phạm vi bài toán (Out of scope):** Xác định rõ những gì hệ thống **không** làm để tránh **over-engineering**.
    - Ví dụ: Hệ thống này không xử lý **hoàn tiền** (refund) — đó là module riêng sẽ xây dựng sau.

**Kết quả mong đợi**

Sau bước này bạn phải có một danh sách rõ ràng: hệ thống làm gì, không làm gì, và chất lượng kỳ vọng ra sao. Không có danh sách này thì mọi bước sau đều xây trên cát.

### 2. Back-of-the-envelope Estimation (Ước lượng quy mô)

Bạn không thể chọn **Database** hay **Server** nếu không biết hệ thống sẽ lớn cỡ nào. Việc ước lượng giúp bạn hiểu rõ "áp lực" mà hệ thống sẽ phải gánh chịu.

- **Lưu lượng (Traffic):** Ước tính **DAU** (Daily Active Users), **Average QPS** và **Peak QPS**.
    - Ví dụ: 1 triệu **DAU**, mỗi người đặt 0.1 đơn/ngày → khoảng **1.2 QPS** trung bình, Peak có thể x10 = **12 QPS**.

- **Lưu trữ (Storage):** Ước tính dung lượng dữ liệu cần lưu trữ theo năm.
    - Ví dụ: Mỗi đơn hàng chiếm **10KB**, 100.000 đơn/ngày → **1GB/ngày** → **365GB/năm**.

- **Băng thông (Bandwidth):** Ước tính lượng dữ liệu ra/vào hệ thống để thiết kế hạ tầng mạng.
    - Kết quả ước tính có thể chỉ ra rằng bạn cần một **Database** có khả năng **ghi cực nhanh** (**write-intensive**) thay vì chỉ ưu tiên tốc độ đọc.

**Kết quả mong đợi**

Bạn có một bộ số liệu sơ bộ: bao nhiêu **QPS**, bao nhiêu **GB/năm**, hệ thống **read-heavy** hay **write-heavy**. Những con số này quyết định bạn cần bao nhiêu server và loại **Database** nào.

### 3. High-Level Design (Thiết kế cấp cao)

Đây là giai đoạn phác thảo **"bản đồ"** tổng thể của hệ thống bằng cách vẽ các khối chức năng chính và cách chúng tương tác với nhau.

- **Ví dụ:** Luồng request từ **Client** đến **Database** cho hệ thống **E-commerce**:
    - **Client** (Mobile App / Browser) gửi request.
    - **Load Balancer** phân phối đến các **Web Server**.
    - **Web Server** kiểm tra **Redis Cache** trước — nếu **cache hit** thì trả về ngay.
    - Nếu **cache miss** mới truy vấn vào **MySQL Database** chính.
    - Kết quả được lưu vào cache cho các request tiếp theo.

**Kết quả mong đợi**

Bạn có một sơ đồ kiến trúc với các thành phần chính: **Client** → **Load Balancer** → **Web Server** → **Cache** / **Database**. Sơ đồ này là nền tảng để bước tiếp theo tìm điểm yếu.

### 4. Deep Dive & Bottlenecks (Tinh chỉnh điểm nghẽn)

Sau khi có khung xương, hãy tập trung vào các thành phần quan trọng nhất để tìm ra **bottleneck** và đưa ra giải pháp:

- **Ví dụ 1: Database bị quá tải đọc** — Thêm **Read Replicas** để chia sẻ tải cho **Primary**; hoặc dùng **Sharding** nếu dữ liệu quá lớn cho một máy.

- **Ví dụ 2: Xử lý tác vụ nặng làm nghẽn request** — Đẩy việc gửi **email xác nhận** vào một **Job Queue** (**Kafka**) để xử lý **bất đồng bộ**, tránh làm chậm luồng chính.

- **Ví dụ 3: Phân phối media chậm** — Dùng **CDN** để phân phối hình ảnh/video từ các điểm gần người dùng nhất, giảm **Latency** đáng kể.

**Kết quả mong đợi**

Mỗi thành phần trên sơ đồ đều đã được đánh giá. Bạn biết rõ đâu là chỗ sẽ chết trước khi tải tăng, và đã có phương án xử lý cho từng điểm.

Sau bốn bước trên, bạn đã có một bản thiết kế hoàn chỉnh từ yêu cầu đến kiến trúc. Nhưng vẫn còn một câu hỏi lớn: **chọn công nghệ nào** cho từng thành phần? Mỗi lựa chọn đều có cái giá — và đó là nội dung phần tiếp theo.

## III. Nghệ thuật Lựa chọn công nghệ và Tư duy kiến trúc

### 1. Mỗi quyết định đều đi kèm sự đánh đổi (Trade-offs)

Không có công nghệ nào là "tốt nhất" cho mọi trường hợp. Dưới đây là các ví dụ phổ biến nhất:

- **Ví dụ 1: SQL hay NoSQL?**
    - Chọn **SQL** (MySQL, PostgreSQL): Hệ thống cần **ACID transaction** và **Strong Consistency** (**E-commerce**, **Banking**). Đánh đổi: khó **scale ngang**, hiệu năng giảm khi data cực lớn.
    - Chọn **NoSQL** (MongoDB, Cassandra): Dữ liệu linh hoạt, cần **scale ngang** tốt (Feed, Logs, Chat). Đánh đổi: chỉ đạt **Eventual Consistency**, phải tự xử lý consistency ở tầng ứng dụng.

- **Ví dụ 2: Dùng Cache (Redis) hay không?**
    - Dùng **Cache**: Giảm **Latency** cực thấp cho **data nóng** (Profile, Product Detail). Đánh đổi: data có thể bị **cũ** (stale) và phải giải quyết bài toán **Cache Invalidation** rất khó.

- **Ví dụ 3: Sync hay Async (Message Queue)?**
    - Dùng **Async** (**Kafka**): Tăng **Throughput**, không chặn luồng chính. Đánh đổi: tăng **Latency** thực tế, khó debug, phải xử lý **retry/duplicate**.

- **Ví dụ 4: Monolith hay Microservices?**
    - **Monolith**: Dễ phát triển và deploy ban đầu. Đánh đổi: khó mở rộng từng phần khi team và dự án phình to.
    - **Microservices**: Scale độc lập từng **service**, team làm việc song song. Đánh đổi: phức tạp về **network**, **data consistency**, cần infra mạnh (**Kubernetes**).

### 2. Tư duy kiến trúc sư: Con số và Quy trình, không phải Cảm tính

Quy trình thiết kế hệ thống không phải là một khuôn mẫu cứng nhắc, mà là một **vòng lặp liên tục**: Thiết kế → Đánh giá sự đánh đổi → Tinh chỉnh dựa trên nhu cầu kinh doanh thực tế.

Một kĩ sư giỏi không phải là người biết dùng nhiều công nghệ nhất, mà là người biết rõ **tại sao** mình chọn giải pháp này thay vì giải pháp kia — dựa trên những **con số ước lượng cụ thể** và **quy trình rành mạch** — và luôn sẵn sàng điều chỉnh khi quy mô hệ thống thay đổi.

# references
## 0
### alias
System Design Interview Framework
### url
https://github.com/donnemartin/system-design-primer#how-to-approach-a-system-design-interview-question

# minutesRead
15