# title
CAP Theorem and Trade-offs

# description
Understand the CAP Theorem to learn why distributed systems cannot achieve Consistency, Availability, and Partition Tolerance all at once, and how to choose the right trade-off for each use case.

# body

## I. Lời mở đầu (Introduction)

In an ideal world, we always want a system that is fast, always online 24/7, and whose data is absolutely accurate everywhere. However, when you start expanding your system across multiple servers communicating over the internet, a harsh reality sets in: networks can be severed, servers can hang, and data **takes time to move** between nodes.

The **CAP Theorem** exists to help us accept these physical limitations and learn how to make smart architectural choices instead of chasing a perfect solution that doesn't exist.

## II. The Three Core Properties of CAP

The CAP Theorem asserts that a **distributed system** can only guarantee at most **two** of the following three characteristics simultaneously:

- **Consistency (C):** Every read request from any **node** must receive the most recent write or return an error. Data across all servers must be synchronized "instantly." If synchronization isn't complete, the system would rather refuse service than return stale data.
- **Availability (A):** The system must respond successfully to every request (no error or timeout), even if one or more nodes are experiencing failures. The focus is on constant, uninterrupted service.
- **Partition Tolerance (P):** The system continues to operate normally even when the network between nodes is disrupted, partitioned, or delayed (**Split-brain**).

## III. The Practical Reality: Choosing Between CP and AP

In any real-world internet environment, **Network Partitions** (the **P**) are inevitable. Therefore, the architectural game revolves around the trade-off between **Consistency (C)** and **Availability (A)**.

### 1. CP Systems (Consistency + Partition Tolerance)
When a network partition occurs, the system prioritizes **data accuracy** above all else.
- **Behavior:** The system will reject read/write requests (sacrificing **Availability**) until the network is restored and data is synchronized.
- **Use Case Example:** **Bank Transfers** or **ATMs**. If the connection is lost, it's better to report a "System Error" than to allow a withdrawal based on an incorrect balance.
- **Typical Tech:** **MongoDB**, **Redis**, **HBase**, **ZooKeeper**.

### 2. AP Systems (Availability + Partition Tolerance)
When a network partition occurs, the system continues to serve users to ensure a seamless experience.
- **Behavior:** The system accepts and returns potentially stale data (sacrificing absolute **Consistency**) to keep the service running. Data syncs eventually once the network stabilizes (**Eventual Consistency**).
- **Use Case Example:** **Social Media Likes/Comments**. Seeing 100 likes while a friend sees 98 is acceptable; keeping the "Like" button working is more important.
- **Typical Tech:** **Cassandra**, **DynamoDB**, **CouchDB**.

## IV. Summary

The **CAP Theorem** is not a barrier; it is a compass for realistic architecture. Designing systems is the art of trade-offs. 

Knowing when to prioritize absolute accuracy (**CP**) and when to prioritize continuous service (**AP**) is a mandatory skill for any software architect.

# references
## 0
### alias
CAP Theorem Simplified
### url
https://en.wikipedia.org/wiki/CAP_theorem

# minutesRead
20