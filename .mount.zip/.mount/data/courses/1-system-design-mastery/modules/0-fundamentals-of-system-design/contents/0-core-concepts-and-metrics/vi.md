# title
Khái niệm cốt lõi & Chỉ số hiệu năng

# description
Khám phá mặt trái của việc thiết kế hệ thống lớn qua những bài toán sống còn về khả năng mở rộng, độ trễ và sự nhất quán dữ liệu.

# body

## I. Lời mở đầu

Mấy thằng **beta** đi phỏng vấn gặp ông review kiến trúc, người ta hỏi: "Nếu Shopee flash sale lượt truy cập tăng gấp nghìn lần, hoặc một data center bị nổ tung thì sao?". Nếu tư duy của beta chỉ quẩn quanh một **DB** và một **server** duy nhất, hầu như là tạch. System Design không nằm ở việc cố xây dựng hệ thống hoàn hảo và no-bug, mà đối mặt với những thứ vốn dĩ vô hình trên môi trường dev: **độ trễ**, rớt mạng, và dữ liệu bất đồng bộ. Đây là lúc bạn cần biết hệ thống bạn thực sự "sống sót" như thế nào dựa trên bốn khái niệm lõi và hai chỉ số vàng.

## II. Trải nghiệm giới hạn phần cứng

Chúng ta ví dụ một hệ thống bán vé vào các tình huống thực tế để quan sát hành vi hệ thống.

### 1. Sự sụp đổ của Monolithic khi traffic tăng cao

Giả sử bạn có duy nhất một cụm **Node.js** và một cơ sở dữ liệu **MySQL** chạy chung trên một máy chủ để tiết kiệm chi phí và dễ quản lý.

- **Hành vi:** Mười người đầu tiên vào mua vé. Hệ thống thực hiện ghi vào bảng `Ticket` trơn tru chỉ trong **50ms**. Trải nghiệm rất mượt mà.
- **Sự cố:** Vào giờ cao điểm mở bán, 10.000 người dùng truy cập cùng lúc. Cơ sở dữ liệu bị khóa bảng diện rộng, CPU chạm mốc 100% do giới hạn vật lý của RAM/CPU và tốc độ đọc/ghi dữ liệu đã đạt tới giới hạn.
- **Kết quả mong đợi:** Người thứ 1.000 bắt đầu thấy màn hình xoay đều, phải chờ tới **10 giây** mới có kết quả hoặc gặp lỗi hệ thống.
- **Kết luận:** **Latency** (độ trễ) bị đẩy lên đỉnh điểm. Hệ thống bị quá tải hoàn toàn vì đã vượt quá **Throughput** (thông lượng tối đa). Để giải quyết vấn đề này, chúng ta cần hiểu về phương pháp **Horizontal Scaling**.

### 2. Các rủi rủi vật lý không thể tránh khỏi

Thử tưởng tượng bạn triển khai toàn bộ hệ thống trên một trung tâm dữ liệu (Data Center) duy nhất tại một khu vực nhất định.

- **Hành vi:** Hệ thống được cấu hình mạnh mẽ, mọi giao dịch diễn ra trơn tru dưới sự giám sát tự động.
- **Sự cố:** Một sự cố bất ngờ (như thiên tai, xung đột hoặc mất điện diện rộng) khiến toàn bộ Data Center bị tê liệt hoặc phá hủy hoàn toàn.
- **Kết quả mong đợi:** Mọi nỗ lực tối ưu code đều vô nghĩa khi cơ sở hạ tầng vật lý bị xóa sổ. Người dùng không thể truy cập và dữ liệu có nguy cơ bị mất sạch nếu không có cơ chế dự phòng.
- **Kết luận:** Tối ưu hiệu năng là chưa đủ nếu hệ thống gặp biến cố vật lý. Để đảm bảo tính bền bỉ, chiến lược **Multi-Region Deployment** và sao lưu dữ liệu là yếu tố sống còn.

## III. Các khái niệm cốt lõi

Sau khi phân tích các vấn đề trên, bạn sẽ nhận ra rằng tư duy kiến trúc quyết định sự tồn tại của hệ thống. Dưới đây là 4 khái niệm "xương sống" mà bất kỳ kiến trúc sư hệ thống nào cũng phải nắm vững.

### 1. Scalability (Khả năng mở rộng)

Đây là năng lực của hệ thống trong việc mở rộng tài nguyên để xử lý lượng traffic tăng cao mà không làm giảm hiệu năng.
- **Vertical Scaling (Nâng cấp hàng dọc):** Tăng sức mạnh phần cứng (RAM, CPU) cho máy chủ hiện tại. Tuy nhiên, cách này luôn bị giới hạn bởi trần công nghệ của linh kiện vật lý.
- **Horizontal Scaling (Mở rộng hàng ngang):** Thêm nhiều máy chủ chạy song song.

- **Ví dụ bán vé:** Thay vì dùng một server cực mạnh gánh 10.000 người và sập, bạn chia tải ra 10 server tầm trung chạy song song phía sau một bộ cân bằng tải (**Load Balancer**). Hệ thống có thể scale linh hoạt bằng các công cụ như **K8s** (Kubernetes).

### 2. Availability (Tính sẵn sàng)

Đo lường thời gian hệ thống hoạt động thực tế so với tổng thời gian yêu cầu. Một hệ thống có tính sẵn sàng cao (High Availability - thường là 99.99%) nghĩa là nó gần như không bao giờ bị dừng hoạt động (downtime).

- **Ví dụ bán vé:** Sử dụng cơ chế dự phòng với 2 Database đặt ở 2 khu vực địa lý khác nhau (ví dụ **AWS** và **GCP**). Nếu một khu vực gặp sự cố, hệ thống tự động chuyển hướng truy cập sang khu vực còn lại.

### 3. Reliability (Độ tin cậy)

Nếu **Availability** trả lời cho câu hỏi "Hệ thống có đang chạy không?", thì **Reliability** trả lời "Hệ thống có chạy đúng không?". Reliability đảm bảo hệ thống thực hiện đúng chức năng và không làm mất hoặc sai lệch dữ liệu ngay cả khi có lỗi thành phần xảy ra.

- **Ví dụ bán vé:** Hai người dùng cùng nhấn "Mua" chiếc vé cuối cùng vào cùng một thời điểm. Một kiến trúc **Reliable** phải đảm bảo tính toàn vẹn của giao dịch (**Transaction**): vé chỉ được bán cho một người, người còn lại không bị trừ tiền oan.

**Các cơ chế xây dựng Reliability:**
- `**Retry**`: Thử lại khi gặp lỗi tạm thời (như chập chờn kết nối).
- `**Timeout**`: Giới hạn thời gian chờ phản hồi để tránh treo luồng xử lý.
- `**Circuit Breaker**`: Tự động ngắt kết nối đến một dịch vụ đang gặp lỗi liên tục để bảo vệ hệ thống chung.
- `**Replication**`: Sao lưu dữ liệu/dịch vụ ra nhiều bản sao để tránh điểm chết duy nhất (Single Point of Failure).
- `**Idempotency**`: Đảm bảo rằng việc thực hiện một yêu cầu nhiều lần (do retry hoặc lag) vẫn chỉ tạo ra một kết quả duy nhất.
- `**Monitoring & Alerting**`: Chủ động theo dõi và cảnh báo sớm các dấu hiệu bất thường.
- `**Backup / Recovery**`: Có quy trình khôi phục dữ liệu nhanh chóng khi xảy ra thảm họa.

**Các yếu tố nâng cao Reliability:**
- `**Rate Limiting**`: Giới hạn số lượng yêu cầu từ một khách hàng để tránh việc hệ thống bị quá tải cục bộ.
- `**Throttling**`: Khi hệ thống bắt đầu quá tải, chủ động từ chối hoặc làm chậm các yêu cầu ít quan trọng hơn (ví dụ: lấy gợi ý sản phẩm) để dành tài nguyên cho các tác vụ quan trọng nhất (như thanh toán).
- `**Graceful Degradation**`: Khi một dịch vụ phụ gặp sự cố, hệ thống tự động hạ cấp tính năng (ví dụ: tắt bộ tìm kiếm nâng cao, dùng tìm kiếm cơ bản hoặc trả về cache) thay vì báo lỗi toàn bộ trang web.
- `**Data Integrity Checks**`: Sử dụng Checksum/Hash để đảm bảo dữ liệu không bị hỏng hóc trong quá trình truyền tải hoặc lưu trữ.
- `**Self-Healing**`: Hệ thống tự động phát hiện và khởi động lại các thành phần bị lỗi (ví dụ: Pod Liveness check trong **K8s**).

**Chiến lược triển khai an toàn:**
- `**Canary Deployment**`: Chỉ triển khai code mới cho một nhóm nhỏ người dùng (ví dụ 1%). Nếu không có lỗi phát sinh mới phổ biến cho toàn bộ hệ thống.
- `**Chaos Engineering**`: Chủ động tạo ra các lỗi giả lập (sập server, ngắt mạng) ở môi trường Staging/Production để kiểm tra khả năng phục hồi của hệ thống.

### 4. Consistency (Tính nhất quán)

Nguyên tắc đảm bảo dữ liệu luôn đồng nhất trên mọi node trong hệ thống phân tán tại cùng một thời điểm.

- **Ví dụ xung đột:** Sau khi chuyển tiền, số dư phải được cập nhật đồng nhất ngay lập tức. Nếu người dùng xem số dư từ hai máy chủ khác nhau mà nhận được hai kết quả khác nhau (Inconsistency), đó là lỗi nghiêm trọng.
- **Strong Consistency:** Đảm bảo mọi giao dịch đọc sau khi ghi đều nhận được dữ liệu mới nhất. Đây là yêu cầu bắt buộc đối với các hệ thống tài chính (**Banking**, **Payment**).

## IV. Hai chỉ số vàng: Latency & Throughput

Để định lượng hiệu năng thực tế của hệ thống dựa trên các quy tắc kiến trúc trên, chúng ta sử dụng hai chỉ số quan trọng mang tính kỹ thuật cao.

### 1. Latency (Độ trễ)

Latency là tổng thời gian từ lúc người dùng gửi yêu cầu đến khi nhận được phản hồi từ hệ thống.
`Latency = Thời gian truyền tải qua mạng + Thời gian xử lý tại Server.`

- **Các yếu tố làm tăng Latency:**
    - `**Network latency**`: Độ trễ do khoảng cách địa lý và chất lượng hạ tầng mạng.
    - `**Processing latency**`: Thời gian thực thi mã nguồn và các thuật toán tại máy chủ.
    - `**Disk latency**`: Tốc độ đọc/ghi dữ liệu của ổ cứng và Database.
    - `**Queue latency**`: Thời gian yêu cầu phải nằm chờ trong hàng đợi khi hệ thống bận.

- **Phương pháp đo lường thực tế:** Cần quan tâm đến các giá trị Worst-case thay vì giá trị trung bình đơn thuần.
    - `**P50 (Median)**`: Mức trễ mà một nửa số người dùng gặp phải.
    - `**P95 / P99**`: Cực kỳ quan trọng để đo trải nghiệm của những người dùng gặp trễ lớn nhất. Ví dụ: `P99 = 500ms` nghĩa là 99% yêu cầu được xử lý trong dưới 500ms.

- **Các cách tối ưu Latency:**
    - `**Cache (Redis)**`: Truy xuất dữ liệu từ RAM thay vì Disk.
    - `**Database Indexing**`: Tăng tốc độ tìm kiếm dữ liệu.
    - `**Optimize queries**`: Chỉ truy vấn các trường dữ liệu cần thiết, tránh lãng phí tài nguyên.
    - `**Async processing**`: Sử dụng xử lý bất đồng bộ để không chặn luồng yêu cầu chính.
    - `**CDN**`: Đưa dữ liệu đến gần người dùng hơn về mặt địa lý.

### 2. Throughput (Thông lượng)

Throughput là số lượng yêu cầu mà hệ thống có thể xử lý thành công trong một đơn vị thời gian (thường tính bằng Requests Per Second - RPS).

- 100 RPS: Phù hợp cho các ứng dụng quy mô nhỏ hoặc đang phát triển.
- 10.000 RPS: Yêu cầu chuẩn mực cho các hệ thống doanh nghiệp lớn và thực chiến.

### 3. Mối liên hệ giữa Latency và Throughput

Một sai lầm phổ biến là cho rằng việc giảm Latency sẽ mặc định làm tăng Throughput.
- Thực tế: Một hệ thống có thể xử lý từng yêu cầu rất nhanh (**Latency thấp**) nhưng lại không thể chịu tải được nhiều yêu cầu cùng lúc do giới hạn về băng thông hoặc tài nguyên (**Throughput thấp**).
- Mục tiêu thiết kế: Một kiến trúc hệ thống tốt phải cân được cả hai – duy trì phản hồi nhanh ngay cả khi chịu tải lớn.

# references
## 0
### alias
System Design Basics
### url
https://github.com/donnemartin/system-design-primer

# minutesRead
20