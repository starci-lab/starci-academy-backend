# title
System Design Process

# description
Master a methodical four-step process for system design: clarify requirements, estimate scale, sketch high-level architecture, and deep-dive into bottlenecks.

# body

## I. Introduction

The biggest mistake many developers make when facing a large system problem is jumping straight into code or selecting the "hottest" technologies (**Kafka**, **Kubernetes**, **Microservices**) before clearly understanding the actual problem they are solving. This **"build as you go"** mindset often leads to patched-together architectures that are difficult to scale and waste resources.

Imagine an interview question: "Design an e-commerce system that handles **50,000 concurrent users** during a flash sale." If your first instinct is **"Use Kafka, split into Microservices, deploy on K8s"** then you have already failed at step one — because you don't know what the system needs, how large it will be, or what will break first.

**System Design** is not a technology knowledge quiz — it is a methodical problem-solving process. If code consists of individual bricks, then **System Design** is the **architectural blueprint**. A poorly drawn blueprint leads to a building that collapses at the first gust of wind. This lesson provides a standardized four-step thinking framework to approach any design problem.

## II. Step-by-step Design Walkthrough

We use an **E-commerce** system in real-world flash sale scenarios to observe system behavior.


### 1. Requirements Clarification
The most common mistake in design is starting to build before fully understanding the destination. You need to take time to clarify three groups of questions:

- **Functional Requirements:** Define the core features users can perform.
    - Example: Users must be able to **view products**, **add them to a cart**, and **complete payment**.

- **Non-functional Requirements:** The quality standards the system must meet.
    - Example: **High availability**, payment latency under **500ms**, handling **50,000 concurrent requests** during peak promotional events.

- **Out of Scope:** Clearly identify what the system **will not** do to avoid **over-engineering**.
    - Example: This system does not handle **refunds** — that is a separate module to be built later.

**Expected Result**

After this step you must have a clear list: what the system does, what it doesn't do, and what quality expectations look like. Without this list, every subsequent step is built on sand.

### 2. Back-of-the-envelope Estimation
You cannot choose a **Database** or **Server** type without knowing how large the system will be. Estimation helps you understand the "pressure" the system will face.

- **Traffic:** Estimate **DAU** (Daily Active Users), **Average QPS**, and **Peak QPS**.
    - Example: 1 million **DAU**, each placing 0.1 orders/day → ~**1.2 QPS** average, Peak can be 10x = **12 QPS**.

- **Storage:** Estimate the data volume needed over time (typically per year).
    - Example: Each order is **10KB**, 100,000 orders/day → **1GB/day** → **365GB/year**.

- **Bandwidth:** Estimate data in/out to design the network infrastructure.
    - Estimation results might indicate you need a **write-intensive** **Database** rather than optimizing purely for read speed.

**Expected Result**

You now have a rough set of numbers: how many **QPS**, how many **GB/year**, whether the system is **read-heavy** or **write-heavy**. These numbers determine how many servers you need and what type of **Database** to use.

### 3. High-Level Design (HLD)
This phase involves sketching the overall **"map"** of the system by drawing the major functional blocks and how they interact.

- **Example:** Request flow from **Client** to **Database** for an **E-commerce** system:
    - **Client** (Mobile App / Browser) sends a request.
    - **Load Balancer** distributes it to **Web Servers**.
    - **Web Server** checks **Redis Cache** first — if it's a **cache hit**, it returns immediately.
    - If it's a **cache miss**, it queries the main **MySQL Database**.
    - The result is then saved to the cache for subsequent requests.

**Expected Result**

You have an architecture diagram with the major components: **Client** → **Load Balancer** → **Web Server** → **Cache** / **Database**. This diagram is the foundation for the next step to find weaknesses.

### 4. Deep Dive & Bottlenecks
After creating the skeleton, focus on the most critical components to identify **bottlenecks** and propose solutions:

- **Example 1: Database read overload** — Add **Read Replicas** to share the load from the **Primary**; or use **Sharding** if data grows too large for one server.

- **Example 2: Heavy tasks blocking requests** — Push confirmation **email sending** into a **Job Queue** (**Kafka**) for **async** processing, avoiding slowdowns in the main request flow.

- **Example 3: Slow media delivery** — Use a **CDN** to distribute images/videos from points closest to users, significantly reducing **Latency**.

**Expected Result**

Every component on the diagram has been evaluated. You know exactly what will break first when load increases, and you have a plan for each point.

After these four steps, you have a complete design from requirements to architecture. But one big question remains: **which technology** to use for each component? Every choice has a cost — and that is the topic of the next section.

## III. The Art of Tech Selection and Architectural Thinking

### 1. Every Decision Comes with a Trade-off
No technology is "best" for every case. Here are the most common examples:

- **Example 1: SQL vs. NoSQL?**
    - Choose **SQL** (MySQL, PostgreSQL): When the system requires **ACID transactions** and **Strong Consistency** (**E-commerce**, **Banking**). Trade-off: harder to **scale horizontally**, performance drops with massive data.
    - Choose **NoSQL** (MongoDB, Cassandra): For flexible data requiring high **horizontal scalability** (Feed, Logs, Chat). Trade-off: only achieves **Eventual Consistency**; consistency must be handled at the application layer.

- **Example 2: Use Cache (Redis) or not?**
    - Use **Cache**: Dramatically reduces **Latency** for **hot data** (Profile, Product Detail). Trade-off: data can become **stale** and **Cache Invalidation** is notoriously difficult.

- **Example 3: Sync or Async (Message Queue)?**
    - Use **Async** (**Kafka**): Increases **Throughput**, avoids blocking the main flow. Trade-off: increases actual end-to-end **Latency**, harder to debug, requires handling **retry/duplicate** scenarios.

- **Example 4: Monolith vs. Microservices?**
    - **Monolith**: Easier to develop and deploy initially. Trade-off: hard to scale individual parts as the team and project grow.
    - **Microservices**: Independent scaling per **service**, teams work in parallel. Trade-off: complex **network** infrastructure, **data consistency** challenges, requires strong infra management (**Kubernetes**).

### 2. Architectural Thinking: Numbers and Process, Not Intuition
The system design process is not a rigid template but a **continuous loop**: Design → Evaluate Trade-offs → Refine based on real-world business needs.

A great engineer is not the one who knows the most technologies, but the one who clearly knows **why** they chose one solution over another — grounded in specific **estimation numbers** and a **clear process** — and is always ready to adjust as the system scale changes.

# references
## 0
### alias
System Design Interview Framework
### url
https://github.com/donnemartin/system-design-primer#how-to-approach-a-system-design-interview-question

# minutesRead
15