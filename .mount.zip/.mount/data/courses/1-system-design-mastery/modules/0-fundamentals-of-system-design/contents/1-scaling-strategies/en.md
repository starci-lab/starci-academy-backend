# title
Scaling Strategies: Vertical vs Horizontal

# description
Explore the differences between Vertical Scaling (Scaling Up) and Horizontal Scaling (Scaling Out) to build high-scale, resilient systems.

# body

## I. Introduction

Imagine you are sitting in a Senior Backend interview. The interviewer asks a trick question: "The system is running stable but suddenly slows down when traffic spikes 10x during peak hours. How would you handle it?" If the first answer that comes to your mind is, "I would upgrade that server to the most powerful version, adding lots of RAM and CPU," then unfortunately, you've fallen into the trap of a **monolithic** mindset.

To answer this question, you need to understand **Horizontal Scaling**. Read more to find out.

## II. Vertical Scaling (Scaling Up)

This is the act of upgrading the resources (CPU, RAM, Disk) of an existing server. Imagine upgrading from an office PC to a dedicated "super-server."

**Pros:**
- **Easy to implement:** Usually just involves changing the configuration on the Cloud or adding more hardware components.
- **No architectural changes:** Your code still runs on a single server, so you don't have to worry about synchronization between servers.

**Cons (The Technology Ceiling):**
- **Hardware ceiling:** No matter how much money you have, a single server has limits on the number of RAM slots and CPU cores.
- **Single Point of Failure (SPOF):** If that "super-server" blows a power supply or fails its hard drive, the entire system crashes.
- **Non-linear costs:** Upgrading from 128GB RAM to 256GB RAM can be several times more expensive than buying two 128GB machines.

## III. Horizontal Scaling (Scaling Out)

Instead of upgrading one machine, you add multiple mid-range servers to the system and share the load between them. This is how giants like Google, Netflix, or Shopee operate.

**Pros:**
- **Infinite scalability:** You can add 10, 100, or 10,000 machines depending on traffic volume.
- **High Availability:** One machine fails? No problem, other machines are still running and picking up the slack.
- **Cost optimization:** You can use many cheap servers to achieve performance equivalent to a single ultra-expensive machine.

**Challenges:**
- Needs a **Load Balancer** to coordinate traffic.
- Requires the application to be designed as **Stateless** (does not store user data locally on the server).

## IV. Comparison Table

| Feature | Vertical Scaling (Scale Up) | Horizontal Scaling (Scale Out) |
| :--- | :--- | :--- |
| **Action** | Upgrade CPU/RAM of the old machine. | Add new machines to the cluster. |
| **Limit** | Restricted by physical hardware. | Near-infinite. |
| **Reliability** | Low (Full system crash risk). | High (System stays up even if nodes fail). |
| **Complexity** | Low (No code changes needed). | High (Needs Load Balancer, data sync). |
| **Cost** | Increases sharply at high-end tiers. | Increases linearly with the number of machines. |

## V. Architectural Insight

To survive "Flash Sales" worth billions, your mindset must shift from *"how to keep this machine from crashing"* to *"how to keep the system running even when this machine crashes."*

In modern system design, we often apply a cost model:

$$Cost_{Vertical} = f(Resource^n)$$
*(With $n > 1$, meaning the higher the resources, the more the cost skyrockets)*

Meanwhile:
$$Cost_{Horizontal} \approx k \times NumberOfNodes$$
*(Costs increase steadily and are more predictable)*

**Bottom Line:** If you are building a small project, Vertical Scaling is a quick and clean choice. But if your ambition is for systems serving millions of users, Horizontal Scaling is the only way to break through physical limitations.

# references
## 0
### alias
System Design Primer - Scaling
### url
https://github.com/donnemartin/system-design-primer#bottlenecks

# minutesRead
10