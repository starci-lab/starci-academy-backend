# title
Định lý CAP và Sự đánh đổi trong Hệ thống phân tán

# description
Tìm hiểu Định lý CAP để hiểu vì sao hệ thống phân tán không thể đạt đồng thời ba yếu tố Nhất quán (Consistency), Sẵn sàng (Availability) và Chịu lỗi mạng (Partition Tolerance), từ đó đưa ra quyết định kiến trúc phù hợp.

# body

## I. Lời mở đầu

Trong một thế giới lý tưởng, chúng ta luôn muốn hệ thống vừa phản hồi nhanh, vừa hoạt động 24/7, và dữ liệu phải tuyệt đối chính xác ở mọi nơi. Tuy nhiên, khi hệ thống mở rộng sang nhiều máy chủ giao tiếp qua mạng internet, thực tế cho thấy mạng có thể bị đứt, máy chủ có thể treo và dữ liệu cần thời gian để truyền tải. 

**Định lý CAP** (**CAP Theorem**) được sinh ra để giúp các kỹ sư hiểu rõ những giới hạn vật lý này, từ đó học cách đưa ra những lựa chọn kiến trúc thông minh thay vì theo đuổi một giải pháp hoàn hảo không tồn tại.

## II. Ba đặc tính cốt lõi của Định lý CAP

Định lý CAP khẳng định rằng một hệ thống máy tính phân tán chỉ có thể đảm bảo tối đa hai trong ba đặc tính sau cùng một lúc:

- **Tính Nhất quán** (**Consistency - C**): Mọi yêu cầu đọc từ bất kỳ máy chủ (**node**) nào cũng đều nhận được dữ liệu mới nhất hoặc nhận về thông báo lỗi. Nếu dữ liệu chưa kịp đồng bộ trên toàn hệ thống, hệ thống thà từ chối phục vụ chứ tuyệt đối không trả về dữ liệu cũ.
- **Tính Sẵn sàng** (**Availability - A**): Mọi yêu cầu gửi đến hệ thống đều nhận được phản hồi (không bị lỗi hoặc timeout), ngay cả khi một số node trong hệ thống đang gặp sự cố. Trọng tâm của đặc tính này là hệ thống luôn hoạt động và phục vụ người dùng liên tục.
- **Khả năng chịu lỗi mạng** (**Partition Tolerance - P**): Hệ thống vẫn tiếp tục hoạt động bình thường ngay cả khi kết nối mạng giữa các node bị đứt gãy, mất gói tin hoặc chậm trễ (tạo ra các "vách ngăn" chia cắt hệ thống thành nhiều phần độc lập).

## III. Thực tế thiết kế: Sự đánh đổi giữa CP và AP

Trong môi trường mạng internet thực tế, sự cố mất kết nối giữa các máy chủ là điều chắc chắn sẽ xảy ra. Do đó, mọi hệ thống phân tán đều bắt buộc phải hỗ trợ **Khả năng chịu lỗi mạng** (chữ **P**). Bài toán thiết kế lúc này chỉ còn là sự đánh đổi giữa **Consistency (C)** và **Availability (A)**.

### 1. Hệ thống CP (Consistency + Partition Tolerance)
Khi kết nối mạng giữa các node bị đứt, hệ thống sẽ ưu tiên tính chính xác của dữ liệu.
- **Hành vi:** Hệ thống sẽ từ chối các yêu cầu đọc/ghi (chấp nhận hy sinh tính **Availability**) cho đến khi mạng được khôi phục và dữ liệu đồng bộ xong.
- **Ví dụ ứng dụng:** Hệ thống giao dịch ngân hàng, máy ATM. Nếu mạng nội bộ gián đoạn, ATM sẽ báo lỗi không thể giao dịch thay vì cho phép rút tiền dựa trên số dư cũ.
- **Công nghệ tiêu biểu:** **MongoDB**, **Redis**, **HBase**, **ZooKeeper**.

### 2. Hệ thống AP (Availability + Partition Tolerance)
Khi mạng bị đứt, hệ thống vẫn tiếp tục phục vụ người dùng để đảm bảo trải nghiệm xuyên suốt.
- **Hành vi:** Hệ thống chấp nhận trả về dữ liệu có thể bị cũ (hy sinh tính **Consistency** tuyệt đối) để giữ cho dịch vụ không bị gián đoạn. Dữ liệu sẽ tự đồng bộ lại khi mạng ổn định (**Eventual Consistency** - Nhất quán cuối cùng).
- **Ví dụ ứng dụng:** Lượt Like/Comment trên mạng xã hội. Bạn có thể thấy bài viết có 100 Like, trong khi máy người khác hiển thị 98 Like, hệ thống vẫn hoạt động bình thường mà không gây ảnh hưởng nghiêm trọng.
- **Công nghệ tiêu biểu:** **Cassandra**, **DynamoDB**, **CouchDB**.

## IV. Tổng kết

**Định lý CAP** không phải là một rào cản, mà là kim chỉ nam giúp định hướng kiến trúc một cách thực tế. Việc thiết kế hệ thống là nghệ thuật của sự đánh đổi. 

Hiểu rõ khi nào cần dữ liệu chính xác tuyệt đối (chọn **CP**) và khi nào cần duy trì dịch vụ liên tục (chọn **AP**) là kỹ năng bắt buộc của một kiến trúc sư phần mềm.

# references
## 0
### alias
CAP Theorem Simplified
### url
https://en.wikipedia.org/wiki/CAP_theorem

# minutesRead
15