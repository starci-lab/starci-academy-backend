# title
Thiết kế hệ thống đặt vé với phân tích trade-off giữa các trụ cột

# description
Thiết kế hệ thống đặt vé sự kiện (ticket booking) cho một sự kiện lớn với 50.000 người truy cập đồng thời. Phân tích trade-off giữa 4 trụ cột (Scalability, Reliability, Availability, Consistency) và xây dựng một demo NestJS cơ bản minh họa các quyết định thiết kế.

# requirements
Viết tài liệu thiết kế hệ thống đặt vé sự kiện bao gồm: phân tích yêu cầu về 4 trụ cột cho từng thành phần (Booking Service, Payment Service, Seat Inventory, Notification Service); giải thích tại sao Seat Inventory cần strong consistency (tránh bán trùng vé); làm rõ cách Scalability ảnh hưởng đến Consistency khi scale horizontal. Đồng thời xây dựng một NestJS app đơn giản mô phỏng luồng đặt vé với cơ chế kiểm tra số lượng vé (seat locking) để chứng minh vấn đề consistency.

# prerequisites
- Kiến thức về 4 trụ cột của thiết kế hệ thống
- Hiểu các chỉ số Latency và Throughput
- Node.js >= 18
- NestJS CLI
- Docker (không bắt buộc nhưng khuyến khích)

# steps

## 0
### title
Phân tích yêu cầu hệ thống đặt vé
### body
- **Các bước thực hiện:**
  - Bước 1: Xác định các thành phần chính của hệ thống: Booking Service, Payment Service, Seat Inventory Service, Notification Service.
  - Bước 2: Với mỗi thành phần, phân tích yêu cầu về 4 trụ cột:
    - **Seat Inventory**: Consistency cao nhất (không bán trùng vé).
    - **Booking Service**: Availability cao (người dùng luôn đặt được vé nếu còn).
    - **Payment Service**: Reliability cao (không mất giao dịch).
    - **Notification Service**: Availability cao, Consistency thấp (gửi thông báo có thể trễ).
  - Bước 3: Xác định chỉ số Latency mục tiêu: < 2 giây cho toàn bộ luồng đặt vé.
  - Bước 4: Ước tính Throughput: 50.000 người dùng đồng thời, tỷ lệ đặt vé 10% = 5.000 request đặt vé trong 1 phút = ~83 request/giây.
- **Kết quả mong đợi:** Tài liệu phân tích yêu cầu đầy đủ với bảng tổng hợp các thuộc tính ưu tiên cho từng thành phần.
- **Kết luận:** Hệ thống đặt vé đòi hỏi sự cân bằng phức tạp giữa các thuộc tính, đặc biệt là Consistency cho Seat Inventory.

## 1
### title
Phân tích trade-off và quyết định thiết kế
### body
- **Các bước thực hiện:**
  - Bước 1: Trình bày trade-off giữa **Consistency** và **Availability** cho Seat Inventory: dùng pessimistic locking đảm bảo không bán trùng nhưng giảm Throughput.
  - Bước 2: Trình bày trade-off giữa **Scalability** và **Consistency**: khi chạy nhiều instance của Booking Service, cần cơ chế đồng bộ trạng thái vé giữa các instance.
  - Bước 3: Đề xuất giải pháp: sử dụng database-level locking (SELECT FOR UPDATE) cho Seat Inventory để đảm bảo Consistency mà không cần distributed lock phức tạp.
  - Bước 4: Giải thích tại sao Notification Service có thể dùng message queue (eventual consistency) để tăng Availability và Scalability.
- **Kết quả mong đợi:** Tài liệu trình bày các quyết định thiết kế với lý do kỹ thuật rõ ràng, thể hiện sự hiểu biết về trade-off.
- **Kết luận:** Mỗi quyết định thiết kế là một sự đánh đổi có chủ đích, cần ghi nhận rõ ràng để team phát triển hiểu và duy trì.

## 2
### title
Xây dựng NestJS demo minh họa consistency
### body
- **Các bước thực hiện:**
  - Bước 1: Khởi tạo project NestJS:
    ```bash
    nest new core-concepts-and-metrics-medium
    ```
  - Bước 2: Tạo `SeatModule` với `SeatService` quản lý danh sách vé (có thể dùng mảng in-memory hoặc SQLite).
  - Bước 3: Tạo endpoint `POST /seats/book/:seatId` thực hiện đặt vé. Trong `SeatService`, implement cơ chế kiểm tra và cập nhật trạng thái vé.
  - Bước 4: Mô phỏng vấn đề race condition: nếu không có locking, hai request đồng thời có thể đặt cùng một vé. Ghi log để chứng minh vấn đề.
  - Bước 5: Thêm cơ chế locking đơn giản (mutex hoặc synchronized access) để giải quyết vấn đề và chứng minh consistency.
- **Kết quả mong đợi:** Demo NestJS hoạt động, có thể chạy 2 request đồng thời và chứng minh được vấn đề race condition trước khi có locking, và consistency sau khi có locking.
- **Kết luận:** Demo thực tế minh họa tại sao Consistency là yếu tố quan trọng trong hệ thống đặt vé.

## 3
### title
Kiểm thử và hoàn thiện
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Kiểm tra luồng đặt vé thành công:
    ```bash
    curl -X POST http://localhost:3000/seats/book/1
    ```
  - Bước 3: Kiểm tra luồng đặt vé đã được đặt (consistency):
    ```bash
    curl -X POST http://localhost:3000/seats/book/1
    ```
    Xác nhận trả về lỗi cho biết vé đã được đặt.
  - Bước 4: Hoàn thiện tài liệu Google Docs với cấu trúc: (1) Phân tích yêu cầu, (2) Trade-offs và quyết định thiết kế, (3) Mô tả demo và kết quả, (4) Kết luận.
- **Kết quả mong đợi:** Demo hoạt động đúng, tài liệu đầy đủ và nhất quán với implementation.
- **Kết luận:** Challenge hoàn thành khi cả tài liệu thiết kế và demo đều thể hiện sự hiểu biết về trade-off giữa các thuộc tính hệ thống.

# references
## 0
### alias
Designing Data-Intensive Applications - Consistency and Consensus
### url
https://dataintensive.net/
## 1
### alias
System Design Primer - Consistency Patterns
### url
https://github.com/donnemartin/system-design-primer#consistency-patterns
## 2
### alias
NestJS Documentation
### url
https://docs.nestjs.com/

# submissions
## 0
### type
googleDocsUrl
### title
Link Google Docs tài liệu thiết kế
### description
Nộp link Google Docs chứa tài liệu phân tích trade-off và quyết định thiết kế cho hệ thống đặt vé.
### score
15
### prompts
#### 0
##### title
Phân tích đầy đủ 4 trụ cột cho từng thành phần
##### score
8
##### promptText
Tài liệu phân tích đầy đủ Scalability, Reliability, Availability, Consistency cho từng thành phần (Booking, Payment, Seat Inventory, Notification) với lý do rõ ràng.
#### 1
##### title
Trade-off và quyết định thiết kế
##### score
7
##### promptText
Trình bày rõ các trade-off giữa các trụ cột, đặc biệt là Consistency vs Availability cho Seat Inventory, và đề xuất giải pháp cụ thể.
## 1
### type
githubUrl
### title
Link GitHub Repository demo NestJS
### description
Nộp link GitHub repository chứa source code demo NestJS minh họa cơ chế consistency trong đặt vé.
### score
15
### prompts
#### 0
##### title
Demo đặt vé cơ bản
##### score
8
##### promptText
Ứng dụng NestJS có endpoint đặt vé hoạt động đúng, có SeatModule và SeatService xử lý logic đặt vé.
#### 1
##### title
Minh họa consistency
##### score
7
##### promptText
Demo chứng minh được vấn đề race condition và giải pháp locking, vé đã đặt không thể đặt lại.

# difficulty
medium

# score
30
