# title
Analyze Scaling Strategies and Deploy a Basic Load Balancer

# description
Analyze the differences between Vertical Scaling and Horizontal Scaling for a specific scenario, then deploy a simple NestJS application running multiple replicas behind an Nginx load balancer using Docker Compose.

# requirements
Write a document analyzing when to use Vertical Scaling versus Horizontal Scaling for a product catalog API system with increasing traffic. Additionally, create a NestJS app with Docker Compose running 3 replicas behind Nginx as a load balancer. Each instance must return a unique ID to prove requests are distributed.

# prerequisites
- Knowledge of Vertical Scaling and Horizontal Scaling
- Understanding of Load Balancer concepts
- Node.js >= 18
- NestJS CLI
- Docker and Docker Compose

# steps

## 0
### title
Analyze Scaling strategies for a product catalog system
### body
- **Steps to follow:**
  - Step 1: Describe the scenario: a product catalog API system starting at 100 requests/second, expected to grow to 10,000 requests/second within 6 months.
  - Step 2: Analyze **Vertical Scaling**: increase CPU/RAM on the current server. List advantages (simple, no code changes needed) and disadvantages (physical limits, single point of failure, non-linear cost increase).
  - Step 3: Analyze **Horizontal Scaling**: add more application instances. List advantages (nearly unlimited scaling, fault tolerance) and disadvantages (more complex session management, data consistency challenges).
  - Step 4: Provide a recommendation: use Vertical Scaling initially for simplicity, transition to Horizontal Scaling when hardware limits are reached or fault tolerance is needed.
- **Expected result:** A clear analysis document with a comparison table between the two strategies, including specific recommendations for the scenario.
- **Conclusion:** No Scaling strategy is universally optimal; the choice depends on the system's current stage and specific requirements.

## 1
### title
Initialize NestJS app and Dockerize
### body
- **Steps to follow:**
  - Step 1: Create the NestJS project:
    ```bash
    nest new scaling-strategies-easy
    ```
  - Step 2: Create endpoint `GET /info` in `AppController` returning JSON with `instanceId` (using environment variable `INSTANCE_ID` or `hostname`).
  - Step 3: Create a `Dockerfile` for the NestJS application:
    ```dockerfile
    FROM node:18-alpine
    WORKDIR /app
    COPY package*.json ./
    RUN npm ci
    COPY . .
    RUN npm run build
    CMD ["node", "dist/main"]
    ```
  - Step 4: Build and test a single container:
    ```bash
    docker build -t scaling-strategies-easy .
    docker run -p 3000:3000 scaling-strategies-easy
    ```
- **Expected result:** The NestJS application runs inside a Docker container, endpoint `GET /info` returns instance information.
- **Conclusion:** The application is ready to be deployed as multiple replicas behind a load balancer.

## 2
### title
Configure Docker Compose with Nginx Load Balancer
### body
- **Steps to follow:**
  - Step 1: Create a `docker-compose.yml` file with 3 replicas of the NestJS application and 1 Nginx service.
  - Step 2: Configure each replica with a different `INSTANCE_ID` environment variable (e.g., `app-1`, `app-2`, `app-3`).
  - Step 3: Create an `nginx.conf` file configuring upstream with 3 backends using round-robin algorithm (default):
    ```nginx
    upstream backend {
        server app1:3000;
        server app2:3000;
        server app3:3000;
    }
    server {
        listen 80;
        location / {
            proxy_pass http://backend;
        }
    }
    ```
  - Step 4: Start the entire system:
    ```bash
    docker-compose up --build
    ```
- **Expected result:** 3 NestJS instances and 1 Nginx are all running successfully, Nginx listens on port 80.
- **Conclusion:** A basic Horizontal Scaling architecture has been established with a load balancer distributing requests.

## 3
### title
Test load distribution and finalize documentation
### body
- **Steps to follow:**
  - Step 1: Send multiple consecutive requests to the endpoint through Nginx:
    ```bash
    for i in $(seq 1 9); do curl http://localhost/info; echo; done
    ```
  - Step 2: Observe the results: `instanceId` should alternate between `app-1`, `app-2`, `app-3` (round-robin).
  - Step 3: Stop 1 instance and continue sending requests, confirm Nginx automatically routes requests to the remaining instances.
  - Step 4: Add test results to the Google Docs document, including screenshots or log output.
- **Expected result:** Requests are evenly distributed across instances; when 1 instance is down, the remaining instances continue serving.
- **Conclusion:** The Load Balancer ensures load distribution and increases fault tolerance for the horizontal scaling system.

# references
## 0
### alias
System Design Primer - Scalability
### url
https://github.com/donnemartin/system-design-primer#scalability
## 1
### alias
Nginx Load Balancing Documentation
### url
https://docs.nginx.com/nginx/admin-guide/load-balancer/http-load-balancer/
## 2
### alias
Docker Compose Documentation
### url
https://docs.docker.com/compose/

# submissions
## 0
### type
googleDocsUrl
### title
Google Docs Scaling Analysis Link
### description
Submit the Google Docs link containing the Vertical vs Horizontal Scaling analysis and load balancer test results.
### score
10
### prompts
#### 0
##### title
Vertical vs Horizontal Scaling analysis
##### score
5
##### promptText
The document fully analyzes advantages and disadvantages of Vertical and Horizontal Scaling with a specific scenario, includes a comparison table and recommendations.
#### 1
##### title
Load distribution test results
##### score
5
##### promptText
Includes test results proving requests are distributed across instances and the system continues operating when 1 instance is down.
## 1
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing the NestJS app source code with Docker Compose and Nginx load balancer.
### score
10
### prompts
#### 0
##### title
NestJS app with Docker Compose
##### score
5
##### promptText
The project has a Dockerfile, docker-compose.yml with 3 NestJS replicas and Nginx, endpoint `GET /info` returns instanceId.
#### 1
##### title
Nginx load balancer works correctly
##### score
5
##### promptText
Nginx is configured with correct upstream using round-robin, requests sent through port 80 are distributed to backend instances.

# difficulty
easy

# score
20
