# title
Phân tích các thuộc tính hệ thống và chỉ số hiệu năng

# description
Phân tích một kịch bản hệ thống thực tế, xác định các thuộc tính hệ thống (Scalability, Reliability, Availability, Consistency) và các chỉ số hiệu năng (Latency, Throughput) áp dụng cho kịch bản đó. Viết tài liệu Google Docs trình bày phân tích chi tiết.

# requirements
Cho một kịch bản cụ thể: một ứng dụng đặt món ăn trực tuyến (food delivery) đang phục vụ 10.000 người dùng đồng thời vào giờ cao điểm. Phân tích và giải thích: thuộc tính nào trong 4 trụ cột (Scalability, Reliability, Availability, Consistency) là quan trọng nhất và tại sao; các chỉ số Latency và Throughput nên được đo lường ở đâu trong hệ thống; mối quan hệ giữa các thuộc tính và cách chúng ảnh hưởng lẫn nhau.

# prerequisites
- Kiến thức cơ bản về kiến trúc hệ thống phân tán
- Hiểu các khái niệm Scalability, Reliability, Availability, Consistency
- Hiểu các chỉ số Latency và Throughput

# steps

## 0
### title
Phân tích kịch bản và xác định các thuộc tính hệ thống
### body
- **Các bước thực hiện:**
  - Bước 1: Đọc kỹ kịch bản hệ thống đặt món ăn trực tuyến với 10.000 người dùng đồng thời vào giờ cao điểm.
  - Bước 2: Liệt kê các thành phần chính của hệ thống (API Gateway, Order Service, Payment Service, Notification Service, Database).
  - Bước 3: Với mỗi thành phần, xác định thuộc tính nào trong 4 trụ cột là ưu tiên cao nhất. Ví dụ: Payment Service cần **Consistency** cao, còn Notification Service cần **Availability** cao.
  - Bước 4: Giải thích lý do chọn ưu tiên cho mỗi thành phần bằng 2-3 câu.
- **Kết quả mong đợi:** Bảng phân tích các thành phần hệ thống với thuộc tính ưu tiên tương ứng và lý do giải thích rõ ràng.
- **Kết luận:** Mỗi thành phần trong hệ thống có yêu cầu khác nhau về các thuộc tính, không có một cấu hình duy nhất phù hợp cho toàn bộ.

## 1
### title
Phân tích chỉ số Latency và Throughput
### body
- **Các bước thực hiện:**
  - Bước 1: Xác định các điểm đo Latency quan trọng trong luồng đặt món: từ lúc người dùng nhấn nút đặt món đến khi nhận được xác nhận.
  - Bước 2: Phân tích Throughput cần thiết: hệ thống cần xử lý bao nhiêu đơn hàng mỗi giây vào giờ cao điểm (10.000 người dùng đồng thời, ước tính tỷ lệ đặt món).
  - Bước 3: Chỉ ra mối quan hệ giữa Latency và Throughput: khi Throughput tăng, Latency có xu hướng tăng do tài nguyên bị chia sẻ.
  - Bước 4: Đề xuất ngưỡng chấp nhận được cho Latency (ví dụ: < 500ms cho việc đặt món) và Throughput (ví dụ: >= 100 đơn/giây).
- **Kết quả mong đợi:** Phân tích cụ thể với số liệu ước tính cho Latency và Throughput tại các điểm đo trong hệ thống.
- **Kết luận:** Latency và Throughput là hai chỉ số bổ sung cho nhau, cần được đo lường và tối ưu tại các điểm nghẽn cổ (bottleneck) của hệ thống.

## 2
### title
Phân tích mối quan hệ giữa các thuộc tính
### body
- **Các bước thực hiện:**
  - Bước 1: Trình bày mối quan hệ giữa **Availability** và **Consistency**: khi tăng Consistency (ví dụ: synchronous replication), Availability có thể giảm do phải chờ tất cả các node đồng bộ.
  - Bước 2: Trình bày mối quan hệ giữa **Scalability** và **Consistency**: khi scale horizontal, việc đảm bảo Consistency trở nên phức tạp hơn.
  - Bước 3: Đưa ra ví dụ cụ thể trong kịch bản food delivery: nếu Payment Service dùng strong consistency, thì phần Order Service có thể dùng eventual consistency để tăng Availability.
  - Bước 4: Tổng hợp thành một sơ đồ hoặc bảng thể hiện các trade-off giữa các thuộc tính.
- **Kết quả mong đợi:** Tài liệu trình bày rõ các trade-off giữa các thuộc tính hệ thống với ví dụ cụ thể từ kịch bản food delivery.
- **Kết luận:** Thiết kế hệ thống luôn đòi hỏi việc cân bằng giữa các thuộc tính, không thể tối ưu tất cả cùng lúc.

## 3
### title
Hoàn thiện tài liệu và kiểm tra
### body
- **Các bước thực hiện:**
  - Bước 1: Tổng hợp tất cả phân tích vào một Google Docs duy nhất với cấu trúc rõ ràng: (1) Giới thiệu kịch bản, (2) Phân tích thuộc tính hệ thống, (3) Phân tích chỉ số hiệu năng, (4) Trade-offs, (5) Kết luận.
  - Bước 2: Đảm bảo mỗi phần có tiêu đề rõ ràng, số liệu cụ thể (nếu có), và kết luận ngắn gọn.
  - Bước 3: Kiểm tra lại toàn bộ tài liệu: không thiếu thuộc tính nào trong 4 trụ cột, cả 2 chỉ số Latency và Throughput đều được phân tích.
- **Kết quả mong đợi:** Tài liệu Google Docs hoàn chỉnh, có cấu trúc logic, phủ toàn bộ 4 thuộc tính và 2 chỉ số.
- **Kết luận:** Tài liệu thể hiện khả năng phân tích hệ thống có hệ thống, áp dụng đúng các khái niệm đã học vào kịch bản thực tế.

# references
## 0
### alias
Designing Data-Intensive Applications - Chapter 1
### url
https://dataintensive.net/
## 1
### alias
System Design Primer - Performance vs Scalability
### url
https://github.com/donnemartin/system-design-primer#performance-vs-scalability

# submissions
## 0
### type
googleDocsUrl
### title
Link Google Docs tài liệu phân tích
### description
Nộp link Google Docs chứa tài liệu phân tích các thuộc tính hệ thống và chỉ số hiệu năng cho kịch bản food delivery.
### score
20
### prompts
#### 0
##### title
Phân tích đầy đủ 4 thuộc tính hệ thống
##### score
8
##### promptText
Tài liệu phân tích đầy đủ Scalability, Reliability, Availability, Consistency cho từng thành phần hệ thống, có lý do giải thích rõ ràng.
#### 1
##### title
Phân tích chỉ số Latency và Throughput
##### score
6
##### promptText
Có phân tích cụ thể về Latency và Throughput với số liệu ước tính, xác định điểm đo và ngưỡng chấp nhận.
#### 2
##### title
Trade-offs giữa các thuộc tính
##### score
6
##### promptText
Trình bày rõ các trade-off giữa các thuộc tính với ví dụ cụ thể từ kịch bản, có sơ đồ hoặc bảng tổng hợp.

# difficulty
easy

# score
20
