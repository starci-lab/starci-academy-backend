# title
Áp dụng quy trình 4 bước để thiết kế URL Shortener

# description
Áp dụng quy trình thiết kế hệ thống 4 bước (làm rõ yêu cầu, ước lượng phong bì, thiết kế mức cao, phân tích bottleneck) để thiết kế một hệ thống rút gọn URL (URL Shortener). Viết tài liệu thiết kế hoàn chỉnh.

# requirements
Thiết kế hệ thống URL Shortener có khả năng xử lý 100 triệu URL mỗi tháng. Tài liệu phải tuân theo đúng 4 bước của quy trình thiết kế hệ thống: (1) Làm rõ yêu cầu chức năng và phi chức năng; (2) Ước lượng back-of-envelope về lưu trữ, băng thông, và QPS; (3) Thiết kế mức cao với sơ đồ kiến trúc; (4) Phân tích bottleneck và đề xuất giải pháp. Mỗi bước phải có nội dung cụ thể, có số liệu và lý do kỹ thuật.

# prerequisites
- Hiểu quy trình thiết kế hệ thống 4 bước
- Kiến thức cơ bản về kiến trúc web (API, Database, Cache)
- Khả năng ước lượng cơ bản (back-of-envelope estimation)

# steps

## 0
### title
Bước 1 - Làm rõ yêu cầu (Requirements Clarification)
### body
- **Các bước thực hiện:**
  - Bước 1: Liệt kê **yêu cầu chức năng** (Functional Requirements):
    - Tạo short URL từ long URL.
    - Redirect từ short URL về long URL gốc.
    - Tùy chọn: custom alias, thời gian hết hạn (TTL), thống kê truy cập.
  - Bước 2: Liệt kê **yêu cầu phi chức năng** (Non-Functional Requirements):
    - Availability cao (99.9% uptime).
    - Latency thấp (redirect < 100ms).
    - Short URL không trùng lặp (uniqueness).
    - Hệ thống xử lý 100 triệu URL mới/tháng.
  - Bước 3: Xác định phạm vi (scope): chỉ tập trung vào core features (tạo và redirect), không bao gồm UI, authentication, hay analytics nâng cao.
  - Bước 4: Liệt kê các câu hỏi làm rõ (clarification questions) mà bạn sẽ hỏi nếu phỏng vấn: tỷ lệ đọc/ghi, độ dài short URL, thời gian lưu trữ URL.
- **Kết quả mong đợi:** Danh sách yêu cầu rõ ràng, phân biệt chức năng và phi chức năng, có scope giới hạn.
- **Kết luận:** Bước làm rõ yêu cầu giúp xác định ranh giới hệ thống và tránh việc thiết kế quá rộng hoặc quá hẹp.

## 1
### title
Bước 2 - Ước lượng phong bì (Back-of-Envelope Estimation)
### body
- **Các bước thực hiện:**
  - Bước 1: Ước tính **QPS (Queries Per Second)**:
    - 100 triệu URL mới/tháng = ~40 URL/giây (ghi).
    - Giả sử tỷ lệ đọc:ghi = 100:1 -> 4.000 đọc/giây.
  - Bước 2: Ước tính **lưu trữ**:
    - Mỗi URL entry: ~500 bytes (short URL + long URL + metadata).
    - 100 triệu URL/tháng x 12 tháng x 5 năm = 6 tỷ record.
    - Tổng lưu trữ: 6 tỷ x 500 bytes = ~3 TB.
  - Bước 3: Ước tính **băng thông**:
    - Ghi: 40 URL/giây x 500 bytes = ~20 KB/giây.
    - Đọc: 4.000 URL/giây x 500 bytes = ~2 MB/giây.
  - Bước 4: Ước tính **cache**:
    - Theo quy tắc 80-20: 20% URL chiếm 80% truy cập.
    - Cache cho 20% của 4.000 đọc/giây x 86.400 giây = ~70 triệu entry/ngày.
    - Cache memory: 70 triệu x 500 bytes = ~35 GB.
- **Kết quả mong đợi:** Bảng tổng hợp các số liệu ước tính cho QPS, lưu trữ, băng thông, và cache, với công thức tính rõ ràng.
- **Kết luận:** Ước lượng phong bì giúp xác định quy mô hệ thống và lựa chọn công nghệ phù hợp trước khi bắt tay vào thiết kế chi tiết.

## 2
### title
Bước 3 - Thiết kế mức cao (High-Level Design)
### body
- **Các bước thực hiện:**
  - Bước 1: Vẽ sơ đồ kiến trúc mức cao gồm các thành phần:
    - **Client** -> **Load Balancer** -> **API Server** (tạo và redirect URL).
    - **API Server** -> **Database** (lưu trữ URL mapping).
    - **API Server** -> **Cache** (Redis/Memcached cho hot URLs).
  - Bước 2: Thiết kế **API endpoints**:
    - `POST /api/shorten` - body: `{ longUrl, customAlias?, ttl? }` -> trả về `{ shortUrl }`.
    - `GET /:shortCode` - redirect 301/302 đến long URL.
  - Bước 3: Thiết kế **thuật toán tạo short code**:
    - Phương án 1: Hash (MD5/SHA256) long URL, lấy 7 ký tự đầu.
    - Phương án 2: Base62 encoding từ auto-increment ID hoặc counter.
    - So sánh ưu nhược điểm của mỗi phương án và chọn phương án phù hợp.
  - Bước 4: Thiết kế **database schema**:
    - Table `urls`: `id`, `short_code` (unique index), `long_url`, `created_at`, `expires_at`.
    - Chọn database: NoSQL (DynamoDB, Cassandra) cho write-heavy và scale, hoặc SQL (PostgreSQL) cho đơn giản.
- **Kết quả mong đợi:** Sơ đồ kiến trúc rõ ràng, API design đầy đủ, thuật toán tạo short code có phân tích, database schema cụ thể.
- **Kết luận:** Thiết kế mức cao cung cấp cái nhìn toàn cảnh về hệ thống, là nền tảng để đi sâu vào các thành phần cụ thể.

## 3
### title
Bước 4 - Phân tích bottleneck và đề xuất giải pháp
### body
- **Các bước thực hiện:**
  - Bước 1: Xác định **bottleneck 1 - Database**: với 4.000 đọc/giây, database có thể bị quá tải.
    - Giải pháp: sử dụng cache (Redis) cho các URL được truy cập nhiều, database sharding theo short_code.
  - Bước 2: Xác định **bottleneck 2 - Short code collision**: hash có thể tạo ra trùng lặp.
    - Giải pháp: sử dụng counter-based approach hoặc retry khi gặp trùng lặp, hoặc dùng pre-generated key service.
  - Bước 3: Xác định **bottleneck 3 - Single point of failure**: nếu API Server hoặc Database chết, toàn hệ thống không hoạt động.
    - Giải pháp: multiple API Server instances sau Load Balancer, database replication (primary-replica).
  - Bước 4: Tổng hợp thành bảng: bottleneck | mức độ nghiêm trọng | giải pháp | trade-off của giải pháp.
- **Kết quả mong đợi:** Bảng phân tích bottleneck chi tiết với giải pháp cụ thể, có xét đến trade-off của từng giải pháp.
- **Kết luận:** Phân tích bottleneck là bước quan trọng nhất, chứng minh khả năng tư duy sâu về vận hành hệ thống thực tế.

## 4
### title
Hoàn thiện tài liệu thiết kế
### body
- **Các bước thực hiện:**
  - Bước 1: Tổng hợp toàn bộ 4 bước vào Google Docs với cấu trúc rõ ràng, mỗi bước là một phần riêng.
  - Bước 2: Đảm bảo có sơ đồ kiến trúc (vẽ bằng draw.io, Excalidraw, hoặc mô tả văn bản chi tiết).
  - Bước 3: Kiểm tra lại: mỗi bước có đủ số liệu, lý do kỹ thuật, và kết luận. Không bỏ sót bất kỳ bước nào trong quy trình.
- **Kết quả mong đợi:** Tài liệu thiết kế hoàn chỉnh theo đúng 4 bước, có thể dùng làm tài liệu tham khảo cho interview thiết kế hệ thống.
- **Kết luận:** Tài liệu thể hiện khả năng áp dụng quy trình thiết kế hệ thống một cách có hệ thống và chuyên nghiệp.

# references
## 0
### alias
System Design Primer - URL Shortener
### url
https://github.com/donnemartin/system-design-primer#design-pastebin.com-or-bit.ly
## 1
### alias
Designing Data-Intensive Applications
### url
https://dataintensive.net/
## 2
### alias
System Design Interview - Alex Xu
### url
https://www.amazon.com/System-Design-Interview-insiders-Second/dp/B08CMF2CQF

# submissions
## 0
### type
googleDocsUrl
### title
Link Google Docs tài liệu thiết kế URL Shortener
### description
Nộp link Google Docs chứa tài liệu thiết kế hệ thống URL Shortener theo quy trình 4 bước.
### score
20
### prompts
#### 0
##### title
Làm rõ yêu cầu và ước lượng
##### score
7
##### promptText
Bước 1 liệt kê đầy đủ yêu cầu chức năng và phi chức năng. Bước 2 có ước lượng QPS, lưu trữ, băng thông, cache với công thức tính rõ ràng.
#### 1
##### title
Thiết kế mức cao
##### score
7
##### promptText
Bước 3 có sơ đồ kiến trúc, API design, thuật toán tạo short code có phân tích ưu nhược điểm, và database schema cụ thể.
#### 2
##### title
Phân tích bottleneck
##### score
6
##### promptText
Bước 4 xác định ít nhất 3 bottleneck với giải pháp cụ thể, có xét trade-off của từng giải pháp, có bảng tổng hợp.

# difficulty
easy

# score
20
