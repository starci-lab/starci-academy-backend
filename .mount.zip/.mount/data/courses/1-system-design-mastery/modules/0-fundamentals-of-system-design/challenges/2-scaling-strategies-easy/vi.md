# title
Phân tích chiến lược Scaling và triển khai Load Balancer cơ bản

# description
Phân tích sự khác biệt giữa Vertical Scaling và Horizontal Scaling cho một kịch bản cụ thể, đồng thời triển khai một ứng dụng NestJS đơn giản chạy nhiều replica sau Nginx load balancer bằng Docker Compose.

# requirements
Viết tài liệu phân tích khi nào nên dùng Vertical Scaling, khi nào nên dùng Horizontal Scaling cho một hệ thống API quản lý sản phẩm (product catalog) với lượng truy cập tăng dần. Đồng thời tạo một NestJS app với Docker Compose chạy 3 replica của ứng dụng phía sau Nginx làm load balancer. Mỗi instance phải trả về ID riêng để chứng minh request được phân phối.

# prerequisites
- Kiến thức về Vertical Scaling và Horizontal Scaling
- Hiểu khái niệm Load Balancer
- Node.js >= 18
- NestJS CLI
- Docker và Docker Compose

# steps

## 0
### title
Phân tích chiến lược Scaling cho hệ thống product catalog
### body
- **Các bước thực hiện:**
  - Bước 1: Mô tả kịch bản: hệ thống API product catalog bắt đầu với 100 request/giây, dự kiến tăng lên 10.000 request/giây trong 6 tháng.
  - Bước 2: Phân tích **Vertical Scaling**: tăng CPU/RAM cho server hiện tại. Liệt kê ưu điểm (đơn giản, không cần thay đổi code) và nhược điểm (giới hạn vật lý, single point of failure, chi phí tăng phi tuyến).
  - Bước 3: Phân tích **Horizontal Scaling**: thêm nhiều instance của ứng dụng. Liệt kê ưu điểm (scale gần như vô hạn, fault tolerance) và nhược điểm (phức tạp hơn về session management, data consistency).
  - Bước 4: Đưa ra khuyến nghị: giai đoạn đầu dùng Vertical Scaling cho đơn giản, chuyển sang Horizontal Scaling khi vượt ngưỡng phần cứng hoặc cần fault tolerance.
- **Kết quả mong đợi:** Tài liệu phân tích rõ ràng với bảng so sánh giữa hai chiến lược, có khuyến nghị cụ thể cho kịch bản.
- **Kết luận:** Không có chiến lược Scaling nào là tối ưu tuyệt đối, lựa chọn phụ thuộc vào giai đoạn và yêu cầu cụ thể của hệ thống.

## 1
### title
Khởi tạo NestJS app và Docker hóa
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS:
    ```bash
    nest new scaling-strategies-easy
    ```
  - Bước 2: Tạo endpoint `GET /info` trong `AppController` trả về JSON chứa `instanceId` (dùng biến môi trường `INSTANCE_ID` hoặc `hostname`).
  - Bước 3: Tạo `Dockerfile` cho ứng dụng NestJS:
    ```dockerfile
    FROM node:18-alpine
    WORKDIR /app
    COPY package*.json ./
    RUN npm ci
    COPY . .
    RUN npm run build
    CMD ["node", "dist/main"]
    ```
  - Bước 4: Build và test container đơn lẻ:
    ```bash
    docker build -t scaling-strategies-easy .
    docker run -p 3000:3000 scaling-strategies-easy
    ```
- **Kết quả mong đợi:** Ứng dụng NestJS chạy trong Docker container, endpoint `GET /info` trả về thông tin instance.
- **Kết luận:** Ứng dụng đã sẵn sàng để triển khai nhiều replica phía sau load balancer.

## 2
### title
Cấu hình Docker Compose với Nginx Load Balancer
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `docker-compose.yml` với 3 replica của ứng dụng NestJS và 1 Nginx service.
  - Bước 2: Cấu hình mỗi replica với biến môi trường `INSTANCE_ID` khác nhau (ví dụ: `app-1`, `app-2`, `app-3`).
  - Bước 3: Tạo file `nginx.conf` cấu hình upstream với 3 backend và sử dụng thuật toán round-robin (mặc định):
    ```nginx
    upstream backend {
        server app1:3000;
        server app2:3000;
        server app3:3000;
    }
    server {
        listen 80;
        location / {
            proxy_pass http://backend;
        }
    }
    ```
  - Bước 4: Chạy toàn bộ hệ thống:
    ```bash
    docker-compose up --build
    ```
- **Kết quả mong đợi:** 3 instance NestJS và 1 Nginx đều chạy thành công, Nginx lắng nghe trên cổng 80.
- **Kết luận:** Kiến trúc Horizontal Scaling cơ bản đã được thiết lập với load balancer phân phối request.

## 3
### title
Kiểm thử phân phối tải và hoàn thiện tài liệu
### body
- **Các bước thực hiện:**
  - Bước 1: Gửi nhiều request liên tiếp đến endpoint qua Nginx:
    ```bash
    for i in $(seq 1 9); do curl http://localhost/info; echo; done
    ```
  - Bước 2: Quan sát kết quả: `instanceId` phải thay đổi luân phiên giữa `app-1`, `app-2`, `app-3` (round-robin).
  - Bước 3: Thử dừng 1 instance và gửi tiếp request, xác nhận Nginx tự động chuyển request sang các instance còn lại.
  - Bước 4: Bổ sung kết quả kiểm thử vào tài liệu Google Docs, bao gồm screenshot hoặc log output.
- **Kết quả mong đợi:** Request được phân phối đều giữa các instance, khi 1 instance down thì các instance còn lại vẫn phục vụ.
- **Kết luận:** Load Balancer đảm bảo phân phối tải và tăng fault tolerance cho hệ thống horizontal scaling.

# references
## 0
### alias
System Design Primer - Scalability
### url
https://github.com/donnemartin/system-design-primer#scalability
## 1
### alias
Nginx Load Balancing Documentation
### url
https://docs.nginx.com/nginx/admin-guide/load-balancer/http-load-balancer/
## 2
### alias
Docker Compose Documentation
### url
https://docs.docker.com/compose/

# submissions
## 0
### type
googleDocsUrl
### title
Link Google Docs tài liệu phân tích Scaling
### description
Nộp link Google Docs chứa tài liệu phân tích Vertical vs Horizontal Scaling và kết quả kiểm thử load balancer.
### score
10
### prompts
#### 0
##### title
Phân tích Vertical vs Horizontal Scaling
##### score
5
##### promptText
Tài liệu phân tích đầy đủ ưu nhược điểm của Vertical và Horizontal Scaling với kịch bản cụ thể, có bảng so sánh và khuyến nghị.
#### 1
##### title
Kết quả kiểm thử load distribution
##### score
5
##### promptText
Có kết quả kiểm thử chứng minh request được phân phối giữa các instance và hệ thống vẫn hoạt động khi 1 instance down.
## 1
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code NestJS app với Docker Compose và Nginx load balancer.
### score
10
### prompts
#### 0
##### title
NestJS app với Docker Compose
##### score
5
##### promptText
Project có Dockerfile, docker-compose.yml với 3 replica NestJS và Nginx, endpoint `GET /info` trả về instanceId.
#### 1
##### title
Nginx load balancer hoạt động
##### score
5
##### promptText
Nginx cấu hình đúng upstream với round-robin, request gửi qua cổng 80 được phân phối đến các instance backend.

# difficulty
easy

# score
20
