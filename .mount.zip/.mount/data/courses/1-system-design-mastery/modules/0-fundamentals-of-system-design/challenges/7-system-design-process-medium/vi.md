# title
Thiết kế và triển khai cơ bản luồng Checkout cho hệ thống E-commerce

# description
Áp dụng quy trình thiết kế hệ thống 4 bước để thiết kế luồng checkout cho một hệ thống e-commerce. Viết tài liệu thiết kế đầy đủ và xây dựng một NestJS app cơ bản minh họa các thành phần chính của luồng checkout.

# requirements
Thiết kế luồng checkout cho hệ thống e-commerce phục vụ 10.000 đơn hàng/ngày. Áp dụng đúng 4 bước: (1) Làm rõ yêu cầu cho luồng checkout (giỏ hàng -> xác nhận đơn -> thanh toán -> cập nhật kho); (2) Ước lượng QPS, lưu trữ, băng thông; (3) Thiết kế mức cao với sơ đồ kiến trúc các service; (4) Phân tích bottleneck (race condition kho hàng, payment failure, order consistency). Đồng thời xây dựng NestJS app với các module: CartModule, OrderModule, InventoryModule mô phỏng luồng checkout cơ bản.

# prerequisites
- Hiểu quy trình thiết kế hệ thống 4 bước
- Kiến thức về kiến trúc microservices cơ bản
- Node.js >= 18
- NestJS CLI
- Hiểu cơ bản về transaction và consistency

# steps

## 0
### title
Bước 1 và 2 - Làm rõ yêu cầu và ước lượng
### body
- **Các bước thực hiện:**
  - Bước 1: Liệt kê **yêu cầu chức năng** cho luồng checkout:
    - Người dùng thêm sản phẩm vào giỏ hàng.
    - Người dùng xác nhận đơn hàng từ giỏ hàng.
    - Hệ thống kiểm tra tồn kho và giữ hàng (reserve inventory).
    - Hệ thống xử lý thanh toán.
    - Hệ thống cập nhật kho và tạo đơn hàng thành công.
    - Xử lý các trường hợp lỗi: hết hàng, thanh toán thất bại, timeout.
  - Bước 2: Liệt kê **yêu cầu phi chức năng**:
    - Consistency: không bán hàng không còn trong kho (no overselling).
    - Reliability: không mất đơn hàng đã thanh toán thành công.
    - Latency: toàn bộ luồng checkout < 5 giây.
    - Availability: 99.9% uptime cho luồng checkout.
  - Bước 3: **Ước lượng** cho 10.000 đơn hàng/ngày:
    - QPS trung bình: 10.000 / 86.400 = ~0.12 đơn/giây. Peak (giờ cao điểm, gấp 10x): ~1.2 đơn/giây.
    - Mỗi đơn hàng: ~2 KB (thông tin đơn + sản phẩm + thanh toán).
    - Lưu trữ 1 năm: 10.000 x 365 x 2 KB = ~7.3 GB.
    - Giỏ hàng active: giả sử 10% người dùng có giỏ hàng = 1.000 giỏ hàng active.
  - Bước 4: Nhận xét: QPS thấp nhưng yêu cầu Consistency và Reliability cao là thách thức chính.
- **Kết quả mong đợi:** Tài liệu yêu cầu và ước lượng đầy đủ, xác định đúng thách thức chính của hệ thống.
- **Kết luận:** Luồng checkout có QPS thấp nhưng độ phức tạp nằm ở consistency giữa nhiều service và xử lý lỗi.

## 1
### title
Bước 3 - Thiết kế mức cao
### body
- **Các bước thực hiện:**
  - Bước 1: Vẽ sơ đồ kiến trúc với các thành phần:
    - **Client** -> **API Gateway** -> **Cart Service** (quản lý giỏ hàng).
    - **API Gateway** -> **Order Service** (tạo và quản lý đơn hàng).
    - **Order Service** -> **Inventory Service** (kiểm tra và giữ hàng).
    - **Order Service** -> **Payment Service** (xử lý thanh toán).
    - **Các service** -> **Database** (PostgreSQL cho consistency).
    - **Order Service** -> **Notification Service** (gửi email/SMS xác nhận).
  - Bước 2: Thiết kế **luồng checkout** (sequence):
    1. Client gửi `POST /checkout` với cartId.
    2. Order Service tạo đơn hàng trạng thái `PENDING`.
    3. Order Service gọi Inventory Service để reserve sản phẩm.
    4. Nếu inventory OK, Order Service gọi Payment Service.
    5. Nếu payment OK, Order Service cập nhật trạng thái `CONFIRMED`, Inventory Service trừ kho.
    6. Nếu payment FAIL, Order Service cập nhật `FAILED`, Inventory Service hoàn trả reserve.
  - Bước 3: Thiết kế **API endpoints**:
    - `POST /cart/items` - thêm sản phẩm vào giỏ hàng.
    - `GET /cart/:cartId` - lấy thông tin giỏ hàng.
    - `POST /checkout` - bắt đầu luồng checkout.
    - `GET /orders/:orderId` - lấy trạng thái đơn hàng.
  - Bước 4: Thiết kế **database schema**:
    - Table `carts`: `id`, `userId`, `status`, `createdAt`.
    - Table `cart_items`: `id`, `cartId`, `productId`, `quantity`.
    - Table `orders`: `id`, `cartId`, `status` (PENDING/CONFIRMED/FAILED), `totalAmount`, `createdAt`.
    - Table `inventory`: `productId`, `totalStock`, `reservedStock`.
- **Kết quả mong đợi:** Sơ đồ kiến trúc rõ ràng, luồng checkout chi tiết với xử lý lỗi, API và schema đầy đủ.
- **Kết luận:** Thiết kế mức cao thể hiện được sự phức tạp của luồng checkout với nhiều service tương tác.

## 2
### title
Bước 4 - Phân tích bottleneck
### body
- **Các bước thực hiện:**
  - Bước 1: **Bottleneck 1 - Race condition kho hàng**: 2 người dùng đặt cùng sản phẩm cuối cùng cùng lúc.
    - Giải pháp: dùng pessimistic locking (`SELECT FOR UPDATE`) trên bảng `inventory` khi reserve.
    - Trade-off: giảm throughput do lock, nhưng đảm bảo consistency.
  - Bước 2: **Bottleneck 2 - Payment failure handling**: sau khi reserve inventory, payment thất bại.
    - Giải pháp: implement Saga pattern (compensating transaction) - khi payment fail, tự động release reserved inventory.
    - Trade-off: phức tạp code, cần retry logic và idempotency.
  - Bước 3: **Bottleneck 3 - Order consistency**: Order Service bị crash giữa lúc reserve và payment.
    - Giải pháp: dùng database transaction cho các bước trong cùng service, dùng outbox pattern cho cross-service.
    - Trade-off: tăng độ phức tạp, cần scheduled job để xử lý outbox.
  - Bước 4: **Bottleneck 4 - Inventory timeout**: giữ hàng quá lâu khi người dùng không hoàn thành checkout.
    - Giải pháp: đặt TTL cho reservation (ví dụ 15 phút), scheduled job tự động release.
    - Trade-off: cần background job, có thể release khi người dùng vẫn đang thanh toán.
- **Kết quả mong đợi:** Phân tích ít nhất 4 bottleneck với giải pháp và trade-off cụ thể.
- **Kết luận:** Luồng checkout e-commerce có nhiều điểm thắt cổ ngầm, việc phân tích kỹ giúp tránh các lỗi nghiêm trọng trong production.

## 3
### title
Xây dựng NestJS demo cho luồng checkout
### body
- **Các bước thực hiện:**
  - Bước 1: Khởi tạo project NestJS:
    ```bash
    nest new system-design-process-medium
    ```
  - Bước 2: Tạo các module:
    - `CartModule` với `CartService`: quản lý giỏ hàng in-memory, endpoint `POST /cart/items` và `GET /cart/:cartId`.
    - `InventoryModule` với `InventoryService`: quản lý tồn kho in-memory, method `reserve(productId, quantity)` và `release(productId, quantity)`.
    - `OrderModule` với `OrderService`: điều phối luồng checkout, endpoint `POST /checkout`.
  - Bước 3: Implement luồng checkout trong `OrderService`:
    - Nhận cartId, lấy thông tin giỏ hàng.
    - Gọi InventoryService.reserve() cho mỗi sản phẩm.
    - Mô phỏng thanh toán (random thành công/thất bại).
    - Nếu thành công: tạo order với trạng thái CONFIRMED, trừ kho.
    - Nếu thất bại: release reservation, trả lời thất bại.
  - Bước 4: Thêm validation: kiểm tra sản phẩm tồn tại, số lượng hợp lệ, giỏ hàng không rỗng.
- **Kết quả mong đợi:** NestJS app với 3 module hoạt động, luồng checkout xử lý cả trường hợp thành công và thất bại.
- **Kết luận:** Demo minh họa được các thành phần chính của luồng checkout và cách xử lý lỗi cơ bản.

## 4
### title
Kiểm thử và hoàn thiện
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Kiểm tra luồng thành công:
    ```bash
    curl -X POST http://localhost:3000/cart/items -H "Content-Type: application/json" -d '{"cartId":"cart-1","productId":"prod-1","quantity":2}'
    curl -X POST http://localhost:3000/checkout -H "Content-Type: application/json" -d '{"cartId":"cart-1"}'
    ```
  - Bước 3: Kiểm tra luồng thất bại (hết hàng):
    ```bash
    curl -X POST http://localhost:3000/cart/items -H "Content-Type: application/json" -d '{"cartId":"cart-2","productId":"prod-1","quantity":9999}'
    curl -X POST http://localhost:3000/checkout -H "Content-Type: application/json" -d '{"cartId":"cart-2"}'
    ```
    Xác nhận trả lời hết hàng và inventory không bị trừ.
  - Bước 4: Hoàn thiện tài liệu Google Docs với cấu trúc đầy đủ 4 bước, bổ sung phần mô tả demo và kết quả kiểm thử.
- **Kết quả mong đợi:** Demo hoạt động đúng cho cả trường hợp thành công và thất bại, tài liệu đầy đủ và nhất quán.
- **Kết luận:** Challenge hoàn thành khi cả tài liệu thiết kế và demo đều thể hiện sự hiểu biết về quy trình thiết kế hệ thống áp dụng vào bài toán thực tế.

# references
## 0
### alias
System Design Interview - Alex Xu - Chapter on E-commerce
### url
https://www.amazon.com/System-Design-Interview-insiders-Second/dp/B08CMF2CQF
## 1
### alias
Saga Pattern - Microservices.io
### url
https://microservices.io/patterns/data/saga.html
## 2
### alias
NestJS Documentation
### url
https://docs.nestjs.com/

# submissions
## 0
### type
googleDocsUrl
### title
Link Google Docs tài liệu thiết kế Checkout
### description
Nộp link Google Docs chứa tài liệu thiết kế luồng checkout theo quy trình 4 bước.
### score
15
### prompts
#### 0
##### title
Yêu cầu, ước lượng và thiết kế mức cao
##### score
8
##### promptText
Tài liệu làm rõ yêu cầu đầy đủ, có ước lượng QPS/lưu trữ, sơ đồ kiến trúc với các service rõ ràng, luồng checkout có xử lý lỗi.
#### 1
##### title
Phân tích bottleneck
##### score
7
##### promptText
Xác định ít nhất 4 bottleneck (race condition, payment failure, order consistency, inventory timeout) với giải pháp và trade-off cụ thể.
## 1
### type
githubUrl
### title
Link GitHub Repository demo Checkout
### description
Nộp link GitHub repository chứa source code NestJS app minh họa luồng checkout cơ bản.
### score
15
### prompts
#### 0
##### title
Cấu trúc module và luồng checkout
##### score
8
##### promptText
NestJS app có CartModule, OrderModule, InventoryModule. Luồng checkout điều phối đúng: reserve -> payment -> confirm/release.
#### 1
##### title
Xử lý lỗi và validation
##### score
7
##### promptText
Demo xử lý đúng trường hợp hết hàng (release reservation), payment thất bại, và có validation cho input.

# difficulty
medium

# score
30
