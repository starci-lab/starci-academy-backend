# title
Xây dựng hệ thống phân tán minh họa CP và AP với PostgreSQL replication

# description
Xây dựng một hệ thống phân tán đơn giản với NestJS sử dụng PostgreSQL synchronous replication (CP behavior) và asynchronous replication (AP behavior). Quan sát và ghi nhận sự khác biệt về hành vi giữa hai chế độ, đồng thời viết tài liệu phân tích trade-off.

# requirements
Tạo một NestJS app kết nối với PostgreSQL có cấu hình replication. Thiết lập 2 môi trường: (1) Synchronous replication - ghi dữ liệu chỉ thành công khi cả primary và replica đồng bộ xong (CP); (2) Asynchronous replication - ghi dữ liệu thành công ngay khi primary xác nhận, replica đồng bộ sau (AP). Chứng minh sự khác biệt qua test: đo Latency ghi trong mỗi chế độ, mô phỏng replica lag và quan sát hành vi đọc dữ liệu. Viết tài liệu trade-off.

# prerequisites
- Hiểu định lý CAP và sự khác biệt CP vs AP
- Node.js >= 18
- NestJS CLI
- Docker và Docker Compose
- Kiến thức cơ bản về PostgreSQL replication

# steps

## 0
### title
Thiết lập PostgreSQL primary-replica với Docker Compose
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `docker-compose.yml` với 2 PostgreSQL container:
    - `pg-primary`: PostgreSQL primary node.
    - `pg-replica`: PostgreSQL replica node.
  - Bước 2: Cấu hình primary để cho phép replication: tạo file `pg_hba.conf` cho phép replication connection, chỉnh `postgresql.conf` với `wal_level = replica`, `max_wal_senders = 2`.
  - Bước 3: Cấu hình replica để kết nối đến primary sử dụng `primary_conninfo` và `restore_command`.
  - Bước 4: Chạy hệ thống và xác nhận replication hoạt động:
    ```bash
    docker-compose up -d
    docker exec pg-primary psql -U postgres -c "SELECT * FROM pg_stat_replication;"
    ```
- **Kết quả mong đợi:** 2 PostgreSQL container chạy, replica kết nối thành công đến primary và nhận WAL logs.
- **Kết luận:** Môi trường PostgreSQL replication đã sẵn sàng để thiết lập chế độ synchronous và asynchronous.

## 1
### title
Cấu hình synchronous và asynchronous replication
### body
- **Các bước thực hiện:**
  - Bước 1: Cấu hình **Synchronous replication** (CP behavior): trên primary, set `synchronous_commit = on` và `synchronous_standby_names = 'replica1'`. Điều này đảm bảo ghi chỉ thành công khi replica xác nhận đã nhận dữ liệu.
  - Bước 2: Tạo NestJS project:
    ```bash
    nest new cap-theorem-and-tradeoffs-medium
    ```
  - Bước 3: Cài đặt TypeORM và kết nối đến PostgreSQL primary. Tạo entity `Product` với các field: `id`, `name`, `price`, `createdAt`.
  - Bước 4: Tạo `ProductModule` với các endpoint:
    - `POST /products` - tạo product mới (ghi vào primary)
    - `GET /products` - đọc danh sách product (có thể đọc từ primary hoặc replica)
    - `GET /products/replica` - đọc danh sách product từ replica (kết nối trực tiếp đến replica)
- **Kết quả mong đợi:** NestJS app kết nối được cả primary và replica, endpoint ghi và đọc hoạt động đúng.
- **Kết luận:** Hệ thống đã sẵn sàng để kiểm thử sự khác biệt giữa synchronous và asynchronous replication.

## 2
### title
Kiểm thử và so sánh CP vs AP behavior
### body
- **Các bước thực hiện:**
  - Bước 1: **Test Synchronous mode (CP):**
    - Ghi 100 record và đo thời gian trung bình cho mỗi lần ghi:
      ```bash
      time for i in $(seq 1 100); do curl -s -X POST http://localhost:3000/products -H "Content-Type: application/json" -d "{\"name\":\"product-$i\",\"price\":$i}"; done
      ```
    - Đọc ngay từ replica và xác nhận dữ liệu nhất quán 100%.
  - Bước 2: Chuyển sang **Asynchronous mode (AP):** trên primary, set `synchronous_commit = off`. Restart PostgreSQL.
  - Bước 3: **Test Asynchronous mode (AP):**
    - Ghi 100 record và đo thời gian trung bình (nên nhanh hơn synchronous).
    - Đọc ngay từ replica: có thể thấy dữ liệu chưa cập nhật hết (replica lag).
  - Bước 4: Mô phỏng replica chậm: dừng replica tạm thời, ghi thêm dữ liệu vào primary, bật lại replica và quan sát thời gian đồng bộ.
- **Kết quả mong đợi:** Synchronous mode có Latency ghi cao hơn nhưng dữ liệu luôn nhất quán. Asynchronous mode có Latency thấp hơn nhưng có thể có replica lag.
- **Kết luận:** Sự khác biệt giữa CP và AP thể hiện rõ qua Latency ghi và mức độ nhất quán khi đọc từ replica.

## 3
### title
Viết tài liệu trade-off và kết luận
### body
- **Các bước thực hiện:**
  - Bước 1: Ghi lại tất cả số liệu kiểm thử: Latency ghi trung bình cho synchronous vs asynchronous, số record không nhất quán khi đọc từ replica trong async mode.
  - Bước 2: Viết tài liệu Google Docs với cấu trúc:
    - Giới thiệu: CP vs AP trong ngữ cảnh PostgreSQL replication.
    - Thiết lập: mô tả kiến trúc và cấu hình.
    - Kết quả kiểm thử: bảng so sánh số liệu giữa 2 chế độ.
    - Phân tích trade-off: khi nào chọn synchronous (CP), khi nào chọn asynchronous (AP).
    - Kết luận: khuyến nghị cho từng loại ứng dụng.
  - Bước 3: Bổ sung sơ đồ kiến trúc hệ thống (primary -> replica) và luồng dữ liệu trong mỗi chế độ.
- **Kết quả mong đợi:** Tài liệu và source code đầy đủ, số liệu kiểm thử thực tế chứng minh trade-off giữa CP và AP.
- **Kết luận:** Challenge hoàn thành khi học viên chứng minh được sự khác biệt thực tế giữa CP và AP thông qua implementation và đo lường cụ thể.

# references
## 0
### alias
PostgreSQL Replication Documentation
### url
https://www.postgresql.org/docs/current/warm-standby.html
## 1
### alias
PostgreSQL Synchronous Replication
### url
https://www.postgresql.org/docs/current/warm-standby.html#SYNCHRONOUS-REPLICATION
## 2
### alias
CAP Theorem - Wikipedia
### url
https://en.wikipedia.org/wiki/CAP_theorem

# submissions
## 0
### type
googleDocsUrl
### title
Link Google Docs tài liệu trade-off
### description
Nộp link Google Docs chứa tài liệu phân tích trade-off giữa CP và AP với số liệu kiểm thử thực tế.
### score
12
### prompts
#### 0
##### title
Phân tích trade-off CP vs AP
##### score
6
##### promptText
Tài liệu trình bày rõ sự khác biệt giữa synchronous (CP) và asynchronous (AP) replication, có số liệu kiểm thử cụ thể và khuyến nghị phù hợp.
#### 1
##### title
Sơ đồ kiến trúc và kết luận
##### score
6
##### promptText
Có sơ đồ kiến trúc hệ thống, bảng so sánh số liệu, và kết luận với khuyến nghị cho từng loại ứng dụng.
## 1
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code NestJS app và Docker Compose với PostgreSQL replication.
### score
18
### prompts
#### 0
##### title
PostgreSQL replication setup
##### score
6
##### promptText
Docker Compose cấu hình đúng PostgreSQL primary-replica, replication hoạt động (có thể chuyển giữa synchronous và asynchronous).
#### 1
##### title
NestJS app với dual connection
##### score
6
##### promptText
NestJS app kết nối cả primary và replica, có endpoint ghi vào primary và đọc từ replica, entity Product đầy đủ.
#### 2
##### title
Kiểm thử chứng minh CP vs AP
##### score
6
##### promptText
Có script hoặc hướng dẫn kiểm thử chứng minh Latency khác nhau giữa 2 chế độ và replica lag trong async mode.

# difficulty
medium

# score
30
