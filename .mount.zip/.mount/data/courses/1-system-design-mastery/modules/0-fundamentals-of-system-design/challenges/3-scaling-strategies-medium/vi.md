# title
Horizontal Scaling với Health Check và chứng minh phân phối tải

# description
Triển khai một ứng dụng NestJS với Docker Compose sử dụng Nginx load balancer, cấu hình health check cho mỗi instance, và chứng minh phân phối tải hoạt động đúng khi scale up/down số lượng replica.

# requirements
Xây dựng một NestJS REST API (quản lý danh sách to-do) chạy trong Docker. Sử dụng Docker Compose để chạy nhiều replica phía sau Nginx load balancer. Cấu hình health check endpoint trong NestJS (`GET /health`) và Docker health check. Chứng minh: request được phân phối đều (round-robin); khi 1 instance fail health check, Nginx tự động loại bỏ; khi scale từ 3 lên 5 replica, hệ thống tự động phân phối lại tải.

# prerequisites
- Kiến thức về Horizontal Scaling và Load Balancer
- Node.js >= 18
- NestJS CLI
- Docker và Docker Compose
- Hiểu cơ bản về Nginx configuration

# steps

## 0
### title
Xây dựng NestJS REST API với health check
### body
- **Các bước thực hiện:**
  - Bước 1: Khởi tạo project NestJS:
    ```bash
    nest new scaling-strategies-medium
    ```
  - Bước 2: Tạo `TodoModule` với `TodoController` và `TodoService` quản lý danh sách to-do in-memory. Implement các endpoint:
    - `GET /todos` - lấy danh sách to-do
    - `POST /todos` - tạo to-do mới
    - `GET /todos/:id` - lấy to-do theo id
  - Bước 3: Tạo endpoint `GET /health` trong `AppController` trả về `{ status: 'ok', instanceId: process.env.INSTANCE_ID, uptime: process.uptime() }`.
  - Bước 4: Tạo `Dockerfile` cho ứng dụng với health check instruction:
    ```dockerfile
    FROM node:18-alpine
    WORKDIR /app
    COPY package*.json ./
    RUN npm ci
    COPY . .
    RUN npm run build
    HEALTHCHECK --interval=10s --timeout=3s --retries=3 \
      CMD wget --no-verbose --tries=1 --spider http://localhost:3000/health || exit 1
    CMD ["node", "dist/main"]
    ```
- **Kết quả mong đợi:** NestJS app có đầy đủ REST API và health check endpoint, Docker image được build thành công.
- **Kết luận:** Ứng dụng đã sẵn sàng để triển khai nhiều instance với khả năng kiểm tra sức khỏe tự động.

## 1
### title
Cấu hình Docker Compose và Nginx nâng cao
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `docker-compose.yml` với 3 replica ban đầu, mỗi replica có `INSTANCE_ID` riêng và health check config.
  - Bước 2: Tạo file `nginx.conf` với cấu hình upstream và health check passive:
    ```nginx
    upstream backend {
        server app1:3000 max_fails=3 fail_timeout=30s;
        server app2:3000 max_fails=3 fail_timeout=30s;
        server app3:3000 max_fails=3 fail_timeout=30s;
    }
    server {
        listen 80;
        location / {
            proxy_pass http://backend;
            proxy_next_upstream error timeout http_500;
        }
        location /nginx-health {
            return 200 'nginx ok';
        }
    }
    ```
  - Bước 3: Cấu hình Nginx cũng là một service trong Docker Compose, mount file `nginx.conf` và expose cổng 80.
  - Bước 4: Chạy hệ thống:
    ```bash
    docker-compose up --build -d
    ```
- **Kết quả mong đợi:** Hệ thống 3 instance + Nginx chạy ổn định, tất cả health check passed.
- **Kết luận:** Cấu hình Docker Compose và Nginx đã sẵn sàng cho việc kiểm thử phân phối tải và fault tolerance.

## 2
### title
Chứng minh phân phối tải và fault tolerance
### body
- **Các bước thực hiện:**
  - Bước 1: Gửi 12 request liên tiếp để kiểm tra round-robin:
    ```bash
    for i in $(seq 1 12); do curl -s http://localhost/health | jq .instanceId; done
    ```
    Xác nhận instanceId xoay vòng đều giữa 3 instance.
  - Bước 2: Dừng 1 instance:
    ```bash
    docker-compose stop app2
    ```
  - Bước 3: Gửi tiếp 6 request và xác nhận chỉ còn `app-1` và `app-3` xử lý, không có lỗi 502:
    ```bash
    for i in $(seq 1 6); do curl -s http://localhost/health | jq .instanceId; done
    ```
  - Bước 4: Khởi động lại instance đã dừng:
    ```bash
    docker-compose start app2
    ```
    Gửi tiếp request và xác nhận `app-2` đã quay lại vòng round-robin.
- **Kết quả mong đợi:** Request phân phối đều khi đủ 3 instance; khi 1 instance down, Nginx tự động loại bỏ và phân phối cho các instance còn lại; khi instance phục hồi, nó được thêm lại.
- **Kết luận:** Hệ thống có khả năng fault tolerance nhờ health check và Nginx tự động phát hiện instance lỗi.

## 3
### title
Scale động và kiểm thử toàn diện
### body
- **Các bước thực hiện:**
  - Bước 1: Thêm 2 instance mới vào `docker-compose.yml` (app4, app5) và cập nhật `nginx.conf` để bao gồm chúng.
  - Bước 2: Chạy lại hệ thống với 5 instance:
    ```bash
    docker-compose up --build -d
    ```
  - Bước 3: Gửi 15 request và xác nhận cả 5 instance đều nhận request:
    ```bash
    for i in $(seq 1 15); do curl -s http://localhost/health | jq .instanceId; done
    ```
  - Bước 4: Ghi lại toàn bộ kết quả kiểm thử, bao gồm: phân phối tải bình thường, xử lý khi instance down, và scale up. Lưu vào README của repository.
- **Kết quả mong đợi:** Hệ thống scale từ 3 lên 5 instance mà không downtime, request phân phối đều cho tất cả instance.
- **Kết luận:** Horizontal Scaling với Docker Compose và Nginx cho phép scale linh hoạt, health check đảm bảo chỉ các instance khỏe mạnh mới nhận request.

# references
## 0
### alias
Nginx Health Checks
### url
https://docs.nginx.com/nginx/admin-guide/load-balancer/http-health-check/
## 1
### alias
Docker Compose Healthcheck
### url
https://docs.docker.com/reference/compose-file/services/#healthcheck
## 2
### alias
System Design Primer - Load Balancer
### url
https://github.com/donnemartin/system-design-primer#load-balancer

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code NestJS app với Docker Compose, Nginx load balancer, và health check.
### score
30
### prompts
#### 0
##### title
NestJS REST API và health check
##### score
8
##### promptText
Ứng dụng NestJS có đầy đủ endpoint CRUD to-do và `GET /health` trả về instanceId và uptime. Dockerfile có HEALTHCHECK instruction.
#### 1
##### title
Docker Compose và Nginx configuration
##### score
8
##### promptText
Docker Compose cấu hình đúng nhiều replica với health check. Nginx cấu hình upstream với max_fails và proxy_next_upstream.
#### 2
##### title
Chứng minh phân phối tải
##### score
7
##### promptText
README hoặc tài liệu chứng minh request phân phối round-robin, hệ thống xử lý đúng khi instance down và khi scale up.
#### 3
##### title
Fault tolerance và recovery
##### score
7
##### promptText
Khi 1 instance bị dừng, Nginx tự động loại bỏ và phân phối cho các instance còn lại. Khi instance phục hồi, nó được thêm lại vào vòng round-robin.

# difficulty
medium

# score
30
