# title
Horizontal Scaling with Health Checks and Load Distribution Proof

# description
Deploy a NestJS application with Docker Compose using Nginx load balancer, configure health checks for each instance, and prove that load distribution works correctly when scaling up/down the number of replicas.

# requirements
Build a NestJS REST API (managing a to-do list) running in Docker. Use Docker Compose to run multiple replicas behind an Nginx load balancer. Configure a health check endpoint in NestJS (`GET /health`) and Docker health check. Prove: requests are distributed evenly (round-robin); when 1 instance fails health check, Nginx automatically removes it; when scaling from 3 to 5 replicas, the system automatically redistributes load.

# prerequisites
- Knowledge of Horizontal Scaling and Load Balancer
- Node.js >= 18
- NestJS CLI
- Docker and Docker Compose
- Basic understanding of Nginx configuration

# steps

## 0
### title
Build NestJS REST API with health check
### body
- **Steps to follow:**
  - Step 1: Initialize the NestJS project:
    ```bash
    nest new scaling-strategies-medium
    ```
  - Step 2: Create `TodoModule` with `TodoController` and `TodoService` managing an in-memory to-do list. Implement endpoints:
    - `GET /todos` - list all to-dos
    - `POST /todos` - create a new to-do
    - `GET /todos/:id` - get to-do by id
  - Step 3: Create endpoint `GET /health` in `AppController` returning `{ status: 'ok', instanceId: process.env.INSTANCE_ID, uptime: process.uptime() }`.
  - Step 4: Create a `Dockerfile` for the application with a health check instruction:
    ```dockerfile
    FROM node:18-alpine
    WORKDIR /app
    COPY package*.json ./
    RUN npm ci
    COPY . .
    RUN npm run build
    HEALTHCHECK --interval=10s --timeout=3s --retries=3 \
      CMD wget --no-verbose --tries=1 --spider http://localhost:3000/health || exit 1
    CMD ["node", "dist/main"]
    ```
- **Expected result:** NestJS app has complete REST API and health check endpoint, Docker image builds successfully.
- **Conclusion:** The application is ready to be deployed as multiple instances with automatic health monitoring capability.

## 1
### title
Configure Docker Compose and advanced Nginx
### body
- **Steps to follow:**
  - Step 1: Create `docker-compose.yml` with 3 initial replicas, each with a unique `INSTANCE_ID` and health check config.
  - Step 2: Create `nginx.conf` with upstream and passive health check configuration:
    ```nginx
    upstream backend {
        server app1:3000 max_fails=3 fail_timeout=30s;
        server app2:3000 max_fails=3 fail_timeout=30s;
        server app3:3000 max_fails=3 fail_timeout=30s;
    }
    server {
        listen 80;
        location / {
            proxy_pass http://backend;
            proxy_next_upstream error timeout http_500;
        }
        location /nginx-health {
            return 200 'nginx ok';
        }
    }
    ```
  - Step 3: Configure Nginx as a service in Docker Compose, mount `nginx.conf` and expose port 80.
  - Step 4: Start the system:
    ```bash
    docker-compose up --build -d
    ```
- **Expected result:** System with 3 instances + Nginx running stably, all health checks passing.
- **Conclusion:** Docker Compose and Nginx configuration is ready for load distribution and fault tolerance testing.

## 2
### title
Prove load distribution and fault tolerance
### body
- **Steps to follow:**
  - Step 1: Send 12 consecutive requests to verify round-robin:
    ```bash
    for i in $(seq 1 12); do curl -s http://localhost/health | jq .instanceId; done
    ```
    Confirm instanceId rotates evenly among 3 instances.
  - Step 2: Stop 1 instance:
    ```bash
    docker-compose stop app2
    ```
  - Step 3: Send 6 more requests and confirm only `app-1` and `app-3` handle them, with no 502 errors:
    ```bash
    for i in $(seq 1 6); do curl -s http://localhost/health | jq .instanceId; done
    ```
  - Step 4: Restart the stopped instance:
    ```bash
    docker-compose start app2
    ```
    Send more requests and confirm `app-2` is back in the round-robin rotation.
- **Expected result:** Requests distribute evenly with all 3 instances; when 1 instance is down, Nginx automatically removes it and distributes to remaining instances; when the instance recovers, it is added back.
- **Conclusion:** The system has fault tolerance capability thanks to health checks and Nginx automatic detection of failed instances.

## 3
### title
Dynamic scaling and comprehensive testing
### body
- **Steps to follow:**
  - Step 1: Add 2 new instances to `docker-compose.yml` (app4, app5) and update `nginx.conf` to include them.
  - Step 2: Restart the system with 5 instances:
    ```bash
    docker-compose up --build -d
    ```
  - Step 3: Send 15 requests and confirm all 5 instances receive requests:
    ```bash
    for i in $(seq 1 15); do curl -s http://localhost/health | jq .instanceId; done
    ```
  - Step 4: Record all test results including: normal load distribution, handling when an instance is down, and scale up. Save to the repository README.
- **Expected result:** System scales from 3 to 5 instances with no downtime, requests are distributed evenly to all instances.
- **Conclusion:** Horizontal Scaling with Docker Compose and Nginx allows flexible scaling; health checks ensure only healthy instances receive requests.

# references
## 0
### alias
Nginx Health Checks
### url
https://docs.nginx.com/nginx/admin-guide/load-balancer/http-health-check/
## 1
### alias
Docker Compose Healthcheck
### url
https://docs.docker.com/reference/compose-file/services/#healthcheck
## 2
### alias
System Design Primer - Load Balancer
### url
https://github.com/donnemartin/system-design-primer#load-balancer

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing the NestJS app source code with Docker Compose, Nginx load balancer, and health checks.
### score
30
### prompts
#### 0
##### title
NestJS REST API and health check
##### score
8
##### promptText
The NestJS application has complete CRUD to-do endpoints and `GET /health` returning instanceId and uptime. Dockerfile includes HEALTHCHECK instruction.
#### 1
##### title
Docker Compose and Nginx configuration
##### score
8
##### promptText
Docker Compose properly configures multiple replicas with health checks. Nginx configures upstream with max_fails and proxy_next_upstream.
#### 2
##### title
Load distribution proof
##### score
7
##### promptText
README or documentation proves requests distribute in round-robin, system handles correctly when an instance is down and when scaling up.
#### 3
##### title
Fault tolerance and recovery
##### score
7
##### promptText
When 1 instance is stopped, Nginx automatically removes it and distributes to remaining instances. When the instance recovers, it is added back to round-robin rotation.

# difficulty
medium

# score
30
