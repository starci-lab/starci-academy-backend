# title
Design and Implement a Basic E-commerce Checkout Flow

# description
Apply the 4-step system design process to design a checkout flow for an e-commerce system. Write a complete design document and build a basic NestJS app illustrating the main components of the checkout flow.

# requirements
Design a checkout flow for an e-commerce system serving 10,000 orders/day. Apply the 4 steps correctly: (1) Clarify requirements for the checkout flow (cart -> order confirmation -> payment -> inventory update); (2) Estimate QPS, storage, bandwidth; (3) High-level design with service architecture diagram; (4) Bottleneck analysis (inventory race condition, payment failure, order consistency). Additionally, build a NestJS app with modules: CartModule, OrderModule, InventoryModule simulating the basic checkout flow.

# prerequisites
- Understanding of the 4-step system design process
- Basic knowledge of microservices architecture
- Node.js >= 18
- NestJS CLI
- Basic understanding of transactions and consistency

# steps

## 0
### title
Steps 1 and 2 - Requirements Clarification and Estimation
### body
- **Steps to follow:**
  - Step 1: List **Functional Requirements** for the checkout flow:
    - User adds products to the cart.
    - User confirms an order from the cart.
    - System checks inventory and reserves items.
    - System processes payment.
    - System updates inventory and creates a successful order.
    - Handle error cases: out of stock, payment failure, timeout.
  - Step 2: List **Non-Functional Requirements**:
    - Consistency: no selling items that are out of stock (no overselling).
    - Reliability: no losing orders that have been successfully paid.
    - Latency: entire checkout flow < 5 seconds.
    - Availability: 99.9% uptime for the checkout flow.
  - Step 3: **Estimation** for 10,000 orders/day:
    - Average QPS: 10,000 / 86,400 = ~0.12 orders/second. Peak (rush hour, 10x): ~1.2 orders/second.
    - Each order: ~2 KB (order info + products + payment).
    - Storage for 1 year: 10,000 x 365 x 2 KB = ~7.3 GB.
    - Active carts: assuming 10% of users have active carts = 1,000 active carts.
  - Step 4: Observation: QPS is low but high Consistency and Reliability requirements are the main challenges.
- **Expected result:** Complete requirements and estimation document, correctly identifying the main system challenges.
- **Conclusion:** The checkout flow has low QPS but complexity lies in consistency across multiple services and error handling.

## 1
### title
Step 3 - High-Level Design
### body
- **Steps to follow:**
  - Step 1: Draw an architecture diagram with components:
    - **Client** -> **API Gateway** -> **Cart Service** (cart management).
    - **API Gateway** -> **Order Service** (order creation and management).
    - **Order Service** -> **Inventory Service** (check and reserve items).
    - **Order Service** -> **Payment Service** (payment processing).
    - **Services** -> **Database** (PostgreSQL for consistency).
    - **Order Service** -> **Notification Service** (send confirmation email/SMS).
  - Step 2: Design the **checkout flow** (sequence):
    1. Client sends `POST /checkout` with cartId.
    2. Order Service creates an order with status `PENDING`.
    3. Order Service calls Inventory Service to reserve products.
    4. If inventory OK, Order Service calls Payment Service.
    5. If payment OK, Order Service updates status to `CONFIRMED`, Inventory Service deducts stock.
    6. If payment FAILS, Order Service updates to `FAILED`, Inventory Service releases reservation.
  - Step 3: Design **API endpoints**:
    - `POST /cart/items` - add product to cart.
    - `GET /cart/:cartId` - get cart information.
    - `POST /checkout` - initiate checkout flow.
    - `GET /orders/:orderId` - get order status.
  - Step 4: Design **database schema**:
    - Table `carts`: `id`, `userId`, `status`, `createdAt`.
    - Table `cart_items`: `id`, `cartId`, `productId`, `quantity`.
    - Table `orders`: `id`, `cartId`, `status` (PENDING/CONFIRMED/FAILED), `totalAmount`, `createdAt`.
    - Table `inventory`: `productId`, `totalStock`, `reservedStock`.
- **Expected result:** Clear architecture diagram, detailed checkout flow with error handling, complete API and schema.
- **Conclusion:** The high-level design demonstrates the complexity of the checkout flow with multiple interacting services.

## 2
### title
Step 4 - Bottleneck Analysis
### body
- **Steps to follow:**
  - Step 1: **Bottleneck 1 - Inventory race condition**: 2 users ordering the last item simultaneously.
    - Solution: use pessimistic locking (`SELECT FOR UPDATE`) on the `inventory` table during reservation.
    - Trade-off: reduces throughput due to locking, but ensures consistency.
  - Step 2: **Bottleneck 2 - Payment failure handling**: after reserving inventory, payment fails.
    - Solution: implement the Saga pattern (compensating transaction) - when payment fails, automatically release reserved inventory.
    - Trade-off: increases code complexity, requires retry logic and idempotency.
  - Step 3: **Bottleneck 3 - Order consistency**: Order Service crashes between reservation and payment.
    - Solution: use database transactions for steps within the same service, use the outbox pattern for cross-service communication.
    - Trade-off: increases complexity, requires a scheduled job to process the outbox.
  - Step 4: **Bottleneck 4 - Inventory timeout**: holding reserved items too long when users do not complete checkout.
    - Solution: set a TTL for reservations (e.g., 15 minutes), scheduled job to auto-release.
    - Trade-off: requires a background job, may release while the user is still completing payment.
- **Expected result:** Analysis of at least 4 bottlenecks with specific solutions and trade-offs.
- **Conclusion:** The e-commerce checkout flow has many hidden bottlenecks; thorough analysis helps avoid critical production errors.

## 3
### title
Build NestJS demo for the checkout flow
### body
- **Steps to follow:**
  - Step 1: Initialize the NestJS project:
    ```bash
    nest new system-design-process-medium
    ```
  - Step 2: Create modules:
    - `CartModule` with `CartService`: manage in-memory cart, endpoints `POST /cart/items` and `GET /cart/:cartId`.
    - `InventoryModule` with `InventoryService`: manage in-memory inventory, methods `reserve(productId, quantity)` and `release(productId, quantity)`.
    - `OrderModule` with `OrderService`: orchestrate the checkout flow, endpoint `POST /checkout`.
  - Step 3: Implement the checkout flow in `OrderService`:
    - Receive cartId, retrieve cart information.
    - Call InventoryService.reserve() for each product.
    - Simulate payment (random success/failure).
    - If successful: create order with status CONFIRMED, deduct inventory.
    - If failed: release reservation, return failure response.
  - Step 4: Add validation: check product existence, valid quantities, non-empty cart.
- **Expected result:** NestJS app with 3 working modules, checkout flow handling both success and failure cases.
- **Conclusion:** The demo illustrates the main components of the checkout flow and basic error handling.

## 4
### title
Test and finalize
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Test the success flow:
    ```bash
    curl -X POST http://localhost:3000/cart/items -H "Content-Type: application/json" -d '{"cartId":"cart-1","productId":"prod-1","quantity":2}'
    curl -X POST http://localhost:3000/checkout -H "Content-Type: application/json" -d '{"cartId":"cart-1"}'
    ```
  - Step 3: Test the failure flow (out of stock):
    ```bash
    curl -X POST http://localhost:3000/cart/items -H "Content-Type: application/json" -d '{"cartId":"cart-2","productId":"prod-1","quantity":9999}'
    curl -X POST http://localhost:3000/checkout -H "Content-Type: application/json" -d '{"cartId":"cart-2"}'
    ```
    Confirm the response indicates out of stock and inventory is not deducted.
  - Step 4: Finalize the Google Docs document with the complete 4-step structure, adding the demo description and test results.
- **Expected result:** Demo works correctly for both success and failure cases, documentation is complete and consistent.
- **Conclusion:** The challenge is complete when both the design document and demo demonstrate understanding of the system design process applied to a real-world problem.

# references
## 0
### alias
System Design Interview - Alex Xu - Chapter on E-commerce
### url
https://www.amazon.com/System-Design-Interview-insiders-Second/dp/B08CMF2CQF
## 1
### alias
Saga Pattern - Microservices.io
### url
https://microservices.io/patterns/data/saga.html
## 2
### alias
NestJS Documentation
### url
https://docs.nestjs.com/

# submissions
## 0
### type
googleDocsUrl
### title
Google Docs Checkout Design Document Link
### description
Submit the Google Docs link containing the checkout flow design document following the 4-step process.
### score
15
### prompts
#### 0
##### title
Requirements, estimation, and high-level design
##### score
8
##### promptText
The document fully clarifies requirements, includes QPS/storage estimation, architecture diagram with clear services, and checkout flow with error handling.
#### 1
##### title
Bottleneck analysis
##### score
7
##### promptText
Identifies at least 4 bottlenecks (race condition, payment failure, order consistency, inventory timeout) with specific solutions and trade-offs.
## 1
### type
githubUrl
### title
GitHub Repository Link for Checkout Demo
### description
Submit the GitHub repository link containing the NestJS app source code illustrating the basic checkout flow.
### score
15
### prompts
#### 0
##### title
Module structure and checkout flow
##### score
8
##### promptText
NestJS app has CartModule, OrderModule, InventoryModule. Checkout flow orchestrates correctly: reserve -> payment -> confirm/release.
#### 1
##### title
Error handling and validation
##### score
7
##### promptText
Demo correctly handles out-of-stock cases (releases reservation), payment failure, and has input validation.

# difficulty
medium

# score
30
