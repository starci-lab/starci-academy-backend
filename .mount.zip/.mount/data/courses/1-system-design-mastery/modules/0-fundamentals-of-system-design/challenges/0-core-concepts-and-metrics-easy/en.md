# title
Analyze System Properties and Performance Metrics

# description
Analyze a real-world system scenario, identify applicable system properties (Scalability, Reliability, Availability, Consistency) and performance metrics (Latency, Throughput). Write a Google Docs document presenting the detailed analysis.

# requirements
Given a specific scenario: an online food delivery application serving 10,000 concurrent users during peak hours. Analyze and explain: which of the 4 pillars (Scalability, Reliability, Availability, Consistency) is most critical and why; where Latency and Throughput should be measured within the system; the relationships between properties and how they influence each other.

# prerequisites
- Basic knowledge of distributed system architecture
- Understanding of Scalability, Reliability, Availability, Consistency concepts
- Understanding of Latency and Throughput metrics

# steps

## 0
### title
Analyze the scenario and identify system properties
### body
- **Steps to follow:**
  - Step 1: Carefully read the food delivery system scenario with 10,000 concurrent users during peak hours.
  - Step 2: List the main system components (API Gateway, Order Service, Payment Service, Notification Service, Database).
  - Step 3: For each component, determine which of the 4 pillars has the highest priority. For example: Payment Service requires high **Consistency**, while Notification Service requires high **Availability**.
  - Step 4: Explain the prioritization reasoning for each component in 2-3 sentences.
- **Expected result:** An analysis table of system components with corresponding priority properties and clear explanations.
- **Conclusion:** Each component in the system has different requirements for system properties; there is no single configuration that fits the entire system.

## 1
### title
Analyze Latency and Throughput metrics
### body
- **Steps to follow:**
  - Step 1: Identify critical Latency measurement points in the order flow: from the moment the user clicks the order button until they receive confirmation.
  - Step 2: Analyze the required Throughput: how many orders per second the system needs to handle during peak hours (10,000 concurrent users, estimate the ordering rate).
  - Step 3: Describe the relationship between Latency and Throughput: as Throughput increases, Latency tends to increase due to shared resources.
  - Step 4: Propose acceptable thresholds for Latency (e.g., < 500ms for placing an order) and Throughput (e.g., >= 100 orders/second).
- **Expected result:** Specific analysis with estimated figures for Latency and Throughput at measurement points throughout the system.
- **Conclusion:** Latency and Throughput are complementary metrics that need to be measured and optimized at the system's bottleneck points.

## 2
### title
Analyze relationships between properties
### body
- **Steps to follow:**
  - Step 1: Present the relationship between **Availability** and **Consistency**: increasing Consistency (e.g., synchronous replication) may reduce Availability due to requiring all nodes to synchronize.
  - Step 2: Present the relationship between **Scalability** and **Consistency**: horizontal scaling makes ensuring Consistency more complex.
  - Step 3: Provide a concrete example from the food delivery scenario: if Payment Service uses strong consistency, the Order Service portion could use eventual consistency to increase Availability.
  - Step 4: Synthesize into a diagram or table showing trade-offs between properties.
- **Expected result:** Document clearly presenting trade-offs between system properties with concrete examples from the food delivery scenario.
- **Conclusion:** System design always requires balancing between properties; it is impossible to optimize all of them simultaneously.

## 3
### title
Finalize the document and review
### body
- **Steps to follow:**
  - Step 1: Compile all analysis into a single Google Docs document with a clear structure: (1) Scenario Introduction, (2) System Properties Analysis, (3) Performance Metrics Analysis, (4) Trade-offs, (5) Conclusion.
  - Step 2: Ensure each section has clear headings, specific figures (where applicable), and concise conclusions.
  - Step 3: Review the entire document: no properties among the 4 pillars should be missing, both Latency and Throughput metrics must be analyzed.
- **Expected result:** A complete Google Docs document with logical structure, covering all 4 properties and 2 metrics.
- **Conclusion:** The document demonstrates systematic analysis capability, correctly applying learned concepts to a real-world scenario.

# references
## 0
### alias
Designing Data-Intensive Applications - Chapter 1
### url
https://dataintensive.net/
## 1
### alias
System Design Primer - Performance vs Scalability
### url
https://github.com/donnemartin/system-design-primer#performance-vs-scalability

# submissions
## 0
### type
googleDocsUrl
### title
Google Docs Analysis Document Link
### description
Submit the Google Docs link containing the analysis of system properties and performance metrics for the food delivery scenario.
### score
20
### prompts
#### 0
##### title
Complete analysis of 4 system properties
##### score
8
##### promptText
The document fully analyzes Scalability, Reliability, Availability, Consistency for each system component with clear explanations.
#### 1
##### title
Latency and Throughput analysis
##### score
6
##### promptText
Includes specific analysis of Latency and Throughput with estimated figures, identifying measurement points and acceptable thresholds.
#### 2
##### title
Trade-offs between properties
##### score
6
##### promptText
Clearly presents trade-offs between properties with concrete examples from the scenario, includes a diagram or summary table.

# difficulty
easy

# score
20
