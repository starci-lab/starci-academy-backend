# title
Build a Distributed System Demonstrating CP vs AP with PostgreSQL Replication

# description
Build a simple distributed system with NestJS using PostgreSQL synchronous replication (CP behavior) and asynchronous replication (AP behavior). Observe and document the behavioral differences between the two modes, and write a trade-off analysis document.

# requirements
Create a NestJS app connected to PostgreSQL with replication configured. Set up 2 environments: (1) Synchronous replication - write succeeds only when both primary and replica are synchronized (CP); (2) Asynchronous replication - write succeeds immediately when primary confirms, replica syncs later (AP). Demonstrate the difference through testing: measure write Latency in each mode, simulate replica lag and observe read behavior. Write a trade-off analysis document.

# prerequisites
- Understanding of the CAP theorem and CP vs AP differences
- Node.js >= 18
- NestJS CLI
- Docker and Docker Compose
- Basic knowledge of PostgreSQL replication

# steps

## 0
### title
Set up PostgreSQL primary-replica with Docker Compose
### body
- **Steps to follow:**
  - Step 1: Create `docker-compose.yml` with 2 PostgreSQL containers:
    - `pg-primary`: PostgreSQL primary node.
    - `pg-replica`: PostgreSQL replica node.
  - Step 2: Configure primary to allow replication: create `pg_hba.conf` allowing replication connections, modify `postgresql.conf` with `wal_level = replica`, `max_wal_senders = 2`.
  - Step 3: Configure replica to connect to primary using `primary_conninfo` and `restore_command`.
  - Step 4: Start the system and verify replication is working:
    ```bash
    docker-compose up -d
    docker exec pg-primary psql -U postgres -c "SELECT * FROM pg_stat_replication;"
    ```
- **Expected result:** 2 PostgreSQL containers running, replica successfully connected to primary and receiving WAL logs.
- **Conclusion:** The PostgreSQL replication environment is ready for configuring synchronous and asynchronous modes.

## 1
### title
Configure synchronous and asynchronous replication
### body
- **Steps to follow:**
  - Step 1: Configure **Synchronous replication** (CP behavior): on primary, set `synchronous_commit = on` and `synchronous_standby_names = 'replica1'`. This ensures writes only succeed when the replica confirms data receipt.
  - Step 2: Create the NestJS project:
    ```bash
    nest new cap-theorem-and-tradeoffs-medium
    ```
  - Step 3: Install TypeORM and connect to PostgreSQL primary. Create a `Product` entity with fields: `id`, `name`, `price`, `createdAt`.
  - Step 4: Create `ProductModule` with endpoints:
    - `POST /products` - create a new product (write to primary)
    - `GET /products` - read product list (can read from primary or replica)
    - `GET /products/replica` - read product list from replica (direct connection to replica)
- **Expected result:** NestJS app connects to both primary and replica, write and read endpoints work correctly.
- **Conclusion:** The system is ready to test the differences between synchronous and asynchronous replication.

## 2
### title
Test and compare CP vs AP behavior
### body
- **Steps to follow:**
  - Step 1: **Test Synchronous mode (CP):**
    - Write 100 records and measure average write time:
      ```bash
      time for i in $(seq 1 100); do curl -s -X POST http://localhost:3000/products -H "Content-Type: application/json" -d "{\"name\":\"product-$i\",\"price\":$i}"; done
      ```
    - Read immediately from replica and confirm 100% data consistency.
  - Step 2: Switch to **Asynchronous mode (AP):** on primary, set `synchronous_commit = off`. Restart PostgreSQL.
  - Step 3: **Test Asynchronous mode (AP):**
    - Write 100 records and measure average write time (should be faster than synchronous).
    - Read immediately from replica: may observe data not fully updated (replica lag).
  - Step 4: Simulate slow replica: temporarily stop replica, write more data to primary, restart replica and observe synchronization time.
- **Expected result:** Synchronous mode has higher write Latency but data is always consistent. Asynchronous mode has lower Latency but may have replica lag.
- **Conclusion:** The difference between CP and AP is clearly demonstrated through write Latency and consistency level when reading from replica.

## 3
### title
Write trade-off documentation and conclusion
### body
- **Steps to follow:**
  - Step 1: Record all test metrics: average write Latency for synchronous vs asynchronous, number of inconsistent records when reading from replica in async mode.
  - Step 2: Write a Google Docs document with structure:
    - Introduction: CP vs AP in the context of PostgreSQL replication.
    - Setup: architecture and configuration description.
    - Test results: comparison table of metrics between the 2 modes.
    - Trade-off analysis: when to choose synchronous (CP), when to choose asynchronous (AP).
    - Conclusion: recommendations for each application type.
  - Step 3: Add system architecture diagrams (primary -> replica) and data flow in each mode.
- **Expected result:** Complete documentation and source code with real test metrics proving trade-offs between CP and AP.
- **Conclusion:** The challenge is complete when the learner demonstrates the real-world difference between CP and AP through implementation and concrete measurements.

# references
## 0
### alias
PostgreSQL Replication Documentation
### url
https://www.postgresql.org/docs/current/warm-standby.html
## 1
### alias
PostgreSQL Synchronous Replication
### url
https://www.postgresql.org/docs/current/warm-standby.html#SYNCHRONOUS-REPLICATION
## 2
### alias
CAP Theorem - Wikipedia
### url
https://en.wikipedia.org/wiki/CAP_theorem

# submissions
## 0
### type
googleDocsUrl
### title
Google Docs Trade-off Analysis Link
### description
Submit the Google Docs link containing the trade-off analysis between CP and AP with real test metrics.
### score
12
### prompts
#### 0
##### title
CP vs AP trade-off analysis
##### score
6
##### promptText
The document clearly presents the difference between synchronous (CP) and asynchronous (AP) replication with specific test metrics and appropriate recommendations.
#### 1
##### title
Architecture diagrams and conclusion
##### score
6
##### promptText
Includes system architecture diagrams, a metrics comparison table, and conclusions with recommendations for each application type.
## 1
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing the NestJS app source code and Docker Compose with PostgreSQL replication.
### score
18
### prompts
#### 0
##### title
PostgreSQL replication setup
##### score
6
##### promptText
Docker Compose correctly configures PostgreSQL primary-replica, replication works (can switch between synchronous and asynchronous).
#### 1
##### title
NestJS app with dual connection
##### score
6
##### promptText
NestJS app connects to both primary and replica, has endpoints for writing to primary and reading from replica, complete Product entity.
#### 2
##### title
Tests proving CP vs AP
##### score
6
##### promptText
Includes scripts or instructions for tests proving different Latency between the 2 modes and replica lag in async mode.

# difficulty
medium

# score
30
