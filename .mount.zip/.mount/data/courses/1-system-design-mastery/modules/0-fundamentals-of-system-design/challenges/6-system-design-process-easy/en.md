# title
Apply the 4-Step Process to Design a URL Shortener

# description
Apply the 4-step system design process (requirements clarification, back-of-envelope estimation, high-level design, bottleneck deep-dive) to design a URL Shortener system. Write a complete design document.

# requirements
Design a URL Shortener system capable of handling 100 million new URLs per month. The document must follow the 4 steps of the system design process: (1) Clarify functional and non-functional requirements; (2) Back-of-envelope estimation for storage, bandwidth, and QPS; (3) High-level design with architecture diagram; (4) Bottleneck analysis and proposed solutions. Each step must contain specific content with metrics and technical reasoning.

# prerequisites
- Understanding of the 4-step system design process
- Basic knowledge of web architecture (API, Database, Cache)
- Basic estimation ability (back-of-envelope estimation)

# steps

## 0
### title
Step 1 - Requirements Clarification
### body
- **Steps to follow:**
  - Step 1: List **Functional Requirements**:
    - Create a short URL from a long URL.
    - Redirect from short URL to the original long URL.
    - Optional: custom alias, expiration time (TTL), access statistics.
  - Step 2: List **Non-Functional Requirements**:
    - High Availability (99.9% uptime).
    - Low Latency (redirect < 100ms).
    - Short URL uniqueness (no duplicates).
    - System handles 100 million new URLs/month.
  - Step 3: Define scope: focus only on core features (create and redirect), excluding UI, authentication, or advanced analytics.
  - Step 4: List clarification questions you would ask in an interview: read/write ratio, short URL length, URL storage duration.
- **Expected result:** A clear requirements list distinguishing functional and non-functional requirements with a defined scope.
- **Conclusion:** The requirements clarification step helps define system boundaries and avoids designing too broadly or too narrowly.

## 1
### title
Step 2 - Back-of-Envelope Estimation
### body
- **Steps to follow:**
  - Step 1: Estimate **QPS (Queries Per Second)**:
    - 100 million new URLs/month = ~40 URLs/second (write).
    - Assuming read:write ratio = 100:1 -> 4,000 reads/second.
  - Step 2: Estimate **storage**:
    - Each URL entry: ~500 bytes (short URL + long URL + metadata).
    - 100 million URLs/month x 12 months x 5 years = 6 billion records.
    - Total storage: 6 billion x 500 bytes = ~3 TB.
  - Step 3: Estimate **bandwidth**:
    - Write: 40 URLs/second x 500 bytes = ~20 KB/second.
    - Read: 4,000 URLs/second x 500 bytes = ~2 MB/second.
  - Step 4: Estimate **cache**:
    - Following the 80-20 rule: 20% of URLs account for 80% of traffic.
    - Cache for 20% of 4,000 reads/second x 86,400 seconds = ~70 million entries/day.
    - Cache memory: 70 million x 500 bytes = ~35 GB.
- **Expected result:** A summary table of estimated metrics for QPS, storage, bandwidth, and cache with clear calculation formulas.
- **Conclusion:** Back-of-envelope estimation helps determine system scale and choose appropriate technologies before diving into detailed design.

## 2
### title
Step 3 - High-Level Design
### body
- **Steps to follow:**
  - Step 1: Draw a high-level architecture diagram with components:
    - **Client** -> **Load Balancer** -> **API Server** (create and redirect URLs).
    - **API Server** -> **Database** (store URL mappings).
    - **API Server** -> **Cache** (Redis/Memcached for hot URLs).
  - Step 2: Design **API endpoints**:
    - `POST /api/shorten` - body: `{ longUrl, customAlias?, ttl? }` -> returns `{ shortUrl }`.
    - `GET /:shortCode` - redirects 301/302 to long URL.
  - Step 3: Design **short code generation algorithm**:
    - Option 1: Hash (MD5/SHA256) the long URL, take the first 7 characters.
    - Option 2: Base62 encoding from auto-increment ID or counter.
    - Compare advantages and disadvantages of each option and choose the most suitable.
  - Step 4: Design **database schema**:
    - Table `urls`: `id`, `short_code` (unique index), `long_url`, `created_at`, `expires_at`.
    - Choose database: NoSQL (DynamoDB, Cassandra) for write-heavy and scale, or SQL (PostgreSQL) for simplicity.
- **Expected result:** A clear architecture diagram, complete API design, short code algorithm with analysis, and specific database schema.
- **Conclusion:** High-level design provides an overview of the system and serves as the foundation for diving deeper into specific components.

## 3
### title
Step 4 - Bottleneck Analysis and Proposed Solutions
### body
- **Steps to follow:**
  - Step 1: Identify **Bottleneck 1 - Database**: with 4,000 reads/second, the database may be overloaded.
    - Solution: use cache (Redis) for frequently accessed URLs, database sharding by short_code.
  - Step 2: Identify **Bottleneck 2 - Short code collision**: hashing may produce duplicates.
    - Solution: use a counter-based approach or retry on collision, or use a pre-generated key service.
  - Step 3: Identify **Bottleneck 3 - Single point of failure**: if the API Server or Database goes down, the entire system is unavailable.
    - Solution: multiple API Server instances behind a Load Balancer, database replication (primary-replica).
  - Step 4: Synthesize into a table: bottleneck | severity | solution | trade-off of the solution.
- **Expected result:** A detailed bottleneck analysis table with specific solutions, considering trade-offs of each solution.
- **Conclusion:** Bottleneck analysis is the most important step, demonstrating deep thinking about operating real-world systems.

## 4
### title
Finalize the design document
### body
- **Steps to follow:**
  - Step 1: Compile all 4 steps into a Google Docs document with a clear structure, each step as a separate section.
  - Step 2: Ensure architecture diagrams are included (drawn with draw.io, Excalidraw, or described in detailed text).
  - Step 3: Review: each step should have sufficient metrics, technical reasoning, and conclusions. No steps in the process should be omitted.
- **Expected result:** A complete design document following the 4 steps exactly, usable as a reference for system design interviews.
- **Conclusion:** The document demonstrates the ability to apply the system design process systematically and professionally.

# references
## 0
### alias
System Design Primer - URL Shortener
### url
https://github.com/donnemartin/system-design-primer#design-pastebin.com-or-bit.ly
## 1
### alias
Designing Data-Intensive Applications
### url
https://dataintensive.net/
## 2
### alias
System Design Interview - Alex Xu
### url
https://www.amazon.com/System-Design-Interview-insiders-Second/dp/B08CMF2CQF

# submissions
## 0
### type
googleDocsUrl
### title
Google Docs URL Shortener Design Document Link
### description
Submit the Google Docs link containing the URL Shortener system design document following the 4-step process.
### score
20
### prompts
#### 0
##### title
Requirements clarification and estimation
##### score
7
##### promptText
Step 1 fully lists functional and non-functional requirements. Step 2 includes QPS, storage, bandwidth, cache estimations with clear calculation formulas.
#### 1
##### title
High-level design
##### score
7
##### promptText
Step 3 includes an architecture diagram, API design, short code generation algorithm with pros/cons analysis, and specific database schema.
#### 2
##### title
Bottleneck analysis
##### score
6
##### promptText
Step 4 identifies at least 3 bottlenecks with specific solutions, considers trade-offs of each solution, includes a summary table.

# difficulty
easy

# score
20
