# title
Analyze Real-World Systems Through the CAP Theorem Lens

# description
Analyze two real-world systems (e-commerce and social media) through the CAP theorem lens. Identify whether each system falls into the CP or AP category, explain the reasoning, and describe the corresponding trade-offs.

# requirements
Write a Google Docs document analyzing the CAP theorem for two systems: (1) an e-commerce system (cart and checkout) and (2) a social media system (news feed and interactions). For each system: determine whether it prioritizes CP or AP; explain why partition tolerance is always mandatory in distributed systems; describe the consequences of each choice (CP sacrifices Availability, AP sacrifices Consistency); provide concrete examples of system behavior during a network partition.

# prerequisites
- Understanding of the CAP theorem (Consistency, Availability, Partition Tolerance)
- Basic knowledge of distributed systems
- Understanding of the difference between strong consistency and eventual consistency

# steps

## 0
### title
Analyze e-commerce system through CAP theorem
### body
- **Steps to follow:**
  - Step 1: Describe the e-commerce system with components: Product Catalog Service, Cart Service, Order Service, Payment Service, Inventory Service.
  - Step 2: Explain why **Partition Tolerance** is mandatory: in production environments, network partitions (lost connectivity between nodes/services) are inevitable.
  - Step 3: Analyze why e-commerce should choose **CP** (Consistency + Partition Tolerance) for critical components:
    - Inventory Service: if AP is chosen, two people could purchase the last item simultaneously -> overselling.
    - Payment Service: payment data must be consistent; stale data is unacceptable.
  - Step 4: Describe the consequences of choosing CP: during a partition, some requests will be rejected (503 Service Unavailable) rather than returning inconsistent data.
- **Expected result:** Clear analysis showing the e-commerce system as CP with specific technical reasoning and examples of behavior during partitions.
- **Conclusion:** E-commerce prioritizes Consistency because data discrepancies (overselling, incorrect balances) have more severe consequences than temporary unavailability.

## 1
### title
Analyze social media system through CAP theorem
### body
- **Steps to follow:**
  - Step 1: Describe the social media system with components: News Feed Service, Post Service, Like/Comment Service, Notification Service, User Profile Service.
  - Step 2: Analyze why social media should choose **AP** (Availability + Partition Tolerance) for most components:
    - News Feed: users accept seeing a not-fully-updated feed (eventual consistency) rather than losing access entirely.
    - Like/Comment: like counts may temporarily differ between regions without severe consequences.
  - Step 3: Identify exceptions: which social media components still need CP (e.g., User Authentication still needs strong consistency for security).
  - Step 4: Describe system behavior during a partition: users in region A can still read their feed but may not see new posts from region B until the partition is resolved.
- **Expected result:** Clear analysis showing the social media system as AP with specific exceptions and examples of behavior during partitions.
- **Conclusion:** Social media prioritizes Availability because continuous user experience is more important than absolute data consistency.

## 2
### title
Compare and synthesize trade-offs
### body
- **Steps to follow:**
  - Step 1: Create a comparison table between e-commerce (CP) and social media (AP) using criteria: behavior during partition, user experience, technical risk, implementation complexity.
  - Step 2: Explain the concept of **eventual consistency** and why it is an acceptable solution for AP systems.
  - Step 3: Present techniques to mitigate the drawbacks of each choice:
    - CP: use retry mechanisms, circuit breakers to reduce the impact of lost Availability.
    - AP: use conflict resolution (last-write-wins, vector clocks) to minimize inconsistency.
  - Step 4: Conclude with a general principle: choosing CP or AP depends on "the cost of data discrepancy" versus "the cost of unavailability."
- **Expected result:** A detailed comparison table and analysis of techniques to mitigate trade-offs.
- **Conclusion:** There is no absolutely right or wrong choice, only choices appropriate for specific business requirements.

## 3
### title
Finalize the document
### body
- **Steps to follow:**
  - Step 1: Compile all analysis into a Google Docs document with structure: (1) Introduction to CAP theorem, (2) E-commerce analysis (CP), (3) Social media analysis (AP), (4) Comparison table and trade-offs, (5) Conclusion.
  - Step 2: Ensure each section includes illustrative diagrams (can be drawn with draw.io or described textually) showing system behavior during partitions.
  - Step 3: Review: no components should be missing from the analysis, all trade-offs should be clearly explained.
- **Expected result:** A complete Google Docs document demonstrating deep understanding of the CAP theorem and the ability to apply it in practice.
- **Conclusion:** The document demonstrates systems thinking capability: not just understanding theory but knowing how to apply it to real-world scenarios.

# references
## 0
### alias
CAP Theorem - Wikipedia
### url
https://en.wikipedia.org/wiki/CAP_theorem
## 1
### alias
System Design Primer - CAP Theorem
### url
https://github.com/donnemartin/system-design-primer#cap-theorem
## 2
### alias
Designing Data-Intensive Applications - Chapter 9
### url
https://dataintensive.net/

# submissions
## 0
### type
googleDocsUrl
### title
Google Docs CAP Theorem Analysis Link
### description
Submit the Google Docs link containing the CAP theorem analysis for e-commerce and social media systems.
### score
20
### prompts
#### 0
##### title
E-commerce analysis (CP)
##### score
7
##### promptText
Correctly analyzes e-commerce as CP with specific reasoning (Inventory, Payment need Consistency), includes examples of behavior during partitions.
#### 1
##### title
Social media analysis (AP)
##### score
7
##### promptText
Correctly analyzes social media as AP with specific reasoning, identifies exceptions (Authentication needs CP), includes examples of behavior during partitions.
#### 2
##### title
Comparison and trade-offs
##### score
6
##### promptText
Includes a detailed comparison table between CP and AP, presents techniques to mitigate drawbacks, concludes with a general principle.

# difficulty
easy

# score
20
