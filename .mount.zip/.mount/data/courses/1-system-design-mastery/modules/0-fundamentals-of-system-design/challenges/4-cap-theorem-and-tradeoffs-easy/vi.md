# title
Phân tích hệ thống thực tế qua lăng kính CAP theorem

# description
Phân tích hai hệ thống thực tế (e-commerce và social media) qua lăng kính CAP theorem. Xác định mỗi hệ thống thuộc nhóm CP hay AP, giải thích lý do và các trade-off tương ứng.

# requirements
Viết tài liệu Google Docs phân tích CAP theorem cho hai hệ thống: (1) hệ thống e-commerce (giỏ hàng và thanh toán) và (2) hệ thống social media (news feed và tương tác). Với mỗi hệ thống: xác định nó ưu tiên CP hay AP; giải thích tại sao partition tolerance luôn bắt buộc trong hệ thống phân tán; chỉ ra hậu quả của lựa chọn (CP mất Availability, AP mất Consistency); đưa ra ví dụ cụ thể về hành vi hệ thống khi xảy ra network partition.

# prerequisites
- Hiểu định lý CAP (Consistency, Availability, Partition Tolerance)
- Kiến thức cơ bản về hệ thống phân tán
- Hiểu sự khác biệt giữa strong consistency và eventual consistency

# steps

## 0
### title
Phân tích hệ thống e-commerce qua CAP theorem
### body
- **Các bước thực hiện:**
  - Bước 1: Mô tả hệ thống e-commerce với các thành phần: Product Catalog Service, Cart Service, Order Service, Payment Service, Inventory Service.
  - Bước 2: Giải thích tại sao **Partition Tolerance** là bắt buộc: trong môi trường production, network partition (mất kết nối giữa các node/service) là điều không thể tránh khỏi.
  - Bước 3: Phân tích tại sao e-commerce nên chọn **CP** (Consistency + Partition Tolerance) cho các thành phần quan trọng:
    - Inventory Service: nếu chọn AP, hai người có thể mua cùng một sản phẩm cuối cùng -> overselling.
    - Payment Service: dữ liệu thanh toán phải nhất quán, không thể chấp nhận dữ liệu cũ (stale data).
  - Bước 4: Chỉ ra hậu quả của lựa chọn CP: khi xảy ra partition, một số request sẽ bị từ chối (503 Service Unavailable) thay vì trả dữ liệu không nhất quán.
- **Kết quả mong đợi:** Phân tích rõ ràng hệ thống e-commerce là CP với lý do kỹ thuật cụ thể và ví dụ về hành vi khi partition xảy ra.
- **Kết luận:** E-commerce ưu tiên Consistency vì sai lệch dữ liệu (overselling, sai số dư) gây hậu quả nghiêm trọng hơn việc tạm thời không khả dụng.

## 1
### title
Phân tích hệ thống social media qua CAP theorem
### body
- **Các bước thực hiện:**
  - Bước 1: Mô tả hệ thống social media với các thành phần: News Feed Service, Post Service, Like/Comment Service, Notification Service, User Profile Service.
  - Bước 2: Phân tích tại sao social media nên chọn **AP** (Availability + Partition Tolerance) cho phần lớn các thành phần:
    - News Feed: người dùng chấp nhận được việc xem bài viết chưa đầy đủ 100% (eventual consistency) thay vì không truy cập được.
    - Like/Comment: số lượng like hiển thị có thể chênh lệch tạm thời giữa các region, không gây hậu quả nghiêm trọng.
  - Bước 3: Chỉ ra ngoại lệ: thành phần nào trong social media vẫn cần CP (ví dụ: User Authentication vẫn cần strong consistency để bảo mật).
  - Bước 4: Mô tả hành vi hệ thống khi partition xảy ra: người dùng ở region A vẫn đọc được feed nhưng có thể không thấy bài đăng mới từ region B cho đến khi partition được giải quyết.
- **Kết quả mong đợi:** Phân tích rõ ràng hệ thống social media là AP với ngoại lệ cụ thể, ví dụ về hành vi khi partition xảy ra.
- **Kết luận:** Social media ưu tiên Availability vì trải nghiệm người dùng liên tục quan trọng hơn sự nhất quán tuyệt đối của dữ liệu.

## 2
### title
So sánh và tổng hợp trade-off
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo bảng so sánh giữa e-commerce (CP) và social media (AP) theo các tiêu chí: hành vi khi partition, trải nghiệm người dùng, rủi ro kỹ thuật, độ phức tạp implementation.
  - Bước 2: Giải thích khái niệm **eventual consistency** và tại sao nó là giải pháp chấp nhận được cho AP systems.
  - Bước 3: Trình bày các kỹ thuật giảm thiểu nhược điểm của mỗi lựa chọn:
    - CP: dùng retry mechanism, circuit breaker để giảm tác động của việc mất Availability.
    - AP: dùng conflict resolution (last-write-wins, vector clocks) để giảm thiểu sự không nhất quán.
  - Bước 4: Kết luận với nguyên tắc chung: lựa chọn CP hay AP phụ thuộc vào "chi phí của sự sai lệch dữ liệu" so với "chi phí của việc không khả dụng".
- **Kết quả mong đợi:** Bảng so sánh chi tiết và phân tích các kỹ thuật giảm thiểu trade-off.
- **Kết luận:** Không có lựa chọn đúng hay sai tuyệt đối, chỉ có lựa chọn phù hợp với yêu cầu nghiệp vụ cụ thể.

## 3
### title
Hoàn thiện tài liệu
### body
- **Các bước thực hiện:**
  - Bước 1: Tổng hợp tất cả phân tích vào Google Docs với cấu trúc: (1) Giới thiệu CAP theorem, (2) Phân tích e-commerce (CP), (3) Phân tích social media (AP), (4) Bảng so sánh và trade-off, (5) Kết luận.
  - Bước 2: Đảm bảo mỗi phần có sơ đồ minh họa (có thể vẽ bằng draw.io hoặc mô tả bằng văn bản) thể hiện hành vi hệ thống khi partition xảy ra.
  - Bước 3: Kiểm tra lại: không thiếu bất kỳ thành phần nào trong phân tích, các trade-off được giải thích rõ ràng.
- **Kết quả mong đợi:** Tài liệu Google Docs hoàn chỉnh, thể hiện sự hiểu biết sâu về CAP theorem và khả năng áp dụng vào thực tế.
- **Kết luận:** Tài liệu chứng minh khả năng tư duy hệ thống: không chỉ hiểu lý thuyết mà còn biết áp dụng vào kịch bản thực tế.

# references
## 0
### alias
CAP Theorem - Wikipedia
### url
https://en.wikipedia.org/wiki/CAP_theorem
## 1
### alias
System Design Primer - CAP Theorem
### url
https://github.com/donnemartin/system-design-primer#cap-theorem
## 2
### alias
Designing Data-Intensive Applications - Chapter 9
### url
https://dataintensive.net/

# submissions
## 0
### type
googleDocsUrl
### title
Link Google Docs phân tích CAP theorem
### description
Nộp link Google Docs chứa tài liệu phân tích CAP theorem cho e-commerce và social media.
### score
20
### prompts
#### 0
##### title
Phân tích e-commerce (CP)
##### score
7
##### promptText
Phân tích đúng e-commerce là CP với lý do cụ thể (Inventory, Payment cần Consistency), có ví dụ hành vi khi partition xảy ra.
#### 1
##### title
Phân tích social media (AP)
##### score
7
##### promptText
Phân tích đúng social media là AP với lý do cụ thể, chỉ ra ngoại lệ (Authentication cần CP), có ví dụ hành vi khi partition xảy ra.
#### 2
##### title
So sánh và trade-off
##### score
6
##### promptText
Có bảng so sánh chi tiết giữa CP và AP, trình bày kỹ thuật giảm thiểu nhược điểm, kết luận có nguyên tắc chung.

# difficulty
easy

# score
20
