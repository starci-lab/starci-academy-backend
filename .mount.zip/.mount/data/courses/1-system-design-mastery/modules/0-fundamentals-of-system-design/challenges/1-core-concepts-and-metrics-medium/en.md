# title
Design a Ticket Booking System with Trade-off Analysis Across Pillars

# description
Design a ticket booking system for a large event with 50,000 concurrent users. Analyze trade-offs between the 4 pillars (Scalability, Reliability, Availability, Consistency) and build a basic NestJS demo illustrating the design decisions.

# requirements
Write a system design document for an event ticket booking system including: analysis of the 4 pillars' requirements for each component (Booking Service, Payment Service, Seat Inventory, Notification Service); explanation of why Seat Inventory needs strong consistency (preventing double-booking); clarification of how Scalability affects Consistency when scaling horizontally. Additionally, build a simple NestJS app simulating the booking flow with seat locking mechanism to demonstrate consistency concerns.

# prerequisites
- Knowledge of the 4 pillars of system design
- Understanding of Latency and Throughput metrics
- Node.js >= 18
- NestJS CLI
- Docker (not required but recommended)

# steps

## 0
### title
Analyze ticket booking system requirements
### body
- **Steps to follow:**
  - Step 1: Identify the main system components: Booking Service, Payment Service, Seat Inventory Service, Notification Service.
  - Step 2: For each component, analyze requirements across the 4 pillars:
    - **Seat Inventory**: Highest Consistency (prevent double-booking).
    - **Booking Service**: High Availability (users can always book if seats remain).
    - **Payment Service**: High Reliability (no lost transactions).
    - **Notification Service**: High Availability, low Consistency (notifications can be delayed).
  - Step 3: Define target Latency metric: < 2 seconds for the entire booking flow.
  - Step 4: Estimate Throughput: 50,000 concurrent users, 10% booking rate = 5,000 booking requests per minute = ~83 requests/second.
- **Expected result:** A complete requirements analysis document with a summary table of priority properties for each component.
- **Conclusion:** The ticket booking system demands complex balancing between properties, especially Consistency for Seat Inventory.

## 1
### title
Analyze trade-offs and design decisions
### body
- **Steps to follow:**
  - Step 1: Present the trade-off between **Consistency** and **Availability** for Seat Inventory: using pessimistic locking ensures no double-booking but reduces Throughput.
  - Step 2: Present the trade-off between **Scalability** and **Consistency**: when running multiple instances of Booking Service, a mechanism is needed to synchronize seat state across instances.
  - Step 3: Propose a solution: use database-level locking (SELECT FOR UPDATE) for Seat Inventory to ensure Consistency without complex distributed locks.
  - Step 4: Explain why Notification Service can use a message queue (eventual consistency) to increase Availability and Scalability.
- **Expected result:** Document presenting design decisions with clear technical reasoning, demonstrating understanding of trade-offs.
- **Conclusion:** Every design decision is a deliberate trade-off that must be clearly documented for the development team to understand and maintain.

## 2
### title
Build NestJS demo illustrating consistency
### body
- **Steps to follow:**
  - Step 1: Initialize the NestJS project:
    ```bash
    nest new core-concepts-and-metrics-medium
    ```
  - Step 2: Create `SeatModule` with `SeatService` managing a seat list (can use in-memory array or SQLite).
  - Step 3: Create endpoint `POST /seats/book/:seatId` to perform booking. In `SeatService`, implement seat status check and update logic.
  - Step 4: Simulate the race condition problem: without locking, two concurrent requests can book the same seat. Log output to demonstrate the issue.
  - Step 5: Add a simple locking mechanism (mutex or synchronized access) to resolve the issue and demonstrate consistency.
- **Expected result:** A working NestJS demo that can run 2 concurrent requests and demonstrate the race condition problem before locking, and consistency after locking.
- **Conclusion:** The practical demo illustrates why Consistency is a critical factor in ticket booking systems.

## 3
### title
Test and finalize
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Test the successful booking flow:
    ```bash
    curl -X POST http://localhost:3000/seats/book/1
    ```
  - Step 3: Test booking an already-booked seat (consistency):
    ```bash
    curl -X POST http://localhost:3000/seats/book/1
    ```
    Confirm it returns an error indicating the seat is already booked.
  - Step 4: Finalize the Google Docs document with structure: (1) Requirements Analysis, (2) Trade-offs and Design Decisions, (3) Demo Description and Results, (4) Conclusion.
- **Expected result:** Demo works correctly, document is complete and consistent with the implementation.
- **Conclusion:** The challenge is complete when both the design document and demo demonstrate understanding of trade-offs between system properties.

# references
## 0
### alias
Designing Data-Intensive Applications - Consistency and Consensus
### url
https://dataintensive.net/
## 1
### alias
System Design Primer - Consistency Patterns
### url
https://github.com/donnemartin/system-design-primer#consistency-patterns
## 2
### alias
NestJS Documentation
### url
https://docs.nestjs.com/

# submissions
## 0
### type
googleDocsUrl
### title
Google Docs Design Document Link
### description
Submit the Google Docs link containing the trade-off analysis and design decisions for the ticket booking system.
### score
15
### prompts
#### 0
##### title
Complete analysis of 4 pillars per component
##### score
8
##### promptText
The document fully analyzes Scalability, Reliability, Availability, Consistency for each component (Booking, Payment, Seat Inventory, Notification) with clear reasoning.
#### 1
##### title
Trade-offs and design decisions
##### score
7
##### promptText
Clearly presents trade-offs between pillars, especially Consistency vs Availability for Seat Inventory, and proposes specific solutions.
## 1
### type
githubUrl
### title
GitHub Repository Link for NestJS Demo
### description
Submit the GitHub repository link containing the NestJS demo source code illustrating consistency mechanisms in ticket booking.
### score
15
### prompts
#### 0
##### title
Basic booking demo
##### score
8
##### promptText
The NestJS application has a working booking endpoint with SeatModule and SeatService handling booking logic.
#### 1
##### title
Consistency demonstration
##### score
7
##### promptText
The demo demonstrates the race condition problem and the locking solution; an already-booked seat cannot be re-booked.

# difficulty
medium

# score
30
