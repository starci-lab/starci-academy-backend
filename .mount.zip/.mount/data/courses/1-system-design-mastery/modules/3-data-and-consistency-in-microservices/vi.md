# title
Dữ liệu và Tính nhất quán trong Microservices

# description
Hiểu về các pattern quản lý dữ liệu trong microservices, chuyên sâu vào Database-per-Service và Command Query Responsibility Segregation (CQRS) để xử lý dữ liệu phân tán và duy trì tính nhất quán.

# previewContents
## 0
### text
Database per Service: hiểu rõ lợi ích và thách thức khi chia tách dữ liệu.
## 1
### text
CQRS Pattern: tách biệt thao tác ghi (command) và đọc (query).
## 2
### text
Học cách duy trì tính nhất quán dữ liệu xuyên suốt các hệ thống phân tán.
