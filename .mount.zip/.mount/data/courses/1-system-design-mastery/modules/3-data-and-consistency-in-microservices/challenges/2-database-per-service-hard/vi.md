# title
Nâng cao: Database per Service & API Composition

# description
Trong thử thách này, bạn sẽ triển khai mô hình Database per Service bằng NestJS kết hợp với API Composition. Việc này giúp xử lý rào cản truy xuất dữ liệu phân tán bằng cách tổng hợp dữ liệu từ nhiều service thông qua một Gateway.

# requirements
Mục tiêu của bạn là xây dựng hệ thống gồm `OrderService` và `InventoryService`. Để giải quyết sự cô lập dữ liệu, bạn phải triển khai thêm một `ApiGateway` đóng vai trò là API Composer. Gateway này sẽ thực hiện truy vấn song song tới các microservices và trộn dữ liệu lại. Bạn cũng cần tích hợp Redis cache trên Gateway để giảm tải network.

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose**
- **NestJS CLI**

# steps

## 0
### title
Hạ tầng Docker
### body
Tạo tệp `docker-compose.yaml` để chạy các database và tầng cache độc lập.
- **PostgreSQL** (Dành cho Database của Order service)
- **MongoDB** (Dành cho Database của Inventory service)
- **Redis** (Dành cho bộ nhớ đệm tại Gateway)

## 1
### title
Khởi tạo Microservice
### body
Tạo các ứng dụng NestJS xử lý nghiệp vụ:
- **Order Service**: Dùng `@nestjs/typeorm` với PostgreSQL.
- **Inventory Service**: Dùng `@nestjs/mongoose` với MongoDB. 
Đảm bảo hai service tuyệt đối không chia sẻ kết nối cơ sở dữ liệu.

## 2
### title
API Gateway & API Composition
### body
Tạo service thứ ba mang tên `ApiGateway`. Service này bảo vệ và cung cấp các endpoint public.
Thiết kế tính năng API Composition tại endpoint `GET /gateway/orders/:id`. Cụ thể, Gateway phải:
1. Gọi API (HTTP hoặc TCP) sang `OrderService` để lấy gốc thông tin hoá đơn.
2. Trích xuất danh sách ID sản phẩm từ hoá đơn.
3. Chuyển tiếp các ID đó sang `InventoryService` để lấy chi tiết tên, mô tả sản phẩm.
4. Xử lý "stitch" (trộn) dữ liệu trên bộ nhớ RAM rồi mới trả về json duy nhất cho client.

## 3
### title
Tối ưu hóa bằng Caching
### body
Nhằm ngăn chặn việc ApiGateway gửi request liên tục lấy thông tin sản phẩm (vốn ít thay đổi), hãy cài đặt Redis cache. Gateway sẽ kiểm tra thông tin sản phẩm trong Redis trước, nếu `Cache Miss` thì mới gọi qua Inventory service và ghi lại vào cache với chỉ số TTL phù hợp.

# references
## 0
### alias
API Composition Pattern
### url
https://microservices.io/patterns/data/api-composition.html
## 1
### alias
NestJS Caching
### url
https://docs.nestjs.com/techniques/caching

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Nộp đường dẫn GitHub chứa cấu trúc hệ thống và file `docker-compose.yaml`.
### score
100
### prompts
#### 0
##### title
Xử lý API Composition
##### score
40
##### promptText
ApiGateway có hoàn thiện tính năng fetch và trộn dữ liệu (stitching) chính xác từ hai microservice backend độc lập không?
#### 1
##### title
Tính năng Caching
##### score
30
##### promptText
Tính năng Redis Cache có được ứng dụng tại gateway nhằm giảm thiểu truy vấn mạng thừa thãi cho dữ liệu sản phẩm không?
#### 2
##### title
Tính cô lập dữ liệu tuyệt đối
##### score
30
##### promptText
Ứng dụng có tuân thủ tuyệt đối việc cô lập cơ sở dữ liệu (Order không được read thẳng vào MongoDB) không?

# difficulty
hard

# score
100
