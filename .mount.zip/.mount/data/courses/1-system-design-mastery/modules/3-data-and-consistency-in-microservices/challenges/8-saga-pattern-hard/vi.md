# title
Nâng cao: Orchestrator Saga & Transactional Outbox

# description
Trong thử thách cực kỳ chuyên sâu này, bạn sẽ làm chủ mô hình Saga dạng tĩnh Orchestration, kết hợp với mẫu kiến trúc Transactional Outbox để đảm bảo hoàn toàn không xảy ra tình trạng mất gói tin (message loss) trên Kafka do lỗi rớt mạng.

# requirements
Nâng cấp từ mô hình Choreography cũ lên dạng có trung tâm điều phối Orchestrator. Thêm vào đó, ngăn chặn dứt điểm tình trạng "dual write" ảo bằng cách cấu hình hệ thống Transactional Outbox, giữ cho việc lưu trữ database nội bộ và phát sự kiện Kafka luôn đồng bộ nguyên tử (atomic).

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose** (Kafka, PostgreSQL)
- **NestJS CLI**
- Cài đặt package `@nestjs/microservices`

# steps

## 0
### title
Bài toán Dual-Write
### body
Khi 1 service vừa cố gắng cập nhật database nội bộ vừa phát đi Kafka event, nếu mạng bị lỗi ngay giây phút event phát đi, sự nhất quán của hệ thống sẽ đổ vỡ.
Khởi tạo cấu trúc PostgreSQL gồm các bảng tác vụ như `orders`, và tạo thêm một bảng `outbox_events` dùng để chứa các gói thông điệp đang chờ chuyển đi.

## 1
### title
Triển khai Transactional Outbox
### body
Thực thi ghi dữ liệu thông qua cơ chế Transaction của SQL (sử dụng TypeORM `queryRunner`).
1. Cập nhật record dữ liệu nền (Ví dụ: trạng thái đơn hàng).
2. Lưu cục payload của Kafka vào trong bảng `outbox_events` *nằm chung trong cùng một khối transaction cơ sở dữ liệu*.
3. Chạy thêm một bộ lặp CRON job ngầm (`@nestjs/schedule`) chịu trách nhiệm thường xuyên đọc bảng `outbox_events`, rồi mới an toàn đưa event lên Kafka và gỡ trạng thái thành `SENT`.

## 2
### title
Xây dựng Saga Orchestrator Service
### body
Xóa bỏ sự kiện lắng nghe lộn xộn giữa các service. Khởi tạo một vị trí trung gian là `Orchestrator Service`.
Orchestrator kiểm soát toàn mạch luồng mua hàng:
1. Nhận lệnh kích hoạt từ Order.
2. Chủ động đánh lệnh yêu cầu `InventoryService` trừ kho.
3. Đợi có trả về từ Inventory, Orchestrator đưa tiếp lệnh đến `PaymentService` yêu cầu thu tiền.
4. Nếu Payment trả về lỗi, Orchestrator sẽ phát lệnh rollback chuyên trách đến thẳng `InventoryService` để thực hiện bù trừ.

## 3
### title
Bảo đảm tính Idempotency (Lũy đẳng)
### body
Lập lịch CRON Outbox có thể bị crash ngay sau khi gửi qua Kafka thành công nhưng chưa kịp chốt dấu trên DB `outbox_events`. Kết quả dẫn đến Kafka nhận nhiều event trùng nhau.
Bắt buộc bạn phải viết cơ chế filter "Lũy đẳng" cho toàn bộ Consumer để xác nhận và bỏ qua event lặp, ngăn chặn lỗi như bị trừ tiền credit card đến hai lần.

# references
## 0
### alias
Transactional Outbox Pattern
### url
https://microservices.io/patterns/data/transactional-outbox.html
## 1
### alias
Orchestration vs Choreography
### url
https://microservices.io/patterns/data/saga.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Nộp repo Github trình bày được độ chặt chẽ của việc áp dụng Orchestrator Saga và Transactional Outbox.
### score
100
### prompts
#### 0
##### title
Cớ chế Transactional Outbox
##### score
40
##### promptText
Dual-write có được xử lý triệt để không nhờ dùng chung transaction commit cho Outbox table và local domain table?
#### 1
##### title
Orchestrator Điều Phối
##### score
30
##### promptText
Hệ thống có thật sự được dẫn nhịp từ trung tâm Orchestrator thay vì để các service phụ trợ tự giao tiếp phi định hướng với nhau không?
#### 2
##### title
Phòng chống lặp trùng Ideompotency
##### score
30
##### promptText
Hệ thống tiêu thụ ở Consumer có bắt và chặn đứng kịp thời các event Kafka bị lặp lại dựa trên unique khóa message id không?

# difficulty
hard

# score
100
