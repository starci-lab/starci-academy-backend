# title
Cơ bản: Database per Service

# description
Hiểu cốt lõi của microservices bằng cách tách biệt cơ sở dữ liệu monolithic sang mô hình Database-per-Service.

# requirements
Xây dựng 'UserService' (PostgreSQL) và 'ProductService' (MongoDB). Hai service này phải hoạt động độc lập và không chia sẻ database.

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose**
- **NestJS CLI**

# steps

## 0
### title
Hạ tầng Docker
### body
Tạo tệp `docker-compose.yaml` để chạy PostgreSQL và MongoDB độc lập.

## 1
### title
Microservice độc lập
### body
Khởi tạo hai ứng dụng NestJS, mỗi ứng dụng kết nối tới database riêng. Triển khai các REST API cơ bản.

# references
## 0
### alias
Database per Service
### url
https://microservices.io/patterns/data/database-per-service.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Nộp đường dẫn GitHub repo dự án của bạn.
### score
20
### prompts
#### 0
##### title
Tính cô lập dữ liệu
##### score
20
##### promptText
Hai service có database hoàn toàn độc lập và không query chéo không?

# difficulty
easy

# score
20