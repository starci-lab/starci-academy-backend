# title
Intermediate: CQRS with Dual Databases

# description
Take CQRS a step further by separating the Read Datastore from the Write Datastore to optimize query performance.

# requirements
Use PostgreSQL for writes and MongoDB for reads. When a Command updates PostgreSQL, publish an Event. The EventHandler should then update the MongoDB Read model.

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose**
- **NestJS CLI**

# steps

## 0
### title
Dual Database Infrastructure
### body
Run PostgreSQL (Write Model) and MongoDB (Read Model) using Docker Compose.

## 1
### title
Data Synchronization
### body
After a successful write in the Command Handler, dispatch an event to the EventBus. Listen for this event and replicate the simplified data projection to MongoDB.

# references
## 0
### alias
CQRS Pattern
### url
https://microservices.io/patterns/data/cqrs.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Submit the GitHub repo link.
### score
50
### prompts
#### 0
##### title
Event-Driven Projection
##### score
50
##### promptText
Does the system correctly update the MongoDB Read view asynchronously when writes occur in PostgreSQL?

# difficulty
medium

# score
50