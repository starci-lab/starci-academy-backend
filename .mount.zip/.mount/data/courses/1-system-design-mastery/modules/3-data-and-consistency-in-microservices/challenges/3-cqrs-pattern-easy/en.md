# title
Foundations: CQRS Pattern

# description
Learn the basics of Command Query Responsibility Segregation by separating reads and writes within a single application using NestJS CQRS module.

# requirements
Build a 'ProductCatalog' application. Implement Commands (e.g., CreateProductCommand) to mutate state and Queries (e.g., GetProductsQuery) to read state, using the standard `@nestjs/cqrs` package.

# prerequisites
- **Node.js >= 18**
- **NestJS CLI**
- `@nestjs/cqrs` package

# steps

## 0
### title
CQRS Module Setup
### body
Import the NestJS CQRS module into your application.

## 1
### title
Command & Query Separation
### body
Create distinct directories for Commands (write logic) and Queries (read logic) and implement the respective Handlers.

# references
## 0
### alias
NestJS CQRS
### url
https://docs.nestjs.com/recipes/cqrs

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Submit your GitHub repo link.
### score
20
### prompts
#### 0
##### title
CQRS Implementation
##### score
20
##### promptText
Are Commands and Queries properly segregated using the NestJS CQRS architecture?

# difficulty
easy

# score
20