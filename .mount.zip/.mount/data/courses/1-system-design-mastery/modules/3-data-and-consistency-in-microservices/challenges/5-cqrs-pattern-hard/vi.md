# title
Nâng cao: CQRS kết hợp Event Sourcing

# description
Trong thử thách này, bạn sẽ triển khai một mô hình CQRS cấp độ cao bằng NestJS. Thay vì chỉ lưu trạng thái hiện tại ở phía write model (Postgres), bạn sẽ tích hợp rập khuôn Event Sourcing để lưu trữ mọi vết thay đổi dưới dạng chuỗi sự kiện bất biến (immutable events).

# requirements
Mục tiêu là xây dựng hệ thống Quản lý Tài khoản Ngân hàng (Bank Account system). Phía "Command" phải lưu lại một chuỗi vết tích giao dịch (`AccountOpened`, `MoneyDeposited`, `MoneyWithdrawn`) vào bảng `EventStore` ở PostgreSQL. Từ chuỗi event đó, hệ thống sẽ ánh xạ (project) các thay đổi này sang Elasticsearch hoặc MongoDB để duy trì một View model truy xuất siêu nhanh cho phía "Query".

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose**
- **NestJS CLI**
- Package `@nestjs/cqrs`

# steps

## 0
### title
Khởi tạo Event Store
### body
Sử dụng **PostgreSQL** làm Event Store (nơi lưu chuỗi sự kiện) và **MongoDB** làm Read Datastore (nơi lưu view dự phóng). 
Thay vì thiết kế bảng `Account` chứa thông tin dư nợ hiện hành, bạn chỉ thiết kế một bảng `Event` lưu `id`, `streamId` (khóa tài khoản), `eventType`, `payload` (JSON), và `version`.

## 1
### title
Cơ chế Command Handlers & Tính toán từ Event
### body
Viết logic Command (VD: `WithdrawMoneyCommand`).
Trong Command Handler này:
1. Load tất cả chuỗi event cũ của tài khoản đó rồi "replay" lại để tính toán số dư hiện tại trong bộ nhớ.
2. Xác minh tính hợp lệ (Số dư có đủ không?).
3. Nếu hợp lệ, lưu event mới (VD: `MoneyWithdrawnEvent`) dưới dạng Append-Only (chỉ được thêm, không được sửa xóa) vào bảng `EventStore`.
4. Gửi event lên EventBus của NestJS.

## 2
### title
Optimistic Concurrency Control (Khóa lạc quan)
### body
Sử dụng trường `version` trên cấu trúc bảng lưu Event để ngăn chặn Race Condition. Khi hai luồng rút tiền gửi đến cùng lúc cho một ID, thao tác commit nào có version trùng lặp thay đổi trên DB sẽ bị `EventStore` chặn lại nhằm đảm bảo Event nào thực hiện sau phải thử lại lệnh (retry).

## 3
### title
Đồng bộ Read Projection
### body
Tạo các Event Handlers bắt sự kiện thông qua EventBus.
Mỗi khi xuất hiện sự kiện, handler sẽ cập nhật dữ liệu cấu trúc phẳng (flattened document) sang MongoDB, đảm bảo model Read luôn phản ánh snapshot tính tới thời điểm hiện tại của một tài khoản.

## 4
### title
Truy vấn phản hồi nhanh (Query)
### body
Khởi tạo `GetAccountSummaryQuery`. Handler này sẽ chỉ fetch thẳng dữ liệu document đã được nhào nặn từ MongoDB, mang lại tốc độ cực nhanh mà không dính líu đến PostgreSQL.

# references
## 0
### alias
Event Sourcing Pattern
### url
https://microservices.io/patterns/data/event-sourcing.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Nộp đường dẫn Github chứa dự án kết hợp Event Sourcing và CQRS.
### score
100
### prompts
#### 0
##### title
Cơ chế Event Sourcing
##### score
40
##### promptText
Phía write model có tuân thủ chặt chẽ việc lưu trữ dưới định dạng chuỗi event không sửa đổi, và biết replay event để khôi phục state không?
#### 1
##### title
Ánh xạ Query Projection
##### score
30
##### promptText
Ứng dụng có cơ chế đồng bộ projection hoàn hảo sang database NoSQL nhằm tạo read model tĩnh siêu tối ưu không?
#### 2
##### title
Xử lý đồng thời (Concurrency)
##### score
30
##### promptText
Đã tích hợp Optimistic Locking version version tracking để tránh race condition khi cùng lúc ghi nhiều sự kiện cho một entity chưa?

# difficulty
hard

# score
100
