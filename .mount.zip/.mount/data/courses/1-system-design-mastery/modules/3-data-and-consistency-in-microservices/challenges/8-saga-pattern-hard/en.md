# title
Advanced: Orchestrator Saga & Transactional Outbox

# description
In this challenge, you will implement an advanced Orchestration-style Saga combined with the Transactional Outbox pattern to ensure zero message loss across Kafka topics during network outages.

# requirements
Migrate the checkout flow from a decentralized choreography approach to a centralized Orchestrator pattern. Furthermore, overcome the "dual write" problem by implementing the Transactional Outbox pattern locally on the generic microservices.

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose** (Kafka, PostgreSQL)
- **NestJS CLI**
- `@nestjs/microservices` package

# steps

## 0
### title
The Dual-Write Problem
### body
When a service updates a local database and instantly emits a Kafka event, network failure can prevent the event from publishing, leading to inconsistency. 
Set up a PostgreSQL database. In addition to normal domain tables (like `orders`), create an `outbox_events` table representing pending Kafka messages. 

## 1
### title
Transactional Outbox Implementation
### body
In your local service logic, execute writes using an ACID Transaction framework (like TypeORM `queryRunner`).
1. Update the local entity (e.g., set order status to PENDING).
2. Insert a serialized message payload into the `outbox_events` table *within the exact same SQL transaction*.
3. Use a background CRON job (`@nestjs/schedule`) or a Change Data Capture tool to poll the `outbox_events` table and securely publish the events to Kafka, marking them as `SENT`.

## 2
### title
Saga Orchestrator Service
### body
Create a centralized `Orchestrator Service` that coordinates the Saga. 
Instead of services directly reacting to each other (Choreography), the Orchestrator will:
1. Receive an `order-requested` event.
2. Instruct the `InventoryService` to process inventory.
3. Wait for the `InventoryService` response. If successful, instruct the `PaymentService`.
4. If the `PaymentService` fails, the Orchestrator must actively issue a compensating command to the `InventoryService` to rollback.

## 3
### title
Handling Idempotency
### body
Because the outbox processor might crash directly after successfully publishing to Kafka but before marking it as `SENT`, duplicate messages may arrive at the Orchestrator or downstream services. Implement idempotency keys (tracking processed message IDs) to prevent business operations from accidentally duplicating (like charging a credit card twice).

# references
## 0
### alias
Transactional Outbox Pattern
### url
https://microservices.io/patterns/data/transactional-outbox.html
## 1
### alias
Orchestration vs Choreography
### url
https://microservices.io/patterns/data/saga.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Submit the GitHub repo demonstrating the Orchestrator Saga and Transactional Outbox integrations.
### score
100
### prompts
#### 0
##### title
Transactional Outbox Integration
##### score
40
##### promptText
Is the outbox pattern correctly resolving the dual-write problem by saving to an outbox table under the same transaction boundary before emitting to Kafka?
#### 1
##### title
Saga Orchestrator
##### score
30
##### promptText
Does a single Orchestrator entity dictate the workflow (sending execution and compensating commands) rather than using decentralized event subscription?
#### 2
##### title
Idempotency Controls
##### score
30
##### promptText
Are the downstream services properly coded to ignore duplicate Kafka message deliveries using Idempotency strategies?

# difficulty
hard

# score
100
