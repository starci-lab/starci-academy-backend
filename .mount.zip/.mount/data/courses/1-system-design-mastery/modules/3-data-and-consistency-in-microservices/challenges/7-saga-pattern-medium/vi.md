# title
Trung cấp: Điều phối Orchestration Saga

# description
Chuyển từ hướng xử lý phi tập trung Choreography sang cấu trúc có Controller điều phối chính nhằm quản lý quy trình transaction phân tán khi có sự cố xảy ra.

# requirements
Tạo một 'OrderOrchestrator' chỉ đạo có trình tự tới `InventoryService` và `PaymentService`. Nếu khâu Payment lỗi, Orchestrator phải tung lệnh bồi hoàn (compensation) để xử lý hoàn lại trong Inventory.

# prerequisites
- **Node.js >= 18**
- **Docker**
- **NestJS CLI**

# steps

## 0
### title
Bộ Điều phối trung tâm
### body
Tạo `Orchestrator` chịu trách nhiệm theo dõi toàn mạch checkout.

## 1
### title
Giao dịch Bồi hoàn
### body
Đảm bảo khi một nhánh service thất bại gửi về lỗi, hệ thống phải tự tung lệnh 'Undo' quay lại rollback các tác vụ trước đó.

# references
## 0
### alias
Saga Compensating Transactions
### url
https://microservices.io/patterns/data/saga.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Nộp repo GitHub.
### score
50
### prompts
#### 0
##### title
Tính năng Bồi hoàn
##### score
50
##### promptText
Orchestrator có thật sự kích hoạt lệnh Rollback và hoàn tác được dữ liệu khi có 1 khâu thất bại không?

# difficulty
medium

# score
50