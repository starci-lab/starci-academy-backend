# title
Trung cấp: CQRS với Đa cơ sở dữ liệu

# description
Nâng cấp CQRS lên cấp tiếp theo bằng cách tách rời Database Đọc và Database Ghi để tối ưu tốc độ truy vấn.

# requirements
Sử dụng PostgreSQL để ghi và MongoDB để đọc. Khi Command cập nhật vào PostgreSQL, hãy phát đi một Event. EventHandler sẽ lắng nghe sự kiện này và cập nhật vào Read model ở MongoDB.

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose**
- **NestJS CLI**

# steps

## 0
### title
Hạ tầng Đa Database
### body
Chạy PostgreSQL (Write Model) và MongoDB (Read Model) thông qua Docker Compose.

## 1
### title
Đồng bộ dữ liệu
### body
Sau khi xử lý xong việc GHI tại Command Handler, đẩy một event lên EventBus. Lắng nghe event này và lưu lại bản sao truy vấn vào MongoDB.

# references
## 0
### alias
CQRS Pattern
### url
https://microservices.io/patterns/data/cqrs.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Nộp repo GitHub.
### score
50
### prompts
#### 0
##### title
Đồng bộ Projection
##### score
50
##### promptText
Hệ thống có cập nhật bất đồng bộ chính xác dữ liệu từ database Ghi (PG) sang bản dự phóng Đọc (Mongo) không?

# difficulty
medium

# score
50