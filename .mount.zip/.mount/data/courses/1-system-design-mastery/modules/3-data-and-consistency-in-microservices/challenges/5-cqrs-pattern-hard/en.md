# title
Advanced: CQRS with Event Sourcing

# description
In this challenge, you will implement an advanced CQRS pattern using NestJS. Rather than just storing the current state in the PostgreSQL write model, you will implement Event Sourcing to store every state change as an immutable event.

# requirements
Your goal is to build an Event-Sourced Bank Account system. The "Command" side must record transactions (`AccountOpened`, `MoneyDeposited`, `MoneyWithdrawn`) into an `EventStore` table in PostgreSQL. The system will then replay these events to compute the current balance, while concurrently projecting them into Elasticsearch or MongoDB to build a heavily optimized "Query" read model.

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose**
- **NestJS CLI**
- `@nestjs/cqrs` package

# steps

## 0
### title
Event Store Initialization
### body
Set up **PostgreSQL** to act as your Event Store and **MongoDB/Elasticsearch** as your Read Datastore. 
Instead of creating a traditional `Account` entity in Postgres, create an `Event` entity with columns like `id`, `streamId` (accountId), `eventType`, `payload` (JSON), and `timestamp`.

## 1
### title
Command Handlers & Event Sourcing
### body
Implement Commands for actions like `DepositMoneyCommand`.
Within the Command Handler:
1. Verify business rules (e.g. account isn't locked). You may need to load past events from the `Event` table to compute the current balance.
2. If valid, persist a new event (e.g., `MoneyDepositedEvent`) to the `EventStore` table.
3. Dispatch the event to the EventBus.

## 2
### title
Optimistic Concurrency Control
### body
Add a `version` or sequence number to your events to prevent concurrency race conditions. When two deposits happen simultaneously, the system should enforce the sequence order and reject or retry outdated transactions.

## 3
### title
Building the View/Projection (Read Side)
### body
Create Event Handlers (`MoneyDepositedEventHandler`) that listen to the EventBus.
When events are dispatched, the handlers project (upsert) the current state (the total balance and transaction history up to that point) into the separate, read-optimized MongoDB/Elasticsearch datastore.

## 4
### title
Read-only Query
### body
Create a `GetAccountSummaryQuery`. Its handler should blindly fetch the pre-computed schema from the Read datastore, achieving sub-millisecond response times.

# references
## 0
### alias
Event Sourcing Pattern
### url
https://microservices.io/patterns/data/event-sourcing.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Submit the GitHub repo link containing the CQRS + Event Sourcing implementation.
### score
100
### prompts
#### 0
##### title
Event Sourcing Implementation
##### score
40
##### promptText
Is the write model purely an append-only Event Store, meaning the system computes state by applying historic events rather than mutating an existing record?
#### 1
##### title
Read Projection
##### score
30
##### promptText
Are events captured properly to project dynamic updates onto a dedicated read-only NoSQL collection?
#### 2
##### title
Concurrency Handling
##### score
30
##### promptText
Is there a robust versioning strategy (Optimistic Locking) to handle race conditions when writing concurrent events to the EventStore?

# difficulty
hard

# score
100
