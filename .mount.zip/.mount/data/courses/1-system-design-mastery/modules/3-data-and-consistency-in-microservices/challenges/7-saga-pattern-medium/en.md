# title
Intermediate: Orchestration Saga Pattern

# description
Shift from a decentralized Choreography flow to a centralized Orchestrator to manage distributed transactions and handle failures gracefully.

# requirements
Create an 'OrderOrchestrator' that systematically instructs the `InventoryService` and `PaymentService`. If Payment fails, the Orchestrator must send a compensating action to reverse the Inventory step.

# prerequisites
- **Node.js >= 18**
- **Docker**
- **NestJS CLI**

# steps

## 0
### title
Centralized Coordinator
### body
Create a dedicated `Orchestrator` module that listens for checkout initiations.

## 1
### title
Compensating Transactions
### body
Ensure that if a downstream service returns a failure response during the saga workflow, the orchestrator emits 'Undo' commands to rollback previously succeeded steps.

# references
## 0
### alias
Saga Compensating Transactions
### url
https://microservices.io/patterns/data/saga.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Submit the GitHub repo.
### score
50
### prompts
#### 0
##### title
Compensation Logic
##### score
50
##### promptText
Does the Orchestrator successfully dispatch and execute Rollback/Compensating transactions when a step fails?

# difficulty
medium

# score
50