# title
Trung cấp: Database per Service & API Gateway

# description
Triển khai một API Gateway để định tuyến và cung cấp các microservice ẩn bên dưới ra phía frontend một cách an toàn.

# requirements
Thêm một service 'ApiGateway' nhận request từ client và chuyển tiếp chúng đến đúng microservice phía sau (UserService hoặc ProductService).

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose**
- **NestJS CLI**

# steps

## 0
### title
Cài đặt API Gateway
### body
Tạo service thứ ba mang tên `ApiGateway`.

## 1
### title
Định tuyến (Routing)
### body
Triển khai HTTP routing tại API Gateway: chuyển tiếp request `/users/*` tới UserService và `/products/*` tới ProductService.

# references
## 0
### alias
API Gateway Pattern
### url
https://microservices.io/patterns/apigateway.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Nộp đường dẫn GitHub repo chứa mã nguồn.
### score
50
### prompts
#### 0
##### title
Định tuyến Gateway
##### score
50
##### promptText
API Gateway có chuyển tiếp chính xác request đến đúng đích service không?

# difficulty
medium

# score
50