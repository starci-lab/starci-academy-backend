# title
Intermediate: Database per Service with API Gateway

# description
Implement an API Gateway to properly route and expose your isolated microservices to the frontend.

# requirements
Add an 'ApiGateway' service that receives client requests and forwards them to the correct underlying microservice (UserService or ProductService).

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose**
- **NestJS CLI**

# steps

## 0
### title
API Gateway Setup
### body
Create a new NestJS service named `ApiGateway`.

## 1
### title
Routing Implementation
### body
Implement HTTP routing in the API Gateway to forward requests for `/users/*` to the UserService and `/products/*` to the ProductService.

# references
## 0
### alias
API Gateway Pattern
### url
https://microservices.io/patterns/apigateway.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Submit the GitHub repo link containing the gateway setup.
### score
50
### prompts
#### 0
##### title
Gateway Routing
##### score
50
##### promptText
Does the API Gateway correctly route requests to the independent downstream services?

# difficulty
medium

# score
50