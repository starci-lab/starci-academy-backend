# title
Cơ bản: Choreography Saga

# description
Học cách xử lý transaction hệ thống thông qua giao tiếp bất đồng bộ (messaging) không cần một bộ điều khiển trung tâm.

# requirements
Xây dựng luồng thương mại điện tử đơn giản. 'OrderService' phát bắn event `OrderCreated`. 'InventoryService' lắng nghe, giảm số lượng hàng trong kho và phát sự kiện `InventoryReserved`.

# prerequisites
- **Node.js >= 18**
- **Docker (Kafka/RabbitMQ)**
- **NestJS CLI**

# steps

## 0
### title
Cài đặt Message Broker
### body
Thiết lập hệ thống thông điệp Kafka hoặc RabbitMQ bằng `docker-compose.yaml`.

## 1
### title
Luồng dự kiện phân tán
### body
Triển khai phát bắn sự kiện với `@nestjs/microservices`. OrderService phát lệnh, InventoryService chỉ việc nhận và tự tiếp tục nghiệp vụ.

# references
## 0
### alias
Saga Pattern
### url
https://microservices.io/patterns/data/saga.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Nộp repo GitHub.
### score
20
### prompts
#### 0
##### title
Hoạt động Choreography
##### score
20
##### promptText
Các service có tự tương tác trực tiếp qua luồng sự kiện thay vì lệnh HTTP Call không?

# difficulty
easy

# score
20