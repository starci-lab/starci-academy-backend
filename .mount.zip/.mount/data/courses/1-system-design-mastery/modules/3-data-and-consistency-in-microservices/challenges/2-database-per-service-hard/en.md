# title
Advanced: Database per Service with API Composition

# description
In this challenge, you will implement the Database per Service pattern using NestJS. To handle the isolated data architecture, you will also implement the API Gateway & API Composition patterns to seamlessly join data across boundaries without shared databases.

# requirements
Your goal is to build an e-commerce microservice backbone with `OrderService` and `InventoryService`. To solve the querying complexity that arises from data isolation, you must implement an `ApiGateway` service that acts as an API Composer. The Gateway will parallelize queries to microservices and stitch the results together. You must also implement Redis caching on the Gateway to minimize network overhead.

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose**
- **NestJS CLI**

# steps

## 0
### title
Dockerized Infrastructure
### body
Create a `docker-compose.yaml` file to spin up isolated databases and caching layers.
- **PostgreSQL** (Order service database)
- **MongoDB** (Inventory service database)
- **Redis** (For caching at the gateway layer)

## 1
### title
Microservice Initialization
### body
Create two distinct NestJS projects or monorepo apps. 
- **Order Service**: Uses `@nestjs/typeorm` with PostgreSQL. Handles local ACID transactions for order placement.
- **Inventory Service**: Uses `@nestjs/mongoose` with MongoDB. Handles stock counters. 
Expose REST or TCP endpoints for both services. Ensure no service accesses another's database directly.

## 2
### title
The API Gateway & API Composition
### body
Create a third NestJS service called `ApiGateway`. This service will expose public endpoints to the client.
Implement an API Composition endpoint (e.g., `GET /gateway/orders/:id`). The gateway must:
1. Make an HTTP or TCP call to the `OrderService` to retrieve the order details.
2. Extract the product IDs from the order.
3. Make a call to the `InventoryService` to get the product details.
4. Merge/stitch the data together in-memory and return a unified JSON response.

## 3
### title
Implement Request Caching
### body
To prevent the API Gateway from constantly hitting the `InventoryService` for static product details, integrate a Redis cache within the Gateway. Retrieve product details from Redis if available; otherwise, query the Inventory service and cache the result with an appropriate TTL.

# references
## 0
### alias
API Composition Pattern
### url
https://microservices.io/patterns/data/api-composition.html
## 1
### alias
NestJS Caching
### url
https://docs.nestjs.com/techniques/caching

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Submit the GitHub repo link containing your services and `docker-compose.yaml`.
### score
100
### prompts
#### 0
##### title
API Composition Validation
##### score
40
##### promptText
Does the ApiGateway successfully aggregate and stitch data from both distinct backend microservices (Order and Inventory) into a single response?
#### 1
##### title
Caching Implementation
##### score
30
##### promptText
Is Redis properly implemented to intercept redundant calls for product information, thereby enhancing performance?
#### 2
##### title
Strict Database Isolation
##### score
30
##### promptText
Is data logic strictly maintained such that no service breaches database boundaries (e.g. Order Service querying MongoDB)?

# difficulty
hard

# score
100
