# title
Foundations: Choreography Saga Pattern

# description
Learn how to link microservices transactions via asynchronous messaging without a centralized controller.

# requirements
Build a basic e-commerce flow. The 'OrderService' emits an `OrderCreated` event. The 'InventoryService' listens to it, reduces stock, and emits an `InventoryReserved` event.

# prerequisites
- **Node.js >= 18**
- **Docker (Kafka/RabbitMQ)**
- **NestJS CLI**

# steps

## 0
### title
Message Broker configuration
### body
Set up Kafka or RabbitMQ via `docker-compose.yaml`.

## 1
### title
Decentralized Event Flow
### body
Implement event emitters in NestJS using `@nestjs/microservices`. OrderService publishes, and InventoryService acts purely on the subscription event.

# references
## 0
### alias
Saga Pattern
### url
https://microservices.io/patterns/data/saga.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Submit the GitHub repo.
### score
20
### prompts
#### 0
##### title
Choreography Execution
##### score
20
##### promptText
Are the microservices reacting directly to domain events instead of synchronized HTTP calls?

# difficulty
easy

# score
20