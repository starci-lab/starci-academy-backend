# title
Cơ bản: Mô hình CQRS

# description
Học các khái niệm cơ bản về Command Query Responsibility Segregation bằng cách tách rời luồng ghi và đọc trong một ứng dụng sử dụng module CQRS của NestJS.

# requirements
Xây dựng ứng dụng 'ProductCatalog'. Triển khai Commands (VD: CreateProductCommand) để thay đổi dữ liệu và Queries (VD: GetProductsQuery) để đọc dữ liệu bằng package `@nestjs/cqrs`.

# prerequisites
- **Node.js >= 18**
- **NestJS CLI**
- Package `@nestjs/cqrs`

# steps

## 0
### title
Cài đặt CQRS Module
### body
Import CQRS Module của NestJS vào trong application.

## 1
### title
Tách rời Command & Query
### body
Tạo các folder riêng biệt cho Commands (logic ghi) và Queries (logic đọc), và triển khai các Handler tương ứng.

# references
## 0
### alias
NestJS CQRS
### url
https://docs.nestjs.com/recipes/cqrs

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Nộp repo GitHub của bạn.
### score
20
### prompts
#### 0
##### title
Triển khai CQRS
##### score
20
##### promptText
Command và Query có được tách rời và xử lý chính xác bởi hệ thống CQRS không?

# difficulty
easy

# score
20