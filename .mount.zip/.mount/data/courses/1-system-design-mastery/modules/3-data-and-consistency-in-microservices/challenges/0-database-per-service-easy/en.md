# title
Foundations: Database per Service

# description
Understand the core of microservices by moving from a monolithic database to a Database-per-Service architecture.

# requirements
Build 'UserService' (PostgreSQL) and 'ProductService' (MongoDB). They must operate independently without sharing a database.

# prerequisites
- **Node.js >= 18**
- **Docker & Docker Compose**
- **NestJS CLI**

# steps

## 0
### title
Dockerized Databases
### body
Create a `docker-compose.yaml` to run PostgreSQL and MongoDB locally.

## 1
### title
Independent Services
### body
Initialize two NestJS services, each connecting to its respective database. Implement basic REST APIs for both.

# references
## 0
### alias
Database per Service
### url
https://microservices.io/patterns/data/database-per-service.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository URL
### description
Submit the GitHub repo link containing your services.
### score
20
### prompts
#### 0
##### title
Database Isolation
##### score
20
##### promptText
Do the services have their own isolated databases and avoid cross-database queries?

# difficulty
easy

# score
20