# title
Data and Consistency in Microservices

# description
Understand pattern for managing data in microservices. Deep dive into Database-per-Service and Command Query Responsibility Segregation (CQRS) to handle distributed data and maintain consistency.

# previewContents
## 0
### text
Database per Service: understand advantages and challenges of splitting data.
## 1
### text
CQRS Pattern: segregate command (write) and query (read) responsibilities.
## 2
### text
Learn how to maintain data consistency across distributed systems.
