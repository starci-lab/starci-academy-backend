# title

Saga Pattern và tính nhất quán dữ liệu trong microservices

# description

Bài học dùng demo chạy local (Order, Payment, Inventory qua Kafka) để thấy chuỗi Saga hoàn tất và nhánh compensation khi lỗi, rồi đọc sâu cách điều phối **Saga** theo **event** so với **orchestration**, transactional outbox và lỗi vận hành.

# body

## I. Lời mở đầu

Người phỏng vấn hay hỏi: trong monolith thì **transaction** **ACID** nằm gọn trong một DB; vậy cùng một nghiệp vụ mà chạy qua ba **service**, mỗi chỗ một DB riêng, thì làm sao cho dữ liệu vẫn **nhất quán**? Đây là chỗ **beta** dễ **toang** nhất. Trả lời kiểu "gọi API lần lượt, chừng nào lỗi thì xử lý sau" nghe có vẻ được, nhưng thực ra đó là tư duy **nôn nớt** — vì luồng này rất dễ **thất bại** khi một trong các bước **fail** (lý do có thể là **bug** logic, **service** chết đột ngột, … Ví dụ **service** A đã xử lý xong nhưng sang bước tới **service** B thì B lỗi logic, không xử lý được).

Để trả lời được câu hỏi đó, bạn phải nắm **Saga pattern**: cả **concepts** lẫn cơ chế **compensation**. **Hãy đọc tiếp các phần sau** để hiểu thêm nhé.

## II. Demo trực quan và thực hành

Dưới đây là ví dụ về **Saga pattern** dùng **Kafka** làm **message broker**, ba **service** **Order** / **Payment** / **Inventory** — mỗi **service** một **DB SQLite** riêng — minh họa ranh giới dữ liệu giữa các **service** (không chung một DB): sự kiện đi theo **`order-events`** → **`payment-events`** → **`inventory-events`**; khi chuỗi thuận, **Order** nhận **`InventoryReserved`** và chuyển **COMPLETED**. Khi kho lỗi, nhánh **compensation** cũng bám **`inventory-events`** — hoàn tiền, đơn **CANCELLED**, tránh kẹt “đã trừ tiền mà đơn vẫn **COMPLETED**”.

**Clone** ở đây: [Saga pattern — demo (NestJS monorepo)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/saga-pattern)

| Thành phần | Cổng | Công nghệ | Trách nhiệm (rút gọn) |
|-------------|------|-----------|------------------------|
| **Order** | **3001** | **NestJS, SQLite** | HTTP tạo order; publish / consume saga topics; cập nhật **COMPLETED** / **CANCELLED** |
| **Payment** | **3002** | **NestJS, SQLite** | Thanh toán sau **`OrderCreated`**; **refund** khi nhận event bù qua **`inventory-events`** |
| **Inventory** | **3003** | **NestJS, SQLite** | HTTP **`/inventory/check`**; trừ kho; publish **`inventory-events`** (thành công hoặc kích hoạt **compensation**) |
| **Kafka** | **9092** | **Kafka** | **Message broker**; topic **`order-events`**, **`payment-events`**, **`inventory-events`** |

![Sơ đồ Saga demo — Order, Payment, Inventory, Kafka](https://starci.org/system-design-mastery/saga-pattern/0.svg)

*Hình 1. Sơ đồ kiến trúc hệ thống từ source code trên.*

**Kafka** nối **Order**, **Payment**, **Inventory** và ba **SQLite** riêng.

### 1. Chuẩn bị và chạy môi trường

Giả định máy đã cài **Docker** và **Node.js** (LTS). Làm lần lượt ba bước dưới đây.

1. **Từ repo**, khởi chạy **Kafka** bằng Docker Compose:

```
docker compose -f .docker/kafka.yaml up -d
```

2. Cài dependency:

```
npm install
```

3. Mở **ba terminal** riêng, mỗi terminal một **service** (thứ tự không bắt buộc, miễn cả ba đều chạy):

```
npx nest start order --watch
npx nest start payment --watch
npx nest start inventory --watch
```

**Kết quả mong đợi**

Cả ba **service** đều chạy, mỗi cái một cổng: **order** — **3001**, **payment** — **3002**, **inventory** — **3003**.

**Kết luận**

Ba **service** chạy độc lập, mỗi **service** một **DB** **SQLite** riêng, cùng giao tiếp với **Kafka**.

### 2. Luồng thành công của Saga Pattern diễn ra như thế nào?

Bạn có thể **làm theo** bằng **app có giao diện** (ví dụ **Postman**, **Insomnia**, **Bruno** …) **hoặc** bằng **`curl`** trong **terminal** trên **Linux** hoặc **macOS**. Nếu bạn dùng **Windows**, hãy **cài WSL2** rồi chạy **`curl`** trong shell Linux — bài **không** hướng dẫn **CMD**/**PowerShell** thuần.

**Các bước thực hiện:**

**Bước 1:** Request tạo order tới **Order Service**.

- Method: **POST**
- URL: `http://localhost:3001/order`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "productId": 2,
  "quantity": 1
}
```

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X POST http://localhost:3001/order -H "Content-Type: application/json" -d "{\"productId\":2,\"quantity\":1}"
```

**Response** ở bước này có dạng JSON khoảng như sau (trường **`id`** là **id** order cần dùng ở bước 2; giá trị **`id`** phụ thuộc DB — ví dụ nếu đây là order mới thứ ba thì có thể là **3**):

```
{
  "id": 3,
  "status": "PENDING",
  "productId": 2,
  "quantity": 1
}
```

Ghi lại **id** của order trong response (dùng cho bước 2).

**Bước 2:** Kích hoạt kiểm kho (theo **repo** — gọi qua **Inventory**).

- Method: **POST**
- URL: `http://localhost:3003/inventory/check`
- Body (thay **42** bằng **id** order từ bước 1 — trong JSON phải là **số**, không để placeholder):

```
{
  "orderId": 42,
  "productId": 2,
  "quantity": 1
}
```

**Câu lệnh `curl` tương đương** — thay **42** bằng **id** order thật từ bước 1; chạy trong **terminal** (**Linux** / **macOS** / **WSL2**).

```
curl -X POST http://localhost:3003/inventory/check -H "Content-Type: application/json" -d "{\"orderId\":42,\"productId\":2,\"quantity\":1}"
```

**Kết quả mong đợi**

Order ban đầu ở trạng thái phù hợp flow (ví dụ **PENDING**); **Payment** trừ tiền; **Inventory** trừ kho thành công; Order chuyển **COMPLETED** khi chuỗi **Saga** chạy xong. Log các **service** và sự kiện trên **Kafka** khớp thứ tự nghiệp vụ.

**Kết luận**

**Saga** chạy trọn vẹn; sau cùng cả ba **service** khớp trạng thái theo nghĩa **eventual consistency** (không cần một **transaction** SQL ôm cả ba DB).

### 3. Luồng thất bại diễn ra như thế nào? (ví dụ hết hàng)

Cùng cấu trúc bước như mục 2; khác ở chỗ dùng **productId** **1** để mô phỏng **hết hàng** (trong **repo**, **productId** **1** được seed **stock** = **0**).

**Các bước thực hiện:**

**Bước 1:** Request tạo order tới **Order Service**.

- Method: **POST**
- URL: `http://localhost:3001/order`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "productId": 1,
  "quantity": 1
}
```

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X POST http://localhost:3001/order -H "Content-Type: application/json" -d "{\"productId\":1,\"quantity\":1}"
```

**Response** ở bước này có dạng JSON khoảng như sau (trường **`id`** là **id** order cần dùng ở bước 2; giá trị **`id`** phụ thuộc DB — ví dụ nếu đây là order mới thứ tư thì có thể là **4**):

```
{
  "id": 4,
  "status": "PENDING",
  "productId": 1,
  "quantity": 1
}
```

Ghi lại **id** của order trong response (dùng cho bước 2).

**Bước 2:** Kích hoạt kiểm kho (theo **repo** — gọi qua **Inventory**).

- Method: **POST**
- URL: `http://localhost:3003/inventory/check`
- Body (thay **42** bằng **id** order từ bước 1 — trong JSON phải là **số**, không để placeholder):

```
{
  "orderId": 42,
  "productId": 1,
  "quantity": 1
}
```

**Câu lệnh `curl` tương đương** — thay **42** bằng **id** order thật từ bước 1; chạy trong **terminal** (**Linux** / **macOS** / **WSL2**).

```
curl -X POST http://localhost:3003/inventory/check -H "Content-Type: application/json" -d "{\"orderId\":42,\"productId\":1,\"quantity\":1}"
```

**Response** ngay từ **Inventory** (HTTP) khoảng như sau khi không đủ tồn kho — **compensation** được kích hoạt qua **Kafka** sau đó:

```
{
  "success": false,
  "message": "Out of stock, compensation triggered"
}
```

**Kết quả mong đợi**

**Inventory** báo hết hàng; trong **repo**, **`apps/inventory/src/app.service.ts`** phát payload lên **Kafka** (topic **`inventory-events`**, **`eventType`: `INVENTORY_OUT_OF_STOCK`**); **Payment** và **Order** subscribe cùng topic đó (**`apps/payment/src/app.controller.ts`**, **`apps/order/src/app.controller.ts`**) và chạy **compensation** — **Payment** **refund**, Order chuyển **CANCELLED**. Không để tình trạng tiền đã trừ mà đơn vẫn **COMPLETED**.

**Kết luận**

Khi một bước sau lỗi, các bước trước được xử lý bằng **compensation** — đây là chỗ **Saga** thay cho việc **rollback** kiểu một DB duy nhất.

Sau hai luồng trên, bạn đã thấy **thành công** và **thất bại** có kiểm soát. Tiếp theo là các **khái niệm** và **edge case** thường gặp khi triển khai thật.

## III. Giải thích nâng cao và kết luận

### 1. Saga là gì và tại sao nó quan trọng trong microservices

**Saga** là một chuỗi **local transaction**; mỗi bước cam kết trong một service. Nếu một bước sau thất bại, các bước trước được xử lý bằng **compensating transaction** (hoàn tiền, hủy giữ chỗ, ghi nhận đơn hủy…) chứ không roll back toàn cục kiểu một **transaction** SQL duy nhất. Trong microservices, đây là một trong các cách **phổ biến** để đạt **nhất quán có kiểm soát** khi **không** chia sẻ DB.

- **Ví dụ:** Đơn đã trừ tiền nhưng kho không đủ — **compensation** là refund + cập nhật đơn **CANCELLED**, không phải hy vọng "undo" ngược thời gian trên ba DB.

### 2. Tự phản ứng theo event và orchestration

Không có **orchestrator** trung tâm: mỗi **service** tự **publish** và **subscribe** theo **event** — kiểu **event-driven**. **Decoupled** mạnh; phù hợp luồng **ít nhánh** và team có kỷ luật **hợp đồng sự kiện**. Điểm yếu: **luồng nghiệp vụ** phân tán trên nhiều repo — khó nhìn một chỗ, dễ **lệch version** schema event.

**Orchestration** dùng một **orchestrator** (Saga manager) như **state machine**: gửi lệnh tới từng service, chờ kết quả, quyết định bước tiếp hoặc nhánh **compensation**. Phù hợp quy trình **nhiều nhánh**, **điều kiện** phức tạp. Trade-off: orchestrator là **điểm tập trung** — cần **high availability**, **thống nhất phiên bản** giao tiếp với các **service**, và tránh nhồi **logic nghiệp vụ** vào orchestrator thay vì để nó chỉ **điều phối** các bước.

- **Ví dụ 1:** Demo ở phần trên là kiểu **tự phản ứng qua event**: **Order** phát sự kiện, **Payment** và **Inventory** **tự** phản ứng và phát tiếp.
- **Ví dụ 2:** **Orchestrator** **publish** lệnh **ChargePayment** lên topic **`commands.payment`** trên **Kafka**, chờ **reply** từ **Payment** (ví dụ trên **`replies.payment`** hoặc cùng **correlation id**); chỉ khi bước đó **OK** mới **publish** **ReserveStock** lên **`commands.inventory`**. Nếu **Inventory** trả **fail** (hoặc **timeout**), orchestrator **publish** lệnh **RefundPayment** lên **`commands.payment`** — nhánh **compensation** và thứ tự bước nằm trong **state machine** của orchestrator; **Kafka** là kênh lệnh / kết quả, không phải chỗ “tự suy” luồng cho cả chuỗi.

### 3. Production: Outbox, idempotency, và chết giữa chừng

Demo chạy local thì không sao; trên **production**, **broker** thường **at-least-once**, **service** chết giữa chừng, và **phát event** dễ lệch với **ghi DB** nếu không thiết kế — dưới đây là vài **edge case** điển hình, gồm có **vấn đề** và **hướng giải quyết**:

- **Message trùng / retry từ broker.** Cùng một message xử lý hai lần có thể **refund** hai lần hoặc **trừ kho** gấp đôi. Cách xử lý: **consumer** **idempotent**; **idempotency key** hoặc ghi nhận “đã xử lý” theo **message id** / **business id**.
- **Ghi DB và phát event không cùng lúc.** Đã **commit** nghiệp vụ nhưng chưa đẩy **event** (hoặc ngược lại) thì trạng thái và log không khớp. Cách xử lý: **Transactional Outbox** — ghi **outbox** trong cùng **transaction** với thay đổi nghiệp vụ, rồi để tiến trình nền đẩy ra **broker** tin cậy.
- **Crash giữa hai bước.** **Service** chết sau **commit** local nhưng trước khi **publish** đủ (hoặc đã gửi message nhưng bên nhận chưa xử lý xong). Cách xử lý: **retry** có giới hạn, **reconciliation**, giám sát **saga** đang kẹt ở bước nào.
- **Poison message / lỗi lặp vô hạn.** Message làm **handler** luôn **fail** thì luồng không tiến. Cách xử lý: **dead-letter queue** (DLQ), cảnh báo, can thiệp thủ công hoặc sửa dữ liệu gốc rồi **replay**.

Một hệ phân tán **đúng nghĩa** không hứa **ACID** xuyên **service**; nó hứa **chuỗi bước có kiểm soát**, **compensation** có kỷ luật, và **nhất quán cuối cùng** mà bạn chứng minh được bằng log và trạng thái nghiệp vụ.

**Saga** không phải "thay thế transaction" bằng ma thuật — nó là **thiết kế có giá**: bạn đổi **ACID** toàn cục lấy **local ACID** + **orchestration** qua **message queue** + **compensation**.
