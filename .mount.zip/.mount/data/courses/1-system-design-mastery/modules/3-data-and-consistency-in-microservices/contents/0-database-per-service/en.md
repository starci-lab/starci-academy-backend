# title
Database per Service

# description
Each microservice owns its own DB and no service JOINs another's store directly — the demo runs Order (PostgreSQL) and Inventory (MongoDB) to reveal the real data boundary, then digs into cross-service query trade-offs, eventual consistency, and polyglot persistence.

# body

## I. Introduction

At a **Senior Backend** interview in a company that has truly split its **microservices**, the classic trap question is: *"The system has an **Order Service** and an **Inventory Service**. The admin page lists orders together with **product name** and **stock count** — how do you query that?"*. A candidate used to **monoliths** will answer on instinct: *"I **JOIN** the `orders` table with the `products` table on `product_id`"* — and the interviewer **knows** **Database per Service** has not landed yet. In real **microservices**, **Order Service** **cannot see** the `products` table of **Inventory Service**; both sides have their **own schema**, sometimes even **different storage technology** (**PostgreSQL** vs **MongoDB**), and every cross-service data need goes through an **API** or **event** — never a cross-service **JOIN**.

The reason is not "to look like **Netflix**", but to **break coupling**: if three **services** all **JOIN** on the `products` table, renaming a column inside **Inventory** can **break** both **Order** and **Report** without the author ever knowing; the shared table becomes an **implicit contract** nobody signed. On top of that, the shared DB is also a **single point of failure** — the DB goes down and **every service** goes down with it, wiping out the whole point of a distributed architecture. To internalize **Database per Service** at demo scope, you have to spin up two **services** backed by **two different DB engines** side by side and watch where the data boundary really lives — read on.

## II. Visual Demo & Hands-on

The **example** below is two **services** — **`order`** (port **3000**, **PostgreSQL** for relational data) and **`inventory`** (port **3001**, **MongoDB** for documents) — inside a single **NestJS monorepo**. Each **service** **owns** its **own DB**, **does not share**, and **does not JOIN** across DBs: **POST** to **Inventory** creates a product → **Inventory** writes **MongoDB**; **POST** to **Order** creates an order → **Order** writes **PostgreSQL**. When **Order** needs a **product name** for display, it **calls Inventory's HTTP API** — **polyglot persistence** (each **store** matches its **workload**) pairs with **loose coupling** (a schema change on one side only affects that service).

**Clone** here: [Database per Service — demo (NestJS monorepo)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/database-per-service)

| Component | Port | Tech | Responsibility (short) |
|-------------|------|-----------|------------------------|
| **Order** | **3000** | **NestJS** | **POST /orders**, writes **PostgreSQL**; calls **Inventory** over **HTTP** for cross-service data |
| **PostgreSQL** | **5432** | **PostgreSQL** | **Private DB** for **Order** (`orders` table, relational, **ACID**) |
| **Inventory** | **3001** | **NestJS** | **POST /inventory**, writes **MongoDB**; exposes **GET** so **Order** can read product data |
| **MongoDB** | **27017** | **MongoDB** | **Private DB** for **Inventory** (`products` collection, document, read-optimized) |

![Database per Service architecture — Order + PostgreSQL, Inventory + MongoDB](https://starci.org/system-design-mastery/database-per-service/0.svg)

*Figure 1. System architecture diagram from the source above.*

**Order** owns **PostgreSQL**; **Inventory** owns **MongoDB**; the dashed line is an internal **HTTP API** — there is **no** DB-to-DB line between the two.

### 1. Environment setup and run

Assumes **Docker** and **Node.js** (LTS) installed. From the cloned **repo**, run in order:

1. Start **PostgreSQL** (for **Order**):

```
docker compose -f .docker/postgresql.yaml up --build -d
```

2. Start **MongoDB** (for **Inventory**):

```
docker compose -f .docker/mongodb.yaml up --build -d
```

3. Install dependencies:

```
npm install
```

4. Open **two terminals**, one per **service**:

```
npx nest start order --watch
```

```
npx nest start inventory --watch
```

**Expected result**

**Order** listens on **3000**, **Inventory** on **3001**; **PostgreSQL** (**5432**) and **MongoDB** (**27017**) are both **up** under **Docker**.

**Conclusion**

Two independent **services**, each connected only to its own **DB**; nobody touches anyone else's store — the **Database per Service** boundary is real at the running-config level.

### 2. Write to two different DBs — no sharing

You can **follow along** with a **GUI client** (**Postman**, **Insomnia**, **Bruno** …) **or** with **`curl`** in a **terminal** on **Linux** or **macOS**. On **Windows**, install **WSL2** and run **`curl`** in the Linux shell — this lesson does not cover **CMD**/**PowerShell**.

**Steps:**

**Step 1:** Add a product to **Inventory** (**MongoDB**).

- Method: **POST**
- URL: `http://localhost:3001/inventory`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "name": "Macbook M3",
  "stock": 50
}
```

**Equivalent `curl`** — run on **Linux**, **macOS** or **WSL2**:

```
curl -X POST http://localhost:3001/inventory -H "Content-Type: application/json" -d "{\"name\":\"Macbook M3\",\"stock\":50}"
```

**Response** confirms the write to **MongoDB** (with an **`_id`** ObjectId plus the submitted fields).

**Step 2:** Create an order in **Order** (**PostgreSQL**).

- Method: **POST**
- URL: `http://localhost:3000/orders`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "customerId": "user_01",
  "totalAmount": 2500
}
```

**Equivalent `curl`**:

```
curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d "{\"customerId\":\"user_01\",\"totalAmount\":2500}"
```

**Response** confirms **Order** wrote to **PostgreSQL** (auto-increment **`id`** or UUID, depending on the **repo**).

**Expected result**

**Inventory** wrote a product document to **MongoDB** (`products` collection); **Order** wrote a row to **PostgreSQL** (`orders` table). There is no DB-to-DB connection between them; **Order** does **not** know the `products` collection exists, and **Inventory** does **not** know about `orders`.

**Conclusion**

Two **services** use **two different storage engines** (**PostgreSQL** vs **MongoDB**) and still run cleanly in one system — this is **polyglot persistence** in action. In **production**, when **Order** needs cross-service data, it **calls Inventory's HTTP API** (or uses **CQRS** / **API Composition** — covered in Part III), it **never** opens a direct connection into **Inventory's MongoDB**.

After the flow above, the next part names the **concepts** and **trade-offs** of **Database per Service** in real deployments.

## III. Advanced Theory and Conclusion

### 1. What Database per Service is and why it matters in microservices

**Database per Service** is the rule: **each service owns one schema (or one DB)**; **no service** may **directly read** or **JOIN** into another service's **store** — all cross-service data needs flow through the owning service's **API**, **events**, or **projections**. This is **not** "one DB per project for tidiness" — this is a **data-ownership boundary** aligned with the business **bounded context**.

- **Example:** **Order Service** owns the `orders` table on **PostgreSQL**; **Inventory Service** owns the `products` collection on **MongoDB**. An admin view showing **order + product name** → **Order** calls **`GET /inventory/:id`** and stitches results (**API Composition**), rather than **JOIN**ing across the two stores.

### 2. The real benefits

Three benefits get quoted on every slide, but their real meaning differs:

- **Schema-level loose coupling:** The **Inventory** team renames `stock` to `availableStock` — only **Inventory** updates; **Order** does **not break** because it never read that column. In a shared DB, **Inventory** would have to notify 3–5 teams and wait for a coordinated **migration** — release speed drops to the slowest team.
- **Polyglot persistence:** **Order** needs multi-row **ACID** for checkout → **PostgreSQL** fits; **Inventory** is read-heavy keyed by `product_id` and holds flexible documents (images, specs, variants) → **MongoDB** fits; **Search** needs **full-text** → **Elasticsearch**. Each **store** is tuned for its own **workload** instead of forcing **PostgreSQL** to be everything.
- **Independent scaling:** **Inventory** reads can be **50×** **Order** writes (every product page hits inventory) — with separate DBs, only **Inventory's MongoDB** needs **read replicas** or **sharding**; **Order's PostgreSQL** can stay small.

### 3. Trade-offs you cannot dodge

**Database per Service** trades **cross-service ACID** for **distributed complexity** — choosing this architecture means accepting:

- **No cross-service transaction.** **Order** creating a row and **Inventory** decrementing stock live on **two different DBs** — **two-phase commit** (**2PC**) is rarely viable in production (slow, brittle when the **coordinator** crashes). Instead, use the **Saga pattern** (chain of **local transactions** + **compensation**) or **Outbox** + **event-driven** to reach **eventual consistency**.
- **Cross-service queries are harder and slower than `JOIN`.** The *"orders with product name and stock"* page is no longer a single **SQL** statement; it is **API Composition** (call **n** APIs and stitch at a **BFF**/**Gateway**) or **CQRS** with a pre-projected **Read Model** — more code, harder debugging, real network latency.
- **Eventual consistency becomes the default.** After **Order** emits `OrderCreated`, **Inventory** decrements stock some **ms** → **seconds** later. A product can show *"in stock"* on the UI briefly after it is actually **sold out** — the business must design to **tolerate** stale intermediate states and **reconcile** on a schedule.
- **Operational cost multiplies.** One DB becoming **n** DBs means **n** backup pipelines, **n** metric sets, **n** schema-migration versions, **n** recovery runbooks — plus **polyglot** adds **n** sets of ops skills.

### 4. Supporting patterns you pair with "Database per Service"

Once you split the DBs, three patterns usually travel with them to patch the trade-offs above:

- **API Composition:** A **Composition Service** (or **BFF**) fans out to several **services**, merges the results, and returns them to the client. Simple, no extra infra; weakens when the result set is large or needs cross-source sorting / pagination.
- **CQRS with Read Model:** The owning service publishes **events** on state changes; a reader (**Query**) service subscribes and **projects** into its own **denormalized store** shaped for the target screen. Fast reads, but you inherit **read lag** and the operational cost of the **projection pipeline**.
- **Transactional Outbox + event-driven:** The **service** writes the business change and the **outbox** row in the **same local transaction**; a background worker reads the **outbox** and **publishes** to a reliable **message queue** (**Kafka**, **RabbitMQ**) with **at-least-once** guarantees. It fixes *"committed but never published an event"* — the root cause of a huge class of inconsistency bugs.

### 5. When **not** to split Database per Service

**Database per Service** is **worth it** when you already have: clear **bounded contexts**, dedicated **teams per context**, and enough **scale** that the cost of splitting is **outweighed** by the **autonomy** gained. Do not rush into it in these cases:

- **Modular monolith with an unsettled domain:** Small team, **bounded contexts** still shifting; splitting DBs early means every boundary change triggers **data migration** across **n** DBs — slower than refactoring modules inside one DB.
- **Core flows that demand strict ACID:** Internal money transfer, seat booking with **seat lock** — keep those in **one DB** (or one **bounded context**) and split only what is truly different in nature (e.g. **Notification**, **Report**).
- **Team lacks distributed-data infrastructure:** No **observability** for events, no **DLQ**, never written a **Saga**/**Outbox** — splitting DBs first turns every data bug into a multi-service investigation.

**Database per Service** is not an architectural decoration — it is a **disciplinary commitment**: *accept **eventual consistency** and the **operational cost of distributed data** in exchange for **schema autonomy**, **polyglot persistence**, and **per-workload independent scale***. Once you have chosen this path, treat the **DB boundary** the same as the **API boundary**: breaking it (quietly reading another service's table through a shared **view** or **read replica**) destroys the whole reason you split in the first place — you end up with a **distributed monolith** coupled through the DB, paying distribution's costs while losing its benefits.

# references
## 0
### alias
Microservices.io — Database per Service
### url
https://microservices.io/patterns/data/database-per-service.html
## 1
### alias
Microservices.io — Shared Database (anti-pattern)
### url
https://microservices.io/patterns/data/shared-database.html
## 2
### alias
Microservices.io — API Composition
### url
https://microservices.io/patterns/data/api-composition.html
## 3
### alias
Microservices.io — Transactional Outbox
### url
https://microservices.io/patterns/data/transactional-outbox.html

# minutesRead
30
