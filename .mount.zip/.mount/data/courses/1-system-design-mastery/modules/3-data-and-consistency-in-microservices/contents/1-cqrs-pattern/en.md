# title

Command Query Responsibility Segregation (CQRS)

# description

Separate write and read flows with CQRS to reduce workload contention and optimize queries in distributed systems, then examine eventual consistency trade-offs and Read Model sync behavior in real deployments.

# body

## I. Opening

In **microservices**, **operations** are usually **split** by **service** — each **service** owns a bounded set of **write** paths: e.g. **Order** handles placing and updating orders and **writes** to one **PostgreSQL** (or equivalent). Traffic is usually **read**-heavy. In **production**, the **write**/**read** ratio often lands around **1/10** or **2/10**, depending on the **application**. At scale, that same **database** must handle both **writes** and **reads** — **connection** contention, **DB** overload, … **CQRS** is essentially **splitting** **writes** and **reads** across **two** distinct **services** instead of one **monolithic** bundle. **Read on in the following sections** to learn more.

## II. Hands-on demo

The example below is two apps — **`command`** (port **3000**, **Write Model** on **PostgreSQL**) and **`query`** (port **3001**, **Read Model** on **Elasticsearch**). **Write**-to-**Read** sync goes through **RabbitMQ** as the **EventBus**: **POST** updates a customer → **CommandBus** writes **PostgreSQL** → publishes **`CustomerProfileUpdatedEvent`** to **RabbitMQ** → **Query** consumes and **projects** into **Elasticsearch**. **GET** from the **Client** hits **Query** → **Elasticsearch** only — **not** through the **broker**, and **not** reading **Command**’s **PostgreSQL**.

**Clone** here: [CQRS — demo (NestJS monorepo)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/cqrs)

| Component | Port | Technology | Responsibility (short) |
|-----------|------|------------|---------------------------|
| **Command** | **3000** | **NestJS** | **CommandBus**, write Write Model, publish events via **RabbitMQ** |
| **PostgreSQL** | **5432** | **PostgreSQL** | **Write Model** (storage on the **Command** side) |
| **RabbitMQ** (**EventBus**) | **5672** | **RabbitMQ** | Async bridge between **Command** and **Query** |
| **Query** | **3001** | **NestJS** | **QueryBus**, consume events, **projection** Read Model; serves **GET** |
| **Elasticsearch** | **9200** | **Elasticsearch** | **Read Model** (queries on the **Query** side) |

![CQRS demo architecture — Command, RabbitMQ, Query, Elasticsearch](https://starci.org/system-design-mastery/cqrs-pattern-0.svg)

*Figure 1. System architecture diagram from the source above.*

**HTTP** writes go through **Command** and the **Write Model**; **Write → Read** sync uses **RabbitMQ**; **GET** reads go through **Query** and the **Read Model**.

### 1. Environment setup

Assume **Docker** and **Node.js** (LTS). From the **cloned** **repo**, run in order:

1. Start **PostgreSQL** (Write Model) — same invocation as the repo **README**:

```
docker compose -f .docker/postgresql.yaml up --build -d
```

2. Start **Elasticsearch** (Read Model):

```
docker compose -f .docker/elasticsearch.yaml up --build -d
```

3. Start **RabbitMQ** (**EventBus**):

```
docker compose -f .docker/rabbitmq.yaml up --build -d
```

4. Install dependencies:

```
npm install
```

5. Open **two terminals** — one for **Command**, one for **Query** (order does not matter as long as both run):

```
npx nest start command --watch
```

```
npx nest start query --watch
```

**Expected results**

**Command** listens on **3000**, **Query** on **3001**; **PostgreSQL**, **Elasticsearch**, and **RabbitMQ** (**5672**) are **up** via **Docker**.

**Conclusion**

Two independent **services**; **writes** and **reads** are separate paths; Write → Read sync in this **demo** goes through **RabbitMQ** (**publish** / **consume**) — **GET** over HTTP does not use the **broker** — **CQRS** at **demo** scope and aligned with the repo **README**.

### 2. Write, then read — Read Model matches the new data

You can **follow along** with a **GUI** HTTP client (for example **Postman**, **Insomnia**, **Bruno** …) **or** with **`curl`** in a **terminal** on **Linux** or **macOS**. On **Windows**, install **WSL2** and run **`curl`** in the Linux shell — there is **no** walkthrough for plain **CMD**/**PowerShell**.

**Execution steps:**

**Step 1:** Update a customer through **Command** (**write**).

- Method: **POST**
- URL: `http://localhost:3000/customer/update`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "id": "123",
  "name": "John Doe",
  "email": "john@example.com"
}
```

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X POST http://localhost:3000/customer/update -H "Content-Type: application/json" -d "{\"id\":\"123\",\"name\":\"John Doe\",\"email\":\"john@example.com\"}"
```

**Response** at this step depends on how the **handler** is implemented (usually an acknowledgement that the **Command** was accepted / **Write Model** updated).

**Step 2:** Read back through **Query** (**read**).

- Method: **GET**
- URL: `http://localhost:3001/customer/123`

**Equivalent `curl` command**:

```
curl -X GET http://localhost:3001/customer/123
```

**Expected response** (after **projection** completes): a body with **`name`** **John Doe** and matching **email** — served from **Elasticsearch**.

**Expected results**

**Command** writes **PostgreSQL** and emits **`CustomerProfileUpdatedEvent`**; **Query** consumes the event and updates the Read Model; **GET** returns the data you just wrote.

**Conclusion**

**Write** and **read** align for the same **id** — the demo **CQRS** path works end to end.

After that **write → read** path, we cover **CQRS** **concepts** and common **edge cases**.

## III. Advanced theory and conclusion

### 1. What CQRS is and why it matters when reads and writes diverge

**CQRS** (**Command Query Responsibility Segregation**) splits the **write model** (**Command**) from the **read model** (**Query**). **Commands** prioritize consistent state changes; **Queries** prioritize fast reads, often **denormalized** for screens. Not every system needs it — but when **reads** and **writes** differ in **shape** or **scale**, separating paths lets you **scale** and **tune** independently instead of forcing one **schema** for everything.

- **Example:** Profile updates land in **PostgreSQL**; the dashboard reads **Elasticsearch** with fields already projected for the view — avoiding cross-service **JOIN** work at render time.

### 2. Benefits and trade-offs

**Performance and independent scaling:** scale the **Query service** when **read** traffic spikes; scale the **Write service** when **writes** / **transactions** spike — do not scale one combined path and hope it fixes the wrong bottleneck.

**Technology flexibility:** **ACID** on the **write** side; **search** / aggregates on the **read** side — each **store** fits its **workload**.

**Trade-offs:** **eventual consistency** between Write and Read; operating multiple **stores** and a **sync** **pipeline**; when the **broker** / **events** fail you need **replay**, **Transactional Outbox**, or an **event log** — depending on system maturity.

### 3. Production: stale reads, projections, and reliability

The local demo is fine; in **production**, the **Read Model** updates **asynchronously**, **messages** can **duplicate**, and **database writes** can **diverge** from **event publish** without careful design. Below are typical **edge cases**, each with a **problem** and a **way forward**:

- **Read lags behind write.** **Problem:** users **write** then **read** immediately and see stale data. **Mitigation:** UI **pending** states / **polling** / **versions**; **eventual consistency** with an agreed **latency** budget for the product.
- **Read Model sync stalls or drifts.** **Problem:** **consumers** die, **events** backlog, or **schemas** change. **Mitigation:** controlled **replay**, **idempotent** **projections**, **dead-letter** queues for poison records.
- **Database write vs event publish.** **Problem:** you **commit** but do not emit the **event** (or the reverse). **Mitigation:** **Transactional Outbox** (or an ordered **event log**) then publish to a reliable **message queue** / **broker**.
- **Multiple sources of truth** when discipline slips. **Problem:** editing **Read** directly without going through **Write** — **Write** and **Read** no longer share a single **source of truth**. **Mitigation:** treat **Write** as the **source of truth**; **Read** is **projection** only; block unsafe shortcuts unless **policy** allows.

**CQRS** is not “one pattern for every **service**”. When **reads** and **writes** do not differ in **load** or **data shape**, adding **CQRS** only raises **operational** cost. When you do split, treat **Read Model** **sync** as a **pipeline** to **monitor** and **test** as part of the architecture — not an afterthought to **release**. Pairing with **Event Sourcing** or **outbox** is a common path when you need **audit** and **event** **recovery**; that is an extension path, not a requirement for every **CQRS** rollout.

# references
## 0
### alias
CQRS pattern - Azure Architecture Center
### url
https://learn.microsoft.com/en-us/azure/architecture/patterns/cqrs
## 1
### alias
Microservices.io: CQRS
### url
https://microservices.io/patterns/data/cqrs.html

# minutesRead
35
