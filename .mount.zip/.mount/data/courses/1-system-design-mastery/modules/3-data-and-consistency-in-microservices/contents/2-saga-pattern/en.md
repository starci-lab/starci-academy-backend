# title

Saga pattern and data consistency in microservices

# description

This lesson uses a local demo (Order, Payment, Inventory via Kafka) to show a completed Saga and a compensation path on failure, then goes deeper into **event**-driven **Saga** coordination versus **orchestration**, transactional outbox, and operational failure modes.

# body

## I. Opening

Interviewers often ask: in a monolith, an **ACID** **transaction** sits in one database — so the same business flow across three **services**, each with its own DB, how do you keep data **consistent**? This is where **beta** answers **collapse** hardest. Saying "call the APIs in order and handle errors later" sounds fine, but it is **naive** thinking — the whole flow can **fail** when one step does (logic **bugs**, a **service** dying mid-flight, … For example **service** A finishes, but the next step is **service** B and B has a logic **bug** and cannot process it).

To answer that question you need the **Saga pattern**: both the **concepts** and how **compensation** works. **Read on in the following sections** to learn more.

## II. Hands-on demo

Below is an example of the **Saga pattern** using **Kafka** as the **message broker**, with **Order**, **Payment**, and **Inventory** — each **service** has its own **SQLite** database, illustrating per-service data boundaries (no shared DB): events flow **`order-events`** → **`payment-events`** → **`inventory-events`**; when the chain succeeds, **Order** receives **`InventoryReserved`** and moves to **COMPLETED**. On stock failure, the **compensation** path still uses **`inventory-events`** — refunds run, orders land **CANCELLED**, and you avoid “money taken but the order still **COMPLETED**”.

**Clone** here: [Saga pattern — demo (NestJS monorepo)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/saga-pattern)

| Component | Port | Technology | Responsibility (short) |
|-----------|------|------------|--------------------------|
| **Order** | **3001** | **NestJS, SQLite** | HTTP create order; publish / consume saga topics; set **COMPLETED** / **CANCELLED** |
| **Payment** | **3002** | **NestJS, SQLite** | Pay after **`OrderCreated`**; **refund** on compensating events via **`inventory-events`** |
| **Inventory** | **3003** | **NestJS, SQLite** | HTTP **`/inventory/check`**; reserve stock; publish **`inventory-events`** (success or **compensation**) |
| **Kafka** | **9092** | **Kafka** | **Message broker**; topics **`order-events`**, **`payment-events`**, **`inventory-events`** |

![Saga demo architecture — Order, Payment, Inventory, Kafka](https://starci.org/system-design-mastery/saga-pattern/0.svg)

*Figure 1. System architecture diagram from the source above.*

**Kafka** connects **Order**, **Payment**, and **Inventory**, each with its own **SQLite**.

### 1. Environment setup

Assume **Docker** and **Node.js** (LTS) are installed. Run the three steps below in order.

1. **In the repo**, start **Kafka** with Docker Compose:

```
docker compose -f .docker/kafka.yaml up -d
```

2. Install dependencies:

```
npm install
```

3. Open **three terminals**, one **service** each (order does not matter as long as all three run):

```
npx nest start order --watch
npx nest start payment --watch
npx nest start inventory --watch
```

**Expected Results**

All three **services** are up, each on its own port: **order** — **3001**, **payment** — **3002**, **inventory** — **3003**.

**Conclusion**

Three **services** run on their own, each with its own **SQLite** **database**, all talking to **Kafka**.

### 2. What does a successful Saga flow look like?

You can **follow along** using a **GUI** HTTP client (for example **Postman**, **Insomnia**, **Bruno** …) **or** using **`curl`** in a **terminal** on **Linux** or **macOS**. On **Windows**, install **WSL2** and run **`curl`** in the Linux shell — there is **no** walkthrough for plain **CMD**/**PowerShell**.

**Execution steps:**

**Step 1:** Create an order on the **Order Service**.

- Method: **POST**
- URL: `http://localhost:3001/order`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "productId": 2,
  "quantity": 1
}
```

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X POST http://localhost:3001/order -H "Content-Type: application/json" -d "{\"productId\":2,\"quantity\":1}"
```

**Response** at this step looks roughly like the JSON below (the **`id`** field is the order **id** you need in Step 2; the actual **`id`** depends on your DB — for example it might be **3** if this is the third order created):

```
{
  "id": 3,
  "status": "PENDING",
  "productId": 2,
  "quantity": 1
}
```

Record the order **id** from the response for Step 2.

**Step 2:** Trigger the stock check (per the **repo** — call **Inventory**).

- Method: **POST**
- URL: `http://localhost:3003/inventory/check`
- Body (replace **42** with the real order **id** — JSON must be a **number**, not a placeholder):

```
{
  "orderId": 42,
  "productId": 2,
  "quantity": 1
}
```

**Equivalent `curl` command** — replace **42** with the real order **id** from Step 1; run in a **terminal** (**Linux** / **macOS** / **WSL2**).

```
curl -X POST http://localhost:3003/inventory/check -H "Content-Type: application/json" -d "{\"orderId\":42,\"productId\":2,\"quantity\":1}"
```

**Expected Results**

Order starts in a flow-appropriate state (for example **PENDING**); **Payment** charges; **Inventory** decrements stock; Order becomes **COMPLETED** when the **Saga** finishes. Logs across **services** and **Kafka** events match the business order.

**Conclusion**

The **Saga** runs to completion; all three **services** end up aligned on state in the sense of **eventual consistency** — without one SQL **transaction** spanning all three databases.

### 3. What does a failure flow look like? (example: out of stock)

Use the same step layout as section 2; the difference is **productId** **1**, which simulates **out of stock** (in the **repo**, **productId** **1** is seeded with **stock** = **0**).

**Execution steps:**

**Step 1:** Create an order on the **Order Service**.

- Method: **POST**
- URL: `http://localhost:3001/order`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "productId": 1,
  "quantity": 1
}
```

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X POST http://localhost:3001/order -H "Content-Type: application/json" -d "{\"productId\":1,\"quantity\":1}"
```

**Response** at this step looks roughly like the JSON below (the **`id`** field is the order **id** you need in Step 2; the actual **`id`** depends on your DB — for example it might be **4** if this is the fourth order created):

```
{
  "id": 4,
  "status": "PENDING",
  "productId": 1,
  "quantity": 1
}
```

Record the order **id** from the response for Step 2.

**Step 2:** Trigger the stock check (per the **repo** — call **Inventory**).

- Method: **POST**
- URL: `http://localhost:3003/inventory/check`
- Body (replace **42** with the real order **id** from Step 1 — JSON must be a **number**, not a placeholder):

```
{
  "orderId": 42,
  "productId": 1,
  "quantity": 1
}
```

**Equivalent `curl` command** — replace **42** with the real order **id** from Step 1; run in a **terminal** (**Linux** / **macOS** / **WSL2**).

```
curl -X POST http://localhost:3003/inventory/check -H "Content-Type: application/json" -d "{\"orderId\":42,\"productId\":1,\"quantity\":1}"
```

**Response** from **Inventory** (HTTP) looks roughly like this when there is not enough stock — **compensation** is then driven via **Kafka**:

```
{
  "success": false,
  "message": "Out of stock, compensation triggered"
}
```

**Expected Results**

**Inventory** reports out of stock; in the **repo**, **`apps/inventory/src/app.service.ts`** emits a payload to **Kafka** (topic **`inventory-events`**, **`eventType`: `INVENTORY_OUT_OF_STOCK`**); **Payment** and **Order** subscribe to that topic (**`apps/payment/src/app.controller.ts`**, **`apps/order/src/app.controller.ts`**) and run **compensation** — **Payment** **refunds**, **Order** becomes **CANCELLED**. You should not see money charged while the order stays **COMPLETED**.

**Conclusion**

When a later step fails, earlier steps are handled with **compensation** — that is how **Saga** stands in for a single-database **rollback**.

After both flows you have seen **success** and **failure** under control. Next come the **concepts** and common **edge cases** in real deployments.

## III. Advanced theory and conclusion

### 1. What Saga is and why it matters in microservices

A **Saga** is a chain of **local transactions**; each step commits inside one service. If a later step fails, earlier work is **undone** via **compensating transactions** (refund, release hold, mark cancelled) — not a single global SQL **rollback**. In microservices, this is a common way to get **controlled consistency** when you **do not** share one database.

- **Example:** Money was charged but stock is insufficient — **compensation** is refund plus **CANCELLED** order, not time travel across three databases.

### 2. Event-driven reactions versus orchestration

There is no central **orchestrator**: each **service** publishes and subscribes to **events** — an **event-driven** style. Strong **decoupling**; fits **fewer branches** and teams that enforce **event contracts**. Weakness: the **business flow** is scattered across repos — hard to see in one place, easy to drift on event schema versions.

**Orchestration** uses an **orchestrator** (Saga manager) as a **state machine**: send commands, wait for results, choose the next step or **compensation** branch. Fits **many branches** and **conditions**. Trade-off: the orchestrator is a **concentration point** — it needs **high availability**, **version alignment** for how it talks to other **services**, and you should avoid stuffing **business logic** into it; keep it focused on **coordinating** steps.

- **Example 1:** The demo above is **event-driven**: **Order** emits events; **Payment** and **Inventory** **react** and emit further events.
- **Example 2:** The **orchestrator** publishes a **ChargePayment** command to the **`commands.payment`** topic on **Kafka**, waits for a **reply** from **Payment** (for example on **`replies.payment`** or via a shared **correlation id**); only if that step succeeds does it **publish** **ReserveStock** to **`commands.inventory`**. If **Inventory** returns **failure** (or the call **times out**), the orchestrator publishes **RefundPayment** to **`commands.payment`** — the **compensation** branch and step order live in the orchestrator’s **state machine**; **Kafka** carries commands and outcomes; individual **services** do not infer the whole **saga** on their own.

### 3. Production: outbox, idempotency, and crashes mid-flight

The local demo is fine; in **production**, **brokers** are usually **at-least-once**, **services** **crash** mid-flight, and **emitting events** can **diverge** from **database writes** if you do not design for it. Below are a few typical **edge cases**, each with a **problem** and a **way forward**:

- **Duplicate messages / broker retries.** The same message handled twice can **refund** twice or **decrement stock** twice. Mitigation: **idempotent** **consumers**; an **idempotency key** or an "already processed" record keyed by **message id** / **business id**.
- **Database write vs event publish.** You **commit** business state but do not publish the **event** (or the reverse), so state and logs disagree. Mitigation: **Transactional Outbox** — write the **outbox** in the same **transaction** as business changes, then let a background process publish to a reliable **broker**.
- **Crash between steps.** A **service** dies after a local **commit** but before a complete **publish**, or messages are in flight but not fully processed. Mitigation: bounded **retries**, **reconciliation**, and knowing which **saga** step is stuck.
- **Poison messages / endless failure.** A message keeps failing the **handler**, so the flow never moves. Mitigation: a **dead-letter queue** (DLQ), alerts, manual intervention or fixing source data, then **replay**.

A serious distributed system does not promise **ACID** across **services**; it promises a **controlled step chain**, **disciplined compensation**, and **eventual** consistency you can justify with logs and business state.

**Saga** is not magic that "replaces transactions" — it is a **design with a price**: you trade global **ACID** for **local ACID** plus **orchestration** through a **message queue** plus **compensation**.
