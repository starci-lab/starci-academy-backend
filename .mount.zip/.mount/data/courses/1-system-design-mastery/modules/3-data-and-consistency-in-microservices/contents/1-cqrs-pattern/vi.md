# title

Mô hình CQRS

# description

Tách luồng ghi và luồng đọc bằng CQRS để giảm đụng độ tải và tối ưu truy vấn trong kiến trúc phân tán, rồi nhìn trade-off eventual consistency và đồng bộ Read Model trên môi trường thật.

# body

## I. Lời mở đầu

Trong **microservices**, các **operation** thường được **chia** theo **service** — mỗi **service** một nhóm **thao tác** **ghi** rõ ranh giới: ví dụ **Order Service** lo tạo đơn, cập nhật trạng thái,… và **ghi** xuống một **PostgreSQL** (hay **DB** tương đương). Traffic thường **lệch** mạnh về **đọc**. **Ở production**, tỉ lệ **ghi** so với **đọc** thường rơi vào **1/10** hoặc **2/10** (tùy **ứng dụng**). Khi scale, cùng **DB** đó vừa phải **ghi** vừa phải **đọc**, dễ tranh **kết nối**, **quá tải** **DB**, … **CQRS** cốt là **tách** hai loại tải — **Command** (ghi) và **Query** (đọc) — ra **hai** **service** khác nhau, thay vì dồn chung một chỗ như **monolith**. **Hãy đọc tiếp các phần sau** để hiểu thêm nhé.

## II. Demo trực quan và thực hành

**Ví dụ** dưới đây là hai **app** **`command`** (cổng **3000**, **Write Model** trên **PostgreSQL**) và **`query`** (cổng **3001**, **Read Model** trên **Elasticsearch**). Đồng bộ **Write** đến **Read** qua **RabbitMQ** làm **EventBus**: **POST** cập nhật khách → **CommandBus** ghi **PostgreSQL** → publish **`CustomerProfileUpdatedEvent`** lên **RabbitMQ** → **Query** consume và **projection** sang **Elasticsearch**. **GET** từ **Client** chỉ gọi **Query** → **Elasticsearch** — **không** qua **broker** và **không** đọc **PostgreSQL** của **Command**.

**Clone** ở đây: [CQRS — demo (NestJS monorepo)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/cqrs)

| Thành phần | Cổng | Công nghệ | Trách nhiệm (rút gọn) |
|-------------|------|-----------|------------------------|
| **Command** | **3000** | **NestJS** | **CommandBus**, ghi Write Model, publish event qua **RabbitMQ** |
| **PostgreSQL** | **5432** | **PostgreSQL** | **Write Model** (lưu trữ phía **Command**) |
| **RabbitMQ** (**EventBus**) | **5672** | **RabbitMQ** | Trung gian bất đồng bộ giữa **Command** và **Query** |
| **Query** | **3001** | **NestJS** | **QueryBus**, consume event, **projection** Read Model; xử lý **GET** |
| **Elasticsearch** | **9200** | **Elasticsearch** | **Read Model** (truy vấn phía **Query**) |

![Sơ đồ CQRS demo — Command, RabbitMQ, Query, Elasticsearch](https://starci.org/system-design-mastery/cqrs-pattern/0.svg)

*Hình 1. Sơ đồ kiến trúc hệ thống từ source code trên.*

Luồng **HTTP** ghi qua **Command** và **Write Model**; đồng bộ **Write → Read** qua **RabbitMQ**; **HTTP** đọc qua **Query** và **Read Model**.

### 1. Chuẩn bị và chạy môi trường

Giả định đã cài **Docker** và **Node.js** (LTS). Trong **repo** (đã **clone**), làm lần lượt:

1. Khởi chạy **PostgreSQL** (Write Model) — cùng cách gọi như **README** repo:

```
docker compose -f .docker/postgresql.yaml up --build -d
```

2. Khởi chạy **Elasticsearch** (Read Model):

```
docker compose -f .docker/elasticsearch.yaml up --build -d
```

3. Khởi chạy **RabbitMQ** (**EventBus**):

```
docker compose -f .docker/rabbitmq.yaml up --build -d
```

4. Cài dependency:

```
npm install
```

5. Mở **hai terminal**: một **Command**, một **Query** (thứ tự không bắt buộc, miễn cả hai chạy):

```
npx nest start command --watch
```

```
npx nest start query --watch
```

**Kết quả mong đợi**

**Command** lắng cổng **3000**, **Query** lắng cổng **3001**; **PostgreSQL**, **Elasticsearch** và **RabbitMQ** (**5672**) đều **up** theo **Docker**.

**Kết luận**

Hai **service** độc lập; **ghi** và **đọc** tách đường; đồng bộ Write → Read trong **demo** này đi qua **RabbitMQ** (**publish** / **consume**) — **GET** HTTP không đi qua **broker** — đúng tinh thần **CQRS** và khớp **README** repo.

### 2. Luồng ghi rồi đọc — Read Model khớp dữ liệu vừa ghi

Bạn có thể **làm theo** bằng **app có giao diện** (ví dụ **Postman**, **Insomnia**, **Bruno** …) **hoặc** bằng **`curl`** trong **terminal** trên **Linux** hoặc **macOS**. Nếu bạn dùng **Windows**, hãy **cài WSL2** rồi chạy **`curl`** trong shell Linux — bài **không** hướng dẫn **CMD**/**PowerShell** thuần.

**Các bước thực hiện:**

**Bước 1:** Cập nhật khách qua **Command** (**Write**).

- Method: **POST**
- URL: `http://localhost:3000/customer/update`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "id": "123",
  "name": "John Doe",
  "email": "john@example.com"
}
```

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X POST http://localhost:3000/customer/update -H "Content-Type: application/json" -d "{\"id\":\"123\",\"name\":\"John Doe\",\"email\":\"john@example.com\"}"
```

**Response** ở bước này phụ thuộc cách **handler** trả về trong repo (thường xác nhận đã nhận **Command** / đã ghi **Write Model**).

**Bước 2:** Đọc lại qua **Query** (**Read**).

- Method: **GET**
- URL: `http://localhost:3001/customer/123`

**Câu lệnh `curl` tương đương**:

```
curl -X GET http://localhost:3001/customer/123
```

**Response** kỳ vọng (sau khi **projection** chạy xong): body chứa **`name`** **John Doe** và **email** khớp bước 1 — đọc từ **Elasticsearch**.

**Kết quả mong đợi**

**Command** ghi **PostgreSQL** và phát **`CustomerProfileUpdatedEvent`**; **Query** nhận event, cập nhật Read Model; **GET** thấy đúng dữ liệu vừa ghi.

**Kết luận**

**Write** và **Read** khớp nhau trên cùng **id** — luồng **CQRS** trong demo chạy trọn.

Sau luồng **ghi → đọc** khớp ở trên, tiếp theo là các **khái niệm** CQRS và **edge case** thường gặp.

## III. Giải thích nâng cao và kết luận

### 1. CQRS là gì và tại sao nó quan trọng khi đọc và ghi lệch tải

**CQRS** (**Command Query Responsibility Segregation**) tách **mô hình ghi** (**Command**) và **mô hình đọc** (**Query**). **Command** ưu tiên **nhất quán** khi thay đổi trạng thái; **Query** ưu tiên **đọc nhanh**, thường **phi chuẩn hóa** cho màn hình. Không phải mọi hệ đều cần — nhưng khi **đọc** và **ghi** không cùng **shape** hoặc không cùng **scale**, tách hai đường giúp bạn **scale** và **tối ưu** độc lập thay vì **kẹt** một **schema** chung.

- **Ví dụ:** Cập nhật hồ sơ đi vào **PostgreSQL**; dashboard đọc từ **Elasticsearch** đã **projection** sẵn field cần hiển thị — tránh **JOIN** xuyên **service** lúc render.

### 2. Lợi ích và trade-off

**Hiệu năng và độc lập scale:** **scale** **Query service** khi lượng **read request** đột biến; **scale** **Write service** khi lượng **write** / **giao dịch** tăng đột biến — đừng **gom** **đọc** lẫn **ghi** một **chỗ** rồi **tăng instance** không đúng chỗ.

**Linh hoạt công nghệ:** **ACID** cho **Write**; **search** / **aggregate** cho **Read** — mỗi **store** đúng **workload**.

**Trade-offs:** **eventual consistency** giữa Write và Read; vận hành **hai** (hoặc nhiều) **store** và **pipeline** đồng bộ; khi **broker** / **event** lỗi cần **replay**, **Transactional Outbox**, hoặc **event log** — tùy mức độ hệ thống.

### 3. Production: Read Model trễ, projection, và độ tin cậy

Demo chạy local thì không sao; trên **production**, **Read Model** cập nhật **bất đồng bộ**, **message** có thể **duplicate**, và **ghi DB** với **phát event** dễ **lệch** nếu không thiết kế — dưới đây là vài **edge case** điển hình, gồm **vấn đề** và **hướng giải quyết**:

- **Read trễ so với Write.** **Vấn đề:** người dùng **ghi** xong **đọc** ngay có thể thấy dữ liệu cũ. **Hướng xử lý:** UI cho **trạng thái chờ** / **poll** / **version**; chấp nhận **eventual consistency** với **mức độ trễ** thống nhất với sản phẩm.
- **Đồng bộ Read Model lệch hoặc dừng.** **Vấn đề:** **consumer** chết, **event** chồng, hoặc **schema** đổi. **Hướng xử lý:** **replay** có kiểm soát, **idempotent** **projection**, có **dead-letter** cho bản ghi không xử lý được.
- **Ghi DB và phát event không cùng lúc.** **Vấn đề:** đã **commit** nhưng chưa phát **event** (hoặc ngược lại). **Hướng xử lý:** **Transactional Outbox** (hoặc **event log** đúng thứ tự) rồi đẩy ra **message queue** / **broker** tin cậy.
- **Multiple sources of truth** (thiết kế lỏng). **Vấn đề:** sửa trực tiếp **Read** mà không qua **Write** — **Write** và **Read** không còn một **source of truth**. **Hướng xử lý:** coi **Write** là **source of truth**; **Read** chỉ **projection**; cấm đường tắt nếu không có **policy** rõ.

**CQRS** không phải “một pattern cho mọi **service**”. Khi **đọc** và **ghi** không tách bạch về **tải** và **hình dạng dữ liệu**, thêm **CQRS** chỉ thêm **chi phí vận hành**. Khi đã tách, hãy coi **đồng bộ Read Model** là **pipeline** cần **giám sát** và **kiểm thử** như một phần của kiến trúc — không phụ lục sau **release**. Kết hợp với **Event Sourcing** hoặc **outbox** là lựa chọn phổ biến khi bạn cần **audit** và **khôi phục** luồng **event**; đó là hướng mở rộng, không bắt buộc mọi bài **CQRS** đều triển khai cùng lúc.

# references
## 0
### alias
CQRS pattern - Azure Architecture Center
### url
https://learn.microsoft.com/en-us/azure/architecture/patterns/cqrs
## 1
### alias
Microservices.io: CQRS
### url
https://microservices.io/patterns/data/cqrs.html

# minutesRead
35
