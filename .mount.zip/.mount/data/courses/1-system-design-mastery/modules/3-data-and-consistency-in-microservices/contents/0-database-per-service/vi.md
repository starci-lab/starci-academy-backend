# title
Database per Service

# description
Mỗi microservice sở hữu DB riêng, không service nào JOIN trực tiếp DB của service khác — demo hai service Order (PostgreSQL) và Inventory (MongoDB) để thấy ranh giới dữ liệu thật, rồi đọc sâu trade-off truy vấn xuyên service, eventual consistency và polyglot persistence.

# body

## I. Lời mở đầu

Đi phỏng vấn **Senior Backend** ở công ty đã tách **microservices**, câu hỏi gài hay gặp: *"Hệ thống có **Order Service** và **Inventory Service**, khi admin vào trang xem danh sách đơn kèm **tên sản phẩm** và **số tồn kho**, em query thế nào?"*. **Beta** quen **monolith** sẽ trả lời gần như bản năng: *"em **JOIN** bảng `orders` với bảng `products` theo `product_id`"* — và đó là lúc người phỏng vấn **biết** là chưa nắm **Database per Service**. Trong **microservices** đúng nghĩa, **Order Service** **không** thấy được bảng `products` của **Inventory Service**; hai bên có **schema riêng**, thậm chí **công nghệ lưu trữ riêng** (**PostgreSQL** vs **MongoDB**), và mọi nhu cầu dữ liệu chéo phải đi qua **API** hoặc **event** — không có **JOIN** xuyên **service**.

Lý do không phải để "cho giống **Netflix**", mà để **tháo coupling**: nếu ba **service** cùng **JOIN** vào bảng `products`, đổi một cột trong **Inventory** có thể **làm sập** **Order** và **Report** mà người sửa **không** hề biết; bảng chung biến thành **contract ngầm** không ai ký. Thêm vào đó, bảng chung cũng là **single point of failure** — **DB** chết thì **tất cả service** chết theo, mất hoàn toàn lợi ích phân tán. Muốn nắm **Database per Service** đúng mức **demo** thì phải mở hai **service** dùng **hai loại DB khác nhau** ra chạy một lượt để thấy ranh giới dữ liệu thật sự nằm ở đâu — đọc tiếp phần sau.

## II. Demo trực quan và thực hành

**Ví dụ** dưới đây là hai **service** **`order`** (cổng **3000**, **PostgreSQL** cho dữ liệu quan hệ) và **`inventory`** (cổng **3001**, **MongoDB** cho dữ liệu document) trong cùng một **monorepo** **NestJS**. Mỗi **service** **sở hữu** **DB riêng**, **không** dùng chung, **không** **JOIN** xuyên **DB**: **POST** tạo sản phẩm vào **Inventory** → **Inventory** ghi **MongoDB**; **POST** tạo đơn vào **Order** → **Order** ghi **PostgreSQL**. Khi **Order** cần **tên sản phẩm** để hiển thị, nó **gọi HTTP API** của **Inventory** — **polyglot persistence** (mỗi **store** đúng **workload**) đi kèm **loose coupling** (đổi **schema** bên nào chỉ ảnh hưởng **service** đó).

**Clone** ở đây: [Database per Service — demo (NestJS monorepo)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/database-per-service)

| Thành phần | Cổng | Công nghệ | Trách nhiệm (rút gọn) |
|-------------|------|-----------|------------------------|
| **Order** | **3000** | **NestJS** | **POST /orders**, ghi **PostgreSQL**; gọi **Inventory** qua **HTTP** khi cần dữ liệu chéo |
| **PostgreSQL** | **5432** | **PostgreSQL** | **DB riêng** của **Order** (bảng `orders`, quan hệ, **ACID**) |
| **Inventory** | **3001** | **NestJS** | **POST /inventory**, ghi **MongoDB**; expose **GET** cho **Order** đọc dữ liệu sản phẩm |
| **MongoDB** | **27017** | **MongoDB** | **DB riêng** của **Inventory** (collection `products`, document, tối ưu đọc) |

![Sơ đồ Database per Service — Order + PostgreSQL, Inventory + MongoDB](https://starci.org/system-design-mastery/database-per-service/0.svg)

*Hình 1. Sơ đồ kiến trúc hệ thống từ source code trên.*

**Order** sở hữu **PostgreSQL**; **Inventory** sở hữu **MongoDB**; đường đứt nét là **HTTP API** nội bộ — **không** có đường **DB-to-DB** giữa hai bên.

### 1. Chuẩn bị và chạy môi trường

Giả định đã cài **Docker** và **Node.js** (LTS). Trong **repo** (đã **clone**), làm lần lượt:

1. Khởi chạy **PostgreSQL** (cho **Order**):

```
docker compose -f .docker/postgresql.yaml up --build -d
```

2. Khởi chạy **MongoDB** (cho **Inventory**):

```
docker compose -f .docker/mongodb.yaml up --build -d
```

3. Cài dependency:

```
npm install
```

4. Mở **hai terminal**, mỗi terminal một **service**:

```
npx nest start order --watch
```

```
npx nest start inventory --watch
```

**Kết quả mong đợi**

**Order** lắng cổng **3000**, **Inventory** lắng cổng **3001**; **PostgreSQL** (**5432**) và **MongoDB** (**27017**) đều **up** theo **Docker**.

**Kết luận**

Hai **service** chạy độc lập, mỗi **service** kết nối đúng **DB** của riêng mình; không ai đọc-ghi DB của ai — ranh giới **Database per Service** đã hiện thực hóa ở mức cấu hình chạy thật.

### 2. Ghi dữ liệu vào hai DB khác nhau — không chia sẻ

Bạn có thể **làm theo** bằng **app có giao diện** (ví dụ **Postman**, **Insomnia**, **Bruno** …) **hoặc** bằng **`curl`** trong **terminal** trên **Linux** hoặc **macOS**. Nếu dùng **Windows**, **cài WSL2** rồi chạy **`curl`** trong shell Linux — bài **không** hướng dẫn **CMD**/**PowerShell** thuần.

**Các bước thực hiện:**

**Bước 1:** Thêm sản phẩm vào **Inventory** (**MongoDB**).

- Method: **POST**
- URL: `http://localhost:3001/inventory`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "name": "Macbook M3",
  "stock": 50
}
```

**Câu lệnh `curl` tương đương** — chạy trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X POST http://localhost:3001/inventory -H "Content-Type: application/json" -d "{\"name\":\"Macbook M3\",\"stock\":50}"
```

**Response** xác nhận đã ghi **MongoDB** (có **`_id`** kiểu ObjectId và các trường vừa gửi).

**Bước 2:** Tạo đơn trong **Order** (**PostgreSQL**).

- Method: **POST**
- URL: `http://localhost:3000/orders`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "customerId": "user_01",
  "totalAmount": 2500
}
```

**Câu lệnh `curl` tương đương**:

```
curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d "{\"customerId\":\"user_01\",\"totalAmount\":2500}"
```

**Response** xác nhận **Order** đã ghi **PostgreSQL** (**`id`** dạng số tự tăng hoặc UUID tùy **repo**).

**Kết quả mong đợi**

**Inventory** đã ghi document sản phẩm vào **MongoDB** (collection `products`); **Order** đã ghi dòng đơn vào **PostgreSQL** (bảng `orders`). Không có kết nối DB-to-DB giữa hai bên; **Order** **không** biết collection `products` tồn tại, **Inventory** **không** biết bảng `orders`.

**Kết luận**

Hai **service** dùng **hai công nghệ lưu trữ khác nhau** (**PostgreSQL** vs **MongoDB**) và vẫn vận hành trọn vẹn trong cùng một hệ — đúng tinh thần **polyglot persistence**. Nếu cần dữ liệu chéo trong **production**, **Order** sẽ **gọi HTTP API** của **Inventory** (hoặc dùng **CQRS** / **API Composition** — bàn ở phần III), **không** mở kết nối vào **MongoDB** của **Inventory** từ **Order**.

Sau luồng vừa chạy, tiếp theo là các **khái niệm** và **trade-off** của **Database per Service** khi triển khai thật.

## III. Giải thích nâng cao và kết luận

### 1. Database per Service là gì và tại sao nó quan trọng trong microservices

**Database per Service** là quy tắc: **mỗi service sở hữu một schema (hoặc một DB) riêng**; **không service nào** được **đọc trực tiếp** hay **JOIN** vào **store** của service khác — mọi nhu cầu dữ liệu chéo đi qua **API**, **event**, hoặc **projection** do chính service chủ đưa ra. Đây **không** phải "mỗi project một DB cho đẹp" — đây là **ranh giới sở hữu dữ liệu** (**data ownership**) khớp với **bounded context** nghiệp vụ.

- **Ví dụ:** **Order Service** sở hữu bảng `orders` trên **PostgreSQL**; **Inventory Service** sở hữu collection `products` trên **MongoDB**. Trang admin cần hiển thị **đơn + tên sản phẩm** → **Order** gọi **`GET /inventory/:id`** rồi ghép (**API Composition**), thay vì **JOIN** hai **store**.

### 2. Lợi ích thật sự

Ba lợi ích thường được nêu, nhưng ý nghĩa thật khác slide hay trình bày:

- **Loose coupling theo schema:** Team **Inventory** đổi tên cột `stock` → `availableStock`, chỉ **Inventory** phải cập nhật; **Order** **không vỡ** vì chưa từng đọc cột đó. Nếu DB chung, **Inventory** phải **thông báo** 3–5 team, chờ **migration** đồng bộ — thời gian release bị **kéo** theo team chậm nhất.
- **Polyglot persistence:** **Order** cần **ACID** đa dòng cho **transaction** đặt hàng → **PostgreSQL** hợp lý; **Inventory** chủ yếu đọc nhanh theo `product_id` và chứa document linh hoạt (ảnh, thông số, biến thể) → **MongoDB** hợp lý; **Search** cần **full-text** → **Elasticsearch**. Mỗi **store** tối ưu cho đúng **workload**, thay vì ép một **PostgreSQL** gánh mọi thứ.
- **Independent scaling:** **Read** của **Inventory** có thể cao gấp **50×** **Order** (mọi trang sản phẩm đều đọc kho) — với **DB riêng**, chỉ **MongoDB** của **Inventory** cần **replica read** hoặc **sharding**, **PostgreSQL** của **Order** vẫn ở cấu hình vừa phải.

### 3. Trade-off không thể né

**Database per Service** đổi **ACID xuyên service** lấy **distributed complexity** — muốn đi với kiến trúc này phải chấp nhận:

- **Không có transaction xuyên service.** **Order** tạo đơn và **Inventory** trừ kho nằm trên **hai DB khác nhau** — **two-phase commit** (**2PC**) hiếm khi là lựa chọn trên production (chậm, khó recover khi **coordinator** chết). Thay vào đó, dùng **Saga pattern** (chuỗi **local transaction** + **compensation**) hoặc **Outbox** + **event-driven** để đạt **eventual consistency**.
- **Truy vấn chéo khó và chậm hơn `JOIN`.** Trang *"đơn hàng kèm tên sản phẩm và tồn kho"* không còn là một câu **SQL**; nó là **API Composition** (gọi **n** API rồi ghép ở tầng **BFF**/**Gateway**) hoặc **CQRS** với **Read Model** đã **projection** sẵn — lập trình nhiều hơn, debug khó hơn, và có độ trễ mạng.
- **Eventual consistency là mặc định.** Sau khi **Order** phát event `OrderCreated`, **Inventory** trừ kho **trễ** vài **ms** → vài **giây**. Sản phẩm có thể hiện *"còn hàng"* trên UI một khoảnh khắc sau khi đã **bán hết** — nghiệp vụ phải thiết kế để **chấp nhận** trạng thái tạm không chính xác và **đối soát** định kỳ.
- **Chi phí vận hành nhân lên.** Một DB thành **n** DB có nghĩa là **n** pipeline backup, **n** bộ metric, **n** phiên bản schema migration, **n** runbook khôi phục — chưa kể **polyglot** đi kèm **n** bộ kỹ năng operations.

### 4. Các pattern bổ trợ khi đã đi "Database per Service"

Khi đã chọn tách DB, ba pattern thường đi cùng để vá các trade-off ở mục 3:

- **API Composition:** Một **Composition Service** (hoặc **BFF**) gọi song song nhiều **service**, ghép kết quả rồi trả client. Đơn giản, không thêm hạ tầng; yếu khi số lượng bản ghi lớn hoặc cần sắp xếp / phân trang xuyên nguồn.
- **CQRS với Read Model:** Service chủ phát **event** khi đổi trạng thái; **service** đọc (**Query**) subscribe và **project** sang **store riêng** đã **phi chuẩn hóa** cho đúng màn hình hiển thị. Truy vấn nhanh, nhưng phải chấp nhận **Read trễ** và chi phí vận hành **pipeline projection**.
- **Transactional Outbox + event-driven:** **Service** ghi thay đổi nghiệp vụ và bản ghi **outbox** trong **cùng một transaction local**; tiến trình nền đọc **outbox** và **publish** ra **message queue** (**Kafka**, **RabbitMQ**) với đảm bảo **at-least-once**. Giải quyết cảnh **"đã commit nhưng chưa publish event"** — là gốc của rất nhiều bug dữ liệu lệch.

### 5. Khi nào **không** nên tách Database per Service

**Database per Service** **đáng** khi bạn đã có: **bounded context rõ**, **team riêng** cho mỗi context, và **quy mô** đủ để chi phí tách **nhỏ hơn** lợi ích về **autonomy**. Các trường hợp **không** nên lao vào:

- **Monolith modular chưa ổn định domain:** Team nhỏ, **bounded context** còn đang dò; tách DB sớm → mỗi lần đổi ranh giới nghiệp vụ kéo theo **data migration** xuyên **n** DB — chậm hơn refactor module trong một DB duy nhất.
- **Luồng nghiệp vụ cốt lõi cần ACID tuyệt đối:** Chuyển tiền liên tài khoản nội bộ, đặt vé với **seat lock** yêu cầu **strong consistency** — giữ trong **một DB** (hoặc một **bounded context**) rồi chỉ tách những gì **thật sự** khác ngữ cảnh (ví dụ **Notification**, **Report**).
- **Team chưa có hạ tầng cho distributed data:** Chưa có **observability** cho event, chưa có **DLQ**, chưa từng viết **Saga**/**Outbox** — tách DB trước sẽ biến mỗi bug dữ liệu thành một cuộc điều tra xuyên **n service**.

**Database per Service** không phải trang trí kiến trúc — nó là một **cam kết kỷ luật**: *chấp nhận **eventual consistency** và **chi phí vận hành distributed data** để đổi lấy **autonomy schema**, **polyglot persistence**, và **scale độc lập** theo đúng workload*. Khi đã chọn đi con đường này, hãy coi **ranh giới DB** ngang với **ranh giới API**: vi phạm nó (đọc trộm bảng của service khác qua một **view** hay **read replica** chung) là hỏng **toàn bộ** lý do đã tách ngay từ đầu — bạn sẽ có một **distributed monolith** coupling qua DB, vừa chịu chi phí phân tán vừa mất lợi ích của nó.

# references
## 0
### alias
Microservices.io — Database per Service
### url
https://microservices.io/patterns/data/database-per-service.html
## 1
### alias
Microservices.io — Shared Database (anti-pattern)
### url
https://microservices.io/patterns/data/shared-database.html
## 2
### alias
Microservices.io — API Composition
### url
https://microservices.io/patterns/data/api-composition.html
## 3
### alias
Microservices.io — Transactional Outbox
### url
https://microservices.io/patterns/data/transactional-outbox.html

# minutesRead
30
