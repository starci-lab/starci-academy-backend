# title
Communication Patterns

# description
Các pattern giao tiếp phổ biến giữa services trong hệ thống Microservices.

# previewContents
## 0
### text
API Gateway Pattern: 1 cổng vào cho client, routing và auth cơ bản.
## 1
### text
Backend for Frontend (BFF): tách backend theo từng loại client (web/mobile).
## 2
### text
Service-to-Service: giao tiếp giữa services bằng REST vs gRPC.
## 3
### text
Event-Driven Architecture: dùng Kafka để xử lý bất đồng bộ.
## 4
### text
Publish–Subscribe: publish event, nhiều consumer xử lý song song.
## 5
### text
Biết chọn đúng cách giao tiếp giữa services theo từng bài toán.
## 6
### text
Hiểu khi nào nên dùng sync (REST/gRPC) và khi nào nên dùng async (Kafka).
## 7
### text
Nắm được vai trò của API Gateway và BFF trong hệ thống thực tế.
## 8
### text
Hiểu Pub/Sub hoạt động ra sao và áp dụng được cho các flow phổ biến.
## 9
### text
Sau khi hoàn tất module: thiết kế luồng giao tiếp giữa các services rõ ràng, tránh "gọi nhau lung tung", sẵn sàng cho các pattern dữ liệu và consistency ở module tiếp theo.
