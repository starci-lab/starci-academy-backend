# title
API Gateway cơ bản với Kong và NestJS Microservices

# description
Xây dựng 2 microservice NestJS (Auth Service và Product Service) và định tuyến chúng qua Kong API Gateway chế độ DB-less bằng Docker Compose. Chứng minh khả năng tập trung hoá routing qua một điểm vào duy nhất.

# requirements
Tạo 2 NestJS microservice riêng biệt: `AuthService` với endpoint `POST /auth/login` trả về token giả lập, và `ProductService` với endpoint `GET /products` trả danh sách sản phẩm mẫu. Cấu hình Kong API Gateway (DB-less mode) bằng file `kong.yml` để định tuyến `/auth/**` đến Auth Service và `/products/**` đến Product Service. Toàn bộ hệ thống chạy bằng `docker-compose.yml`.

# prerequisites
- Docker và Docker Compose
- Node.js >= 18
- NestJS CLI
- Kiến thức cơ bản về RESTful API

# steps

## 0
### title
Khởi tạo 2 NestJS microservice
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project Auth Service:
    ```bash
    nest new auth-service
    ```
  - Bước 2: Tạo project Product Service:
    ```bash
    nest new product-service
    ```
  - Bước 3: Trong `auth-service`, tạo `AuthController` với endpoint `POST /auth/login` nhận body `{ username, password }` và trả về `{ token: "fake-jwt-token" }`.
  - Bước 4: Trong `product-service`, tạo `ProductController` với endpoint `GET /products` trả về mảng sản phẩm mẫu (ít nhất 3 sản phẩm, mỗi sản phẩm có `id`, `name`, `price`).
- **Kết quả mong đợi:** Mỗi service chạy độc lập trên các cổng khác nhau (ví dụ 3001 và 3002), các endpoint trả đúng dữ liệu.
- **Kết luận:** Hai microservice đã sẵn sàng để được định tuyến qua API Gateway.

## 1
### title
Tạo Dockerfile cho mỗi service
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `Dockerfile` trong thư mục `auth-service` với base image `node:18-alpine`, copy source code, chạy `npm install` và `npm run build`, expose cổng 3001.
  - Bước 2: Tạo `Dockerfile` trong thư mục `product-service` tương tự, expose cổng 3002.
  - Bước 3: Tạo file `.dockerignore` cho mỗi service để loại trừ `node_modules` và `dist`.
- **Kết quả mong đợi:** Mỗi service có thể build thành Docker image thành công.
- **Kết luận:** Các service đã được container hoá, sẵn sàng tích hợp vào Docker Compose.

## 2
### title
Cấu hình Kong API Gateway (DB-less mode)
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `kong.yml` (declarative config) với nội dung:
    ```yaml
    _format_version: "3.0"
    services:
      - name: auth-service
        url: http://auth-service:3001
        routes:
          - name: auth-route
            paths:
              - /auth
      - name: product-service
        url: http://product-service:3002
        routes:
          - name: product-route
            paths:
              - /products
    ```
  - Bước 2: Xác nhận cấu trúc file đúng cú pháp YAML và mapping đúng service name với container name trong Docker Compose.
- **Kết quả mong đợi:** File `kong.yml` định nghĩa đúng 2 service và 2 route tương ứng.
- **Kết luận:** Kong sẽ đọc file này khi khởi động để tự động tạo routing mà không cần database.

## 3
### title
Tạo docker-compose.yml và chạy hệ thống
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `docker-compose.yml` với 3 service: `auth-service` (build từ `./auth-service`), `product-service` (build từ `./product-service`), và `kong` (image `kong:3.4`, environment `KONG_DATABASE=off`, `KONG_DECLARATIVE_CONFIG=/etc/kong/kong.yml`, mount file `kong.yml` vào container).
  - Bước 2: Expose cổng Kong (ví dụ `8000:8000`).
  - Bước 3: Chạy hệ thống:
    ```bash
    docker-compose up --build
    ```
- **Kết quả mong đợi:** Cả 3 container khởi động thành công, Kong log cho thấy đã load declarative config.
- **Kết luận:** Hệ thống API Gateway đã sẵn sàng nhận request và định tuyến đến các microservice.

## 4
### title
Kiểm thử định tuyến qua Kong
### body
- **Các bước thực hiện:**
  - Bước 1: Gọi endpoint Auth qua Kong:
    ```bash
    curl -X POST http://localhost:8000/auth/login -H "Content-Type: application/json" -d '{"username":"admin","password":"123"}'
    ```
  - Bước 2: Gọi endpoint Product qua Kong:
    ```bash
    curl http://localhost:8000/products
    ```
  - Bước 3: Gọi một path không tồn tại để xác nhận Kong trả 404:
    ```bash
    curl http://localhost:8000/unknown
    ```
- **Kết quả mong đợi:**
  - `POST /auth/login` qua Kong trả `{ token: "fake-jwt-token" }`.
  - `GET /products` qua Kong trả mảng sản phẩm.
  - `GET /unknown` trả 404 hoặc thông báo route not found từ Kong.
- **Kết luận:** Kong API Gateway định tuyến đúng request đến từng microservice tương ứng dựa trên path prefix.

# references
## 0
### alias
Kong DB-less Declarative Config
### url
https://docs.konghq.com/gateway/latest/production/deployment-topologies/db-less-and-declarative-config/
## 1
### alias
NestJS Documentation
### url
https://docs.nestjs.com/
## 2
### alias
Docker Compose Documentation
### url
https://docs.docker.com/compose/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn, bao gồm 2 NestJS service, Dockerfile, kong.yml và docker-compose.yml.
### score
20
### prompts
#### 0
##### title
Cấu trúc project và Dockerfile
##### score
7
##### promptText
Có 2 NestJS service riêng biệt (Auth và Product), mỗi service có Dockerfile hợp lệ, docker-compose.yml chạy được toàn bộ hệ thống.
#### 1
##### title
Cấu hình Kong và định tuyến
##### score
7
##### promptText
File `kong.yml` cấu hình đúng DB-less mode, định nghĩa 2 service và 2 route. Kong định tuyến `/auth/**` đến Auth Service và `/products/**` đến Product Service.
#### 2
##### title
Kết quả endpoint đúng
##### score
6
##### promptText
`POST /auth/login` qua Kong trả `{ token: "fake-jwt-token" }`. `GET /products` qua Kong trả danh sách sản phẩm. Path không tồn tại trả 404.

# difficulty
easy

# score
20
