# title
Basic API Gateway with Kong and NestJS Microservices

# description
Build 2 NestJS microservices (Auth Service and Product Service) and route them through Kong API Gateway in DB-less mode using Docker Compose. Demonstrate the ability to centralize routing through a single entry point.

# requirements
Create 2 separate NestJS microservices: `AuthService` with endpoint `POST /auth/login` returning a mock token, and `ProductService` with endpoint `GET /products` returning a list of sample products. Configure Kong API Gateway (DB-less mode) using a `kong.yml` file to route `/auth/**` to Auth Service and `/products/**` to Product Service. The entire system runs via `docker-compose.yml`.

# prerequisites
- Docker and Docker Compose
- Node.js >= 18
- NestJS CLI
- Basic knowledge of RESTful API

# steps

## 0
### title
Initialize 2 NestJS microservices
### body
- **Steps to follow:**
  - Step 1: Create the Auth Service project:
    ```bash
    nest new auth-service
    ```
  - Step 2: Create the Product Service project:
    ```bash
    nest new product-service
    ```
  - Step 3: In `auth-service`, create `AuthController` with endpoint `POST /auth/login` that accepts body `{ username, password }` and returns `{ token: "fake-jwt-token" }`.
  - Step 4: In `product-service`, create `ProductController` with endpoint `GET /products` returning an array of sample products (at least 3 products, each with `id`, `name`, `price`).
- **Expected result:** Each service runs independently on different ports (e.g., 3001 and 3002), endpoints return correct data.
- **Conclusion:** Both microservices are ready to be routed through the API Gateway.

## 1
### title
Create Dockerfile for each service
### body
- **Steps to follow:**
  - Step 1: Create a `Dockerfile` in the `auth-service` directory with base image `node:18-alpine`, copy source code, run `npm install` and `npm run build`, expose port 3001.
  - Step 2: Create a `Dockerfile` in the `product-service` directory similarly, expose port 3002.
  - Step 3: Create a `.dockerignore` file for each service to exclude `node_modules` and `dist`.
- **Expected result:** Each service can be built into a Docker image successfully.
- **Conclusion:** Services are containerized and ready for Docker Compose integration.

## 2
### title
Configure Kong API Gateway (DB-less mode)
### body
- **Steps to follow:**
  - Step 1: Create a `kong.yml` (declarative config) file with the following content:
    ```yaml
    _format_version: "3.0"
    services:
      - name: auth-service
        url: http://auth-service:3001
        routes:
          - name: auth-route
            paths:
              - /auth
      - name: product-service
        url: http://product-service:3002
        routes:
          - name: product-route
            paths:
              - /products
    ```
  - Step 2: Verify the file structure follows correct YAML syntax and maps service names to container names in Docker Compose.
- **Expected result:** The `kong.yml` file correctly defines 2 services and 2 corresponding routes.
- **Conclusion:** Kong will read this file on startup to automatically create routing without a database.

## 3
### title
Create docker-compose.yml and run the system
### body
- **Steps to follow:**
  - Step 1: Create `docker-compose.yml` with 3 services: `auth-service` (build from `./auth-service`), `product-service` (build from `./product-service`), and `kong` (image `kong:3.4`, environment `KONG_DATABASE=off`, `KONG_DECLARATIVE_CONFIG=/etc/kong/kong.yml`, mount `kong.yml` into container).
  - Step 2: Expose Kong port (e.g., `8000:8000`).
  - Step 3: Run the system:
    ```bash
    docker-compose up --build
    ```
- **Expected result:** All 3 containers start successfully, Kong logs show declarative config loaded.
- **Conclusion:** The API Gateway system is ready to receive requests and route them to microservices.

## 4
### title
Test routing through Kong
### body
- **Steps to follow:**
  - Step 1: Call the Auth endpoint through Kong:
    ```bash
    curl -X POST http://localhost:8000/auth/login -H "Content-Type: application/json" -d '{"username":"admin","password":"123"}'
    ```
  - Step 2: Call the Product endpoint through Kong:
    ```bash
    curl http://localhost:8000/products
    ```
  - Step 3: Call a non-existent path to confirm Kong returns 404:
    ```bash
    curl http://localhost:8000/unknown
    ```
- **Expected result:**
  - `POST /auth/login` through Kong returns `{ token: "fake-jwt-token" }`.
  - `GET /products` through Kong returns the product array.
  - `GET /unknown` returns 404 or a route not found message from Kong.
- **Conclusion:** Kong API Gateway correctly routes requests to the corresponding microservice based on path prefix.

# references
## 0
### alias
Kong DB-less Declarative Config
### url
https://docs.konghq.com/gateway/latest/production/deployment-topologies/db-less-and-declarative-config/
## 1
### alias
NestJS Documentation
### url
https://docs.nestjs.com/
## 2
### alias
Docker Compose Documentation
### url
https://docs.docker.com/compose/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code, including 2 NestJS services, Dockerfiles, kong.yml, and docker-compose.yml.
### score
20
### prompts
#### 0
##### title
Project structure and Dockerfiles
##### score
7
##### promptText
There are 2 separate NestJS services (Auth and Product), each with a valid Dockerfile, docker-compose.yml can run the entire system.
#### 1
##### title
Kong configuration and routing
##### score
7
##### promptText
The `kong.yml` file is configured correctly in DB-less mode, defines 2 services and 2 routes. Kong routes `/auth/**` to Auth Service and `/products/**` to Product Service.
#### 2
##### title
Correct endpoint results
##### score
6
##### promptText
`POST /auth/login` through Kong returns `{ token: "fake-jwt-token" }`. `GET /products` through Kong returns the product list. Non-existent paths return 404.

# difficulty
easy

# score
20
