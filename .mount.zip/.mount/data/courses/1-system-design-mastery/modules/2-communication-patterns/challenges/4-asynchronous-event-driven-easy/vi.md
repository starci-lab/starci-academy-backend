# title
Event-Driven cơ bản với Kafka: Producer và Consumer Groups

# description
Xây dựng hệ thống event-driven với Apache Kafka trong NestJS: Payment Service (Producer) phát sự kiện `PAYMENT_COMPLETED`, 2 Consumer (Shipping Service và Notification Service) xử lý sự kiện đó. Chứng minh cơ chế broadcasting qua Consumer Groups khác nhau.

# requirements
Tạo 3 NestJS application: `PaymentService` (Producer, cổng 3001) có endpoint `POST /payments` phát sự kiện `PAYMENT_COMPLETED` lên Kafka topic, `ShippingService` (Consumer, Consumer Group `shipping-group`) lắng nghe và log thông tin vận chuyển, `NotificationService` (Consumer, Consumer Group `notification-group`) lắng nghe và log thông báo. Sử dụng Docker Compose để chạy Kafka (KRaft mode) cùng các service. Chứng minh cả 2 consumer đều nhận được cùng một sự kiện (broadcasting).

# prerequisites
- Docker và Docker Compose
- Node.js >= 18
- NestJS CLI
- Package `@nestjs/microservices` và `kafkajs`
- Kiến thức cơ bản về Message Queue và Event-Driven Architecture

# steps

## 0
### title
Thiết lập Kafka bằng Docker Compose
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `docker-compose.yml` với Kafka chạy chế độ KRaft (không cần Zookeeper):
    ```yaml
    services:
      kafka:
        image: bitnami/kafka:3.6
        environment:
          - KAFKA_CFG_NODE_ID=1
          - KAFKA_CFG_PROCESS_ROLES=broker,controller
          - KAFKA_CFG_CONTROLLER_QUORUM_VOTERS=1@kafka:9093
          - KAFKA_CFG_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093
          - KAFKA_CFG_ADVERTISED_LISTENERS=PLAINTEXT://kafka:9092
          - KAFKA_CFG_CONTROLLER_LISTENER_NAMES=CONTROLLER
          - KAFKA_CFG_LISTENER_SECURITY_PROTOCOL_MAP=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
        ports:
          - "9092:9092"
    ```
  - Bước 2: Chạy Kafka:
    ```bash
    docker-compose up -d kafka
    ```
- **Kết quả mong đợi:** Kafka broker khởi động thành công trên cổng 9092.
- **Kết luận:** Hạ tầng messaging đã sẵn sàng để các service kết nối.

## 1
### title
Xây dựng Payment Service (Producer)
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS:
    ```bash
    nest new payment-service
    ```
  - Bước 2: Cài đặt dependencies:
    ```bash
    npm install @nestjs/microservices kafkajs
    ```
  - Bước 3: Đăng ký Kafka client trong module với `ClientsModule.register()`, cấu hình broker `kafka:9092`.
  - Bước 4: Tạo `PaymentController` với endpoint `POST /payments` nhận body `{ orderId, amount, method }`.
  - Bước 5: Trong handler, sau khi xử lý logic thanh toán (giả lập), emit sự kiện lên topic `payment-events` với key `PAYMENT_COMPLETED` và payload `{ orderId, amount, paidAt }`.
- **Kết quả mong đợi:** Mỗi khi gọi `POST /payments`, một message được gửi lên Kafka topic `payment-events`.
- **Kết luận:** Producer đã sẵn sàng phát sự kiện để các consumer xử lý.

## 2
### title
Xây dựng Shipping Service (Consumer Group 1)
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho Shipping Service.
  - Bước 2: Cấu hình `main.ts` để kết nối Kafka consumer với `groupId: 'shipping-group'`.
  - Bước 3: Tạo handler lắng nghe topic `payment-events` với decorator `@EventPattern('PAYMENT_COMPLETED')` hoặc `@MessagePattern`.
  - Bước 4: Trong handler, log thông tin vận chuyển: `[Shipping] Processing shipment for order ${orderId}`.
- **Kết quả mong đợi:** Shipping Service tự động nhận và xử lý sự kiện `PAYMENT_COMPLETED` khi có message mới trên topic.
- **Kết luận:** Consumer group `shipping-group` đã hoạt động độc lập.

## 3
### title
Xây dựng Notification Service (Consumer Group 2)
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho Notification Service.
  - Bước 2: Cấu hình `main.ts` để kết nối Kafka consumer với `groupId: 'notification-group'`.
  - Bước 3: Tạo handler lắng nghe topic `payment-events` với decorator `@EventPattern('PAYMENT_COMPLETED')`.
  - Bước 4: Trong handler, log thông báo: `[Notification] Sending payment confirmation for order ${orderId}, amount: ${amount}`.
- **Kết quả mong đợi:** Notification Service tự động nhận và xử lý cùng sự kiện `PAYMENT_COMPLETED`.
- **Kết luận:** Consumer group `notification-group` hoạt động độc lập với `shipping-group`, cả hai đều nhận được sự kiện (broadcasting).

## 4
### title
Kiểm thử broadcasting và Consumer Groups
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy toàn bộ hệ thống (Kafka + 3 service):
    ```bash
    docker-compose up --build
    ```
  - Bước 2: Gửi request thanh toán:
    ```bash
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":101,"amount":250000,"method":"credit_card"}'
    ```
  - Bước 3: Kiểm tra log của Shipping Service: phải có dòng `[Shipping] Processing shipment for order 101`.
  - Bước 4: Kiểm tra log của Notification Service: phải có dòng `[Notification] Sending payment confirmation for order 101`.
  - Bước 5: Gửi thêm 2-3 request để xác nhận mỗi sự kiện đều được cả 2 consumer xử lý.
- **Kết quả mong đợi:**
  - Mỗi `PAYMENT_COMPLETED` event được cả Shipping Service và Notification Service nhận và xử lý.
  - Log của 2 service hiển thị độc lập, chứng minh Consumer Groups khác nhau đều nhận được message.
- **Kết luận:** Cơ chế broadcasting qua Consumer Groups trong Kafka hoạt động đúng: mỗi group nhận bản sao của message, đảm bảo mỗi domain xử lý nghiệp vụ riêng.

# references
## 0
### alias
NestJS Kafka Microservice
### url
https://docs.nestjs.com/microservices/kafka
## 1
### alias
Apache Kafka Documentation
### url
https://kafka.apache.org/documentation/
## 2
### alias
KafkaJS Documentation
### url
https://kafka.js.org/docs/getting-started

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge, bao gồm Payment Service (Producer), Shipping Service và Notification Service (Consumers), và docker-compose.yml.
### score
20
### prompts
#### 0
##### title
Producer và Kafka topic
##### score
7
##### promptText
Payment Service emit sự kiện `PAYMENT_COMPLETED` lên Kafka topic `payment-events` với đầy đủ payload (`orderId`, `amount`, `paidAt`). Kafka chạy đúng trong Docker Compose.
#### 1
##### title
2 Consumer Groups độc lập
##### score
7
##### promptText
Shipping Service (`shipping-group`) và Notification Service (`notification-group`) dùng 2 Consumer Group khác nhau, cả hai đều nhận và xử lý sự kiện từ cùng topic.
#### 2
##### title
Broadcasting hoạt động đúng
##### score
6
##### promptText
Mỗi sự kiện `PAYMENT_COMPLETED` được cả 2 consumer nhận và xử lý độc lập. Log chứng minh cả 2 service xử lý cùng sự kiện.

# difficulty
easy

# score
20
