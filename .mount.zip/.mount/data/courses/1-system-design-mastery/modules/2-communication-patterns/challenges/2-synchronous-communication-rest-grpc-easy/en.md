# title
Hybrid REST Gateway and gRPC Backend Service

# description
Build a Hybrid system with a REST API Gateway (NestJS) as the entry point for clients, which calls a gRPC backend service (Inventory Service) behind the scenes. Demonstrate the conversion flow from REST to gRPC and back.

# requirements
Create 2 NestJS applications: `ApiGateway` (REST, port 3000) and `InventoryService` (gRPC, port 5000). Define an `inventory.proto` file with service `InventoryService` containing 2 RPCs: `GetItem` (accepts `ItemRequest { id }`, returns `ItemResponse { id, name, quantity }`) and `ListItems` (accepts `Empty`, returns `ItemListResponse { items[] }`). The Gateway receives REST requests and calls gRPC to InventoryService, returning results to the client as JSON.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Packages `@grpc/grpc-js` and `@grpc/proto-loader`
- Package `@nestjs/microservices`
- Basic knowledge of Protocol Buffers

# steps

## 0
### title
Define the Protocol Buffers file
### body
- **Steps to follow:**
  - Step 1: Create a `proto` directory at the project root.
  - Step 2: Create the file `proto/inventory.proto`:
    ```protobuf
    syntax = "proto3";
    package inventory;

    service InventoryService {
      rpc GetItem (ItemRequest) returns (ItemResponse);
      rpc ListItems (Empty) returns (ItemListResponse);
    }

    message Empty {}

    message ItemRequest {
      int32 id = 1;
    }

    message ItemResponse {
      int32 id = 1;
      string name = 2;
      int32 quantity = 3;
    }

    message ItemListResponse {
      repeated ItemResponse items = 1;
    }
    ```
- **Expected result:** The `.proto` file correctly defines protobuf syntax with 2 RPC methods and message types.
- **Conclusion:** The communication contract between Gateway and Inventory Service has been established.

## 1
### title
Build the Inventory gRPC Service
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for Inventory Service:
    ```bash
    nest new inventory-service
    ```
  - Step 2: Install dependencies:
    ```bash
    npm install @nestjs/microservices @grpc/grpc-js @grpc/proto-loader
    ```
  - Step 3: Configure `main.ts` to initialize a gRPC microservice on port 5000, pointing to the `inventory.proto` file.
  - Step 4: Create `InventoryController` implementing methods `getItem` and `listItems` with decorators `@GrpcMethod('InventoryService', 'GetItem')` and `@GrpcMethod('InventoryService', 'ListItems')`.
  - Step 5: Create sample data in the service (at least 3 items with `id`, `name`, `quantity`).
- **Expected result:** Inventory Service starts and listens for gRPC requests on port 5000.
- **Conclusion:** The gRPC backend service is ready to receive requests from the Gateway.

## 2
### title
Build the REST API Gateway
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for the API Gateway:
    ```bash
    nest new api-gateway
    ```
  - Step 2: Install dependencies:
    ```bash
    npm install @nestjs/microservices @grpc/grpc-js @grpc/proto-loader
    ```
  - Step 3: Create `InventoryModule` in the Gateway, register the gRPC client pointing to `localhost:5000` and the `inventory.proto` file.
  - Step 4: Create `InventoryController` in the Gateway with 2 REST endpoints:
    - `GET /inventory` calls `ListItems` via gRPC and returns JSON.
    - `GET /inventory/:id` calls `GetItem` via gRPC and returns JSON.
  - Step 5: Inject the gRPC client service and use `this.inventoryService.getService()` to call RPC methods.
- **Expected result:** The Gateway starts on port 3000, receives REST requests, and converts them to gRPC calls.
- **Conclusion:** The REST -> gRPC -> Response conversion flow has been established.

## 3
### title
Test the Hybrid flow
### body
- **Steps to follow:**
  - Step 1: Start Inventory Service (gRPC):
    ```bash
    cd inventory-service && npm run start:dev
    ```
  - Step 2: Start the API Gateway (REST):
    ```bash
    cd api-gateway && npm run start:dev
    ```
  - Step 3: Call the endpoint to list all items:
    ```bash
    curl http://localhost:3000/inventory
    ```
  - Step 4: Call the endpoint to get an item by id:
    ```bash
    curl http://localhost:3000/inventory/1
    ```
  - Step 5: Call the endpoint with a non-existent id to test error handling:
    ```bash
    curl http://localhost:3000/inventory/999
    ```
- **Expected result:**
  - `GET /inventory` returns an array of items as JSON.
  - `GET /inventory/1` returns the item with id = 1 as JSON.
  - `GET /inventory/999` returns a 404 or not found message.
- **Conclusion:** The Hybrid REST-gRPC system works correctly, the Gateway successfully converts between the two protocols.

# references
## 0
### alias
NestJS gRPC Microservice
### url
https://docs.nestjs.com/microservices/grpc
## 1
### alias
Protocol Buffers Language Guide
### url
https://protobuf.dev/programming-guides/proto3/
## 2
### alias
gRPC Official Documentation
### url
https://grpc.io/docs/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code, including the API Gateway (REST), Inventory Service (gRPC), and the .proto file.
### score
20
### prompts
#### 0
##### title
Proto file and gRPC Service
##### score
7
##### promptText
The `inventory.proto` file correctly defines 2 RPC methods (`GetItem`, `ListItems`). Inventory Service implements the methods correctly with `@GrpcMethod` decorators.
#### 1
##### title
REST Gateway calls gRPC correctly
##### score
7
##### promptText
The API Gateway registers a gRPC client, 2 REST endpoints (`GET /inventory`, `GET /inventory/:id`) successfully call the gRPC service and return JSON results.
#### 2
##### title
End-to-end flow works
##### score
6
##### promptText
Client calls REST to Gateway, Gateway calls gRPC to Inventory Service, results are returned correctly as JSON. Handles the case where an item does not exist.

# difficulty
easy

# score
20
