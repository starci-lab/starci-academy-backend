# title
Redis Pub/Sub cơ bản với NestJS

# description
Xây dựng hệ thống Pub/Sub với Redis trong NestJS: User Service (Publisher) phát sự kiện `USER_REGISTERED` lên một Redis channel, 2 Subscriber (Welcome Email Service và Activity Log Service) nhận và xử lý sự kiện đó. Chứng minh mô hình fire-and-forget của Redis Pub/Sub.

# requirements
Tạo 3 NestJS application: `UserService` (Publisher, cổng 3001) có endpoint `POST /users/register` phát sự kiện `USER_REGISTERED` lên Redis channel `user-events`, `WelcomeEmailService` (Subscriber) lắng nghe channel và log gửi email chào mừng, `ActivityLogService` (Subscriber) lắng nghe channel và log ghi nhận hoạt động. Sử dụng Docker Compose để chạy Redis cùng các service. Chứng minh tính chất fire-and-forget: nếu subscriber offline, message sẽ bị mất.

# prerequisites
- Docker và Docker Compose
- Node.js >= 18
- NestJS CLI
- Package `ioredis`
- Kiến thức cơ bản về Redis và Pub/Sub pattern

# steps

## 0
### title
Thiết lập Redis bằng Docker Compose
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `docker-compose.yml` với Redis:
    ```yaml
    services:
      redis:
        image: redis:7-alpine
        ports:
          - "6379:6379"
    ```
  - Bước 2: Chạy Redis:
    ```bash
    docker-compose up -d redis
    ```
- **Kết quả mong đợi:** Redis server khởi động thành công trên cổng 6379.
- **Kết luận:** Hạ tầng Pub/Sub đã sẵn sàng.

## 1
### title
Xây dựng User Service (Publisher)
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS:
    ```bash
    nest new user-service
    ```
  - Bước 2: Cài đặt Redis client:
    ```bash
    npm install ioredis
    ```
  - Bước 3: Tạo `RedisModule` đăng ký Redis client (kết nối `redis:6379`) và export để các module khác dùng.
  - Bước 4: Tạo `UserController` với endpoint `POST /users/register` nhận body `{ name, email }`.
  - Bước 5: Trong handler, sau khi xử lý đăng ký (giả lập), publish message lên Redis channel `user-events`:
    ```typescript
    this.redisClient.publish('user-events', JSON.stringify({
      event: 'USER_REGISTERED',
      data: { name, email, registeredAt: new Date().toISOString() }
    }));
    ```
- **Kết quả mong đợi:** Mỗi khi gọi `POST /users/register`, một message được publish lên Redis channel `user-events`.
- **Kết luận:** Publisher đã sẵn sàng phát sự kiện theo mô hình fire-and-forget.

## 2
### title
Xây dựng Welcome Email Service (Subscriber 1)
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho Welcome Email Service.
  - Bước 2: Cài đặt `ioredis` và tạo Redis subscriber client.
  - Bước 3: Trong `OnModuleInit`, subscribe vào channel `user-events`:
    ```typescript
    this.subscriber.subscribe('user-events');
    this.subscriber.on('message', (channel, message) => {
      const parsed = JSON.parse(message);
      if (parsed.event === 'USER_REGISTERED') {
        console.log(`[Welcome Email] Sending welcome email to ${parsed.data.email}`);
      }
    });
    ```
- **Kết quả mong đợi:** Welcome Email Service tự động nhận và log thông báo gửi email khi có sự kiện `USER_REGISTERED`.
- **Kết luận:** Subscriber 1 đã hoạt động và lắng nghe đúng channel.

## 3
### title
Xây dựng Activity Log Service (Subscriber 2)
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho Activity Log Service.
  - Bước 2: Cài đặt `ioredis` và tạo Redis subscriber client.
  - Bước 3: Trong `OnModuleInit`, subscribe vào channel `user-events` và xử lý:
    ```typescript
    this.subscriber.on('message', (channel, message) => {
      const parsed = JSON.parse(message);
      if (parsed.event === 'USER_REGISTERED') {
        console.log(`[Activity Log] New user registered: ${parsed.data.name} at ${parsed.data.registeredAt}`);
      }
    });
    ```
- **Kết quả mong đợi:** Activity Log Service tự động nhận và log thông tin hoạt động khi có sự kiện.
- **Kết luận:** Subscriber 2 hoạt động độc lập với Subscriber 1, cả hai đều nhận cùng message.

## 4
### title
Chứng minh fire-and-forget và kiểm thử
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy toàn bộ hệ thống (Redis + 3 service):
    ```bash
    docker-compose up --build
    ```
  - Bước 2: Gửi request đăng ký user:
    ```bash
    curl -X POST http://localhost:3001/users/register -H "Content-Type: application/json" -d '{"name":"Minh","email":"minh@example.com"}'
    ```
  - Bước 3: Kiểm tra log của Welcome Email Service và Activity Log Service: cả hai phải nhận được sự kiện.
  - Bước 4: Dừng Activity Log Service (docker-compose stop activity-log-service).
  - Bước 5: Gửi thêm 1 request đăng ký:
    ```bash
    curl -X POST http://localhost:3001/users/register -H "Content-Type: application/json" -d '{"name":"Lan","email":"lan@example.com"}'
    ```
  - Bước 6: Khởi động lại Activity Log Service và kiểm tra log: message gửi trong lúc offline sẽ KHÔNG được nhận lại.
- **Kết quả mong đợi:**
  - Khi cả 2 subscriber online: cả hai nhận được sự kiện.
  - Khi Activity Log offline: chỉ Welcome Email nhận, Activity Log mất message.
  - Khi Activity Log bật lại: KHÔNG nhận được message đã mất (fire-and-forget).
- **Kết luận:** Redis Pub/Sub là fire-and-forget: message chỉ được gửi đến subscriber đang online tại thời điểm publish, không lưu trữ persistent như Kafka.

# references
## 0
### alias
Redis Pub/Sub Documentation
### url
https://redis.io/docs/interact/pubsub/
## 1
### alias
ioredis GitHub
### url
https://github.com/redis/ioredis
## 2
### alias
NestJS Custom Transporters
### url
https://docs.nestjs.com/microservices/custom-transport

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge, bao gồm User Service (Publisher), Welcome Email Service và Activity Log Service (Subscribers), và docker-compose.yml.
### score
20
### prompts
#### 0
##### title
Publisher và Redis channel
##### score
7
##### promptText
User Service publish sự kiện `USER_REGISTERED` lên Redis channel `user-events` với đầy đủ payload (`name`, `email`, `registeredAt`). Redis chạy đúng trong Docker Compose.
#### 1
##### title
2 Subscriber hoạt động
##### score
7
##### promptText
Welcome Email Service và Activity Log Service subscribe vào cùng channel `user-events`, cả hai đều nhận và xử lý sự kiện khi online.
#### 2
##### title
Chứng minh fire-and-forget
##### score
6
##### promptText
Khi một subscriber offline, message gửi trong thời gian đó bị mất. Subscriber bật lại không nhận được message cũ. Chứng minh rõ sự khác biệt với message queue.

# difficulty
easy

# score
20
