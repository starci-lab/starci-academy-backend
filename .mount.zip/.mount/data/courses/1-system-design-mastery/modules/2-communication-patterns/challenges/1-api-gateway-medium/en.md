# title
Advanced API Gateway with Kong Plugins (Rate Limiting and JWT)

# description
Build 3 NestJS microservices (User, Product, Order) routed through Kong API Gateway (DB-less mode), configure **Rate Limiting** plugin to limit requests and **JWT Authentication** plugin to protect sensitive routes. Everything runs via Docker Compose.

# requirements
Create 3 NestJS microservices: `UserService` (endpoints `GET /users`, `GET /users/:id`), `ProductService` (endpoints `GET /products`, `GET /products/:id`), `OrderService` (endpoints `POST /orders`, `GET /orders`). Configure Kong (DB-less) with a `kong.yml` file: route 3 services, apply `rate-limiting` plugin (limit 5 requests/minute) on the Product route, and `jwt` plugin on the Order route. Create JWT credentials in kong.yml for authentication testing.

# prerequisites
- Docker and Docker Compose
- Node.js >= 18
- NestJS CLI
- Basic knowledge of API Gateway and JWT

# steps

## 0
### title
Initialize 3 NestJS microservices
### body
- **Steps to follow:**
  - Step 1: Create 3 NestJS projects:
    ```bash
    nest new user-service
    nest new product-service
    nest new order-service
    ```
  - Step 2: In `user-service`, create `UserController` with endpoint `GET /users` returning a mock user array and `GET /users/:id` returning a user by id.
  - Step 3: In `product-service`, create `ProductController` with endpoint `GET /products` returning a product array and `GET /products/:id` returning a product by id.
  - Step 4: In `order-service`, create `OrderController` with endpoint `POST /orders` accepting body `{ productId, quantity, userId }` returning the created order, and `GET /orders` returning the order list.
  - Step 5: Configure each service to run on a separate port (3001, 3002, 3003).
- **Expected result:** Each service runs independently and endpoints return correct data when tested directly.
- **Conclusion:** All three microservices are ready for Kong integration.

## 1
### title
Create Dockerfiles and docker-compose.yml
### body
- **Steps to follow:**
  - Step 1: Create a `Dockerfile` for each service with base image `node:18-alpine`, install dependencies, build, and expose the corresponding port.
  - Step 2: Create `docker-compose.yml` with 4 services: `user-service`, `product-service`, `order-service`, and `kong` (image `kong:3.4`).
  - Step 3: Configure Kong in docker-compose: `KONG_DATABASE=off`, `KONG_DECLARATIVE_CONFIG=/etc/kong/kong.yml`, expose port `8000:8000`.
- **Expected result:** Docker Compose builds and runs 4 containers.
- **Conclusion:** Container infrastructure is ready, next step is configuring routing and plugins on Kong.

## 2
### title
Configure Kong with routing and Rate Limiting plugin
### body
- **Steps to follow:**
  - Step 1: Create `kong.yml` defining 3 services (user-service, product-service, order-service) with corresponding routes (`/users`, `/products`, `/orders`).
  - Step 2: Add the `rate-limiting` plugin to `product-service`:
    ```yaml
    plugins:
      - name: rate-limiting
        config:
          minute: 5
          policy: local
    ```
  - Step 3: Run the system and test rate limiting by calling `GET /products` more than 5 times consecutively within 1 minute.
- **Expected result:** The first 5 requests return 200, from the 6th request Kong returns 429 Too Many Requests.
- **Conclusion:** The Rate Limiting plugin works correctly, protecting the service from overload.

## 3
### title
Configure JWT Authentication plugin for Order route
### body
- **Steps to follow:**
  - Step 1: In `kong.yml`, create a consumer and JWT credential:
    ```yaml
    consumers:
      - username: app-user
        jwt_secrets:
          - key: my-jwt-key
            secret: my-jwt-secret
            algorithm: HS256
    ```
  - Step 2: Add the `jwt` plugin to `order-service`:
    ```yaml
    plugins:
      - name: jwt
    ```
  - Step 3: Generate a valid JWT token (using the `jsonwebtoken` library or jwt.io) with payload containing `iss: "my-jwt-key"`, signed with secret `my-jwt-secret`.
  - Step 4: Call `POST /orders` without a token to confirm 401 response. Call again with `Authorization: Bearer <token>` header to confirm 201 response.
- **Expected result:** Requests without JWT are blocked by Kong with 401. Requests with valid JWT are forwarded to Order Service normally.
- **Conclusion:** The JWT plugin protects sensitive routes, only allowing authenticated requests.

## 4
### title
Test the entire system
### body
- **Steps to follow:**
  - Step 1: Run the system:
    ```bash
    docker-compose up --build
    ```
  - Step 2: Test User Service (no plugin):
    ```bash
    curl http://localhost:8000/users
    ```
  - Step 3: Test Rate Limiting on Product Service (call 6 times consecutively):
    ```bash
    for i in $(seq 1 6); do curl -s -o /dev/null -w "%{http_code}\n" http://localhost:8000/products; done
    ```
  - Step 4: Test JWT on Order Service:
    ```bash
    curl -X POST http://localhost:8000/orders -H "Content-Type: application/json" -d '{"productId":1,"quantity":2,"userId":1}'
    curl -X POST http://localhost:8000/orders -H "Content-Type: application/json" -H "Authorization: Bearer <valid-token>" -d '{"productId":1,"quantity":2,"userId":1}'
    ```
- **Expected result:**
  - `GET /users` returns user list (200).
  - `GET /products` returns 200 for the first 5 requests, 429 for the 6th.
  - `POST /orders` without token returns 401, with valid token returns 201.
- **Conclusion:** The API Gateway system with 3 microservices, Rate Limiting, and JWT Authentication works correctly.

# references
## 0
### alias
Kong Rate Limiting Plugin
### url
https://docs.konghq.com/hub/kong-inc/rate-limiting/
## 1
### alias
Kong JWT Plugin
### url
https://docs.konghq.com/hub/kong-inc/jwt/
## 2
### alias
Kong DB-less Declarative Config
### url
https://docs.konghq.com/gateway/latest/production/deployment-topologies/db-less-and-declarative-config/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code, including 3 NestJS services, Dockerfiles, kong.yml with plugin config, and docker-compose.yml.
### score
30
### prompts
#### 0
##### title
3 microservice structure and Docker
##### score
10
##### promptText
There are 3 separate NestJS services (User, Product, Order) with valid Dockerfiles. `docker-compose.yml` runs the entire system with 4 containers.
#### 1
##### title
Rate Limiting plugin works
##### score
10
##### promptText
The `kong.yml` configures `rate-limiting` for the Product route, limiting to 5 requests/minute. The 6th request within 1 minute returns 429.
#### 2
##### title
JWT Authentication plugin works
##### score
10
##### promptText
The `kong.yml` configures `jwt` plugin for the Order route. Consumer and JWT credentials are declared. Requests without a token return 401, requests with a valid token are processed normally.

# difficulty
medium

# score
30
