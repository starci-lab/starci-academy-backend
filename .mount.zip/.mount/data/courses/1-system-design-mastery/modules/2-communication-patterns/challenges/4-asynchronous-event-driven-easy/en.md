# title
Basic Event-Driven with Kafka: Producer and Consumer Groups

# description
Build an event-driven system with Apache Kafka in NestJS: Payment Service (Producer) emits a `PAYMENT_COMPLETED` event, 2 Consumers (Shipping Service and Notification Service) process that event. Demonstrate broadcasting via different Consumer Groups.

# requirements
Create 3 NestJS applications: `PaymentService` (Producer, port 3001) with endpoint `POST /payments` emitting a `PAYMENT_COMPLETED` event to a Kafka topic, `ShippingService` (Consumer, Consumer Group `shipping-group`) that listens and logs shipping information, `NotificationService` (Consumer, Consumer Group `notification-group`) that listens and logs notifications. Use Docker Compose to run Kafka (KRaft mode) along with the services. Demonstrate that both consumers receive the same event (broadcasting).

# prerequisites
- Docker and Docker Compose
- Node.js >= 18
- NestJS CLI
- Packages `@nestjs/microservices` and `kafkajs`
- Basic knowledge of Message Queue and Event-Driven Architecture

# steps

## 0
### title
Set up Kafka with Docker Compose
### body
- **Steps to follow:**
  - Step 1: Create `docker-compose.yml` with Kafka running in KRaft mode (no Zookeeper needed):
    ```yaml
    services:
      kafka:
        image: bitnami/kafka:3.6
        environment:
          - KAFKA_CFG_NODE_ID=1
          - KAFKA_CFG_PROCESS_ROLES=broker,controller
          - KAFKA_CFG_CONTROLLER_QUORUM_VOTERS=1@kafka:9093
          - KAFKA_CFG_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093
          - KAFKA_CFG_ADVERTISED_LISTENERS=PLAINTEXT://kafka:9092
          - KAFKA_CFG_CONTROLLER_LISTENER_NAMES=CONTROLLER
          - KAFKA_CFG_LISTENER_SECURITY_PROTOCOL_MAP=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
        ports:
          - "9092:9092"
    ```
  - Step 2: Start Kafka:
    ```bash
    docker-compose up -d kafka
    ```
- **Expected result:** Kafka broker starts successfully on port 9092.
- **Conclusion:** The messaging infrastructure is ready for services to connect.

## 1
### title
Build the Payment Service (Producer)
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project:
    ```bash
    nest new payment-service
    ```
  - Step 2: Install dependencies:
    ```bash
    npm install @nestjs/microservices kafkajs
    ```
  - Step 3: Register a Kafka client in the module using `ClientsModule.register()`, configure broker `kafka:9092`.
  - Step 4: Create `PaymentController` with endpoint `POST /payments` accepting body `{ orderId, amount, method }`.
  - Step 5: In the handler, after processing payment logic (mock), emit an event to topic `payment-events` with key `PAYMENT_COMPLETED` and payload `{ orderId, amount, paidAt }`.
- **Expected result:** Each time `POST /payments` is called, a message is sent to the Kafka topic `payment-events`.
- **Conclusion:** The Producer is ready to emit events for consumers to process.

## 2
### title
Build the Shipping Service (Consumer Group 1)
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for Shipping Service.
  - Step 2: Configure `main.ts` to connect a Kafka consumer with `groupId: 'shipping-group'`.
  - Step 3: Create a handler listening to topic `payment-events` with the `@EventPattern('PAYMENT_COMPLETED')` or `@MessagePattern` decorator.
  - Step 4: In the handler, log shipping information: `[Shipping] Processing shipment for order ${orderId}`.
- **Expected result:** Shipping Service automatically receives and processes `PAYMENT_COMPLETED` events when new messages appear on the topic.
- **Conclusion:** Consumer group `shipping-group` is operating independently.

## 3
### title
Build the Notification Service (Consumer Group 2)
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for Notification Service.
  - Step 2: Configure `main.ts` to connect a Kafka consumer with `groupId: 'notification-group'`.
  - Step 3: Create a handler listening to topic `payment-events` with the `@EventPattern('PAYMENT_COMPLETED')` decorator.
  - Step 4: In the handler, log the notification: `[Notification] Sending payment confirmation for order ${orderId}, amount: ${amount}`.
- **Expected result:** Notification Service automatically receives and processes the same `PAYMENT_COMPLETED` event.
- **Conclusion:** Consumer group `notification-group` operates independently from `shipping-group`, both receive the event (broadcasting).

## 4
### title
Test broadcasting and Consumer Groups
### body
- **Steps to follow:**
  - Step 1: Run the entire system (Kafka + 3 services):
    ```bash
    docker-compose up --build
    ```
  - Step 2: Send a payment request:
    ```bash
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":101,"amount":250000,"method":"credit_card"}'
    ```
  - Step 3: Check the Shipping Service log: should contain `[Shipping] Processing shipment for order 101`.
  - Step 4: Check the Notification Service log: should contain `[Notification] Sending payment confirmation for order 101`.
  - Step 5: Send 2-3 more requests to confirm every event is processed by both consumers.
- **Expected result:**
  - Every `PAYMENT_COMPLETED` event is received and processed by both Shipping Service and Notification Service.
  - Logs from both services display independently, proving different Consumer Groups each receive the message.
- **Conclusion:** The broadcasting mechanism via Consumer Groups in Kafka works correctly: each group receives a copy of the message, ensuring each domain processes its own business logic.

# references
## 0
### alias
NestJS Kafka Microservice
### url
https://docs.nestjs.com/microservices/kafka
## 1
### alias
Apache Kafka Documentation
### url
https://kafka.apache.org/documentation/
## 2
### alias
KafkaJS Documentation
### url
https://kafka.js.org/docs/getting-started

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code, including Payment Service (Producer), Shipping Service and Notification Service (Consumers), and docker-compose.yml.
### score
20
### prompts
#### 0
##### title
Producer and Kafka topic
##### score
7
##### promptText
Payment Service emits a `PAYMENT_COMPLETED` event to Kafka topic `payment-events` with complete payload (`orderId`, `amount`, `paidAt`). Kafka runs correctly in Docker Compose.
#### 1
##### title
2 independent Consumer Groups
##### score
7
##### promptText
Shipping Service (`shipping-group`) and Notification Service (`notification-group`) use 2 different Consumer Groups, both receive and process events from the same topic.
#### 2
##### title
Broadcasting works correctly
##### score
6
##### promptText
Every `PAYMENT_COMPLETED` event is received and processed independently by both consumers. Logs prove both services process the same event.

# difficulty
easy

# score
20
