# title
Event-Driven nâng cao: Dead Letter Queue, Retry và Consumer Recovery

# description
Mở rộng hệ thống event-driven với Kafka để xử lý các kịch bản thất bại: implement cơ chế Dead Letter Queue (DLQ) khi consumer xử lý lỗi, chứng minh khả năng phục hồi của consumer khi offline (Kafka persistent log), và thêm retry logic cơ bản trước khi gửi message vào DLQ.

# requirements
Xây dựng hệ thống NestJS với Kafka gồm: `PaymentService` (Producer) phát sự kiện `PAYMENT_COMPLETED`, `FulfillmentService` (Consumer) xử lý sự kiện với retry logic (tối đa 3 lần), nếu thất bại gửi message vào topic DLQ `payment-events-dlq`. Thêm `DlqMonitorService` đọc và log các message từ DLQ. Chứng minh Kafka persistent log bằng cách tắt consumer, gửi event, bật lại consumer và xác nhận consumer vẫn nhận được message đã bỏ lỡ.

# prerequisites
- Docker và Docker Compose
- Node.js >= 18
- NestJS CLI
- Package `@nestjs/microservices` và `kafkajs`
- Hoàn thành challenge `asynchronous-event-driven-easy`
- Kiến thức về error handling và retry pattern

# steps

## 0
### title
Thiết lập Kafka và cấu trúc project
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `docker-compose.yml` với Kafka (KRaft mode), cấu hình tương tự challenge easy.
  - Bước 2: Tạo 3 NestJS project: `payment-service`, `fulfillment-service`, `dlq-monitor-service`.
  - Bước 3: Cài đặt dependencies cho tất cả project:
    ```bash
    npm install @nestjs/microservices kafkajs
    ```
  - Bước 4: Cấu hình Kafka client cho Payment Service (Producer) và Kafka consumer cho Fulfillment Service với `groupId: 'fulfillment-group'`.
- **Kết quả mong đợi:** 3 project NestJS đã được khởi tạo với dependencies đúng, Kafka chạy trong Docker.
- **Kết luận:** Hạ tầng đã sẵn sàng để implement các cơ chế xử lý lỗi nâng cao.

## 1
### title
Implement Payment Service với Producer
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `PaymentController` với endpoint `POST /payments` nhận body `{ orderId, amount, shouldFail }`.
  - Bước 2: Trường `shouldFail` (boolean) được gửi kèm trong payload để giả lập kịch bản consumer thất bại.
  - Bước 3: Emit sự kiện `PAYMENT_COMPLETED` lên topic `payment-events` với payload `{ orderId, amount, shouldFail, paidAt }`.
- **Kết quả mong đợi:** Producer gửi message lên Kafka với flag `shouldFail` để điều khiển hành vi consumer.
- **Kết luận:** Producer đã hỗ trợ giả lập cả thành công và thất bại.

## 2
### title
Implement Fulfillment Service với Retry và DLQ
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo handler lắng nghe topic `payment-events` với `@EventPattern('PAYMENT_COMPLETED')`.
  - Bước 2: Implement retry logic: khi nhận message, kiểm tra `shouldFail`. Nếu `true`, tăng `retryCount` và thử lại (tối đa 3 lần).
  - Bước 3: Lưu `retryCount` trong metadata hoặc trong payload (thêm trường `retryCount` khi re-emit).
  - Bước 4: Sau 3 lần thất bại, gửi message gốc vào topic DLQ `payment-events-dlq` kèm thông tin lỗi:
    ```json
    {
      "originalPayload": { "orderId": 101, "amount": 250000 },
      "error": "Processing failed after 3 retries",
      "failedAt": "2024-01-01T00:00:00Z",
      "retryCount": 3
    }
    ```
  - Bước 5: Nếu xử lý thành công (shouldFail = false), log: `[Fulfillment] Order ${orderId} fulfilled successfully`.
- **Kết quả mong đợi:** Message thành công được xử lý bình thường, message thất bại được retry 3 lần rồi chuyển vào DLQ.
- **Kết luận:** Cơ chế retry và DLQ đảm bảo không mất message và cách ly được lỗi.

## 3
### title
Implement DLQ Monitor Service
### body
- **Các bước thực hiện:**
  - Bước 1: Cấu hình DLQ Monitor Service lắng nghe topic `payment-events-dlq` với `groupId: 'dlq-monitor-group'`.
  - Bước 2: Tạo handler đọc message từ DLQ và log chi tiết: `[DLQ Monitor] Failed message - orderId: ${orderId}, error: ${error}, retryCount: ${retryCount}`.
  - Bước 3: (Tuỳ chọn) Lưu message DLQ vào mảng in-memory và expose endpoint `GET /dlq/messages` để kiểm tra.
- **Kết quả mong đợi:** DLQ Monitor nhận và log mỗi message thất bại từ DLQ topic.
- **Kết luận:** DLQ Monitor cho phép giám sát và xử lý thủ công các message thất bại.

## 4
### title
Chứng minh Kafka Persistent Log và Consumer Recovery
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy hệ thống chỉ với Kafka và Payment Service (không chạy Fulfillment Service).
  - Bước 2: Gửi 3 payment request:
    ```bash
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":201,"amount":100000,"shouldFail":false}'
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":202,"amount":200000,"shouldFail":false}'
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":203,"amount":300000,"shouldFail":false}'
    ```
  - Bước 3: Khởi động Fulfillment Service:
    ```bash
    docker-compose up fulfillment-service
    ```
  - Bước 4: Kiểm tra log của Fulfillment Service: phải xử lý được cả 3 message đã gửi trước đó.
- **Kết quả mong đợi:** Fulfillment Service khi bật lại vẫn nhận được 3 message đã gửi trong lúc nó offline, chứng minh Kafka lưu trữ message persistent.
- **Kết luận:** Kafka persistent log đảm bảo consumer không mất message khi offline, khác với mô hình fire-and-forget.

## 5
### title
Kiểm thử toàn bộ luồng retry và DLQ
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy toàn bộ hệ thống:
    ```bash
    docker-compose up --build
    ```
  - Bước 2: Gửi request thành công:
    ```bash
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":301,"amount":500000,"shouldFail":false}'
    ```
    Kiểm tra Fulfillment log: `Order 301 fulfilled successfully`.
  - Bước 3: Gửi request thất bại:
    ```bash
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":302,"amount":100000,"shouldFail":true}'
    ```
    Kiểm tra Fulfillment log: 3 lần retry.
    Kiểm tra DLQ Monitor log: nhận message thất bại của order 302.
- **Kết quả mong đợi:**
  - Message thành công được xử lý ngay.
  - Message thất bại được retry 3 lần, sau đó chuyển vào DLQ.
  - DLQ Monitor nhận và log chi tiết message thất bại.
- **Kết luận:** Hệ thống event-driven nâng cao đã xử lý được các kịch bản lỗi một cách có hệ thống: retry -> DLQ -> monitoring.

# references
## 0
### alias
NestJS Kafka Microservice
### url
https://docs.nestjs.com/microservices/kafka
## 1
### alias
Kafka Consumer Group Recovery
### url
https://kafka.apache.org/documentation/#consumerconfigs
## 2
### alias
Dead Letter Queue Pattern
### url
https://learn.microsoft.com/en-us/azure/architecture/patterns/dead-letter-queue

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge, bao gồm Payment Service, Fulfillment Service (với retry + DLQ), DLQ Monitor Service, và docker-compose.yml.
### score
30
### prompts
#### 0
##### title
Retry logic hoạt động
##### score
10
##### promptText
Fulfillment Service implement retry logic tối đa 3 lần khi xử lý thất bại. Log cho thấy retry count tăng dần. Message thành công được xử lý bình thường.
#### 1
##### title
Dead Letter Queue hoạt động
##### score
10
##### promptText
Sau 3 lần retry thất bại, message được gửi vào topic `payment-events-dlq` với đầy đủ thông tin lỗi. DLQ Monitor Service nhận và log message từ DLQ.
#### 2
##### title
Consumer Recovery từ Kafka Persistent Log
##### score
10
##### promptText
Chứng minh được Fulfillment Service khi offline và bật lại vẫn nhận được message đã gửi trong thời gian offline. Kafka persistent log hoạt động đúng.

# difficulty
medium

# score
30
