# title
Kết hợp Redis Pub/Sub và Kafka: Chọn đúng pattern cho đúng kịch bản

# description
Xây dựng hệ thống kết hợp Redis Pub/Sub cho thông báo real-time và Kafka cho sự kiện quan trọng cần đảm bảo delivery. Chứng minh khi nào nên dùng từng pattern bằng các kịch bản cụ thể: Redis Pub/Sub cho notification tức thời (chấp nhận mất), Kafka cho sự kiện nghiệp vụ quan trọng (không được mất).

# requirements
Tạo hệ thống NestJS với 4 service: `OrderService` (phát sự kiện qua cả Kafka và Redis), `InventoryService` (Kafka consumer - xử lý trừ kho, sự kiện quan trọng), `AnalyticsService` (Kafka consumer - ghi nhận thống kê, sự kiện quan trọng), `DashboardNotifier` (Redis subscriber - cập nhật dashboard real-time, chấp nhận mất). Sử dụng Docker Compose chạy cả Redis và Kafka. Viết tài liệu giải thích lý do chọn pattern cho từng kịch bản.

# prerequisites
- Docker và Docker Compose
- Node.js >= 18
- NestJS CLI
- Package `@nestjs/microservices`, `kafkajs`, `ioredis`
- Hoàn thành challenge `publish-subscribe-pattern-easy` và `asynchronous-event-driven-easy`
- Hiểu sự khác biệt giữa Pub/Sub và Message Queue

# steps

## 0
### title
Thiết lập Kafka và Redis bằng Docker Compose
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `docker-compose.yml` với cả Kafka (KRaft mode) và Redis:
    ```yaml
    services:
      kafka:
        image: bitnami/kafka:3.6
        environment:
          - KAFKA_CFG_NODE_ID=1
          - KAFKA_CFG_PROCESS_ROLES=broker,controller
          - KAFKA_CFG_CONTROLLER_QUORUM_VOTERS=1@kafka:9093
          - KAFKA_CFG_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093
          - KAFKA_CFG_ADVERTISED_LISTENERS=PLAINTEXT://kafka:9092
          - KAFKA_CFG_CONTROLLER_LISTENER_NAMES=CONTROLLER
          - KAFKA_CFG_LISTENER_SECURITY_PROTOCOL_MAP=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
        ports:
          - "9092:9092"
      redis:
        image: redis:7-alpine
        ports:
          - "6379:6379"
    ```
  - Bước 2: Chạy hạ tầng:
    ```bash
    docker-compose up -d kafka redis
    ```
- **Kết quả mong đợi:** Kafka và Redis đều khởi động thành công.
- **Kết luận:** Hạ tầng messaging kép đã sẵn sàng cho cả 2 pattern.

## 1
### title
Xây dựng Order Service (Dual Publisher)
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho Order Service.
  - Bước 2: Cài đặt dependencies:
    ```bash
    npm install @nestjs/microservices kafkajs ioredis
    ```
  - Bước 3: Đăng ký cả Kafka client và Redis client trong module.
  - Bước 4: Tạo `OrderController` với endpoint `POST /orders` nhận body `{ productId, quantity, customerName }`.
  - Bước 5: Trong handler, khi tạo đơn hàng thành công:
    - Gửi sự kiện `ORDER_CREATED` lên **Kafka** topic `order-events` (sự kiện quan trọng, cần đảm bảo delivery):
      ```typescript
      this.kafkaClient.emit('ORDER_CREATED', { orderId, productId, quantity, customerName, createdAt });
      ```
    - Gửi thông báo lên **Redis** channel `order-notifications` (thông báo real-time, fire-and-forget):
      ```typescript
      this.redisClient.publish('order-notifications', JSON.stringify({ type: 'NEW_ORDER', orderId, customerName }));
      ```
- **Kết quả mong đợi:** Mỗi khi tạo đơn hàng, sự kiện được gửi đồng thời lên Kafka (persistent) và Redis (real-time).
- **Kết luận:** Order Service sử dụng đúng pattern cho đúng mục đích: Kafka cho dữ liệu quan trọng, Redis cho thông báo tức thời.

## 2
### title
Xây dựng Inventory Service (Kafka Consumer - sự kiện quan trọng)
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho Inventory Service.
  - Bước 2: Cấu hình Kafka consumer với `groupId: 'inventory-group'`.
  - Bước 3: Tạo handler lắng nghe topic `order-events` với `@EventPattern('ORDER_CREATED')`.
  - Bước 4: Trong handler, xử lý trừ kho: `[Inventory] Reducing stock for product ${productId} by ${quantity}`.
  - Bước 5: Lưu trạng thái kho vào mảng in-memory.
- **Kết quả mong đợi:** Inventory Service nhận mỗi sự kiện `ORDER_CREATED` từ Kafka và xử lý trừ kho đáng tin cậy.
- **Kết luận:** Kafka đảm bảo không mất sự kiện trừ kho, kể cả khi Inventory Service tạm offline.

## 3
### title
Xây dựng Analytics Service (Kafka Consumer - sự kiện quan trọng)
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho Analytics Service.
  - Bước 2: Cấu hình Kafka consumer với `groupId: 'analytics-group'`.
  - Bước 3: Tạo handler lắng nghe topic `order-events` với `@EventPattern('ORDER_CREATED')`.
  - Bước 4: Trong handler, ghi nhận thống kê: `[Analytics] Recording order ${orderId} - product ${productId}, quantity ${quantity}`.
  - Bước 5: Lưu thống kê vào mảng in-memory và expose endpoint `GET /analytics/summary` trả tổng số đơn, tổng số lượng.
- **Kết quả mong đợi:** Analytics Service nhận mỗi sự kiện và ghi nhận đầy đủ thống kê.
- **Kết luận:** Kafka đảm bảo dữ liệu analytics chính xác và không bị mất.

## 4
### title
Xây dựng Dashboard Notifier (Redis Subscriber - real-time)
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho Dashboard Notifier.
  - Bước 2: Cài đặt `ioredis` và tạo Redis subscriber client.
  - Bước 3: Subscribe vào channel `order-notifications` và log: `[Dashboard] Real-time update: New order ${orderId} from ${customerName}`.
  - Bước 4: (Tuỳ chọn) Tích hợp WebSocket để push thông báo đến frontend dashboard.
- **Kết quả mong đợi:** Dashboard Notifier nhận thông báo real-time khi có đơn hàng mới (nếu đang online).
- **Kết luận:** Redis Pub/Sub phù hợp cho thông báo tức thời, chấp nhận mất nếu subscriber offline.

## 5
### title
Kiểm thử và chứng minh sự khác biệt giữa 2 pattern
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy toàn bộ hệ thống:
    ```bash
    docker-compose up --build
    ```
  - Bước 2: Gửi request tạo đơn hàng:
    ```bash
    curl -X POST http://localhost:3001/orders -H "Content-Type: application/json" -d '{"productId":1,"quantity":3,"customerName":"Minh"}'
    ```
  - Bước 3: Kiểm tra log: cả 3 consumer (Inventory, Analytics, Dashboard) đều nhận sự kiện.
  - Bước 4: Dừng Dashboard Notifier và Inventory Service:
    ```bash
    docker-compose stop dashboard-notifier inventory-service
    ```
  - Bước 5: Gửi thêm 2 đơn hàng trong khi 2 service offline.
  - Bước 6: Khởi động lại cả 2 service.
  - Bước 7: Kiểm tra:
    - **Inventory Service** (Kafka): nhận được 2 đơn hàng đã gửi khi offline (persistent).
    - **Dashboard Notifier** (Redis): KHÔNG nhận được 2 thông báo đã gửi khi offline (fire-and-forget).
- **Kết quả mong đợi:**
  - Kafka consumer (Inventory, Analytics) phục hồi và xử lý message đã bỏ lỡ.
  - Redis subscriber (Dashboard) mất message gửi trong lúc offline.
- **Kết luận:** Kafka phù hợp cho sự kiện quan trọng cần đảm bảo delivery (inventory, analytics). Redis Pub/Sub phù hợp cho thông báo real-time chấp nhận mất (dashboard, live notification).

# references
## 0
### alias
Redis Pub/Sub Documentation
### url
https://redis.io/docs/interact/pubsub/
## 1
### alias
Apache Kafka Documentation
### url
https://kafka.apache.org/documentation/
## 2
### alias
NestJS Kafka Microservice
### url
https://docs.nestjs.com/microservices/kafka
## 3
### alias
ioredis GitHub
### url
https://github.com/redis/ioredis

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge, bao gồm Order Service (Dual Publisher), Inventory Service và Analytics Service (Kafka Consumers), Dashboard Notifier (Redis Subscriber), và docker-compose.yml.
### score
22
### prompts
#### 0
##### title
Dual Publisher hoạt động
##### score
7
##### promptText
Order Service gửi sự kiện đồng thời lên Kafka topic `order-events` và Redis channel `order-notifications`. Cả 2 đường đều hoạt động khi consumer/subscriber online.
#### 1
##### title
Kafka consumers xử lý đúng
##### score
8
##### promptText
Inventory Service và Analytics Service nhận sự kiện từ Kafka, xử lý đúng nghiệp vụ (trừ kho và ghi thống kê). Kafka consumer phục hồi khi offline và xử lý message đã bỏ lỡ.
#### 2
##### title
Redis subscriber và chứng minh fire-and-forget
##### score
7
##### promptText
Dashboard Notifier nhận thông báo real-time qua Redis. Khi offline và bật lại, message cũ bị mất. Chứng minh rõ sự khác biệt giữa Kafka (persistent) và Redis Pub/Sub (fire-and-forget).

## 1
### type
googleDocsUrl
### title
Tài liệu phân tích pattern
### description
Nộp tài liệu giải thích lý do chọn Redis Pub/Sub cho kịch bản nào và Kafka cho kịch bản nào, kèm so sánh ưu nhược điểm.
### score
8
### prompts
#### 0
##### title
Phân tích và so sánh đúng
##### score
8
##### promptText
Tài liệu giải thích rõ: khi nào dùng Redis Pub/Sub (real-time, chấp nhận mất), khi nào dùng Kafka (sự kiện quan trọng, cần persistent). Nêu được ưu nhược điểm của từng pattern và kịch bản phù hợp.

# difficulty
medium

# score
30
