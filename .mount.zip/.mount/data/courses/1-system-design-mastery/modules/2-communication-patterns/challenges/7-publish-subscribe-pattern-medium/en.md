# title
Combining Redis Pub/Sub and Kafka: Choosing the Right Pattern for Each Scenario

# description
Build a system combining Redis Pub/Sub for real-time notifications and Kafka for critical events requiring guaranteed delivery. Demonstrate when to use each pattern with concrete scenarios: Redis Pub/Sub for instant notifications (acceptable loss), Kafka for critical business events (no loss allowed).

# requirements
Create a NestJS system with 4 services: `OrderService` (emits events via both Kafka and Redis), `InventoryService` (Kafka consumer - processes stock deduction, critical event), `AnalyticsService` (Kafka consumer - records statistics, critical event), `DashboardNotifier` (Redis subscriber - real-time dashboard updates, acceptable loss). Use Docker Compose to run both Redis and Kafka. Write documentation explaining the reasoning behind pattern choices for each scenario.

# prerequisites
- Docker and Docker Compose
- Node.js >= 18
- NestJS CLI
- Packages `@nestjs/microservices`, `kafkajs`, `ioredis`
- Completed `publish-subscribe-pattern-easy` and `asynchronous-event-driven-easy` challenges
- Understanding of the difference between Pub/Sub and Message Queue

# steps

## 0
### title
Set up Kafka and Redis with Docker Compose
### body
- **Steps to follow:**
  - Step 1: Create `docker-compose.yml` with both Kafka (KRaft mode) and Redis:
    ```yaml
    services:
      kafka:
        image: bitnami/kafka:3.6
        environment:
          - KAFKA_CFG_NODE_ID=1
          - KAFKA_CFG_PROCESS_ROLES=broker,controller
          - KAFKA_CFG_CONTROLLER_QUORUM_VOTERS=1@kafka:9093
          - KAFKA_CFG_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093
          - KAFKA_CFG_ADVERTISED_LISTENERS=PLAINTEXT://kafka:9092
          - KAFKA_CFG_CONTROLLER_LISTENER_NAMES=CONTROLLER
          - KAFKA_CFG_LISTENER_SECURITY_PROTOCOL_MAP=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
        ports:
          - "9092:9092"
      redis:
        image: redis:7-alpine
        ports:
          - "6379:6379"
    ```
  - Step 2: Start the infrastructure:
    ```bash
    docker-compose up -d kafka redis
    ```
- **Expected result:** Both Kafka and Redis start successfully.
- **Conclusion:** Dual messaging infrastructure is ready for both patterns.

## 1
### title
Build the Order Service (Dual Publisher)
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for Order Service.
  - Step 2: Install dependencies:
    ```bash
    npm install @nestjs/microservices kafkajs ioredis
    ```
  - Step 3: Register both the Kafka client and Redis client in the module.
  - Step 4: Create `OrderController` with endpoint `POST /orders` accepting body `{ productId, quantity, customerName }`.
  - Step 5: In the handler, when an order is created successfully:
    - Send `ORDER_CREATED` event to **Kafka** topic `order-events` (critical event, guaranteed delivery):
      ```typescript
      this.kafkaClient.emit('ORDER_CREATED', { orderId, productId, quantity, customerName, createdAt });
      ```
    - Send notification to **Redis** channel `order-notifications` (real-time, fire-and-forget):
      ```typescript
      this.redisClient.publish('order-notifications', JSON.stringify({ type: 'NEW_ORDER', orderId, customerName }));
      ```
- **Expected result:** Every order creation sends events simultaneously to Kafka (persistent) and Redis (real-time).
- **Conclusion:** Order Service uses the right pattern for the right purpose: Kafka for critical data, Redis for instant notifications.

## 2
### title
Build Inventory Service (Kafka Consumer - critical events)
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for Inventory Service.
  - Step 2: Configure Kafka consumer with `groupId: 'inventory-group'`.
  - Step 3: Create a handler listening to topic `order-events` with `@EventPattern('ORDER_CREATED')`.
  - Step 4: In the handler, process stock deduction: `[Inventory] Reducing stock for product ${productId} by ${quantity}`.
  - Step 5: Store stock state in an in-memory array.
- **Expected result:** Inventory Service receives every `ORDER_CREATED` event from Kafka and reliably processes stock deductions.
- **Conclusion:** Kafka ensures no stock deduction events are lost, even if Inventory Service is temporarily offline.

## 3
### title
Build Analytics Service (Kafka Consumer - critical events)
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for Analytics Service.
  - Step 2: Configure Kafka consumer with `groupId: 'analytics-group'`.
  - Step 3: Create a handler listening to topic `order-events` with `@EventPattern('ORDER_CREATED')`.
  - Step 4: In the handler, record statistics: `[Analytics] Recording order ${orderId} - product ${productId}, quantity ${quantity}`.
  - Step 5: Store statistics in an in-memory array and expose endpoint `GET /analytics/summary` returning total orders and total quantity.
- **Expected result:** Analytics Service receives every event and records complete statistics.
- **Conclusion:** Kafka ensures analytics data is accurate and never lost.

## 4
### title
Build Dashboard Notifier (Redis Subscriber - real-time)
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for Dashboard Notifier.
  - Step 2: Install `ioredis` and create a Redis subscriber client.
  - Step 3: Subscribe to channel `order-notifications` and log: `[Dashboard] Real-time update: New order ${orderId} from ${customerName}`.
  - Step 4: (Optional) Integrate WebSocket to push notifications to a frontend dashboard.
- **Expected result:** Dashboard Notifier receives real-time notifications when new orders are placed (if online).
- **Conclusion:** Redis Pub/Sub is suitable for instant notifications, accepting loss if the subscriber is offline.

## 5
### title
Test and demonstrate the difference between the 2 patterns
### body
- **Steps to follow:**
  - Step 1: Run the entire system:
    ```bash
    docker-compose up --build
    ```
  - Step 2: Send an order creation request:
    ```bash
    curl -X POST http://localhost:3001/orders -H "Content-Type: application/json" -d '{"productId":1,"quantity":3,"customerName":"Minh"}'
    ```
  - Step 3: Check logs: all 3 consumers (Inventory, Analytics, Dashboard) should receive the event.
  - Step 4: Stop Dashboard Notifier and Inventory Service:
    ```bash
    docker-compose stop dashboard-notifier inventory-service
    ```
  - Step 5: Send 2 more orders while both services are offline.
  - Step 6: Restart both services.
  - Step 7: Check:
    - **Inventory Service** (Kafka): receives the 2 orders sent while offline (persistent).
    - **Dashboard Notifier** (Redis): does NOT receive the 2 notifications sent while offline (fire-and-forget).
- **Expected result:**
  - Kafka consumers (Inventory, Analytics) recover and process missed messages.
  - Redis subscriber (Dashboard) loses messages sent during its offline period.
- **Conclusion:** Kafka is suitable for critical events requiring guaranteed delivery (inventory, analytics). Redis Pub/Sub is suitable for real-time notifications where loss is acceptable (dashboard, live notifications).

# references
## 0
### alias
Redis Pub/Sub Documentation
### url
https://redis.io/docs/interact/pubsub/
## 1
### alias
Apache Kafka Documentation
### url
https://kafka.apache.org/documentation/
## 2
### alias
NestJS Kafka Microservice
### url
https://docs.nestjs.com/microservices/kafka
## 3
### alias
ioredis GitHub
### url
https://github.com/redis/ioredis

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code, including Order Service (Dual Publisher), Inventory Service and Analytics Service (Kafka Consumers), Dashboard Notifier (Redis Subscriber), and docker-compose.yml.
### score
22
### prompts
#### 0
##### title
Dual Publisher works
##### score
7
##### promptText
Order Service sends events simultaneously to Kafka topic `order-events` and Redis channel `order-notifications`. Both channels work when consumers/subscribers are online.
#### 1
##### title
Kafka consumers process correctly
##### score
8
##### promptText
Inventory Service and Analytics Service receive events from Kafka and process correctly (stock deduction and statistics recording). Kafka consumers recover when offline and process missed messages.
#### 2
##### title
Redis subscriber and fire-and-forget proof
##### score
7
##### promptText
Dashboard Notifier receives real-time notifications via Redis. When offline and restarted, old messages are lost. Clearly demonstrates the difference between Kafka (persistent) and Redis Pub/Sub (fire-and-forget).

## 1
### type
googleDocsUrl
### title
Pattern Analysis Document
### description
Submit a document explaining when to use Redis Pub/Sub and when to use Kafka, including a comparison of pros and cons.
### score
8
### prompts
#### 0
##### title
Correct analysis and comparison
##### score
8
##### promptText
Document clearly explains: when to use Redis Pub/Sub (real-time, acceptable loss), when to use Kafka (critical events, needs persistence). Lists pros and cons of each pattern and appropriate scenarios.

# difficulty
medium

# score
30
