# title
Hybrid REST Gateway với 2 gRPC Service và luồng dữ liệu hai chiều

# description
Xây dựng hệ thống Hybrid nâng cao với REST API Gateway kết nối 2 gRPC backend service (Catalog Service và Order Service). Order Service gọi ngược lại Catalog Service qua gRPC để validate sản phẩm trước khi tạo đơn hàng, chứng minh luồng dữ liệu hai chiều giữa các gRPC service.

# requirements
Tạo 3 NestJS application: `ApiGateway` (REST, cổng 3000), `CatalogService` (gRPC, cổng 5001), `OrderService` (gRPC, cổng 5002). Định nghĩa 2 file proto: `catalog.proto` (RPC `GetProduct`, `ListProducts`) và `order.proto` (RPC `CreateOrder`, `ListOrders`). Order Service phải gọi gRPC đến Catalog Service để kiểm tra sản phẩm tồn tại và lấy giá trước khi tạo đơn hàng. Gateway expose REST endpoint cho client.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Package `@grpc/grpc-js`, `@grpc/proto-loader`, `@nestjs/microservices`
- Kiến thức về gRPC và Protocol Buffers
- Hiểu luồng giao tiếp giữa các microservice

# steps

## 0
### title
Định nghĩa 2 file Protocol Buffers
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo thư mục `proto` dùng chung.
  - Bước 2: Tạo file `proto/catalog.proto`:
    ```protobuf
    syntax = "proto3";
    package catalog;

    service CatalogService {
      rpc GetProduct (ProductRequest) returns (ProductResponse);
      rpc ListProducts (Empty) returns (ProductListResponse);
    }

    message Empty {}
    message ProductRequest { int32 id = 1; }
    message ProductResponse {
      int32 id = 1;
      string name = 2;
      double price = 3;
      int32 stock = 4;
    }
    message ProductListResponse { repeated ProductResponse products = 1; }
    ```
  - Bước 3: Tạo file `proto/order.proto`:
    ```protobuf
    syntax = "proto3";
    package order;

    service OrderService {
      rpc CreateOrder (CreateOrderRequest) returns (OrderResponse);
      rpc ListOrders (Empty) returns (OrderListResponse);
    }

    message Empty {}
    message CreateOrderRequest {
      int32 productId = 1;
      int32 quantity = 2;
      string customerName = 3;
    }
    message OrderResponse {
      int32 id = 1;
      int32 productId = 2;
      string productName = 3;
      int32 quantity = 4;
      double totalPrice = 5;
      string status = 6;
    }
    message OrderListResponse { repeated OrderResponse orders = 1; }
    ```
- **Kết quả mong đợi:** 2 file `.proto` định nghĩa đầy đủ service, RPC method và message type.
- **Kết luận:** Contract giao tiếp giữa các service đã được xác định rõ ràng.

## 1
### title
Xây dựng Catalog gRPC Service
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho Catalog Service.
  - Bước 2: Cài đặt dependencies gRPC và cấu hình `main.ts` khởi tạo gRPC server trên cổng 5001.
  - Bước 3: Implement `CatalogController` với `@GrpcMethod('CatalogService', 'GetProduct')` trả sản phẩm theo id (ném lỗi nếu không tồn tại) và `@GrpcMethod('CatalogService', 'ListProducts')` trả danh sách sản phẩm mẫu (ít nhất 5 sản phẩm với `id`, `name`, `price`, `stock`).
- **Kết quả mong đợi:** Catalog Service lắng nghe gRPC trên cổng 5001, trả đúng dữ liệu sản phẩm.
- **Kết luận:** Catalog Service sẵn sàng phục vụ cả Gateway và Order Service.

## 2
### title
Xây dựng Order gRPC Service với gọi ngược Catalog
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho Order Service.
  - Bước 2: Cấu hình `main.ts` khởi tạo gRPC server trên cổng 5002.
  - Bước 3: Trong Order Service, đăng ký gRPC client kết nối đến Catalog Service (`localhost:5001`, dùng `catalog.proto`).
  - Bước 4: Implement `CreateOrder`: trước khi tạo đơn hàng, gọi `GetProduct` đến Catalog Service để:
    - Kiểm tra sản phẩm có tồn tại không (nếu không, trả lỗi gRPC với status `NOT_FOUND`).
    - Kiểm tra `stock >= quantity` (nếu không đủ, trả lỗi `FAILED_PRECONDITION`).
    - Tính `totalPrice = price * quantity`.
  - Bước 5: Lưu đơn hàng vào mảng in-memory và trả `OrderResponse` với đầy đủ thông tin.
  - Bước 6: Implement `ListOrders` trả danh sách đơn hàng đã tạo.
- **Kết quả mong đợi:** Order Service validate sản phẩm qua Catalog trước khi tạo đơn, trả lời chính xác khi thành công hoặc thất bại.
- **Kết luận:** Luồng gRPC hai chiều giữa Order và Catalog đã được thiết lập.

## 3
### title
Xây dựng REST API Gateway
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho API Gateway.
  - Bước 2: Đăng ký 2 gRPC client: một kết nối Catalog Service (cổng 5001), một kết nối Order Service (cổng 5002).
  - Bước 3: Tạo REST endpoint:
    - `GET /catalog` -> gọi `ListProducts`.
    - `GET /catalog/:id` -> gọi `GetProduct`.
    - `POST /orders` (body: `{ productId, quantity, customerName }`) -> gọi `CreateOrder`.
    - `GET /orders` -> gọi `ListOrders`.
  - Bước 4: Xử lý lỗi gRPC (NOT_FOUND, FAILED_PRECONDITION) và chuyển đổi thành HTTP status code phù hợp (404, 400).
- **Kết quả mong đợi:** Gateway expose 4 REST endpoint, chuyển đổi đúng giữa REST và gRPC, xử lý lỗi hợp lý.
- **Kết luận:** Gateway đóng vai trò trung gian, ẩn đi giao thức gRPC khỏi client.

## 4
### title
Kiểm thử luồng hai chiều và xử lý lỗi
### body
- **Các bước thực hiện:**
  - Bước 1: Khởi động lần lượt Catalog Service, Order Service, API Gateway.
  - Bước 2: Lấy danh sách sản phẩm:
    ```bash
    curl http://localhost:3000/catalog
    ```
  - Bước 3: Tạo đơn hàng thành công:
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d '{"productId":1,"quantity":2,"customerName":"Minh"}'
    ```
  - Bước 4: Tạo đơn hàng với sản phẩm không tồn tại:
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d '{"productId":999,"quantity":1,"customerName":"Minh"}'
    ```
  - Bước 5: Tạo đơn hàng với số lượng vượt stock:
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d '{"productId":1,"quantity":99999,"customerName":"Minh"}'
    ```
  - Bước 6: Lấy danh sách đơn hàng đã tạo:
    ```bash
    curl http://localhost:3000/orders
    ```
- **Kết quả mong đợi:**
  - `GET /catalog` trả danh sách sản phẩm.
  - `POST /orders` với dữ liệu hợp lệ trả đơn hàng với `totalPrice` tính đúng.
  - `POST /orders` với `productId` không tồn tại trả 404.
  - `POST /orders` với `quantity` vượt `stock` trả 400.
  - `GET /orders` trả danh sách đơn hàng đã tạo thành công.
- **Kết luận:** Luồng hai chiều hoạt động chính xác: Gateway -> Order -> Catalog (validate) -> Order (tạo đơn) -> Gateway (trả kết quả).

# references
## 0
### alias
NestJS gRPC Microservice
### url
https://docs.nestjs.com/microservices/grpc
## 1
### alias
gRPC Status Codes
### url
https://grpc.github.io/grpc/core/md_doc_statuscodes.html
## 2
### alias
Protocol Buffers Language Guide
### url
https://protobuf.dev/programming-guides/proto3/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge, bao gồm API Gateway, Catalog Service, Order Service và 2 file .proto.
### score
30
### prompts
#### 0
##### title
Định nghĩa proto và cấu trúc project
##### score
8
##### promptText
Có 2 file `.proto` định nghĩa đúng. 3 NestJS app (Gateway, Catalog, Order) được tổ chức rõ ràng, gRPC server và client cấu hình đúng.
#### 1
##### title
Luồng hai chiều Order -> Catalog
##### score
12
##### promptText
Order Service gọi `GetProduct` đến Catalog Service qua gRPC để validate sản phẩm trước khi tạo đơn. Kiểm tra tồn tại và kiểm tra stock. Tính `totalPrice` đúng.
#### 2
##### title
Gateway và xử lý lỗi
##### score
10
##### promptText
Gateway expose 4 REST endpoint, chuyển đổi gRPC error thành HTTP status phù hợp (404 cho NOT_FOUND, 400 cho FAILED_PRECONDITION). Luồng end-to-end hoạt động chính xác.

# difficulty
medium

# score
30
