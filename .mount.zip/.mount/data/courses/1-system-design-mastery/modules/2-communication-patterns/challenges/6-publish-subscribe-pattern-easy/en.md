# title
Basic Redis Pub/Sub with NestJS

# description
Build a Pub/Sub system with Redis in NestJS: User Service (Publisher) emits a `USER_REGISTERED` event on a Redis channel, 2 Subscribers (Welcome Email Service and Activity Log Service) receive and process the event. Demonstrate the fire-and-forget behavior of Redis Pub/Sub.

# requirements
Create 3 NestJS applications: `UserService` (Publisher, port 3001) with endpoint `POST /users/register` emitting a `USER_REGISTERED` event on Redis channel `user-events`, `WelcomeEmailService` (Subscriber) listening to the channel and logging welcome email sending, `ActivityLogService` (Subscriber) listening to the channel and logging activity records. Use Docker Compose to run Redis along with the services. Demonstrate fire-and-forget behavior: if a subscriber is offline, messages are lost.

# prerequisites
- Docker and Docker Compose
- Node.js >= 18
- NestJS CLI
- Package `ioredis`
- Basic knowledge of Redis and Pub/Sub pattern

# steps

## 0
### title
Set up Redis with Docker Compose
### body
- **Steps to follow:**
  - Step 1: Create `docker-compose.yml` with Redis:
    ```yaml
    services:
      redis:
        image: redis:7-alpine
        ports:
          - "6379:6379"
    ```
  - Step 2: Start Redis:
    ```bash
    docker-compose up -d redis
    ```
- **Expected result:** Redis server starts successfully on port 6379.
- **Conclusion:** The Pub/Sub infrastructure is ready.

## 1
### title
Build the User Service (Publisher)
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project:
    ```bash
    nest new user-service
    ```
  - Step 2: Install the Redis client:
    ```bash
    npm install ioredis
    ```
  - Step 3: Create a `RedisModule` registering a Redis client (connecting to `redis:6379`) and exporting it for other modules to use.
  - Step 4: Create `UserController` with endpoint `POST /users/register` accepting body `{ name, email }`.
  - Step 5: In the handler, after processing registration (mock), publish a message to Redis channel `user-events`:
    ```typescript
    this.redisClient.publish('user-events', JSON.stringify({
      event: 'USER_REGISTERED',
      data: { name, email, registeredAt: new Date().toISOString() }
    }));
    ```
- **Expected result:** Each time `POST /users/register` is called, a message is published to Redis channel `user-events`.
- **Conclusion:** The Publisher is ready to emit events in a fire-and-forget manner.

## 2
### title
Build the Welcome Email Service (Subscriber 1)
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for Welcome Email Service.
  - Step 2: Install `ioredis` and create a Redis subscriber client.
  - Step 3: In `OnModuleInit`, subscribe to the `user-events` channel:
    ```typescript
    this.subscriber.subscribe('user-events');
    this.subscriber.on('message', (channel, message) => {
      const parsed = JSON.parse(message);
      if (parsed.event === 'USER_REGISTERED') {
        console.log(`[Welcome Email] Sending welcome email to ${parsed.data.email}`);
      }
    });
    ```
- **Expected result:** Welcome Email Service automatically receives and logs email notifications when a `USER_REGISTERED` event occurs.
- **Conclusion:** Subscriber 1 is operational and listening to the correct channel.

## 3
### title
Build the Activity Log Service (Subscriber 2)
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for Activity Log Service.
  - Step 2: Install `ioredis` and create a Redis subscriber client.
  - Step 3: In `OnModuleInit`, subscribe to the `user-events` channel and process:
    ```typescript
    this.subscriber.on('message', (channel, message) => {
      const parsed = JSON.parse(message);
      if (parsed.event === 'USER_REGISTERED') {
        console.log(`[Activity Log] New user registered: ${parsed.data.name} at ${parsed.data.registeredAt}`);
      }
    });
    ```
- **Expected result:** Activity Log Service automatically receives and logs activity information when an event occurs.
- **Conclusion:** Subscriber 2 operates independently from Subscriber 1, both receive the same message.

## 4
### title
Demonstrate fire-and-forget and test
### body
- **Steps to follow:**
  - Step 1: Run the entire system (Redis + 3 services):
    ```bash
    docker-compose up --build
    ```
  - Step 2: Send a user registration request:
    ```bash
    curl -X POST http://localhost:3001/users/register -H "Content-Type: application/json" -d '{"name":"Minh","email":"minh@example.com"}'
    ```
  - Step 3: Check logs of Welcome Email Service and Activity Log Service: both should receive the event.
  - Step 4: Stop Activity Log Service (docker-compose stop activity-log-service).
  - Step 5: Send another registration request:
    ```bash
    curl -X POST http://localhost:3001/users/register -H "Content-Type: application/json" -d '{"name":"Lan","email":"lan@example.com"}'
    ```
  - Step 6: Restart Activity Log Service and check logs: the message sent while offline will NOT be received.
- **Expected result:**
  - When both subscribers are online: both receive the event.
  - When Activity Log is offline: only Welcome Email receives it, Activity Log loses the message.
  - When Activity Log restarts: it does NOT receive the lost message (fire-and-forget).
- **Conclusion:** Redis Pub/Sub is fire-and-forget: messages are only delivered to subscribers that are online at the time of publishing, with no persistent storage like Kafka.

# references
## 0
### alias
Redis Pub/Sub Documentation
### url
https://redis.io/docs/interact/pubsub/
## 1
### alias
ioredis GitHub
### url
https://github.com/redis/ioredis
## 2
### alias
NestJS Custom Transporters
### url
https://docs.nestjs.com/microservices/custom-transport

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code, including User Service (Publisher), Welcome Email Service and Activity Log Service (Subscribers), and docker-compose.yml.
### score
20
### prompts
#### 0
##### title
Publisher and Redis channel
##### score
7
##### promptText
User Service publishes `USER_REGISTERED` events to Redis channel `user-events` with complete payload (`name`, `email`, `registeredAt`). Redis runs correctly in Docker Compose.
#### 1
##### title
2 Subscribers work
##### score
7
##### promptText
Welcome Email Service and Activity Log Service subscribe to the same `user-events` channel, both receive and process events when online.
#### 2
##### title
Fire-and-forget demonstrated
##### score
6
##### promptText
When a subscriber is offline, messages sent during that time are lost. Subscriber on restart does not receive old messages. Clearly demonstrates the difference from message queues.

# difficulty
easy

# score
20
