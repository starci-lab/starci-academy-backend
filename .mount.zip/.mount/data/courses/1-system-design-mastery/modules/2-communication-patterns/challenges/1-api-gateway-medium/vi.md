# title
API Gateway nâng cao với Kong Plugins (Rate Limiting và JWT)

# description
Xây dựng 3 NestJS microservice (User, Product, Order) định tuyến qua Kong API Gateway (DB-less mode), cấu hình plugin **Rate Limiting** giới hạn request và **JWT Authentication** bảo vệ các route nhạy cảm. Toàn bộ chạy bằng Docker Compose.

# requirements
Tạo 3 NestJS microservice: `UserService` (endpoint `GET /users`, `GET /users/:id`), `ProductService` (endpoint `GET /products`, `GET /products/:id`), `OrderService` (endpoint `POST /orders`, `GET /orders`). Cấu hình Kong (DB-less) với file `kong.yml`: định tuyến 3 service, áp dụng plugin `rate-limiting` (giới hạn 5 request/phút) cho route Product, và plugin `jwt` cho route Order. Tạo JWT credential trong kong.yml để kiểm tra xác thực.

# prerequisites
- Docker và Docker Compose
- Node.js >= 18
- NestJS CLI
- Kiến thức cơ bản về API Gateway và JWT

# steps

## 0
### title
Khởi tạo 3 NestJS microservice
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo 3 project NestJS:
    ```bash
    nest new user-service
    nest new product-service
    nest new order-service
    ```
  - Bước 2: Trong `user-service`, tạo `UserController` với endpoint `GET /users` trả mảng user mẫu và `GET /users/:id` trả user theo id.
  - Bước 3: Trong `product-service`, tạo `ProductController` với endpoint `GET /products` trả mảng sản phẩm và `GET /products/:id` trả sản phẩm theo id.
  - Bước 4: Trong `order-service`, tạo `OrderController` với endpoint `POST /orders` nhận body `{ productId, quantity, userId }` trả đơn hàng đã tạo, và `GET /orders` trả danh sách đơn hàng.
  - Bước 5: Cấu hình mỗi service chạy trên cổng riêng (3001, 3002, 3003).
- **Kết quả mong đợi:** Mỗi service chạy độc lập và endpoint trả đúng dữ liệu khi test trực tiếp.
- **Kết luận:** Ba microservice đã sẵn sàng để tích hợp qua Kong.

## 1
### title
Tạo Dockerfile và docker-compose.yml
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `Dockerfile` cho mỗi service với base image `node:18-alpine`, cài đặt dependencies, build và expose cổng tương ứng.
  - Bước 2: Tạo `docker-compose.yml` với 4 service: `user-service`, `product-service`, `order-service`, và `kong` (image `kong:3.4`).
  - Bước 3: Cấu hình Kong trong docker-compose: `KONG_DATABASE=off`, `KONG_DECLARATIVE_CONFIG=/etc/kong/kong.yml`, expose cổng `8000:8000`.
- **Kết quả mong đợi:** Docker Compose build và chạy được 4 container.
- **Kết luận:** Hạ tầng container đã sẵn sàng, bước tiếp theo cấu hình routing và plugin trên Kong.

## 2
### title
Cấu hình Kong với routing và Rate Limiting plugin
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `kong.yml` định nghĩa 3 service (user-service, product-service, order-service) với route tương ứng (`/users`, `/products`, `/orders`).
  - Bước 2: Thêm plugin `rate-limiting` cho service `product-service`:
    ```yaml
    plugins:
      - name: rate-limiting
        config:
          minute: 5
          policy: local
    ```
  - Bước 3: Chạy hệ thống và test rate limiting bằng cách gọi `GET /products` liên tục hơn 5 lần trong 1 phút.
- **Kết quả mong đợi:** 5 request đầu trả 200, từ request thứ 6 Kong trả 429 Too Many Requests.
- **Kết luận:** Plugin Rate Limiting hoạt động đúng, bảo vệ service khỏi bị quá tải.

## 3
### title
Cấu hình JWT Authentication plugin cho Order route
### body
- **Các bước thực hiện:**
  - Bước 1: Trong `kong.yml`, tạo consumer và JWT credential:
    ```yaml
    consumers:
      - username: app-user
        jwt_secrets:
          - key: my-jwt-key
            secret: my-jwt-secret
            algorithm: HS256
    ```
  - Bước 2: Thêm plugin `jwt` cho service `order-service`:
    ```yaml
    plugins:
      - name: jwt
    ```
  - Bước 3: Tạo JWT token hợp lệ (dùng thư viện `jsonwebtoken` hoặc jwt.io) với payload chứa `iss: "my-jwt-key"`, ký bằng secret `my-jwt-secret`.
  - Bước 4: Gọi `POST /orders` không có token để xác nhận bị 401. Gọi lại với header `Authorization: Bearer <token>` để xác nhận trả 201.
- **Kết quả mong đợi:** Request không có JWT bị Kong chặn với 401. Request có JWT hợp lệ được chuyển đến Order Service bình thường.
- **Kết luận:** JWT plugin bảo vệ route nhạy cảm, chỉ cho phép request đã xác thực.

## 4
### title
Kiểm thử toàn bộ hệ thống
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy hệ thống:
    ```bash
    docker-compose up --build
    ```
  - Bước 2: Test User Service (không plugin):
    ```bash
    curl http://localhost:8000/users
    ```
  - Bước 3: Test Rate Limiting trên Product Service (gọi 6 lần liên tục):
    ```bash
    for i in $(seq 1 6); do curl -s -o /dev/null -w "%{http_code}\n" http://localhost:8000/products; done
    ```
  - Bước 4: Test JWT trên Order Service:
    ```bash
    curl -X POST http://localhost:8000/orders -H "Content-Type: application/json" -d '{"productId":1,"quantity":2,"userId":1}'
    curl -X POST http://localhost:8000/orders -H "Content-Type: application/json" -H "Authorization: Bearer <valid-token>" -d '{"productId":1,"quantity":2,"userId":1}'
    ```
- **Kết quả mong đợi:**
  - `GET /users` trả danh sách user (200).
  - `GET /products` trả 200 cho 5 request đầu, 429 cho request thứ 6.
  - `POST /orders` không token trả 401, có token hợp lệ trả 201.
- **Kết luận:** Hệ thống API Gateway với 3 microservice, Rate Limiting và JWT Authentication hoạt động chính xác.

# references
## 0
### alias
Kong Rate Limiting Plugin
### url
https://docs.konghq.com/hub/kong-inc/rate-limiting/
## 1
### alias
Kong JWT Plugin
### url
https://docs.konghq.com/hub/kong-inc/jwt/
## 2
### alias
Kong DB-less Declarative Config
### url
https://docs.konghq.com/gateway/latest/production/deployment-topologies/db-less-and-declarative-config/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge, bao gồm 3 NestJS service, Dockerfile, kong.yml với plugin config, và docker-compose.yml.
### score
30
### prompts
#### 0
##### title
Cấu trúc 3 microservice và Docker
##### score
10
##### promptText
Có 3 NestJS service riêng biệt (User, Product, Order) với Dockerfile hợp lệ. `docker-compose.yml` chạy được toàn bộ hệ thống gồm 4 container.
#### 1
##### title
Rate Limiting plugin hoạt động
##### score
10
##### promptText
File `kong.yml` cấu hình `rate-limiting` cho Product route, giới hạn 5 request/phút. Request thứ 6 trong 1 phút bị trả 429.
#### 2
##### title
JWT Authentication plugin hoạt động
##### score
10
##### promptText
File `kong.yml` cấu hình `jwt` plugin cho Order route. Consumer và JWT credential được khai báo. Request không có token bị 401, có token hợp lệ được xử lý bình thường.

# difficulty
medium

# score
30
