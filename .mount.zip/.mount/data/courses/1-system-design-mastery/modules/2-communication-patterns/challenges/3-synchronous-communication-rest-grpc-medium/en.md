# title
Hybrid REST Gateway with 2 gRPC Services and Bidirectional Data Flow

# description
Build an advanced Hybrid system with a REST API Gateway connecting to 2 gRPC backend services (Catalog Service and Order Service). Order Service calls back to Catalog Service via gRPC to validate products before creating an order, demonstrating bidirectional data flow between gRPC services.

# requirements
Create 3 NestJS applications: `ApiGateway` (REST, port 3000), `CatalogService` (gRPC, port 5001), `OrderService` (gRPC, port 5002). Define 2 proto files: `catalog.proto` (RPCs `GetProduct`, `ListProducts`) and `order.proto` (RPCs `CreateOrder`, `ListOrders`). Order Service must call gRPC to Catalog Service to verify product existence and get the price before creating an order. Gateway exposes REST endpoints for clients.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Packages `@grpc/grpc-js`, `@grpc/proto-loader`, `@nestjs/microservices`
- Knowledge of gRPC and Protocol Buffers
- Understanding of inter-service communication flow

# steps

## 0
### title
Define 2 Protocol Buffers files
### body
- **Steps to follow:**
  - Step 1: Create a shared `proto` directory.
  - Step 2: Create `proto/catalog.proto`:
    ```protobuf
    syntax = "proto3";
    package catalog;

    service CatalogService {
      rpc GetProduct (ProductRequest) returns (ProductResponse);
      rpc ListProducts (Empty) returns (ProductListResponse);
    }

    message Empty {}
    message ProductRequest { int32 id = 1; }
    message ProductResponse {
      int32 id = 1;
      string name = 2;
      double price = 3;
      int32 stock = 4;
    }
    message ProductListResponse { repeated ProductResponse products = 1; }
    ```
  - Step 3: Create `proto/order.proto`:
    ```protobuf
    syntax = "proto3";
    package order;

    service OrderService {
      rpc CreateOrder (CreateOrderRequest) returns (OrderResponse);
      rpc ListOrders (Empty) returns (OrderListResponse);
    }

    message Empty {}
    message CreateOrderRequest {
      int32 productId = 1;
      int32 quantity = 2;
      string customerName = 3;
    }
    message OrderResponse {
      int32 id = 1;
      int32 productId = 2;
      string productName = 3;
      int32 quantity = 4;
      double totalPrice = 5;
      string status = 6;
    }
    message OrderListResponse { repeated OrderResponse orders = 1; }
    ```
- **Expected result:** 2 `.proto` files fully define services, RPC methods, and message types.
- **Conclusion:** The communication contract between services has been clearly defined.

## 1
### title
Build the Catalog gRPC Service
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for Catalog Service.
  - Step 2: Install gRPC dependencies and configure `main.ts` to initialize a gRPC server on port 5001.
  - Step 3: Implement `CatalogController` with `@GrpcMethod('CatalogService', 'GetProduct')` returning a product by id (throw error if not found) and `@GrpcMethod('CatalogService', 'ListProducts')` returning a list of sample products (at least 5 products with `id`, `name`, `price`, `stock`).
- **Expected result:** Catalog Service listens on gRPC port 5001 and returns correct product data.
- **Conclusion:** Catalog Service is ready to serve both the Gateway and Order Service.

## 2
### title
Build Order gRPC Service with callback to Catalog
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for Order Service.
  - Step 2: Configure `main.ts` to initialize a gRPC server on port 5002.
  - Step 3: In Order Service, register a gRPC client connecting to Catalog Service (`localhost:5001`, using `catalog.proto`).
  - Step 4: Implement `CreateOrder`: before creating an order, call `GetProduct` to Catalog Service to:
    - Verify the product exists (if not, return gRPC status `NOT_FOUND`).
    - Check `stock >= quantity` (if insufficient, return `FAILED_PRECONDITION`).
    - Calculate `totalPrice = price * quantity`.
  - Step 5: Save the order to an in-memory array and return `OrderResponse` with complete information.
  - Step 6: Implement `ListOrders` returning the list of created orders.
- **Expected result:** Order Service validates products via Catalog before creating orders, responds correctly on success or failure.
- **Conclusion:** Bidirectional gRPC flow between Order and Catalog has been established.

## 3
### title
Build the REST API Gateway
### body
- **Steps to follow:**
  - Step 1: Create a NestJS project for the API Gateway.
  - Step 2: Register 2 gRPC clients: one connecting to Catalog Service (port 5001), one connecting to Order Service (port 5002).
  - Step 3: Create REST endpoints:
    - `GET /catalog` -> calls `ListProducts`.
    - `GET /catalog/:id` -> calls `GetProduct`.
    - `POST /orders` (body: `{ productId, quantity, customerName }`) -> calls `CreateOrder`.
    - `GET /orders` -> calls `ListOrders`.
  - Step 4: Handle gRPC errors (NOT_FOUND, FAILED_PRECONDITION) and convert them to appropriate HTTP status codes (404, 400).
- **Expected result:** Gateway exposes 4 REST endpoints, correctly converts between REST and gRPC, handles errors appropriately.
- **Conclusion:** The Gateway acts as an intermediary, hiding the gRPC protocol from clients.

## 4
### title
Test the bidirectional flow and error handling
### body
- **Steps to follow:**
  - Step 1: Start Catalog Service, Order Service, and API Gateway sequentially.
  - Step 2: Get the product list:
    ```bash
    curl http://localhost:3000/catalog
    ```
  - Step 3: Create a successful order:
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d '{"productId":1,"quantity":2,"customerName":"Minh"}'
    ```
  - Step 4: Create an order with a non-existent product:
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d '{"productId":999,"quantity":1,"customerName":"Minh"}'
    ```
  - Step 5: Create an order with quantity exceeding stock:
    ```bash
    curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d '{"productId":1,"quantity":99999,"customerName":"Minh"}'
    ```
  - Step 6: Get the list of created orders:
    ```bash
    curl http://localhost:3000/orders
    ```
- **Expected result:**
  - `GET /catalog` returns the product list.
  - `POST /orders` with valid data returns an order with correctly calculated `totalPrice`.
  - `POST /orders` with non-existent `productId` returns 404.
  - `POST /orders` with `quantity` exceeding `stock` returns 400.
  - `GET /orders` returns the list of successfully created orders.
- **Conclusion:** The bidirectional flow works correctly: Gateway -> Order -> Catalog (validate) -> Order (create) -> Gateway (return result).

# references
## 0
### alias
NestJS gRPC Microservice
### url
https://docs.nestjs.com/microservices/grpc
## 1
### alias
gRPC Status Codes
### url
https://grpc.github.io/grpc/core/md_doc_statuscodes.html
## 2
### alias
Protocol Buffers Language Guide
### url
https://protobuf.dev/programming-guides/proto3/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code, including API Gateway, Catalog Service, Order Service, and 2 .proto files.
### score
30
### prompts
#### 0
##### title
Proto definitions and project structure
##### score
8
##### promptText
There are 2 `.proto` files correctly defined. 3 NestJS apps (Gateway, Catalog, Order) are well-organized, gRPC server and client are configured correctly.
#### 1
##### title
Bidirectional flow Order -> Catalog
##### score
12
##### promptText
Order Service calls `GetProduct` to Catalog Service via gRPC to validate the product before creating an order. Checks existence and stock. Calculates `totalPrice` correctly.
#### 2
##### title
Gateway and error handling
##### score
10
##### promptText
Gateway exposes 4 REST endpoints, converts gRPC errors to appropriate HTTP status codes (404 for NOT_FOUND, 400 for FAILED_PRECONDITION). End-to-end flow works correctly.

# difficulty
medium

# score
30
