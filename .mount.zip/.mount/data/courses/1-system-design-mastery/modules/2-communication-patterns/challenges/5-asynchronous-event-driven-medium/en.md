# title
Advanced Event-Driven: Dead Letter Queue, Retry, and Consumer Recovery

# description
Extend the event-driven system with Kafka to handle failure scenarios: implement a Dead Letter Queue (DLQ) mechanism when a consumer fails to process, demonstrate consumer recovery when offline (Kafka persistent log), and add basic retry logic before sending messages to the DLQ.

# requirements
Build a NestJS system with Kafka consisting of: `PaymentService` (Producer) emitting `PAYMENT_COMPLETED` events, `FulfillmentService` (Consumer) processing events with retry logic (max 3 attempts), sending failed messages to DLQ topic `payment-events-dlq` after exhausting retries. Add `DlqMonitorService` to read and log messages from the DLQ. Demonstrate Kafka persistent log by stopping the consumer, sending events, restarting the consumer, and confirming the consumer still receives the missed messages.

# prerequisites
- Docker and Docker Compose
- Node.js >= 18
- NestJS CLI
- Packages `@nestjs/microservices` and `kafkajs`
- Completed the `asynchronous-event-driven-easy` challenge
- Knowledge of error handling and retry patterns

# steps

## 0
### title
Set up Kafka and project structure
### body
- **Steps to follow:**
  - Step 1: Create `docker-compose.yml` with Kafka (KRaft mode), similar to the easy challenge configuration.
  - Step 2: Create 3 NestJS projects: `payment-service`, `fulfillment-service`, `dlq-monitor-service`.
  - Step 3: Install dependencies for all projects:
    ```bash
    npm install @nestjs/microservices kafkajs
    ```
  - Step 4: Configure the Kafka client for Payment Service (Producer) and Kafka consumer for Fulfillment Service with `groupId: 'fulfillment-group'`.
- **Expected result:** 3 NestJS projects are initialized with correct dependencies, Kafka runs in Docker.
- **Conclusion:** The infrastructure is ready for implementing advanced error handling mechanisms.

## 1
### title
Implement Payment Service with Producer
### body
- **Steps to follow:**
  - Step 1: Create `PaymentController` with endpoint `POST /payments` accepting body `{ orderId, amount, shouldFail }`.
  - Step 2: The `shouldFail` field (boolean) is included in the payload to simulate consumer failure scenarios.
  - Step 3: Emit the `PAYMENT_COMPLETED` event to topic `payment-events` with payload `{ orderId, amount, shouldFail, paidAt }`.
- **Expected result:** The Producer sends messages to Kafka with a `shouldFail` flag to control consumer behavior.
- **Conclusion:** The Producer supports simulating both success and failure scenarios.

## 2
### title
Implement Fulfillment Service with Retry and DLQ
### body
- **Steps to follow:**
  - Step 1: Create a handler listening to topic `payment-events` with `@EventPattern('PAYMENT_COMPLETED')`.
  - Step 2: Implement retry logic: when receiving a message, check `shouldFail`. If `true`, increment `retryCount` and retry (max 3 times).
  - Step 3: Store `retryCount` in metadata or in the payload (add a `retryCount` field when re-emitting).
  - Step 4: After 3 failed attempts, send the original message to DLQ topic `payment-events-dlq` with error information:
    ```json
    {
      "originalPayload": { "orderId": 101, "amount": 250000 },
      "error": "Processing failed after 3 retries",
      "failedAt": "2024-01-01T00:00:00Z",
      "retryCount": 3
    }
    ```
  - Step 5: If processing succeeds (shouldFail = false), log: `[Fulfillment] Order ${orderId} fulfilled successfully`.
- **Expected result:** Successful messages are processed normally, failed messages are retried 3 times then moved to the DLQ.
- **Conclusion:** The retry and DLQ mechanism ensures no messages are lost and errors are isolated.

## 3
### title
Implement DLQ Monitor Service
### body
- **Steps to follow:**
  - Step 1: Configure DLQ Monitor Service to listen to topic `payment-events-dlq` with `groupId: 'dlq-monitor-group'`.
  - Step 2: Create a handler to read messages from the DLQ and log details: `[DLQ Monitor] Failed message - orderId: ${orderId}, error: ${error}, retryCount: ${retryCount}`.
  - Step 3: (Optional) Store DLQ messages in an in-memory array and expose endpoint `GET /dlq/messages` for inspection.
- **Expected result:** DLQ Monitor receives and logs every failed message from the DLQ topic.
- **Conclusion:** DLQ Monitor enables monitoring and manual handling of failed messages.

## 4
### title
Demonstrate Kafka Persistent Log and Consumer Recovery
### body
- **Steps to follow:**
  - Step 1: Run the system with only Kafka and Payment Service (do not start Fulfillment Service).
  - Step 2: Send 3 payment requests:
    ```bash
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":201,"amount":100000,"shouldFail":false}'
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":202,"amount":200000,"shouldFail":false}'
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":203,"amount":300000,"shouldFail":false}'
    ```
  - Step 3: Start Fulfillment Service:
    ```bash
    docker-compose up fulfillment-service
    ```
  - Step 4: Check Fulfillment Service log: it should process all 3 messages that were sent while it was offline.
- **Expected result:** Fulfillment Service, upon restarting, still receives all 3 messages sent during its offline period, proving Kafka stores messages persistently.
- **Conclusion:** Kafka persistent log ensures consumers do not lose messages when offline, unlike fire-and-forget models.

## 5
### title
Test the complete retry and DLQ flow
### body
- **Steps to follow:**
  - Step 1: Run the entire system:
    ```bash
    docker-compose up --build
    ```
  - Step 2: Send a successful request:
    ```bash
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":301,"amount":500000,"shouldFail":false}'
    ```
    Check Fulfillment log: `Order 301 fulfilled successfully`.
  - Step 3: Send a failing request:
    ```bash
    curl -X POST http://localhost:3001/payments -H "Content-Type: application/json" -d '{"orderId":302,"amount":100000,"shouldFail":true}'
    ```
    Check Fulfillment log: 3 retry attempts.
    Check DLQ Monitor log: receives the failed message for order 302.
- **Expected result:**
  - Successful messages are processed immediately.
  - Failed messages are retried 3 times, then moved to the DLQ.
  - DLQ Monitor receives and logs the failed message details.
- **Conclusion:** The advanced event-driven system handles failure scenarios systematically: retry -> DLQ -> monitoring.

# references
## 0
### alias
NestJS Kafka Microservice
### url
https://docs.nestjs.com/microservices/kafka
## 1
### alias
Kafka Consumer Group Recovery
### url
https://kafka.apache.org/documentation/#consumerconfigs
## 2
### alias
Dead Letter Queue Pattern
### url
https://learn.microsoft.com/en-us/azure/architecture/patterns/dead-letter-queue

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code, including Payment Service, Fulfillment Service (with retry + DLQ), DLQ Monitor Service, and docker-compose.yml.
### score
30
### prompts
#### 0
##### title
Retry logic works
##### score
10
##### promptText
Fulfillment Service implements retry logic with a maximum of 3 attempts when processing fails. Logs show the retry count incrementing. Successful messages are processed normally.
#### 1
##### title
Dead Letter Queue works
##### score
10
##### promptText
After 3 failed retries, the message is sent to topic `payment-events-dlq` with complete error information. DLQ Monitor Service receives and logs messages from the DLQ.
#### 2
##### title
Consumer Recovery from Kafka Persistent Log
##### score
10
##### promptText
Demonstrates that Fulfillment Service, after going offline and restarting, still receives messages sent during its offline period. Kafka persistent log works correctly.

# difficulty
medium

# score
30
