# title
Hybrid REST Gateway và gRPC Backend Service

# description
Xây dựng hệ thống Hybrid với một REST API Gateway (NestJS) làm điểm vào cho client, phía sau gọi đến 1 gRPC backend service (Inventory Service). Chứng minh luồng chuyển đổi từ REST sang gRPC và ngược lại.

# requirements
Tạo 2 NestJS application: `ApiGateway` (REST, cổng 3000) và `InventoryService` (gRPC, cổng 5000). Định nghĩa file `inventory.proto` với service `InventoryService` chứa 2 RPC: `GetItem` (nhận `ItemRequest { id }`, trả `ItemResponse { id, name, quantity }`) và `ListItems` (nhận `Empty`, trả `ItemListResponse { items[] }`). Gateway nhận REST request và gọi gRPC đến InventoryService, trả kết quả về cho client dạng JSON.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Package `@grpc/grpc-js` và `@grpc/proto-loader`
- Package `@nestjs/microservices`
- Kiến thức cơ bản về Protocol Buffers

# steps

## 0
### title
Định nghĩa file Protocol Buffers
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo thư mục `proto` ở root project.
  - Bước 2: Tạo file `proto/inventory.proto`:
    ```protobuf
    syntax = "proto3";
    package inventory;

    service InventoryService {
      rpc GetItem (ItemRequest) returns (ItemResponse);
      rpc ListItems (Empty) returns (ItemListResponse);
    }

    message Empty {}

    message ItemRequest {
      int32 id = 1;
    }

    message ItemResponse {
      int32 id = 1;
      string name = 2;
      int32 quantity = 3;
    }

    message ItemListResponse {
      repeated ItemResponse items = 1;
    }
    ```
- **Kết quả mong đợi:** File `.proto` định nghĩa đúng cú pháp protobuf với 2 RPC method và các message type.
- **Kết luận:** Contract giao tiếp giữa Gateway và Inventory Service đã được thiết lập.

## 1
### title
Xây dựng Inventory gRPC Service
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho Inventory Service:
    ```bash
    nest new inventory-service
    ```
  - Bước 2: Cài đặt dependencies:
    ```bash
    npm install @nestjs/microservices @grpc/grpc-js @grpc/proto-loader
    ```
  - Bước 3: Cấu hình `main.ts` để khởi tạo gRPC microservice trên cổng 5000, trỏ đến file `inventory.proto`.
  - Bước 4: Tạo `InventoryController` implement các method `getItem` và `listItems` với decorator `@GrpcMethod('InventoryService', 'GetItem')` và `@GrpcMethod('InventoryService', 'ListItems')`.
  - Bước 5: Tạo dữ liệu mẫu trong service (ít nhất 3 item với `id`, `name`, `quantity`).
- **Kết quả mong đợi:** Inventory Service khởi động và lắng nghe gRPC request trên cổng 5000.
- **Kết luận:** gRPC backend service đã sẵn sàng nhận request từ Gateway.

## 2
### title
Xây dựng REST API Gateway
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project NestJS cho API Gateway:
    ```bash
    nest new api-gateway
    ```
  - Bước 2: Cài đặt dependencies:
    ```bash
    npm install @nestjs/microservices @grpc/grpc-js @grpc/proto-loader
    ```
  - Bước 3: Tạo `InventoryModule` trong Gateway, đăng ký gRPC client trỏ đến `localhost:5000` và file `inventory.proto`.
  - Bước 4: Tạo `InventoryController` trong Gateway với 2 REST endpoint:
    - `GET /inventory` gọi `ListItems` qua gRPC và trả JSON.
    - `GET /inventory/:id` gọi `GetItem` qua gRPC và trả JSON.
  - Bước 5: Inject gRPC client service và sử dụng `this.inventoryService.getService()` để gọi RPC method.
- **Kết quả mong đợi:** Gateway khởi động trên cổng 3000, nhận REST request và chuyển đổi thành gRPC call.
- **Kết luận:** Luồng chuyển đổi REST -> gRPC -> Response đã được thiết lập.

## 3
### title
Kiểm thử luồng Hybrid
### body
- **Các bước thực hiện:**
  - Bước 1: Khởi động Inventory Service (gRPC):
    ```bash
    cd inventory-service && npm run start:dev
    ```
  - Bước 2: Khởi động API Gateway (REST):
    ```bash
    cd api-gateway && npm run start:dev
    ```
  - Bước 3: Gọi endpoint lấy danh sách item:
    ```bash
    curl http://localhost:3000/inventory
    ```
  - Bước 4: Gọi endpoint lấy item theo id:
    ```bash
    curl http://localhost:3000/inventory/1
    ```
  - Bước 5: Gọi endpoint với id không tồn tại để kiểm tra xử lý lỗi:
    ```bash
    curl http://localhost:3000/inventory/999
    ```
- **Kết quả mong đợi:**
  - `GET /inventory` trả mảng item dạng JSON.
  - `GET /inventory/1` trả item có id = 1 dạng JSON.
  - `GET /inventory/999` trả lỗi 404 hoặc thông báo không tìm thấy.
- **Kết luận:** Hệ thống Hybrid REST-gRPC hoạt động đúng, Gateway chuyển đổi thành công giữa 2 giao thức.

# references
## 0
### alias
NestJS gRPC Microservice
### url
https://docs.nestjs.com/microservices/grpc
## 1
### alias
Protocol Buffers Language Guide
### url
https://protobuf.dev/programming-guides/proto3/
## 2
### alias
gRPC Official Documentation
### url
https://grpc.io/docs/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge, bao gồm API Gateway (REST), Inventory Service (gRPC), và file .proto.
### score
20
### prompts
#### 0
##### title
File .proto và gRPC Service
##### score
7
##### promptText
File `inventory.proto` định nghĩa đúng 2 RPC method (`GetItem`, `ListItems`). Inventory Service implement đúng các method với decorator `@GrpcMethod`.
#### 1
##### title
REST Gateway gọi gRPC đúng
##### score
7
##### promptText
API Gateway đăng ký gRPC client, 2 REST endpoint (`GET /inventory`, `GET /inventory/:id`) gọi thành công đến gRPC service và trả kết quả JSON.
#### 2
##### title
Luồng end-to-end hoạt động
##### score
6
##### promptText
Client gọi REST đến Gateway, Gateway gọi gRPC đến Inventory Service, kết quả trả về đúng dạng JSON. Xử lý được trường hợp item không tồn tại.

# difficulty
easy

# score
20
