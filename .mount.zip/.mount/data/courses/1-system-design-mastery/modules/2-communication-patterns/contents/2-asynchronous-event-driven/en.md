# title
Asynchronous communication — Event-Driven with Kafka

# description
Wire microservices through events instead of synchronous calls — demo Order (Producer) publishing ORDER_CREATED so Inventory and Notification react on their own, then dig into Consumer Groups, persistent logs, at-least-once delivery, and event-driven failure modes.

# body

## I. Introduction

In a **Senior Backend** interview, the loaded question often is: *"When a user places an order, do you call **Inventory** to decrement stock and **Notification** to send the email synchronously? If **Notification** is slow for **3 seconds** or **down**, does the user see an error on the 'Place Order' button?"*. A junior answer: *"I `await` them in sequence to be safe"* — and that exposes the problem: the order flow is **tied** to the mail service, **throughput** is capped by the **slowest** one; next week you add **Analytics**, **Fraud**, **CRM** — back to editing `order.service.ts` and pushing risk into the core. Business-wise the user only needs the order recorded — the email arriving **5 seconds** later hurts nobody.

The way out is flipping the direction: the source service just **publishes an event** and returns immediately; whoever cares **listens on their own**. We use **Kafka** in the next part to get at the essence of **event-driven** — read on.

## II. Visual Demo & Hands-on

The **example** below is three **NestJS** services in a **monorepo** wired through **Kafka**: **`order`** (port **3001**) is the **Producer**, publishing **`ORDER_CREATED`** to the topic **`order-events`**; **`inventory`** (**3002**) and **`notification`** (**3003**) are two **Consumers** in **two different Consumer Groups** (**`inventory-grp`** and **`notification-grp`**) — different groups means both receive every event (**broadcast** / fan-out). **Kafka** runs in **KRaft** mode via **Docker** on port **9092**, storing events on disk as a **persistent log** with **offsets** — offline consumers can resume from their committed offset.

**Clone** here: [Asynchronous Event-Driven — demo (NestJS monorepo + Kafka)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/asynchronous-event-driven)

| Component | Port | Tech | Responsibility (short) |
|-------------|------|-----------|------------------------|
| **Order** | **3001** | **NestJS** | **POST /orders** → writes DB → publishes **`ORDER_CREATED`** on **`order-events`** |
| **Kafka** | **9092** | **Kafka** (KRaft) | **Broker** + **persistent log**; stores events, tracks offsets per group |
| **Inventory** | **3002** | **NestJS** | Consumer group **`inventory-grp`**; listens to **`order-events`** → decrements stock |
| **Notification** | **3003** | **NestJS** | Consumer group **`notification-grp`**; listens to **`order-events`** → sends notification |

![Event-Driven architecture — Order publishes, Kafka fans out to Inventory and Notification](https://starci.org/system-design-mastery/asynchronous-event-driven/0.svg)

*Figure 1. System architecture diagram from the source above.*

**Order** publishes, **Kafka** keeps an offset-tracked log, two different-group consumers **both** read the same events — **Order** does not know and does not need to know who is listening.

### 1. Environment setup and run

Assumes **Docker** and **Node.js** (LTS). From the cloned **repo**:

1. Start **Kafka** (**KRaft** mode):

```
docker compose -f .docker/kafka.yaml up -d
```

2. Install dependencies:

```
npm install
```

3. Open **three terminals**, one per **service**:

```
npx nest start order --watch
```

```
npx nest start inventory --watch
```

```
npx nest start notification --watch
```

**Expected result**

**Kafka broker** is ready at **9092**; three **services** run at **3001** (Order), **3002** (Inventory), **3003** (Notification). **Inventory** and **Notification** subscribe to the topic **`order-events`** with their own **Consumer Group IDs**.

**Conclusion**

One **Producer** and two independent **Consumers**, connected only through **Kafka** — **Order** never calls **Inventory** or **Notification** directly; the only path is the **event** through the **broker**.

### 2. Place an order → both consumers react in parallel

You can **follow along** with a **GUI client** (**Postman**, **Insomnia**, **Bruno** …) **or** **`curl`** on **Linux**, **macOS** or **WSL2**.

**Steps:**

**Step 1:** Place an order via **Order**.

- Method: **POST**
- URL: `http://localhost:3001/orders`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "productId": "p-001",
  "quantity": 2
}
```

**Equivalent `curl`**:

```
curl -X POST http://localhost:3001/orders -H "Content-Type: application/json" -d "{\"productId\":\"p-001\",\"quantity\":2}"
```

**Response** comes back immediately (HTTP 2xx) — **without waiting** for **Inventory** or **Notification**. **Order** just publishes the event and replies.

**Step 2:** Watch the logs in the **Inventory** and **Notification** terminals.

**Expected result**

**Order** writes its DB and publishes **`ORDER_CREATED`** onto **`order-events`**. **Inventory** logs the event and debits stock of `p-001` by **2**. **Notification** logs the **same event** and sends its notification. They process in **parallel** and **independently**; the client response is returned **immediately**, not after the two consumers finish.

**Conclusion**

Two consumers in **different Consumer Groups** → **both** receive every event — the **broadcast** / fan-out behavior of Kafka. **Order** does not know how many consumers listen; adding an **Analytics Service** later is just subscribing a new group, **no change** to **Order**.

### 3. Consumer offline — Kafka holds the log, replay on reconnect

Kafka's core difference from plain pub/sub: the **persistent log** lets an offline consumer still pick up missed events when it reconnects, resuming from its committed offset.

**Steps:**

**Step 1:** Stop **Notification Service** (Ctrl+C in terminal 3).

**Step 2:** Place a new order while Notification is down.

- Method: **POST**
- URL: `http://localhost:3001/orders`
- Body:

```
{
  "productId": "p-002",
  "quantity": 1
}
```

```
curl -X POST http://localhost:3001/orders -H "Content-Type: application/json" -d "{\"productId\":\"p-002\",\"quantity\":1}"
```

**Step 3:** Observe — **Inventory** still processes normally.

**Step 4:** Restart **Notification Service** and watch the logs.

```
npx nest start notification --watch
```

**Expected result**

While **Notification** was down: **Inventory** still received the new event and debited `p-002` — the producer was **unaffected**. **Kafka** kept the event in **`order-events`** at the exact **offset** that **`notification-grp`** had not yet consumed. When **Notification** comes back, it reads from the old offset and **catches up** on the missed event — the notification for `p-002` goes out **late**, but it is **not lost**.

**Conclusion**

**Kafka** ≠ **fire-and-forget** pub/sub: it is a **distributed event log** with **per-consumer-group offsets**. A consumer down for minutes can still **catch up** completely when it returns. That is why Kafka is chosen for flows where **events must not be lost** (payment, transactions, audit) — unlike **Redis Pub/Sub**, which is fire-and-forget.

After these two flows, the next part names the core **concepts** and **edge cases** of real **event-driven** deployments.

## III. Advanced Theory and Conclusion

### 1. What event-driven is and why it matters in microservices

**Event-driven architecture** is a communication style where a **service** announces **what has happened** (**events** like **`ORDER_CREATED`**, **`PAYMENT_COMPLETED`**) to a **message broker**, and other services **subscribe** to react. Unlike a **command** ("do X") over **REST**/**gRPC**, an **event** is a past-tense fact — the **producer** does not care **who** processes it, **how many** services process it, or **when**. The result is **temporal decoupling** (no time lock-in) and **spatial decoupling** (no need to know each other's address).

- **Example:** In the demo above, once **Order** publishes **`ORDER_CREATED`** it is done; **Inventory** and **Notification** read when ready and process independently. To add an **Analytics Service** that computes live revenue, just subscribe to **`order-events`** with a new **Consumer Group** — **no change** to **Order**.

### 2. Apache Kafka — distinguished from plain message queues

**Kafka** is often introduced as "a message broker", but it **differs** from classic queues (**RabbitMQ classic queue**, **ActiveMQ**) at the root: **Kafka is a distributed commit log**, **not** a delete-on-consume queue.

- **Topic & Partition:** A **topic** is a logical channel (e.g. **`order-events`**); each topic splits into **partitions** for scale — events with the same key land on the same partition, preserving in-partition order.
- **Offset:** Every event has an **offset** (monotonic integer within a partition). Consumers **commit** their processed offset; Kafka **does not delete** events on consume — only on **retention** (by time or size).
- **Consumer Group:** A group of consumers **shares** messages within the group (load balancing); **two different groups** each receive **every** event (broadcast).
- **Replay:** Since events remain on disk, new consumers (or consumers that reset their offset) can **replay** history — extremely useful for **CQRS**, **Event Sourcing**, and rebuilding **Read Models**.
- **Throughput:** Kafka is engineered for **millions of events per second** per cluster thanks to append-only logs + sequential disk writes — orders of magnitude above classic brokers.

### 3. Consumer Group — load balance vs broadcast

The mechanism that decides fan-out behavior, and the concept juniors misread most often:

- **Same Consumer Group (load balance):** Running **5 replicas** of **Inventory Service** all with `groupId = inventory-grp` → Kafka assigns partitions among the 5 instances; each event is processed by **exactly one** instance. This is natural **horizontal scaling** — double throughput by doubling replicas (up to the partition count).
- **Different Consumer Groups (broadcast):** **Inventory** (group `inventory-grp`) and **Notification** (group `notification-grp`) both subscribe to `order-events` → **both groups** receive every event; each keeps its own offset. The demo above is exactly this pattern.

To let several services **each** receive every event: one group per service. To let several replicas of **one** service **share** the load: one group.

### 4. Trade-offs and failure modes

**Event-driven** is not magic — common sharp edges:

- **Eventual consistency.** After `OrderCreated`, stock may not yet be decremented for **ms → seconds**; a user refreshing early might see stale state. Fix: surface a pending state in the UI, use **polling** or **WebSocket** updates, and design the business to **tolerate** bounded staleness.
- **At-least-once delivery.** Kafka defaults to **at-least-once**: a consumer might receive **the same event twice** (retries, rebalances). Fix: make consumers **idempotent** — deduplicate by **event id** or **business key**; processing twice must not double the effect.
- **Ordering only within a partition.** Kafka preserves order **within** a partition, **not** across partitions. Events for the same business entity (e.g. same `orderId`) must share a **partition key**. Forget this and **`OrderCancelled`** can arrive **before** **`OrderCreated`**.
- **Debugging is harder than synchronous.** Stack traces do not cross requests — a failure late in the event chain can be far from the root. Fix: **distributed tracing** (**OpenTelemetry**, **Jaeger**) with a **trace id** in event headers; correlate via a **correlation id** in the payload.
- **The broker is new operational ground.** A **Kafka cluster** is **not** a "lightweight queue" — you need **3+ brokers** for HA, tuned **partition count**, **retention**, **replica factor**, plus monitoring of **ISR** and **consumer lag**. Small teams often start with **managed Kafka** (Confluent Cloud, MSK, Upstash) to reduce ops burden.
- **DB write and event publish are not atomic.** A service may **commit** the DB change but fail to publish the event (or vice versa) → state drifts. Fix: **Transactional Outbox** — write the outbox row in the same business transaction; a background worker reads the outbox and publishes to Kafka with **at-least-once** guarantees.

### 5. When to go event-driven vs synchronous

Not every interaction should be **asynchronous** — overuse creates needless complexity:

- **Use event-driven when:** One action fans out to multiple consequences (order → debit stock + send email + update analytics + fraud check); the producer does not need an immediate result; **temporal decoupling** matters (consumers may go offline); you need **replay** (rebuild read models, audit).
- **Use synchronous (REST/gRPC) when:** The user needs a **result right now** in the same request (fetch account, quote price); you require **immediate strong consistency**; the business truly needs an **instant** success/failure answer (e.g. debit on checkout — do it synchronously with compensation, do not fire-and-forget).
- **Common hybrid:** **Synchronous** for the core **request-response** path; **event-driven** for **side effects** (notify, analytics, search re-index, cache invalidation).

**Event-driven** is not "REST for modern people" — it is a **different communication model** with **different guarantees**: you trade **guaranteed synchronous responses** for **strong decoupling**, **independent scaling**, and **replayability**. Once you commit to this path, invest properly in **observability** (trace id across events, consumer-lag monitoring), **Transactional Outbox** (to keep DB and broker in sync), and **idempotent consumers** (to survive duplicates). Skipping those three areas produces an **unreliable event-driven system** — which is **worse** than a plain **REST** one because it is much harder to debug.

# references
## 0
### alias
Apache Kafka — Introduction
### url
https://kafka.apache.org/intro
## 1
### alias
NestJS — Kafka Microservice
### url
https://docs.nestjs.com/microservices/kafka
## 2
### alias
Microservices.io — Transactional Outbox
### url
https://microservices.io/patterns/data/transactional-outbox.html

# minutesRead
30
