# title
Synchronous communication — REST vs gRPC

# description
Compare REST (HTTP/1.1 + JSON) and gRPC (HTTP/2 + Protobuf) for synchronous microservice communication, demo the Hybrid pattern with REST at the edge and gRPC internally, then dig into strong contracts, streaming, and failure modes.

# body

## I. Introduction

In a **Senior Backend** interview, the loaded question often is: *"Your **5 internal services** talk to each other with what — **REST JSON**? At **10M internal RPCs per hour**, have you measured **bandwidth** and **latency**?"*. A junior answer: *"I use **REST** for everything synchronous"* — and that exposes the problem: at that scale, **JSON text** on **HTTP/1.1** bloats the payload several times over, and each request opens its own connection — both **bandwidth** and **latency** pay the bill. Worse, with no shared **schema**, team A changes a field and team B hits a **runtime bug** that no **compile** step ever caught.

The way out is picking the right **synchronous protocol** for the right seat: one shape for external clients, another for internal calls. We use **REST** and **gRPC** in the next part to get at the essence — read on.

## II. Visual Demo & Hands-on

The **example** below is three **NestJS** services in one **monorepo**: **`gateway`** (port **3000**, **REST**) accepts **HTTP/JSON** from clients and relays to two backends over **gRPC** — **`user-service`** (**5001**) and **`product-service`** (**5002**). The backends do **not** expose **REST**; they speak only **gRPC** (**HTTP/2** + **Protobuf**). The **`.proto`** file is the **single source of truth** for the schema — every field change starts there, and both **Gateway** and backends generate code from the same file.

**Clone** here: [Synchronous REST + gRPC — demo (NestJS monorepo)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/synchronous-communication-rest-grpc)

| Component | Port | Tech | Responsibility (short) |
|-------------|------|-----------|------------------------|
| **Gateway** | **3000** | **NestJS**, **REST** | Receives **HTTP/JSON** from clients; calls backends over **gRPC**; re-serializes to **JSON** |
| **User Service** | **5001** | **NestJS**, **gRPC** | User business logic; **gRPC** only (HTTP/2 + Protobuf) |
| **Product Service** | **5002** | **NestJS**, **gRPC** | Product business logic; **gRPC** only |

![Hybrid REST + gRPC architecture — REST gateway, gRPC backends](https://starci.org/system-design-mastery/synchronous-communication-rest-grpc/0.svg)

*Figure 1. System architecture diagram from the source above.*

Clients only see **REST** at the edge; inside, the three **services** communicate over binary **gRPC**; the **`.proto`** file is the shared schema.

### 1. Environment setup and run

Assumes **Node.js** (LTS). From the cloned **repo**:

1. Install dependencies:

```
npm install
```

2. Open **three terminals**, one per **service**:

```
npx nest start user-service --watch
```

```
npx nest start product-service --watch
```

```
npx nest start gateway --watch
```

**Expected result**

**User** listens on **5001** (gRPC), **Product** on **5002** (gRPC), **Gateway** on **3000** (REST). External clients only reach **3000**.

**Conclusion**

**Hybrid** is live: **REST** is the only shape at the edge; the two backends are **pure gRPC**, no **HTTP/JSON** exposed — internal traffic runs over **HTTP/2** + **Protobuf**.

### 2. Call through Hybrid — REST at edge, gRPC inside

You can **follow along** with a **GUI client** (**Postman**, **Insomnia**, **Bruno** …) **or** **`curl`** on **Linux**, **macOS** or **WSL2**.

**Steps:**

**Step 1:** Fetch a user through **Gateway**.

- Method: **GET**
- URL: `http://localhost:3000/users/1`

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X GET http://localhost:3000/users/1
```

**Response** is **JSON** — the Gateway decoded **Protobuf** from **User Service** and re-serialized as **JSON** for the client.

**Step 2:** Fetch a product through **Gateway**.

- Method: **GET**
- URL: `http://localhost:3000/products/1`

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X GET http://localhost:3000/products/1
```

**Response** is also **JSON** — Gateway called **Product Service** over **gRPC** and converted the result.

**Expected result**

Both requests to the **REST Gateway** return correct data. **Gateway** logs show **gRPC** calls to the backends; backend logs show requests arriving with **Content-Type: application/grpc** (not **JSON**). On the **Gateway ↔ backend** wire, payloads are **binary Protobuf**, not text.

**Conclusion**

Clients never know **gRPC** exists — they only see familiar **REST JSON**. Internally the system exploits **HTTP/2 multiplexing** + **Protobuf binary** to cut overhead vs **HTTP/1.1 + JSON**; at the same time, **`.proto`** forces every field to have a **declared type** — mismatches fail at code-gen, not at runtime.

After the flow above, the next part names the **concepts** and **edge cases** of **REST** / **gRPC** in real deployments.

## III. Advanced Theory and Conclusion

### 1. How REST and gRPC actually differ

Both are **synchronous** (caller waits for a reply), but they differ on **encoding**, **transport**, **contract**, and **tooling**:

- **Transport:** **REST** typically runs on **HTTP/1.1** (sometimes **HTTP/2**); each request usually opens a fresh connection (or keep-alive without multiplexing). **gRPC** requires **HTTP/2** — **multiplexing** (many RPCs over one TCP connection), **server push**, **flow control**.
- **Encoding:** **REST** uses **JSON** (text, self-describing, human-readable) or **XML**. **gRPC** uses **Protocol Buffers** (binary, schema required). For the same 5-field payload, **Protobuf** is usually **3–10× smaller** and parses faster (no string parsing).
- **Contract:** **REST** loosely relies on **OpenAPI/Swagger** as documentation — **not enforced**, easy to drift from code. **gRPC** starts from **`.proto`** — client and server code are **code-gen'd** from that file, type mismatches are **compile failures**.
- **Streaming:** **REST** has simple request/response (SSE or WebSocket must be wired separately). **gRPC** offers **4 modes**: unary, server-streaming, client-streaming, bidirectional — multiple messages over one RPC.
- **Browser:** **REST** works natively. **gRPC** does not run natively in browsers — you need **gRPC-Web** (proxy) or fall back to REST at the edge.

### 2. When to pick REST

**REST** is the right default when:

- **Public APIs for external clients** (web, mobile, third-party): every stack can call it, **Postman/cURL** debug in 30 seconds, standard **HTTP caching** (CDN) works out of the box.
- **Simple CRUD** business logic, moderate payloads, no thousands of RPCs per second between two services.
- **Multi-stack teams**: PHP, Ruby, Python, Node — every language has a clean HTTP client; no **protoc** toolchain to install.
- **Audit / compliance** needs human-readable logs: **JSON** in ELK beats reading **Protobuf hex dumps** by a wide margin.

### 3. When to pick gRPC

**gRPC** wins when:

- **High-frequency internal microservice calls**: one edge request fans out to 5–20 internal RPCs; saving **3–10×** on **bandwidth** and **latency** is a real difference.
- **Strong contracts required**: large teams, many services — changing a field without a shared schema causes **runtime bugs**. **`.proto`** + **code-gen** solves this at the root.
- **Streaming**: server-pushed metrics, bidirectional chat, chunked upload/download — **gRPC streaming** is cleaner than rolling your own SSE/WebSocket.
- **Consistent polyglot clients**: **protoc** generates clients for Go, Java, Python, C++, Node… from the **same file** — no hand-written SDKs.

### 4. Trade-offs and failure modes you must know

Both are **synchronous** — and synchronous comes with its own scars:

- **Runtime tight coupling.** The caller waits for the callee — if the callee is slow or dead, the caller stalls. Fix: explicit **timeouts** (every call needs one), **circuit breaker** (Hystrix/Resilience4j), **retry with backoff**, **bulkhead** (isolated pools per downstream).
- **Cascading failure.** A 100ms slowdown in one service can ripple through the whole chain → system collapse. Fix: **deadline propagation** (gRPC has built-in **deadline** that flows through the call chain), **fail-fast** instead of infinite retry.
- **gRPC is harder to debug than REST.** Binary on the wire — Wireshark cannot read it directly; you need **grpcurl** or **gRPC reflection**. Logs should decode Protobuf to JSON before persisting.
- **Contract versioning.** **Protobuf** has clear rules: do not change **field numbers**, only add **optional** fields, do not delete released fields — every team must learn them. **REST** looks "easier" but silently drifts more often.
- **Mesh / service discovery.** High-frequency synchronous calls require **service discovery** (Consul, **Kubernetes DNS**) and **client-side load balancing**; with gRPC this usually pairs with a **service mesh** (**Istio**, **Linkerd**) to handle mTLS, retries, and metrics at the proxy layer.

### 5. Hybrid — REST at the edge, gRPC internally

The common, pragmatic shape for mid-sized and larger **microservices** systems (the demo above is a small instance of it):

- **External client ↔ Gateway**: **REST** (or **GraphQL**) for **browser** reach, **CDN** caching, **easy debugging**, broad compatibility.
- **Gateway ↔ internal service**: **gRPC** to save **bandwidth**, preserve **strong contracts**, and use **streaming** when needed.
- **Service ↔ service internal**: **gRPC** for synchronous, **message queue** (**Kafka**, **RabbitMQ**) for asynchronous.

**Google**, **Netflix**, **Uber**, and most sizable companies run this shape — not because **gRPC** is "modern", but because at their scale **millions of internal RPCs per minute** make the cost of **JSON over HTTP/1.1** impossible to justify.

**REST vs gRPC** is not a **good-vs-bad** choice — it is **picking the right tool for the communication axis**: at the edge, **compatibility and consumability** beat raw optimization; inside the system, **performance and contracts** beat familiarity. Avoid the two extremes: (1) **REST for everything** and then bleeding bandwidth as you scale, and (2) forcing **gRPC on browser clients** and suffering under **gRPC-Web proxies** and awkward debugging. Go **Hybrid** once you have the scale — that is why most **senior architects** default to this answer in interviews.

# references
## 0
### alias
gRPC — Official Introduction
### url
https://grpc.io/docs/what-is-grpc/introduction/
## 1
### alias
NestJS — gRPC Microservice
### url
https://docs.nestjs.com/microservices/grpc
## 2
### alias
Google — Protocol Buffers
### url
https://protobuf.dev/overview/

# minutesRead
25
