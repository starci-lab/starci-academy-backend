# title
Giao tiếp bất đồng bộ — Event-Driven với Kafka

# description
Kết nối microservices qua event thay vì gọi đồng bộ — demo Order (Producer) phát ORDER_CREATED xuống Kafka để Inventory và Notification tự phản ứng, rồi đọc sâu về Consumer Group, persistent log, at-least-once và failure mode của event-driven.

# body

## I. Lời mở đầu

Phỏng vấn **Senior Backend**, câu hỏi gài hay rơi vào: *"User đặt đơn, em gọi **Inventory** trừ kho và **Notification** gửi mail đồng bộ à? **Notification** chậm **3 giây** hoặc **sập** thì user có thấy lỗi khi bấm 'Đặt hàng' không?"*. **Beta** thường trả lời: *"em `await` lần lượt cho chắc"* — đáp án đó **làm lộ** ngay vấn đề: luồng đặt hàng bị **trói** vào dịch vụ gửi mail, **throughput** giới hạn bởi service **chậm nhất**; tuần sau thêm **Analytics**, **Fraud**, **CRM** — lại sửa đúng file `order.service.ts` và đẩy rủi ro vào core. Trong khi về nghiệp vụ, user chỉ cần đơn được ghi nhận — mail đến **5 giây** sau cũng chẳng ai phàn nàn.

Cách giải quyết đó là đảo hướng: dịch vụ nguồn chỉ **phát event** rồi trả kết quả ngay; ai quan tâm thì **tự lắng nghe**. Ta dùng **Kafka** ở phần sau để chạm bản chất của **event-driven** — đọc tiếp.

## II. Demo trực quan và thực hành

**Ví dụ** dưới đây là ba **service** **NestJS** trong một **monorepo** kết nối qua **Kafka**: **`order`** (cổng **3001**) là **Producer**, phát event **`ORDER_CREATED`** vào topic **`order-events`**; **`inventory`** (**3002**) và **`notification`** (**3003**) là hai **Consumer** thuộc **hai Consumer Group khác nhau** (**`inventory-grp`** và **`notification-grp`**) — vì khác group, cả hai đều nhận event (mô hình **broadcast** / fan-out). **Kafka** chạy ở chế độ **KRaft** qua **Docker** (cổng **9092**), lưu event trên **disk** dưới dạng **persistent log** có **offset** — consumer offline quay lại vẫn replay được từ offset đã commit.

**Clone** ở đây: [Asynchronous Event-Driven — demo (NestJS monorepo + Kafka)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/asynchronous-event-driven)

| Thành phần | Cổng | Công nghệ | Trách nhiệm (rút gọn) |
|-------------|------|-----------|------------------------|
| **Order** | **3001** | **NestJS** | **POST /orders** → ghi DB → publish **`ORDER_CREATED`** lên **`order-events`** |
| **Kafka** | **9092** | **Kafka** (KRaft) | **Broker** + **persistent log**; giữ event, theo dõi offset mỗi group |
| **Inventory** | **3002** | **NestJS** | Consumer group **`inventory-grp`**; nghe **`order-events`** → trừ kho |
| **Notification** | **3003** | **NestJS** | Consumer group **`notification-grp`**; nghe **`order-events`** → gửi thông báo |

![Sơ đồ Event-Driven — Order publish, Kafka fan-out tới Inventory và Notification](https://starci.org/system-design-mastery/asynchronous-event-driven/0.svg)

*Hình 1. Sơ đồ kiến trúc hệ thống từ source code trên.*

**Order** phát event, **Kafka** giữ log có offset, hai consumer khác group **cùng** đọc cùng event — **Order** không biết và không cần biết có mấy consumer đang nghe.

### 1. Chuẩn bị và chạy môi trường

Giả định đã cài **Docker** và **Node.js** (LTS). Trong **repo** (đã **clone**):

1. Khởi chạy **Kafka** (chế độ **KRaft**):

```
docker compose -f .docker/kafka.yaml up -d
```

2. Cài dependency:

```
npm install
```

3. Mở **ba terminal**, mỗi terminal một **service**:

```
npx nest start order --watch
```

```
npx nest start inventory --watch
```

```
npx nest start notification --watch
```

**Kết quả mong đợi**

**Kafka broker** sẵn sàng tại cổng **9092**; ba **service** chạy tại **3001** (Order), **3002** (Inventory), **3003** (Notification). **Inventory** và **Notification** đăng ký **subscribe** topic **`order-events`** với **Consumer Group ID** riêng.

**Kết luận**

Một **Producer** và hai **Consumer** độc lập, kết nối qua **Kafka** — **Order** không gọi **Inventory** hay **Notification** trực tiếp; đường duy nhất là **event** qua **broker**.

### 2. Đặt đơn → cả hai consumer tự phản ứng song song

Bạn có thể **làm theo** bằng **app có giao diện** (**Postman**, **Insomnia**, **Bruno** …) **hoặc** bằng **`curl`** trên **Linux**, **macOS** hoặc **WSL2**.

**Các bước thực hiện:**

**Bước 1:** Tạo đơn hàng qua **Order**.

- Method: **POST**
- URL: `http://localhost:3001/orders`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "productId": "p-001",
  "quantity": 2
}
```

**Câu lệnh `curl` tương đương**:

```
curl -X POST http://localhost:3001/orders -H "Content-Type: application/json" -d "{\"productId\":\"p-001\",\"quantity\":2}"
```

**Response** trả ngay (HTTP 2xx), **không đợi** **Inventory** hay **Notification** — **Order** chỉ publish event xong là trả client.

**Bước 2:** Quan sát log hai terminal **Inventory** và **Notification**.

**Kết quả mong đợi**

**Order** ghi DB và publish **`ORDER_CREATED`** lên **`order-events`**. **Inventory** log nhận event → trừ kho `p-001` đi **2**. **Notification** log nhận **cùng event đó** → gửi thông báo. Cả hai xử lý **song song**, **độc lập**; response của client được trả **ngay** mà không đợi hai consumer xong.

**Kết luận**

Hai consumer khác **Consumer Group** nên **cả hai đều nhận event** — đây là **broadcast** / fan-out theo Kafka. **Order** không biết có mấy consumer nghe; thêm **Analytics Service** vào sau chỉ là subscribe topic mới, **không** đụng code **Order**.

### 3. Consumer offline — Kafka giữ event, quay lại replay được

Điểm khác biệt cốt lõi của **Kafka** so với pub/sub thuần: **persistent log** cho phép consumer đã offline vẫn nhận được event cũ khi kết nối lại (theo offset đã commit).

**Các bước thực hiện:**

**Bước 1:** Tắt **Notification Service** (Ctrl+C ở terminal 3).

**Bước 2:** Tạo đơn mới trong lúc Notification đang offline.

- Method: **POST**
- URL: `http://localhost:3001/orders`
- Body:

```
{
  "productId": "p-002",
  "quantity": 1
}
```

```
curl -X POST http://localhost:3001/orders -H "Content-Type: application/json" -d "{\"productId\":\"p-002\",\"quantity\":1}"
```

**Bước 3:** Quan sát — **Inventory** vẫn xử lý bình thường.

**Bước 4:** Khởi chạy lại **Notification Service** và quan sát log.

```
npx nest start notification --watch
```

**Kết quả mong đợi**

Trong khi **Notification** offline: **Inventory** vẫn nhận event mới và trừ kho `p-002` — producer **không** bị ảnh hưởng. **Kafka** giữ event đó trong **`order-events`** ở đúng **offset** mà **`notification-grp`** chưa consume. Khi **Notification** quay lại, nó đọc từ offset cũ, xử lý **bù** event đã miss — thông báo cho đơn `p-002` được gửi **muộn** nhưng **không mất**.

**Kết luận**

**Kafka** ≠ pub/sub **fire-and-forget**: nó là **distributed event log** có **offset per consumer group**. Consumer chết vài phút rồi lên lại vẫn **catch up** đủ event. Đây là lý do Kafka được dùng cho các nghiệp vụ **không được mất** (thanh toán, giao dịch, audit) — khác với **Redis Pub/Sub** vốn fire-and-forget.

Sau hai luồng trên, tiếp theo là các **khái niệm** cốt lõi và **edge case** khi triển khai **event-driven** thật.

## III. Giải thích nâng cao và kết luận

### 1. Event-driven là gì và tại sao nó quan trọng trong microservices

**Event-driven architecture** là kiểu giao tiếp trong đó **service** công bố **điều đã xảy ra** (**event** như **`ORDER_CREATED`**, **`PAYMENT_COMPLETED`**) ra một **message broker**, và các service khác **tự đăng ký** lắng nghe để phản ứng. Khác với **command** (yêu cầu "làm X") của **REST**/**gRPC**, **event** là thông báo sự thật ở thì **quá khứ** — **producer** không quan tâm **ai** xử lý, **bao nhiêu** service xử lý, hoặc xử lý **khi nào**. Kết quả là **temporal decoupling** (không bị khóa theo thời gian) và **spatial decoupling** (không cần biết địa chỉ nhau).

- **Ví dụ:** Demo ở phần trên — **Order** publish **`ORDER_CREATED`** xong là xong; **Inventory** và **Notification** đọc khi rảnh, xử lý độc lập. Muốn thêm **Analytics Service** tính doanh thu realtime: chỉ cần subscribe **`order-events`** với một **Consumer Group** mới, **không** đụng code **Order**.

### 2. Apache Kafka — phân biệt với message queue thuần

**Kafka** được giới thiệu là "message broker" nhưng **khác** các queue truyền thống (**RabbitMQ classic queue**, **ActiveMQ**) ở một điểm gốc: **Kafka là distributed commit log**, **không** phải hàng đợi xóa-sau-khi-consume.

- **Topic & Partition:** **Topic** là kênh logic (ví dụ **`order-events`**); mỗi topic chia thành **partition** để scale — event cùng key đi cùng partition, giữ thứ tự trong partition.
- **Offset:** Mỗi event có một **offset** (số nguyên tăng dần trong partition). Consumer tự **commit** offset đã xử lý; Kafka **không xóa** event khi consume — chỉ xóa theo **retention** (thời gian hoặc dung lượng).
- **Consumer Group:** Một nhóm consumer **chia** message trong cùng group (load balancing); **hai group khác nhau** đều nhận **đầy đủ** event (broadcast).
- **Replay:** Vì event còn trên disk, consumer mới (hoặc consumer reset offset) có thể **replay** lịch sử — cực hữu ích cho **CQRS**, **Event Sourcing**, rebuild **Read Model**.
- **Throughput:** Kafka thiết kế để đạt **triệu event/giây** trên một cluster nhờ append-only log + sequential disk write — nhanh hơn broker-truyền-thống một vài bậc.

### 3. Consumer Group — load balance vs broadcast

Đây là cơ chế quyết định hành vi fan-out, là khái niệm **beta** hay nhầm nhất:

- **Cùng Consumer Group (load balance):** Chạy **5 replica** của **Inventory Service** cùng `groupId = inventory-grp` → Kafka chia partition cho 5 instance, mỗi event chỉ **một instance** xử lý. Đây là **scale horizontal** tự nhiên — muốn gấp đôi throughput xử lý, nhân đôi replica (tối đa bằng số partition).
- **Khác Consumer Group (broadcast):** **Inventory** (group `inventory-grp`) và **Notification** (group `notification-grp`) cùng subscribe `order-events` → **cả hai** nhận đầy đủ event; mỗi group có offset riêng. Demo phần trên chính là mô hình này.

Muốn nhiều service **cùng** nhận event: mỗi service một group. Muốn nhiều replica của **một** service **chia** tải: cùng một group.

### 4. Trade-off và failure mode

**Event-driven** không phải liều thuốc tiên — vài vết thương nặng thường gặp:

- **Eventual consistency.** Sau `OrderCreated`, kho có thể chưa trừ trong **ms → giây**; user refresh sớm có thể thấy trạng thái cũ. Giải: UI hiển thị trạng thái chờ, **polling** hoặc **WebSocket** cập nhật, thiết kế nghiệp vụ **chấp nhận** trễ có giới hạn.
- **At-least-once delivery.** Kafka mặc định **at-least-once**: consumer có thể nhận **cùng một event hai lần** (do retry, rebalance). Giải: consumer phải **idempotent** — ghi nhận theo **event id** hoặc **business key**, xử lý lần hai không tạo hiệu ứng hai lần.
- **Ordering chỉ trong partition.** Kafka đảm bảo thứ tự **trong** một partition, **không** xuyên partition. Event cùng nghiệp vụ (ví dụ cùng `orderId`) phải cùng **partition key** để giữ thứ tự. Bỏ qua điều này → **`OrderCancelled`** đến **trước** **`OrderCreated`**.
- **Debug khó hơn đồng bộ.** Stack trace không xuyên request — lỗi cuối chuỗi event có thể ở service xa gốc. Giải: **distributed tracing** (**OpenTelemetry**, **Jaeger**) chuyển **trace id** theo event header; **correlation id** gắn vào payload.
- **Broker là nền tảng mới cần vận hành.** **Kafka cluster** **không** là "queue nhẹ" — cần **3+ broker** cho HA, cần tune **partition count**, **retention**, **replica factor**, cần monitor **ISR**, **consumer lag**. Team nhỏ chưa sẵn có thể dùng **managed Kafka** (Confluent Cloud, MSK, Upstash) để giảm gánh.
- **Ghi DB và publish event không nguyên tử.** Service ghi DB **commit thành công** nhưng chưa kịp publish event (hoặc ngược lại) → trạng thái lệch. Giải: **Transactional Outbox** — ghi outbox cùng transaction nghiệp vụ, worker nền đọc outbox và publish vào Kafka với **at-least-once**.

### 5. Khi nào dùng event-driven, khi nào dùng đồng bộ

Không phải mọi giao tiếp đều nên **bất đồng bộ** — dùng sai làm kiến trúc phức tạp không cần thiết:

- **Dùng event-driven khi:** Fan-out một action ra nhiều hệ quả (đặt đơn → trừ kho + gửi mail + cập nhật analytics + check fraud); producer không cần kết quả ngay; **temporal decoupling** quan trọng (consumer được phép offline); cần **replay** lịch sử (rebuild read model, audit).
- **Dùng đồng bộ (REST/gRPC) khi:** User cần **kết quả ngay** trong cùng request (lấy thông tin tài khoản, check giá); cần **strong consistency** tức thời; luồng nghiệp vụ thật sự yêu cầu biết **ngay** thành công hay thất bại (ví dụ trừ tiền khi mua hàng — nên đồng bộ + compensation, không nên fire event rồi quên).
- **Hybrid thường gặp:** **Đồng bộ** cho đường **request-response** cốt lõi, **event-driven** cho các **side effect** (notify, analytics, reindex search, cache invalidate).

**Event-driven** không phải "REST cho người hiện đại" — đây là một **mô hình giao tiếp khác** với **cam kết khác**: đổi **phản hồi đồng bộ chắc chắn** lấy **decoupling mạnh**, **scale độc lập**, và **khả năng replay**. Khi đã chọn con đường này, hãy đầu tư đúng vào **observability** (trace id xuyên event, monitor consumer lag), **Transactional Outbox** (tránh lệch DB với broker), và **idempotency consumer** (xử lý trùng không sinh lỗi). Bỏ qua ba mảng đó, bạn sẽ có một hệ thống **event-driven nhưng không tin cậy** — và đó là kiểu kiến trúc **tệ hơn** cả **REST thuần** vì nó khó debug hơn nhiều.

# references
## 0
### alias
Apache Kafka — Introduction
### url
https://kafka.apache.org/intro
## 1
### alias
NestJS — Kafka Microservice
### url
https://docs.nestjs.com/microservices/kafka
## 2
### alias
Microservices.io — Transactional Outbox
### url
https://microservices.io/patterns/data/transactional-outbox.html

# minutesRead
30
