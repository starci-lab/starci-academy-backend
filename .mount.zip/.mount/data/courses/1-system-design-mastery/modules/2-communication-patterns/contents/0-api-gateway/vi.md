# title
API Gateway Pattern

# description
Đặt Kong API Gateway (chế độ DB — PostgreSQL) trước ba microservices để tập trung routing, auth và rate-limit vào một cổng duy nhất; cấu hình động qua Admin API hoặc GUI Konga, rồi đọc sâu BFF, edge concerns, và bẫy biến gateway thành monolith mới.

# body

## I. Lời mở đầu

Phỏng vấn **Senior Backend**, câu hỏi gài hay rơi vào: *"Hệ thống có **10 microservice**, mỗi service một cổng — app mobile gọi thẳng từng service à? Nếu có thì **auth**, **rate-limit** và **log** em đặt ở đâu?"*. **Beta** thường trả lời: *"em copy middleware **JWT** vào cả 10 service"* — đáp án đó **làm lộ** ngay vấn đề: mỗi lần đổi logic **xác thực** phải sửa **10 repo**, **10 pipeline**, chưa kể hai team quên đồng bộ version là hệ thống lỗ hổng bảo mật. Tệ hơn, client (web/mobile) phải **nhớ** tọa độ mọi service; đổi một cổng trong nội bộ thì cả app client phải **release mới**.

Cách giải quyết đó là đặt **một lớp trung gian** đứng trước mọi **service** để gánh phần chung, để backend chỉ còn lo nghiệp vụ. Ta dùng **Kong** ở phần sau để chạm bản chất của **API Gateway** — đọc tiếp.

## II. Demo trực quan và thực hành

**Ví dụ** dưới đây là một **Kong Gateway** ở chế độ **DB mode** với **PostgreSQL** làm config store, đứng trước ba **service** **NestJS** **`user-service`** (**3001**), **`product-service`** (**3002**), **`order-service`** (**3003**) — tất cả trong cùng **monorepo**. Client **chỉ** gọi **cổng 8000** của **Kong** (proxy); **operator** có thể dùng **Admin API** tại **cổng 8001**, **Kong Manager** tại **cổng 8002**, hoặc **GUI Konga** tại **cổng 1337** để **đăng ký services**, **routes**, **plugins** — mỗi thao tác đều ghi xuống **PostgreSQL** ở **cổng 5433**. Kong sinh được **HA**: nhiều node Kong cùng đọc cấu hình từ DB chung, sửa một chỗ là mọi node đồng bộ.

**Clone** ở đây: [API Gateway — demo (NestJS monorepo + Kong + Konga)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/api-gateway)

| Thành phần | Cổng | Công nghệ | Trách nhiệm (rút gọn) |
|-------------|------|-----------|------------------------|
| **Kong proxy** | **8000** | **Kong 3.9** (DB mode) | Nhận request client, apply **routes** + **plugins** rồi forward |
| **Kong Admin API** | **8001** | **Kong 3.9** | **CRUD** services / routes / plugins / consumers qua HTTP |
| **Kong Manager** | **8002** | **Kong 3.9** | GUI quản trị **chính chủ** của Kong |
| **Kong Database** | **5433** (host) → **5432** (container) | **PostgreSQL 16** | Lưu **toàn bộ cấu hình Kong** (services, routes, plugins, consumers, credentials) |
| **Konga** | **1337** | **pantsel/konga** | **GUI** bên thứ ba — quản lý nhiều Kong node trực quan hơn |
| **Konga Database** | nội bộ | **PostgreSQL 16** | Lưu users, connections, snapshots của Konga (tách khỏi DB Kong) |
| **User Service** | **3001** | **NestJS** | Nghiệp vụ người dùng, không tự lo **auth biên** |
| **Product Service** | **3002** | **NestJS** | Nghiệp vụ sản phẩm |
| **Order Service** | **3003** | **NestJS** | Nghiệp vụ đơn hàng |

![Sơ đồ API Gateway — Kong (DB mode + PostgreSQL) + Konga đứng trước ba microservice](https://starci.org/system-design-mastery/api-gateway/0.svg)

*Hình 1. Sơ đồ kiến trúc hệ thống từ source code trên.*

Client đi qua **Kong proxy (8000)**; operator/CI đẩy cấu hình qua **Admin API (8001)**, **Kong Manager (8002)**, hoặc **Konga (1337)** → cả ba đều ghi xuống **PostgreSQL** của Kong; Kong đọc cấu hình từ DB rồi route về đúng service; cross-cutting concerns nằm trong **Kong**, không lặp trong từng service.

### 1. Chuẩn bị và chạy môi trường

Giả định đã cài **Docker** và **Node.js** (LTS). Trong **repo** (đã **clone**):

1. Khởi chạy **toàn bộ stack Kong + Konga** bằng một lệnh duy nhất:

```
docker compose -f .docker/kong.yaml up -d
```

File compose này dựng sáu service: **`kong-database`** (Postgres 16 cho Kong, publish **5433** ra host), **`kong-migrations`** (chạy `kong migrations bootstrap` rồi thoát), **`kong`** (gateway chính — proxy **8000**, admin API **8001**, Kong Manager **8002**), **`konga-database`** (Postgres riêng cho Konga), **`konga-migrations`** (chuẩn bị schema Konga rồi thoát), và **`konga`** (GUI tại **1337**). Nhờ `depends_on` + `healthcheck`, thứ tự **DB healthy → migration xong → gateway / GUI start** tự được đảm bảo; thầy không phải chạy từng bước tay. Ở local dùng mật khẩu mặc định (`kongpass`, `kongapass`); production **bắt buộc** đổi qua **secret manager**, không hardcode.

2. Cài dependency và chạy ba backend **service**:

```
npm install
```

Mở **ba terminal**:

```
npx nest start user-service --watch
```

```
npx nest start product-service --watch
```

```
npx nest start order-service --watch
```

**Kết quả mong đợi**

Postgres (Kong) lắng **5433** trên host; Kong **proxy** lắng **8000**, **Admin API** lắng **8001**, **Kong Manager** lắng **8002**; **Konga** lắng **1337**; ba service NestJS lắng **3001**, **3002**, **3003**. Kiểm tra Kong đã nối được DB:

```
curl -s http://localhost:8001/status
```

Response có trường **`database.reachable: true`** tức là Kong đã đọc/ghi được **PostgreSQL**.

**Kết luận**

Kong đã chạy nhưng **chưa biết** route nào trỏ service nào — khác với DB-less có sẵn file YAML. Mọi **services** và **routes** phải được **đăng ký qua Admin API** ở bước kế.

### 2. Đăng ký services và routes qua Admin API

Bạn có thể **làm theo** bằng **app có giao diện** (**Postman**, **Insomnia**, **Bruno** …) **hoặc** bằng **`curl`** trong **terminal** trên **Linux**, **macOS** hoặc **WSL2** (trên Windows).

**Các bước thực hiện:**

**Bước 1:** Đăng ký **upstream service** cho User.

- Method: **POST**
- URL: `http://localhost:8001/services`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "name": "user-service",
  "url": "http://host.docker.internal:3001"
}
```

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X POST http://localhost:8001/services -H "Content-Type: application/json" -d "{\"name\":\"user-service\",\"url\":\"http://host.docker.internal:3001\"}"
```

**Bước 2:** Gắn **route** `/users` vào service vừa tạo.

- Method: **POST**
- URL: `http://localhost:8001/services/user-service/routes`
- Body:

```
{
  "name": "user-route",
  "paths": ["/users"],
  "strip_path": false
}
```

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X POST http://localhost:8001/services/user-service/routes -H "Content-Type: application/json" -d "{\"name\":\"user-route\",\"paths\":[\"/users\"],\"strip_path\":false}"
```

**Bước 3:** Lặp lại cho **Product** và **Order**.

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X POST http://localhost:8001/services -H "Content-Type: application/json" -d "{\"name\":\"product-service\",\"url\":\"http://host.docker.internal:3002\"}"
curl -X POST http://localhost:8001/services/product-service/routes -H "Content-Type: application/json" -d "{\"name\":\"product-route\",\"paths\":[\"/products\"],\"strip_path\":false}"

curl -X POST http://localhost:8001/services -H "Content-Type: application/json" -d "{\"name\":\"order-service\",\"url\":\"http://host.docker.internal:3003\"}"
curl -X POST http://localhost:8001/services/order-service/routes -H "Content-Type: application/json" -d "{\"name\":\"order-route\",\"paths\":[\"/orders\"],\"strip_path\":false}"
```

**Bước 4:** Kiểm tra cấu hình đã ghi xuống Postgres.

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -s http://localhost:8001/services | jq
curl -s http://localhost:8001/routes | jq
```

Hai lệnh này đọc thẳng bảng **`services`** và **`routes`** trong Postgres qua Admin API. Nếu thầy `docker exec` vào container Postgres và chạy `psql -U kong -d kong -c "SELECT name, host, port FROM services;"` sẽ thấy đúng ba dòng vừa tạo.

**Kết quả mong đợi**

Ba cặp **service + route** đã tồn tại trong Kong; **Admin API** trả về đầy đủ metadata; Postgres giữ mọi thứ bền vững — **restart Kong container, cấu hình không mất**.

**Kết luận**

Đây là khác biệt cốt lõi của **DB mode**: cấu hình là **state trong DB**, không phải file. Điểm mạnh — sửa động, không cần restart Kong, nhiều Kong node share DB chung (horizontal scale); điểm yếu — mất tính "khai báo tường minh trong Git", cần công cụ như **decK** để xuất ngược cấu hình ra YAML nếu muốn GitOps.

### 3. Gọi ba service qua một cổng duy nhất

**Các bước thực hiện:**

**Bước 1:** Gọi **Users** qua **Kong proxy**.

- Method: **GET**
- URL: `http://localhost:8000/users`

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X GET http://localhost:8000/users
```

**Bước 2:** Tạo user mới qua Kong.

- Method: **POST**
- URL: `http://localhost:8000/users`
- Body:

```
{
  "name": "Nguyen Van A",
  "email": "a@example.com"
}
```

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X POST http://localhost:8000/users -H "Content-Type: application/json" -d "{\"name\":\"Nguyen Van A\",\"email\":\"a@example.com\"}"
```

**Bước 3:** Gọi **Products** và **Orders** qua Kong.

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X GET http://localhost:8000/products
curl -X GET http://localhost:8000/orders
```

**Kết quả mong đợi**

Cả bốn request vào cùng **`localhost:8000`** đều trả đúng dữ liệu của **service** tương ứng. Client **không** cần biết **3001**, **3002**, **3003**; log truy cập ghi nhận tập trung tại **Kong** (stdout của container).

**Kết luận**

Client nhìn hệ thống là **một endpoint** duy nhất; nội bộ vẫn là **ba service riêng** có thể đổi cổng, thêm replica, thay công nghệ mà client **không** phải sửa. Mọi **đổi route** hay **thêm plugin** (ví dụ **rate-limit** cho `/orders`) đều là một **lệnh `POST`** xuống Admin API — **không** restart gì cả.

### 4. Bật plugin rate-limit — minh họa sức mạnh của DB mode

Điểm mà DB mode phát huy: **plugin** có thể bật ngay trong runtime, không cần deploy lại Kong.

**Các bước thực hiện:**

**Bước 1:** Bật plugin **`rate-limiting`** cho route `/orders`, giới hạn **5 req/phút**.

- Method: **POST**
- URL: `http://localhost:8001/routes/order-route/plugins`
- Body:

```
{
  "name": "rate-limiting",
  "config": {
    "minute": 5,
    "policy": "local"
  }
}
```

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X POST http://localhost:8001/routes/order-route/plugins -H "Content-Type: application/json" -d "{\"name\":\"rate-limiting\",\"config\":{\"minute\":5,\"policy\":\"local\"}}"
```

**Bước 2:** Bắn **7 request** liên tiếp vào `/orders` và quan sát header.

```
for ($i=1; $i -le 7; $i++) { curl -s -o nul -w "%{http_code}`n" http://localhost:8000/orders }
```

Hoặc trên **Linux/macOS/WSL2**:

```
for i in {1..7}; do curl -s -o /dev/null -w "%{http_code}\n" http://localhost:8000/orders; done
```

**Kết quả mong đợi**

Năm request đầu trả **200**; request thứ sáu và bảy trả **429 Too Many Requests**. Header response có các trường **`X-RateLimit-Limit-Minute: 5`**, **`X-RateLimit-Remaining-Minute: 0`**, **`Retry-After`** — Kong tự quản lý, backend NestJS **không phải viết một dòng code** nào về rate-limit.

**Kết luận**

Thêm một **đảm bảo biên** chỉ tốn **một lệnh HTTP** xuống Admin API, ghi vào Postgres, và có hiệu lực **ngay lập tức** cho mọi Kong node đọc chung DB. Tháo plugin cũng chỉ là **`DELETE`** trên endpoint tương ứng — đây là sức mạnh thật của DB mode so với sửa-file-rồi-reload của DB-less.

### 5. Quản lý Kong trực quan bằng Konga

Toàn bộ cấu hình ở trên được **tạo bằng `curl`** xuống Admin API — rất hợp cho **script hóa** và **CI**, nhưng khó đọc khi hệ thống đã có hàng chục routes và plugins. **Konga** (bên thứ ba) gắn vào **cùng Admin API (:8001)** và trình bày mọi thứ dưới dạng bảng biểu, form — không ghi đè, không thay thế; nó chỉ là **một client khác** của cùng một Kong.

**Các bước thực hiện:**

**Bước 1:** Mở **`http://localhost:1337`** lần đầu → tạo tài khoản admin cục bộ (username + password + email).

**Bước 2:** Vào **`CONNECTIONS` → `NEW CONNECTION`**, điền:

- **Name:** `kong-gateway`
- **Kong Admin URL:** `http://kong:8001`

Lưu ý: dùng **service name trong Docker network** (`kong`), **không** dùng `localhost` — vì Konga chạy trong container chứ không phải trên host.

**Bước 3:** Sau khi **`ACTIVATE`** connection, mở tab **`SERVICES`** → sẽ thấy đủ **`user-service`**, **`product-service`**, **`order-service`** đã tạo ở bước 2. Vào tab **`ROUTES`** để thấy **`user-route`**, **`product-route`**, **`order-route`**. Vào tab **`PLUGINS`** → thấy plugin **`rate-limiting`** đang gắn vào **`order-route`** từ bước 4.

**Bước 4:** Thử sửa động bằng GUI — bấm vào **`order-route`**, mở tab **`Plugins`**, đổi `minute` từ **5** xuống **3**, **`SUBMIT`**. Ngay sau đó chạy lại vòng lặp `curl` 7 request, lần này **request thứ tư** đã bị **429**.

**Kết quả mong đợi**

Cùng một cấu hình nhìn được bằng hai cách: **`curl` + `jq`** để script / review trong **Git**, và **Konga** để người mới onboarding hoặc **non-engineer** (SRE junior, QA) thấy tổng quan mà không cần học Admin API.

**Kết luận**

**Admin API** là **nguồn sự thật duy nhất**; **Konga** (và **Kong Manager**) chỉ là **GUI** gọi xuống nó. Điều đó có nghĩa: thao tác ở Konga cũng ghi xuống **PostgreSQL**, cũng đồng bộ cho mọi Kong node, cũng audit được. Trong production, kỷ luật là **vẫn giữ Admin API trong network nội bộ**, chỉ để Konga / Kong Manager (có auth riêng) làm cổng vào cho con người; **không** expose **`:8001`** ra Internet dù đã có GUI đẹp.

Sau năm luồng vừa chạy, tiếp theo là các **khái niệm** và **bẫy** của **API Gateway** khi triển khai thật.

## III. Giải thích nâng cao và kết luận

### 1. API Gateway là gì và tại sao nó quan trọng trong microservices

**API Gateway** là một **reverse proxy có logic** đứng ở **biên** hệ thống: nó nhận mọi request từ client, chạy một chuỗi **plugin** / **filter** (auth, rate-limit, transform, log) rồi chuyển tiếp về **service** phía sau dựa trên **route**. Nó gom các **edge concerns** — những thứ **không** phải nghiệp vụ nhưng **mọi** request đều phải đi qua — vào **một chỗ** để các **service** chỉ còn lo phần nghiệp vụ thuần. Đây là lý do ngay cả hệ **3 service** cũng có lợi khi đặt **Gateway**: bạn **không** muốn viết **JWT middleware** ba lần rồi phát hiện version lệch.

- **Ví dụ:** Demo ở phần trên cho client gọi **`localhost:8000/users`** thay vì **`localhost:3001/users`** — **Kong** ánh xạ prefix, client **không** cần biết cổng nội bộ; đổi cổng service chỉ là **`PATCH`** xuống Admin API, không release client.

### 2. Kong DB mode vs DB-less — chọn kiểu nào

**Kong** hỗ trợ hai kiểu deployment, mỗi kiểu phù hợp một ngữ cảnh vận hành:

- **DB mode (bài này):** Config sống trong **PostgreSQL** (hoặc **Cassandra** ở các bản cũ). Sửa động qua **Admin API**, không cần restart; nhiều node Kong share cùng DB — **horizontal scale** tự nhiên; hỗ trợ đầy đủ **consumers**, **credentials**, **rate-limit counter** tập trung; hợp cho team đã có **Konga**/**Kong Manager** hoặc **decK** làm pipeline. Đánh đổi: thêm một stateful service (Postgres) phải vận hành — backup, HA, tune, và single source of truth là DB chứ không phải Git.
- **DB-less:** Config là **`kong.yml`** mount vào container; mọi thay đổi là commit Git → rebuild/reload. GitOps thuần, hạ tầng stateless, dễ rollback. Điểm yếu: **consumers** và **credentials** khó dùng (không lưu động); mọi node phải nhận cùng file; plugin trạng thái (rate-limit distributed) cần backend ngoài như **Redis**.
- **Quy tắc chọn:** Team nhỏ, ít route, muốn GitOps → **DB-less**. Team lớn, nhiều route, cần **dynamic consumers** (tạo API key cho từng khách hàng), nhiều node Kong — **DB mode** với **PostgreSQL** là mặc định công nghiệp.

### 3. Các chức năng cốt lõi thường gom vào Gateway

Không phải Gateway nào cũng có đủ; tùy sản phẩm mà bạn bật/tắt từng lớp:

- **Routing / path rewriting:** Map **`/api/v1/orders`** → **Order Service**; rewrite path nội bộ; **weighted routing** cho canary deploy.
- **Authentication & Authorization:** Kiểm **JWT** / **OAuth2** / **mTLS** tại biên; **strip** header nhạy cảm trước khi forward; đính kèm **claims** đã verify vào header cho backend đọc.
- **Rate-limiting & quota:** Giới hạn theo **IP**, **API key**, **user**; chống abuse ở biên trước khi tải rơi vào backend.
- **Request / response transform:** Đổi format (XML ↔ JSON), thêm/bỏ header, gom kết quả từ nhiều backend.
- **Observability:** **Access log**, **trace id** injection (chuẩn **W3C Trace Context**), metric **per-route**, **audit**.
- **Caching ở biên:** Cache **GET** theo **ETag** hoặc **TTL** — giảm tải backend cho tài nguyên public.
- **SSL / TLS termination:** Gateway nắm chứng chỉ, backend nói **HTTP** nội bộ — giảm gánh nặng cho service.

### 4. BFF (Backend for Frontend) vs API Gateway đơn

**Gateway** đơn (như demo) phục vụ **một nhóm client** hoặc nhiều client cùng shape. Khi **web** và **mobile** có nhu cầu rất khác nhau (mobile cần payload nhỏ, gộp nhiều endpoint; web có thể gọi nhiều API độc lập), đặt **một Gateway "to"** cố gắng chiều cả hai thường dẫn đến mớ **conditional logic**. Pattern **BFF** (Sam Newman) đề xuất: mỗi loại client có **một Gateway riêng** — **BFF-Mobile**, **BFF-Web**, **BFF-Partner** — mỗi BFF tối ưu shape dữ liệu và UX cho đúng client mình phục vụ; backend service **không** bị ép chạy theo yêu cầu lặt vặt của từng UI.

- **Ví dụ:** **BFF-Mobile** gộp **`GET /orders` + `GET /user` + `GET /inventory`** thành **`GET /home`** trả gói dữ liệu gọn cho màn hình chính; **BFF-Web** để web tự orchestrate ba call riêng vì băng thông thoải mái.

### 5. Trade-off và bẫy vận hành

**Gateway** không miễn phí — đây là vài mặt tối thường gặp:

- **Single point of failure biên.** Cả hệ đi qua **một** process **Kong** / **NGINX**; nó chết thì toàn bộ **API** chết. Giải: chạy **≥ 2 instance** Kong sau **Load Balancer** (hoặc **cloud-managed API Gateway**), health check sâu, tự động **failover**. Với DB mode, đừng quên **Postgres HA** (primary + replica) — DB sập cũng kéo Kong theo.
- **Thêm độ trễ.** Mỗi request **+1 hop** — plugin nặng (JWT verify, rate-limit distributed, body transform) có thể cộng **5–30 ms**. Giải: **benchmark** plugin chain, tắt plugin không dùng, tách **path nhanh** vs **path giàu logic**.
- **Admin API là vector tấn công.** Cổng **8001** cho phép **CRUD toàn bộ cấu hình** — lộ ra Internet là thảm họa. Kỷ luật: **bind Admin API vào network nội bộ**, bảo vệ bằng **mTLS** hoặc **RBAC** (**Kong Manager Enterprise**), không bao giờ expose ra client.
- **Gateway phình thành "Monolith biên".** Team đua nhau nhét business logic vào plugin vì "dễ hơn sửa service" — vài tháng sau, cấu hình trong Postgres dài **hàng ngàn dòng**, đổi plugin phải review cả đội. **Quy tắc kỷ luật:** Gateway chỉ xử lý **cross-cutting concerns**; logic nghiệp vụ **ở service**, **không** ở gateway.
- **Version lock.** Gateway giữ tất cả **route contract**; đổi một **route** chung cần phối hợp với rất nhiều consumer. Giải: **versioning** ở path (`/v1`, `/v2`) hoặc header, **deprecation** có timeline.
- **Debugging xuyên nhiều tầng.** Một request chạy qua **client → LB → Gateway → service → DB**; thiếu **distributed tracing** thì truy lỗi rất khó. Giải: **trace id** bắt buộc ở Gateway, chuyển xuống header cho backend; tích hợp **OpenTelemetry** / **Jaeger**.

### 6. Khi nào **chưa** cần API Gateway

Không phải dự án nào cũng cần **Gateway** từ ngày đầu. Với **monolith** đơn hoặc **2–3 service** nhỏ dùng cùng một **middleware** nội bộ (ví dụ **NestJS** chia sẻ package auth), đặt **Gateway** thêm một tầng đôi khi **thừa** và làm onboarding dài hơn. Tín hiệu rõ để kéo **Gateway** vào: **≥ 4–5 service** có **client chung**, nhu cầu **rate-limit** theo tenant/user, hoặc **compliance** đòi **log tập trung** tại biên. Khi đã đủ tín hiệu, chọn công cụ đúng quy mô: **Kong/NGINX** self-hosted cho on-prem/K8s, **cloud-managed** (**AWS API Gateway**, **Apigee**, **Azure APIM**) khi team nhỏ và muốn trút vận hành.

**API Gateway** không phải "lớp mạng thêm cho sang" — nó là **điểm kỷ luật** của kiến trúc **microservices**: nơi bạn **ép** mọi request công khai tuân thủ cùng một chuẩn **bảo mật**, **quan sát**, và **kiểm soát tải** trước khi chạm đến bất kỳ **service** nào. Chọn **DB mode + PostgreSQL** khi cần **dynamic consumers** và **horizontal scale** cho Kong; chọn **DB-less** khi team muốn GitOps thuần. Khi đã đặt Gateway, giữ nó **mỏng** và **tập trung đúng vai trò biên**; mọi cám dỗ "nhét logic vào plugin cho nhanh" sẽ trả giá trong **6 tháng** khi cả đội không dám động vào cấu hình vì sợ làm sập **toàn hệ**.

# references
## 0
### alias
Microservices.io — API Gateway
### url
https://microservices.io/patterns/apigateway.html
## 1
### alias
Microservices.io — Backends for Frontends (BFF)
### url
https://microservices.io/patterns/apigateway.html#variant-backends-for-frontends
## 2
### alias
Kong Gateway — Database mode (PostgreSQL)
### url
https://docs.konghq.com/gateway/latest/production/deployment-topologies/traditional/
## 3
### alias
Kong Gateway — Admin API reference
### url
https://docs.konghq.com/gateway/latest/admin-api/

# minutesRead
30
