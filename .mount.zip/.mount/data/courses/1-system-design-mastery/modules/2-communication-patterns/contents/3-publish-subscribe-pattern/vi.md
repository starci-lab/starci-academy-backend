# title
Publish-Subscribe với NATS

# description
Phát event một lần tới nhiều subscriber qua NATS core Pub/Sub — demo Publisher bắn USER_REGISTERED để Analytics, Notification, Audit cùng nhận, rồi đọc sâu trade-off fire-and-forget, queue group, wildcard subject, và khi nào cần JetStream hay Kafka.

# body

## I. Lời mở đầu

Phỏng vấn **Senior Backend**, câu hỏi gài hay rơi vào: *"User vừa đăng ký xong, em cần **ba việc** độc lập: gửi mail chào mừng, đẩy **Analytics**, ghi **Audit log**. Em viết thế nào?"*. **Beta** thường trả lời: *"em `await sendMail(); await pushAnalytics(); await writeAudit()`"* — đáp án đó **làm lộ** ngay vấn đề: ba việc **không liên quan** lại bị xếp hàng chờ nhau; tuần sau sếp bảo thêm *"bắn vào **CRM**"* — lại **mở `user.service.ts`** sửa luồng đăng ký, mỗi hệ quả mới là một lần động vào code core.

Cách giải quyết đó là lật hướng: dịch vụ nguồn chỉ **phát** một thông báo lên **subject**; ai quan tâm thì **tự đăng ký**. Ta dùng **NATS** ở phần sau để chạm bản chất của **Publish-Subscribe** — đọc tiếp.

## II. Demo trực quan và thực hành

**Ví dụ** dưới đây là bốn **service** **NestJS** trong cùng **monorepo** kết nối qua **NATS core Pub/Sub** (dùng thư viện **`nats`** — client chính thức **nats.js**): một **`publisher-service`** (cổng **3001**) nhận **POST** từ client và `publish` message lên **subject** **`app.events`**; ba subscriber — **`subscriber-analytics`**, **`subscriber-notification`**, **`subscriber-audit`** — cùng `subscribe` subject đó và xử lý theo logic riêng (đếm thống kê / gửi thông báo / ghi audit log). Ba subscriber **không có HTTP port** vì không tiếp nhận request từ client — chúng chỉ là worker nghe NATS. **NATS** chạy qua **Docker** ở cổng **4222** (client) và **8222** (HTTP monitoring); ở chế độ **core Pub/Sub**, server **không lưu message** lên disk — subscriber offline thì message **mất**.

**Clone** ở đây: [Publish-Subscribe — demo (NestJS monorepo + NATS)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/publish-subscribe-pattern)

| Thành phần | Cổng | Công nghệ | Trách nhiệm (rút gọn) |
|-------------|------|-----------|------------------------|
| **Publisher Service** | **3001** | **NestJS**, **nats** | **POST /events** → `publish` lên subject **`app.events`** |
| **NATS Server** | **4222** client, **8222** monitoring | **NATS** (core Pub/Sub) | Định tuyến subject tới mọi subscriber đang connect; **không** persist |
| **Analytics Subscriber** | — | **NestJS**, subscriber | `subscribe('app.events')`, đếm và ghi thống kê |
| **Notification Subscriber** | — | **NestJS**, subscriber | `subscribe('app.events')`, gửi thông báo (mô phỏng email/SMS) |
| **Audit Subscriber** | — | **NestJS**, subscriber | `subscribe('app.events')`, ghi audit log |

![Sơ đồ Pub/Sub — Publisher phát, NATS broadcast tới ba Subscriber](https://starci.org/system-design-mastery/publish-subscribe-pattern/0.svg)

*Hình 1. Sơ đồ kiến trúc hệ thống từ source code trên.*

Publisher bắn một message, **NATS** đẩy **đồng thời** cho ba subscriber đang connect subject **`app.events`** — nếu có subscriber offline lúc `publish`, message đó **mất** với subscriber đó.

### 1. Chuẩn bị và chạy môi trường

Giả định đã cài **Docker** và **Node.js** (LTS). Trong **repo** (đã **clone**):

1. Cài dependency:

```
npm install
```

2. Khởi chạy **NATS**:

```
docker compose -f .docker/nats.yaml up -d
```

3. Kiểm tra **NATS** đã sẵn sàng qua HTTP monitoring:

```
curl http://localhost:8222/varz
```

4. Mở **bốn terminal**. Theo **README**, chạy **ba subscriber trước** để sẵn sàng nhận event:

```
npx nest start subscriber-analytics --watch
```

```
npx nest start subscriber-notification --watch
```

```
npx nest start subscriber-audit --watch
```

Rồi mới khởi **publisher**:

```
npx nest start publisher-service --watch
```

**Kết quả mong đợi**

**NATS** lắng **4222** (client) và **8222** (monitoring); **Publisher Service** lắng **3001**; ba **subscriber** log dòng xác nhận đã `subscribe` subject **`app.events`**; `curl http://localhost:8222/varz` trả về JSON metadata của server.

**Kết luận**

Một **Publisher** và ba **Subscriber** độc lập, không ai gọi thẳng ai — đường duy nhất là subject **`app.events`** trên NATS. Subscriber có thể thêm hay bớt mà **không** đụng code **Publisher**.

### 2. Publisher phát → cả ba subscriber cùng nhận

Bạn có thể **làm theo** bằng **app có giao diện** (**Postman**, **Insomnia**, **Bruno** …) **hoặc** bằng **`curl`** trên **Linux**, **macOS** hoặc **WSL2**.

**Các bước thực hiện:**

**Bước 1:** Gửi event `USER_REGISTERED` qua **Publisher**.

- Method: **POST**
- URL: `http://localhost:3001/events`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "type": "USER_REGISTERED",
  "payload": {
    "userId": 1,
    "name": "Nguyen Van A"
  }
}
```

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X POST http://localhost:3001/events -H "Content-Type: application/json" -d "{\"type\":\"USER_REGISTERED\",\"payload\":{\"userId\":1,\"name\":\"Nguyen Van A\"}}"
```

**Bước 2:** Quan sát log **ba terminal** subscriber — theo **repo**, mỗi subscriber log một dòng riêng:

- **Analytics**: `Ghi nhận event USER_REGISTERED — totalCount: 1`
- **Notification**: `Gửi thông báo — Sự kiện "USER_REGISTERED" đã xảy ra`
- **Audit**: `Ghi audit log — auditId: 1, eventType: USER_REGISTERED`

**Kết quả mong đợi**

**Publisher** trả response ngay (HTTP 2xx) sau khi `publish` xong — **không đợi** subscriber. **Analytics**, **Notification**, **Audit** đồng loạt nhận cùng message và xử lý theo logic riêng. Độ trễ publish-to-receive ~ **sub-millisecond** nhờ NATS hoàn toàn in-memory.

**Kết luận**

**Broadcasting** đúng nghĩa: một lần `publish`, **tất cả** subscriber đang connect subject **`app.events`** đều nhận. Publisher **không biết** có ba subscriber — thêm **CRM Subscriber** mai chỉ là chạy thêm một process `subscribe('app.events')`, **không** đụng code **Publisher**.

### 3. Subscriber offline → message mất (fire-and-forget)

Đây là đặc tính **quan trọng nhất** của **NATS core Pub/Sub** — giống **Redis Pub/Sub**, khác **Kafka**.

**Các bước thực hiện:**

**Bước 1:** Tắt **`subscriber-audit`** (Ctrl+C ở terminal tương ứng).

**Bước 2:** Gửi event mới qua **Publisher**:

- Method: **POST**
- URL: `http://localhost:3001/events`
- Body:

```
{
  "type": "ORDER_PLACED",
  "payload": {
    "orderId": 42,
    "amount": 999
  }
}
```

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X POST http://localhost:3001/events -H "Content-Type: application/json" -d "{\"type\":\"ORDER_PLACED\",\"payload\":{\"orderId\":42,\"amount\":999}}"
```

**Bước 3:** Chờ vài giây rồi khởi chạy lại **Audit** và quan sát log:

```
npx nest start subscriber-audit --watch
```

**Kết quả mong đợi**

Khi **Audit** offline: **Analytics** và **Notification** vẫn nhận event **`ORDER_PLACED`** bình thường. Khi **Audit** chạy lại, nó **không nhận được** event `orderId: 42` — NATS ở chế độ **core Pub/Sub không giữ** lại message; subscriber nào không connect subject tại **đúng thời điểm** `publish` thì **mất** event vĩnh viễn.

**Kết luận**

**NATS core Pub/Sub là fire-and-forget** — message không persist, không replay, không ack. Đây là **đặc tính, không phải bug**: đánh đổi **persistence** lấy **tốc độ cực thấp** và **mô hình cực đơn giản**. Nếu nghiệp vụ **không được mất event** (thanh toán, giao dịch, audit tài chính), **core Pub/Sub là lựa chọn sai** — phải bật **NATS JetStream** (có persist + ack + replay), hoặc dùng **Kafka** / **RabbitMQ** có persistence.

Sau hai luồng trên, tiếp theo là các **khái niệm** cốt lõi và **quy tắc chọn công cụ** giữa Pub/Sub ephemeral, queue group, và Message Log có persistence.

## III. Giải thích nâng cao và kết luận

### 1. Publish-Subscribe là gì và tại sao nó quan trọng trong microservices

**Publish-Subscribe** là một **messaging pattern** trong đó **producer** (publisher) không biết và không quan tâm **ai** đang lắng nghe — publisher chỉ phát message vào **subject** / **channel** / **topic** (tùy broker gọi tên khác nhau). **Consumer** (subscriber) đăng ký subject nào thì nhận message của subject đó. Đây là cực của tư duy **decoupling**: publisher và subscriber không biết nhau về **identity**, **số lượng**, và **thời điểm** xử lý. Khác với **point-to-point message queue** (một message, một consumer xử lý), **Pub/Sub** là **one-to-many** — cùng một message đến **mọi** subscriber.

- **Ví dụ:** Demo ở phần trên — một lần `publish` lên **`app.events`**, ba subscriber cùng nhận. Thêm subscriber thứ tư (CRM) mai ngày: chạy thêm một process `subscribe('app.events')`, **không** đụng code Publisher.

### 2. NATS — subject, wildcard và queue group

**NATS** là **message broker** nhẹ viết bằng **Go**, nổi tiếng về **latency sub-millisecond** và **throughput** rất cao (hàng triệu message/giây trên một node). Nó gọi đơn vị định tuyến là **subject** — chuỗi có dấu chấm (ví dụ **`order.created`**, **`app.events.user`**) — thay vì "channel" phẳng như Redis. Có ba khái niệm cần phân biệt:

- **Subject và wildcard:** `subscribe('order.*')` match **một** token (ví dụ **`order.created`**, **`order.paid`**); `subscribe('order.>')` match **nhiều** token (ví dụ **`order.item.added`**). Nhờ vậy subscriber có thể lắng rộng hoặc hẹp theo cây phân cấp — không cần nhiều subject thủ công.
- **Core Pub/Sub (broadcast):** subscriber **khác connection** cùng subject → **mọi** subscriber cùng nhận (đúng mô hình demo ở trên). **Fire-and-forget**, không persist.
- **Queue group (load balancing):** subscriber khai báo cùng **queue name** (`subscribe('app.events', { queue: 'workers' })`) → NATS chỉ giao **một** subscriber trong group xử lý mỗi message — **chia tải** giống **consumer group Kafka** nhưng **không persist**. Đây là cách **scale worker** bằng NATS mà **không** lặp xử lý.

Cơ chế **core** hoàn toàn **in-memory, in-process**: không ghi disk, không offset, không ack, không retry. Đây là lựa chọn **ưu việt** khi cần tốc độ cực thấp và chấp nhận mất một vài event không quan trọng.

Chú ý: **NATS JetStream** là một API **khác** trên cùng server — có **persistence**, **consumer**, **ack**, **replay**, **at-least-once** — gần với **Kafka** nhẹ. Đừng nhầm **JetStream** với **core Pub/Sub**; bài này tập trung vào **core**.

### 3. Phân biệt Pub/Sub với Message Queue và Event Log

Đây là chỗ **beta** hay nhầm nhất — ba công cụ nghe giống nhưng hành vi rất khác:

- **Pub/Sub (NATS core, Redis classic):** **Fire-and-forget**; **one-to-many**; **không persist**; tốc độ **cực thấp (< 1ms)**; subscriber offline **mất** message. Đúng cho **realtime notification**, **live dashboard**, **cache invalidation**, **chat presence**.
- **Message Queue (RabbitMQ classic, AWS SQS, NATS queue group):** **One-to-one** trong group (mỗi message, một consumer lấy); có **ack**, **retry**, **DLQ**; persist tùy cấu hình. Đúng cho **task queue** (xử lý background job, gửi email batch, resize ảnh).
- **Event Log (Kafka, NATS JetStream, AWS Kinesis, Redis Streams):** **Persistent log** có **offset**, **one-to-many** qua consumer group, **replay** được, persist **mặc định**. Đúng cho **nghiệp vụ không được mất** (thanh toán, audit, event sourcing, CQRS).

Muốn broadcast realtime và **chịu được mất event** → **Pub/Sub** (**NATS core** hoặc **Redis**). Muốn fan-out mà **không được mất event** → **Event Log** (**Kafka** hoặc **NATS JetStream**). Muốn task queue cho job nặng → **Message Queue** (hoặc **NATS queue group**). Chọn sai công cụ là hệ thống sẽ **không hoạt động đúng** dưới tải thật.

### 4. So sánh nhanh NATS core vs Redis Pub/Sub vs Kafka

Trong họ công cụ cùng mô hình, ba cái tên thường được đem ra cân nhắc:

- **NATS core:** Subject-based với **wildcard mạnh**, **queue group** có sẵn (load balance ngay trong broker), binary nhỏ (~20MB), **latency sub-ms**, **throughput** rất cao. Không persist ở chế độ core; cần persist thì bật **JetStream**. Hợp cho **microservices nội bộ**, **IoT**, **RPC qua request-reply**.
- **Redis Pub/Sub classic:** Kênh phẳng (không có tầng subject), không có queue group thực sự (broadcast hết), **không persist**. Mạnh khi hệ đã có sẵn **Redis** làm cache; hạn chế khi cần routing phức tạp. **Redis Streams** là API khác, có persist — đừng nhầm.
- **Kafka:** **Persistent log** có **partition** + **offset**, consumer group **chia** partition tự động, **replay** theo offset. Nặng hơn (broker + ZooKeeper/KRaft), latency **ms** thay vì **sub-ms**, nhưng **đảm bảo không mất** message. Hợp cho **event sourcing**, **pipeline data**, **CQRS**, **audit bắt buộc**.

Không có cái nào **tốt nhất** tuyệt đối — chọn theo **đảm bảo** (persist hay không), **routing** (subject wildcard vs topic phẳng), và **quy mô** (team, throughput, chi phí vận hành).

### 5. Khi nào chọn NATS core Pub/Sub

**NATS core** là lựa chọn **đúng** khi **cả ba** điều kiện sau đúng:

- **Event có thể mất mà không gây thiệt hại nghiệp vụ.** Ví dụ: cập nhật số người online trên dashboard (mất một tick, cập nhật tiếp theo sẽ đúng); cache invalidation (mất một invalidation, TTL cache sẽ tự xử lý sau); broadcast tín hiệu nội bộ giữa các service như "config mới, reload đi".
- **Cần latency rất thấp.** Hệ chat realtime, tín hiệu "user đang gõ", feed live score, telemetry **IoT** — tất cả đều cần **< 10ms**, persistent broker thường không đạt.
- **Subscriber luôn connect khi cần nhận.** Mô hình thường là worker chạy 24/7 có **high availability**, hoặc kết nối ngắn hạn nhận tín hiệu realtime. Nếu subscriber có thể **offline** và vẫn cần event, **không dùng core** — chuyển sang **JetStream** hoặc **Kafka**.

Ví dụ đúng: **NATS** broadcast **cache invalidation** giữa các web server ("key X vừa cập nhật, invalidate cache"); một web server chết rồi lên lại sẽ không cần event cũ vì cache nó đã rỗng.

### 6. Khi nào **không** nên chọn NATS core — tín hiệu cần JetStream hoặc Kafka

**Không** dùng core Pub/Sub khi có **một** trong các tín hiệu:

- **Event phải được xử lý đủ, không được mất.** Thanh toán, tạo đơn, ghi audit log tài chính — mất một event là mất tiền thật hoặc mất compliance. Cần **JetStream** (trong cùng NATS) hoặc **Kafka**.
- **Cần replay lịch sử.** Rebuild Read Model trong **CQRS**, gỡ bug bằng cách chạy lại event trên môi trường staging, cần audit trail — core không giữ lịch sử; JetStream / Kafka giữ theo **retention**.
- **Subscriber có thể offline lâu.** Service phụ restart vài phút, deploy mới, down do lỗi — cần broker persist để catch up; core sẽ mất mọi event trong thời gian offline.
- **Cần ordering guarantee hoặc exactly-once semantics.** Core không đảm bảo thứ tự khi có nhiều publisher cùng lúc, không có consumer offset. **Kafka** (partition key + offset) và **JetStream** (stream + sequence) đáp ứng tốt hơn.
- **Cần scale out consumer kiểu chia tải.** Muốn 10 replica cùng **chia** tải một subject — core Pub/Sub broadcast nên 10 replica sẽ **cùng** xử lý (trùng); dùng **NATS queue group** để chia trong chính NATS, hoặc **Kafka consumer group** nếu cần kèm persistence.

**Publish-Subscribe** không phải phiên bản nhẹ của Kafka — nó là **một công cụ khác** với **cam kết khác**: cho bạn **tốc độ** và **đơn giản tuyệt đối**, đổi lại **mất message khi subscriber vắng mặt**. Trong một kiến trúc **microservices** chín chắn, thường bạn sẽ dùng **cả hai**: **Kafka** (hoặc **JetStream**) cho các event **nghiệp vụ** (thanh toán, đơn hàng, audit) cần persistence và replay; **NATS core** (hoặc **Redis Pub/Sub**) cho **tín hiệu biên** (cache bust, presence, live dashboard) không chịu được latency cao. Chọn đúng công cụ cho đúng loại **đảm bảo** cần thiết — đó là dấu hiệu của kỹ sư đã hiểu bản chất mô hình messaging, không phải học thuộc vài cái tên.

# references
## 0
### alias
NATS — Documentation
### url
https://docs.nats.io/
## 1
### alias
NATS — Subject Design
### url
https://docs.nats.io/nats-concepts/subjects
## 2
### alias
NATS JetStream Overview
### url
https://docs.nats.io/nats-concepts/jetstream
## 3
### alias
Microservices.io — Messaging
### url
https://microservices.io/patterns/communication-style/messaging.html

# minutesRead
25
