# title
API Gateway Pattern

# description
Put Kong API Gateway (DB mode — PostgreSQL) in front of three microservices to centralize routing, auth, and rate-limiting at a single edge; configure dynamically through the Admin API or the Konga GUI, then dig into BFF, edge concerns, and the trap of turning the gateway into a new monolith.

# body

## I. Introduction

In a **Senior Backend** interview the loaded question often is: *"Your system has **10 microservices**, each on its own port — does the mobile app call every service directly? If so, where do you put **auth**, **rate-limit** and **logging**?"*. A junior answer is: *"I copy the **JWT** middleware into all 10 services"* — and that answer exposes the problem: every change in **authentication** logic now requires touching **10 repos** and **10 pipelines**, and if two teams miss a bump in the library version, you get a security gap. Worse, the client (web/mobile) must **remember** the coordinates of every service; changing any internal port forces the client app to ship a **new release**.

The way out of that trap is to place **an intermediate layer** in front of every **service** to take over the common work, leaving backends free to focus on business logic. We will use **Kong** in the next part to get at the essence of an **API Gateway** — read on.

## II. Visual Demo & Hands-on

The **example** below runs a **Kong Gateway** in **DB mode** with **PostgreSQL** as the config store, in front of three **NestJS** services: **`user-service`** (**3001**), **`product-service`** (**3002**), **`order-service`** (**3003**) — all in one **monorepo**. Clients only hit **port 8000** on **Kong** (proxy); operators can use the **Admin API** on **port 8001**, **Kong Manager** on **port 8002**, or the **Konga GUI** on **port 1337** to **register services**, **routes**, and **plugins** — every change is persisted to **PostgreSQL** on host **port 5433**. This is how Kong scales out: multiple Kong nodes read the same config from one DB, and any change is reflected everywhere.

**Clone** here: [API Gateway — demo (NestJS monorepo + Kong + Konga)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/api-gateway)

| Component | Port | Tech | Responsibility (short) |
|-------------|------|-----------|------------------------|
| **Kong proxy** | **8000** | **Kong 3.9** (DB mode) | Accepts client requests, applies **routes** + **plugins**, forwards |
| **Kong Admin API** | **8001** | **Kong 3.9** | **CRUD** for services / routes / plugins / consumers over HTTP |
| **Kong Manager** | **8002** | **Kong 3.9** | **Official** admin GUI bundled with Kong |
| **Kong Database** | **5433** (host) → **5432** (container) | **PostgreSQL 16** | Stores **all Kong configuration** (services, routes, plugins, consumers, credentials) |
| **Konga** | **1337** | **pantsel/konga** | **Third-party** GUI — friendlier for managing multiple Kong nodes |
| **Konga Database** | internal | **PostgreSQL 16** | Stores Konga users, connections, snapshots (separate from Kong's DB) |
| **User Service** | **3001** | **NestJS** | User business logic, does not handle edge **auth** |
| **Product Service** | **3002** | **NestJS** | Product business logic |
| **Order Service** | **3003** | **NestJS** | Order business logic |

![API Gateway architecture — Kong (DB mode + PostgreSQL) + Konga in front of three microservices](https://starci.org/system-design-mastery/api-gateway/0.svg)

*Figure 1. System architecture diagram from the source above.*

Clients hit the **Kong proxy (8000)**; operators/CI push config through the **Admin API (8001)**, **Kong Manager (8002)**, or **Konga (1337)** → all three persist to Kong's **PostgreSQL**; Kong reads config from the DB and routes to the right service; cross-cutting concerns live inside **Kong**, not duplicated across services.

### 1. Environment setup and run

Assumes **Docker** and **Node.js** (LTS) installed. From the cloned **repo**:

1. Start the **entire Kong + Konga stack** with a single command:

```
docker compose -f .docker/kong.yaml up -d
```

This compose file spins up six services: **`kong-database`** (Postgres 16 for Kong, published on **5433** on the host), **`kong-migrations`** (runs `kong migrations bootstrap` and exits), **`kong`** (the gateway itself — proxy **8000**, Admin API **8001**, Kong Manager **8002**), **`konga-database`** (a separate Postgres for Konga), **`konga-migrations`** (prepares Konga's schema and exits), and **`konga`** (the GUI on **1337**). Thanks to `depends_on` + `healthcheck`, the ordering **DB healthy → migration done → gateway / GUI up** is enforced automatically; you do not run the steps by hand. Default passwords (`kongpass`, `kongapass`) are fine for local; in production you **must** rotate them through a **secret manager**, never hardcode.

2. Install dependencies and run the three backend **services**:

```
npm install
```

Open **three terminals**:

```
npx nest start user-service --watch
```

```
npx nest start product-service --watch
```

```
npx nest start order-service --watch
```

**Expected result**

Kong's Postgres is on host port **5433**; Kong **proxy** on **8000**, **Admin API** on **8001**, **Kong Manager** on **8002**; **Konga** on **1337**; NestJS services on **3001**, **3002**, **3003**. Verify Kong is connected to the DB:

```
curl -s http://localhost:8001/status
```

If the response contains **`database.reachable: true`**, Kong can read/write **PostgreSQL**.

**Conclusion**

Kong is running but **does not yet know** any route — unlike DB-less where the YAML file pre-loads everything. Every **service** and **route** must be **registered through the Admin API** in the next step.

### 2. Register services and routes through the Admin API

You can **follow along** with a **GUI client** (**Postman**, **Insomnia**, **Bruno** …) **or** **`curl`** in a **terminal** on **Linux**, **macOS** or **WSL2** (Windows).

**Steps:**

**Step 1:** Register the **upstream service** for User.

- Method: **POST**
- URL: `http://localhost:8001/services`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "name": "user-service",
  "url": "http://host.docker.internal:3001"
}
```

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X POST http://localhost:8001/services -H "Content-Type: application/json" -d "{\"name\":\"user-service\",\"url\":\"http://host.docker.internal:3001\"}"
```

**Step 2:** Attach the `/users` **route** to the service you just created.

- Method: **POST**
- URL: `http://localhost:8001/services/user-service/routes`
- Body:

```
{
  "name": "user-route",
  "paths": ["/users"],
  "strip_path": false
}
```

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X POST http://localhost:8001/services/user-service/routes -H "Content-Type: application/json" -d "{\"name\":\"user-route\",\"paths\":[\"/users\"],\"strip_path\":false}"
```

**Step 3:** Repeat for **Product** and **Order**.

**Equivalent `curl` commands** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X POST http://localhost:8001/services -H "Content-Type: application/json" -d "{\"name\":\"product-service\",\"url\":\"http://host.docker.internal:3002\"}"
curl -X POST http://localhost:8001/services/product-service/routes -H "Content-Type: application/json" -d "{\"name\":\"product-route\",\"paths\":[\"/products\"],\"strip_path\":false}"

curl -X POST http://localhost:8001/services -H "Content-Type: application/json" -d "{\"name\":\"order-service\",\"url\":\"http://host.docker.internal:3003\"}"
curl -X POST http://localhost:8001/services/order-service/routes -H "Content-Type: application/json" -d "{\"name\":\"order-route\",\"paths\":[\"/orders\"],\"strip_path\":false}"
```

**Step 4:** Verify the config was persisted to Postgres.

**Equivalent `curl` commands** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -s http://localhost:8001/services | jq
curl -s http://localhost:8001/routes | jq
```

These calls read straight from the **`services`** and **`routes`** tables through the Admin API. If you `docker exec` into the Postgres container and run `psql -U kong -d kong -c "SELECT name, host, port FROM services;"`, you will see exactly the three rows you just created.

**Expected result**

Three **service + route** pairs exist in Kong; the **Admin API** returns full metadata; Postgres holds everything durably — **restart the Kong container and nothing is lost**.

**Conclusion**

This is the core difference of **DB mode**: configuration is **state in the DB**, not a file. Upside — live updates, no Kong restart, multiple Kong nodes share one DB (horizontal scale); downside — you lose "declarative truth in Git" and need a tool like **decK** to dump config back to YAML if you want GitOps.

### 3. Call three services through one entry

**Steps:**

**Step 1:** Call **Users** through the **Kong proxy**.

- Method: **GET**
- URL: `http://localhost:8000/users`

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X GET http://localhost:8000/users
```

**Step 2:** Create a new user through Kong.

- Method: **POST**
- URL: `http://localhost:8000/users`
- Body:

```
{
  "name": "Nguyen Van A",
  "email": "a@example.com"
}
```

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X POST http://localhost:8000/users -H "Content-Type: application/json" -d "{\"name\":\"Nguyen Van A\",\"email\":\"a@example.com\"}"
```

**Step 3:** Call **Products** and **Orders** through Kong.

**Equivalent `curl` commands** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X GET http://localhost:8000/products
curl -X GET http://localhost:8000/orders
```

**Expected result**

All four requests to **`localhost:8000`** return the correct data from the matching **service**. The client does not need to know ports **3001**, **3002**, **3003**; access logs are centralized in **Kong** (container stdout).

**Conclusion**

From the outside the system looks like **one endpoint**; inside it is still **three separate services** that can change ports, add replicas, or switch tech without the client changing anything. Every **route change** or **new plugin** (e.g. **rate-limit** on `/orders`) is just a **`POST`** to the Admin API — **no restart**.

### 4. Enable a rate-limit plugin — showcasing DB mode

Where DB mode shines: **plugins** can be flipped on at runtime, no Kong redeploy.

**Steps:**

**Step 1:** Enable the **`rate-limiting`** plugin on the `/orders` route, capping **5 req/min**.

- Method: **POST**
- URL: `http://localhost:8001/routes/order-route/plugins`
- Body:

```
{
  "name": "rate-limiting",
  "config": {
    "minute": 5,
    "policy": "local"
  }
}
```

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X POST http://localhost:8001/routes/order-route/plugins -H "Content-Type: application/json" -d "{\"name\":\"rate-limiting\",\"config\":{\"minute\":5,\"policy\":\"local\"}}"
```

**Step 2:** Fire **7 requests** in a row at `/orders` and watch the response codes.

```
for ($i=1; $i -le 7; $i++) { curl -s -o nul -w "%{http_code}`n" http://localhost:8000/orders }
```

Or on **Linux/macOS/WSL2**:

```
for i in {1..7}; do curl -s -o /dev/null -w "%{http_code}\n" http://localhost:8000/orders; done
```

**Expected result**

The first five requests return **200**; the sixth and seventh return **429 Too Many Requests**. Response headers include **`X-RateLimit-Limit-Minute: 5`**, **`X-RateLimit-Remaining-Minute: 0`**, and **`Retry-After`** — Kong handles it, the NestJS backend writes **zero lines of code** for rate-limiting.

**Conclusion**

Adding an **edge guarantee** costs a single **HTTP call** to the Admin API, gets persisted to Postgres, and takes effect **instantly** across every Kong node reading the same DB. Removing the plugin is a **`DELETE`** on the corresponding endpoint — this is the real power of DB mode vs the edit-file-then-reload workflow of DB-less.

### 5. Managing Kong visually with Konga

Everything above was **driven by `curl`** against the Admin API — perfect for **scripting** and **CI**, but painful to read once you have dozens of routes and plugins. **Konga** (third-party) plugs into the **same Admin API (:8001)** and renders everything as tables and forms — it does not overwrite or replace anything; it is **just another client** of the same Kong.

**Steps:**

**Step 1:** Open **`http://localhost:1337`** the first time → create a local admin account (username + password + email).

**Step 2:** Go to **`CONNECTIONS` → `NEW CONNECTION`** and fill in:

- **Name:** `kong-gateway`
- **Kong Admin URL:** `http://kong:8001`

Note: use the **Docker network service name** (`kong`), **not** `localhost` — Konga runs inside a container, not on the host.

**Step 3:** After you **`ACTIVATE`** the connection, open the **`SERVICES`** tab → you will see **`user-service`**, **`product-service`**, **`order-service`** from step 2. The **`ROUTES`** tab lists **`user-route`**, **`product-route`**, **`order-route`**. The **`PLUGINS`** tab shows the **`rate-limiting`** plugin attached to **`order-route`** from step 4.

**Step 4:** Try a live edit from the GUI — click **`order-route`**, open the **`Plugins`** tab, change `minute` from **5** to **3**, **`SUBMIT`**. Immediately re-run the 7-request `curl` loop; this time the **fourth** request already returns **429**.

**Expected result**

The same configuration is now visible two ways: **`curl` + `jq`** for scripting and Git review, and **Konga** for new engineers onboarding or **non-engineers** (junior SRE, QA) who need an overview without learning the Admin API.

**Conclusion**

The **Admin API** is the **single source of truth**; **Konga** (and **Kong Manager**) are just **GUIs** talking to it. That means: every action in Konga also writes to **PostgreSQL**, also syncs across every Kong node, and is still audit-friendly. The production discipline is unchanged: **keep the Admin API on the internal network** and let Konga / Kong Manager (with their own auth) be the human-facing entry point; **never** expose **`:8001`** to the Internet even if you ship a pretty GUI.

After these five flows, the next part names the **concepts** and **traps** of **API Gateway** in real deployments.

## III. Advanced Theory and Conclusion

### 1. What API Gateway is and why it matters in microservices

An **API Gateway** is a **reverse proxy with logic** sitting at the **edge**: it receives every client request, runs a chain of **plugins** / **filters** (auth, rate-limit, transform, log) and forwards to the right **service** based on **routes**. It concentrates **edge concerns** — the stuff that is **not** business logic but **every** request must pass through — in **one place**, leaving services to focus on pure business. That is why even a 3-service system benefits from a Gateway: you do not want to write **JWT middleware** three times and find out later the versions drifted.

- **Example:** In the demo above, clients call **`localhost:8000/users`** instead of **`localhost:3001/users`** — **Kong** maps the prefix; the client does not need to know internal ports; moving a service's port is a **`PATCH`** on the Admin API, no client release.

### 2. Kong DB mode vs DB-less — which one to pick

**Kong** supports two deployment shapes, each fitting a different ops context:

- **DB mode (this lesson):** Config lives in **PostgreSQL** (or **Cassandra** in older versions). Changes are dynamic via the **Admin API**, no restart; multiple Kong nodes share one DB — **horizontal scale** for free; full support for **consumers**, **credentials**, centralized **rate-limit counters**; fits teams that already use **Konga**/**Kong Manager** or **decK** as their pipeline. Trade-off: you now run a stateful service (Postgres) that needs backups, HA, tuning, and the single source of truth is the DB, not Git.
- **DB-less:** Config is a **`kong.yml`** mounted into the container; every change is a Git commit → rebuild/reload. Pure GitOps, stateless infra, easy rollback. Weakness: **consumers** and **credentials** are awkward (no dynamic store); every node must receive the same file; stateful plugins (distributed rate-limit) need an external backend like **Redis**.
- **Rule of thumb:** Small team, few routes, GitOps discipline → **DB-less**. Large team, many routes, **dynamic consumers** (creating API keys per customer), multiple Kong nodes → **DB mode with PostgreSQL** is the industry default.

### 3. Core functions usually concentrated in the Gateway

Not every Gateway does them all; you pick what your product needs:

- **Routing / path rewriting:** Map **`/api/v1/orders`** → **Order Service**; rewrite internal paths; **weighted routing** for canary deploys.
- **Authentication & Authorization:** Verify **JWT** / **OAuth2** / **mTLS** at the edge; **strip** sensitive headers before forwarding; inject verified **claims** into headers for the backend to read.
- **Rate-limiting & quota:** By **IP**, **API key**, or **user**; stop abuse at the edge before load reaches backends.
- **Request / response transform:** Format conversions (XML ↔ JSON), header shaping, aggregating results from multiple backends.
- **Observability:** **Access logs**, **trace id** injection (**W3C Trace Context**), per-route metrics, **audit**.
- **Edge caching:** Cache **GET** responses with **ETag** or **TTL** — offloads backends for public resources.
- **SSL / TLS termination:** The Gateway holds certificates and speaks **HTTP** internally — services no longer bear TLS overhead.

### 4. BFF (Backend for Frontend) vs single API Gateway

A **single Gateway** (like the demo) serves **one group of clients** or multiple clients with the same shape. When **web** and **mobile** have very different needs (mobile wants small payloads and aggregated endpoints; web is fine calling many endpoints), forcing one "big Gateway" to please both usually degenerates into conditional logic. Sam Newman's **BFF** pattern says: give each client type its **own Gateway** — **BFF-Mobile**, **BFF-Web**, **BFF-Partner** — each BFF optimizes the data shape and UX for the client it serves; backend services are not dragged into UI-specific demands.

- **Example:** **BFF-Mobile** aggregates **`GET /orders` + `GET /user` + `GET /inventory`** into a single **`GET /home`** tailored for the home screen; **BFF-Web** lets the browser orchestrate the three calls separately since bandwidth is generous.

### 5. Trade-offs and operational traps

Gateways are not free — common dark sides:

- **Edge single point of failure.** The whole stack flows through **one** **Kong** / **NGINX** process; if it dies, the entire **API** dies. Fix: run **≥ 2 Kong instances** behind a **Load Balancer** (or a **cloud-managed API Gateway**), deep health checks, automatic **failover**. Under DB mode, do not forget **Postgres HA** (primary + replica) — a DB outage drags Kong down.
- **Extra latency.** Every request gains **+1 hop** — heavy plugins (JWT verify, distributed rate-limit, body transform) can add **5–30 ms**. Fix: **benchmark** the plugin chain, disable unused plugins, separate **fast paths** from **logic-heavy paths**.
- **Admin API is an attack vector.** Port **8001** allows **CRUD over the entire config** — leaking it to the Internet is catastrophic. Discipline: **bind the Admin API to an internal network**, protect with **mTLS** or **RBAC** (**Kong Manager Enterprise**), never expose it to clients.
- **Gateway grows into an "edge monolith".** Teams race to shove business logic into plugins because "it is easier than editing a service" — a few months later, the config in Postgres spans **thousands of rows** and any change needs the whole team to review. **Discipline:** Gateway handles **cross-cutting concerns only**; business logic stays **in services**, **not** in the gateway.
- **Version lock.** The Gateway holds all **route contracts**; changing a shared **route** requires coordination across many consumers. Fix: path **versioning** (`/v1`, `/v2`) or header-based versioning, **deprecation** with a timeline.
- **Multi-tier debugging.** A request flows **client → LB → Gateway → service → DB**; without **distributed tracing**, root-cause is brutal. Fix: **trace id** mandatory at the Gateway, propagated as a header to every backend; integrate **OpenTelemetry** / **Jaeger**.

### 6. When you do **not** need an API Gateway yet

Not every project needs a **Gateway** on day one. For a simple **monolith** or **2–3 small services** already sharing an internal middleware (e.g. a shared **NestJS** auth package), adding a Gateway is often **overhead** that just lengthens onboarding. Clear signals to pull it in: **≥ 4–5 services** with **shared clients**, **per-tenant/user rate-limiting** needs, or **compliance** requiring centralized edge logging. When those signals arrive, pick a tool that fits your scale: self-hosted **Kong/NGINX** for on-prem/K8s, **cloud-managed** (**AWS API Gateway**, **Apigee**, **Azure APIM**) when the team is small and wants to offload operations.

An **API Gateway** is not "an extra network layer for appearance" — it is the **discipline checkpoint** of a **microservices** architecture: the place where every public request is forced to comply with the same **security**, **observability**, and **load-control** standards before touching any **service**. Pick **DB mode + PostgreSQL** when you need **dynamic consumers** and Kong **horizontal scale**; pick **DB-less** when your team wants pure GitOps. Once you have a Gateway, keep it **thin** and focused on edge duties; every temptation to "stuff logic into a plugin for speed" will be paid back in **6 months** when nobody on the team dares to touch the config for fear of bringing the **whole system** down.

# references
## 0
### alias
Microservices.io — API Gateway
### url
https://microservices.io/patterns/apigateway.html
## 1
### alias
Microservices.io — Backends for Frontends (BFF)
### url
https://microservices.io/patterns/apigateway.html#variant-backends-for-frontends
## 2
### alias
Kong Gateway — Database mode (PostgreSQL)
### url
https://docs.konghq.com/gateway/latest/production/deployment-topologies/traditional/
## 3
### alias
Kong Gateway — Admin API reference
### url
https://docs.konghq.com/gateway/latest/admin-api/

# minutesRead
30
