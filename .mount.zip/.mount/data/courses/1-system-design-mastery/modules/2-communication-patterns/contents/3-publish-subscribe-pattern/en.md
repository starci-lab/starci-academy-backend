# title
Publish-Subscribe with NATS

# description
Broadcast one event to many subscribers over NATS core Pub/Sub — demo a Publisher firing USER_REGISTERED so Analytics, Notification, and Audit all react, then dig into the fire-and-forget trade-off, queue groups, wildcard subjects, and when to reach for JetStream or Kafka.

# body

## I. Introduction

In a **Senior Backend** interview, the loaded question often is: *"A user just registered — you need **three independent things**: send the welcome email, push an **Analytics** event, write an **Audit log**. How do you code it?"*. A junior answer: *"I `await sendMail(); await pushAnalytics(); await writeAudit()`"* — and that exposes the problem: three **unrelated** actions get queued up waiting on each other; next week the product owner adds *"push to **CRM** too"* — back to opening **`user.service.ts`** and editing the registration flow, every new consequence touching core code.

The way out is flipping the direction: the source service just **publishes** a notice to a **subject**; whoever cares **subscribes**. We use **NATS** in the next part to get at the essence of **Publish-Subscribe** — read on.

## II. Visual Demo & Hands-on

The **example** below is four **NestJS** services in one **monorepo** wired through **NATS core Pub/Sub** (using the official **`nats`** client **nats.js**): one **`publisher-service`** (port **3001**) receives **POST** from clients and `publish`es to the subject **`app.events`**; three subscribers — **`subscriber-analytics`**, **`subscriber-notification`**, **`subscriber-audit`** — all `subscribe` the same subject and run their own logic (stats / notifications / audit log). The three subscribers have **no HTTP port** because they do not accept client requests — they are purely NATS workers. **NATS** runs via **Docker** on **4222** (client) and **8222** (HTTP monitoring); in **core Pub/Sub** mode, the server **does not persist** messages to disk — an offline subscriber **loses** messages.

**Clone** here: [Publish-Subscribe — demo (NestJS monorepo + NATS)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/publish-subscribe-pattern)

| Component | Port | Tech | Responsibility (short) |
|-------------|------|-----------|------------------------|
| **Publisher Service** | **3001** | **NestJS**, **nats** | **POST /events** → `publish` to subject **`app.events`** |
| **NATS Server** | **4222** client, **8222** monitoring | **NATS** (core Pub/Sub) | Routes subjects to every connected subscriber; **no** persistence |
| **Analytics Subscriber** | — | **NestJS** subscriber | `subscribe('app.events')`, counts and records stats |
| **Notification Subscriber** | — | **NestJS** subscriber | `subscribe('app.events')`, sends notifications (simulated) |
| **Audit Subscriber** | — | **NestJS** subscriber | `subscribe('app.events')`, writes audit logs |

![Pub/Sub architecture — Publisher emits, NATS broadcasts to three Subscribers](https://starci.org/system-design-mastery/publish-subscribe-pattern/0.svg)

*Figure 1. System architecture diagram from the source above.*

The Publisher emits a single message and **NATS** delivers it **simultaneously** to every subscriber connected on subject **`app.events`** — any subscriber offline at the moment of `publish` **loses** that message.

### 1. Environment setup and run

Assumes **Docker** and **Node.js** (LTS). From the cloned **repo**:

1. Install dependencies:

```
npm install
```

2. Start **NATS**:

```
docker compose -f .docker/nats.yaml up -d
```

3. Check that **NATS** is ready via the HTTP monitoring endpoint:

```
curl http://localhost:8222/varz
```

4. Open **four terminals**. Per the **README**, start the **three subscribers first** so they are ready to receive:

```
npx nest start subscriber-analytics --watch
```

```
npx nest start subscriber-notification --watch
```

```
npx nest start subscriber-audit --watch
```

Then start the **publisher**:

```
npx nest start publisher-service --watch
```

**Expected result**

**NATS** listens on **4222** (client) and **8222** (monitoring); **Publisher Service** listens on **3001**; each of the three **subscribers** logs a line confirming it has `subscribe`d to **`app.events`**; `curl http://localhost:8222/varz` returns the server's metadata JSON.

**Conclusion**

One **Publisher** and three **Subscribers**, none calling each other directly — the only path is the NATS subject **`app.events`**. Subscribers can be added or removed without touching the **Publisher** code.

### 2. Publisher emits → all three subscribers receive

You can **follow along** with a **GUI client** (**Postman**, **Insomnia**, **Bruno** …) **or** **`curl`** on **Linux**, **macOS** or **WSL2**.

**Steps:**

**Step 1:** Send a `USER_REGISTERED` event via **Publisher**.

- Method: **POST**
- URL: `http://localhost:3001/events`
- Headers: `Content-Type: application/json`
- Body:

```
{
  "type": "USER_REGISTERED",
  "payload": {
    "userId": 1,
    "name": "Nguyen Van A"
  }
}
```

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X POST http://localhost:3001/events -H "Content-Type: application/json" -d "{\"type\":\"USER_REGISTERED\",\"payload\":{\"userId\":1,\"name\":\"Nguyen Van A\"}}"
```

**Step 2:** Watch the logs in the **three subscriber** terminals — per the **repo**, each one prints its own line:

- **Analytics**: `recorded event USER_REGISTERED — totalCount: 1`
- **Notification**: `sending notification — event "USER_REGISTERED" occurred`
- **Audit**: `recording audit log — auditId: 1, eventType: USER_REGISTERED`

**Expected result**

**Publisher** returns a response (HTTP 2xx) as soon as `publish` completes — **without waiting** for subscribers. **Analytics**, **Notification**, and **Audit** simultaneously receive the same message and act on it. Publish-to-receive latency is **sub-millisecond**, as NATS core is fully in-memory.

**Conclusion**

True **broadcasting**: one `publish`, **every** subscriber connected on **`app.events`** receives. The Publisher **does not know** there are three subscribers — adding a **CRM Subscriber** tomorrow is just another process running `subscribe('app.events')`, **no change** to the Publisher code.

### 3. Subscriber offline → message lost (fire-and-forget)

This is the **single most important** property of **NATS core Pub/Sub** — same as **Redis Pub/Sub**, unlike **Kafka**.

**Steps:**

**Step 1:** Stop **`subscriber-audit`** (Ctrl+C in its terminal).

**Step 2:** Send a new event via **Publisher**:

- Method: **POST**
- URL: `http://localhost:3001/events`
- Body:

```
{
  "type": "ORDER_PLACED",
  "payload": {
    "orderId": 42,
    "amount": 999
  }
}
```

**Equivalent `curl` command** — run in a **terminal** on **Linux**, **macOS**, or **WSL2**:

```
curl -X POST http://localhost:3001/events -H "Content-Type: application/json" -d "{\"type\":\"ORDER_PLACED\",\"payload\":{\"orderId\":42,\"amount\":999}}"
```

**Step 3:** Wait a few seconds, then restart **Audit** and watch the logs:

```
npx nest start subscriber-audit --watch
```

**Expected result**

While **Audit** was down, **Analytics** and **Notification** still received **`ORDER_PLACED`** as normal. When **Audit** restarts, it **does not receive** the `orderId: 42` event — NATS in **core Pub/Sub** mode **did not retain** it; any subscriber not connected at the **exact moment** of `publish` **loses** that event forever.

**Conclusion**

**NATS core Pub/Sub is fire-and-forget** — no persistence, no replay, no ack. This is a **feature, not a bug**: the trade is **persistence** for **very low latency** and **very simple semantics**. If the business **cannot afford to lose events** (payments, transactions, financial audit), **core Pub/Sub is the wrong tool** — enable **NATS JetStream** (persistence + ack + replay) on the same server, or reach for **Kafka** / persistent **RabbitMQ**.

After these two flows, the next part names the core **concepts** and the **tool-selection rules** across ephemeral Pub/Sub, queue groups, and persistent Event Logs.

## III. Advanced Theory and Conclusion

### 1. What Publish-Subscribe is and why it matters in microservices

**Publish-Subscribe** is a **messaging pattern** where the **producer** (publisher) neither knows nor cares **who** is listening — it simply emits messages to a **subject** / **channel** / **topic** (the name varies by broker). **Consumers** (subscribers) register a subject and receive its messages. This is the extreme of the **decoupling** mindset: publisher and subscriber do not know each other's **identity**, **count**, or **processing time**. Unlike a **point-to-point message queue** (one message, one consumer), **Pub/Sub** is **one-to-many** — the same message reaches **every** subscriber.

- **Example:** The demo above — one `publish` to **`app.events`** hits three subscribers. A fourth subscriber (CRM) tomorrow is just another process running `subscribe('app.events')`, **no change** to the Publisher.

### 2. NATS — subjects, wildcards, and queue groups

**NATS** is a lightweight **message broker** written in **Go**, famous for **sub-millisecond latency** and very high **throughput** (millions of messages per second on one node). Its routing unit is the **subject** — a dot-separated string like **`order.created`** or **`app.events.user`** — rather than the flat "channel" used by Redis. Three concepts are worth separating:

- **Subjects and wildcards:** `subscribe('order.*')` matches **one** token (e.g. **`order.created`**, **`order.paid`**); `subscribe('order.>')` matches **many** tokens (e.g. **`order.item.added`**). This lets a subscriber listen broadly or narrowly through a hierarchy without enumerating subjects by hand.
- **Core Pub/Sub (broadcast):** subscribers on **different connections** sharing a subject → **every** subscriber receives (exactly the demo above). **Fire-and-forget**, no persistence.
- **Queue group (load balancing):** subscribers declaring the same **queue name** (`subscribe('app.events', { queue: 'workers' })`) → NATS delivers each message to **only one** subscriber in the group — **load sharing** just like a **Kafka consumer group**, but **without persistence**. This is how you **scale workers** on NATS without duplicating work.

The **core** mechanism is entirely **in-memory, in-process**: no disk, no offsets, no acks, no retries. This is the winning choice when you need extreme speed and can tolerate losing occasional low-value events.

A caveat: **NATS JetStream** is a **different** API on the same server — with **persistence**, **consumers**, **acks**, **replay**, and **at-least-once** delivery — closer to a lightweight **Kafka**. Do not conflate **JetStream** with **core Pub/Sub**; this lesson focuses on **core**.

### 3. Pub/Sub vs Message Queue vs Event Log

Where juniors get lost most often — three tools that sound similar and behave very differently:

- **Pub/Sub (NATS core, Redis classic):** **Fire-and-forget**; **one-to-many**; **no persistence**; **sub-ms** latency; subscribers offline **lose** messages. Right for **realtime notifications**, **live dashboards**, **cache invalidation**, **chat presence**.
- **Message Queue (classic RabbitMQ, AWS SQS, NATS queue group):** **One-to-one** within a group (each message consumed by one); with **ack**, **retry**, **DLQ**; persistence configurable. Right for **task queues** (background jobs, batch email, image resize).
- **Event Log (Kafka, NATS JetStream, AWS Kinesis, Redis Streams):** **Persistent log** with **offsets**; **one-to-many** through consumer groups; **replayable**; **persistent by default**. Right for **critical flows** (payments, audit, event sourcing, CQRS).

Need realtime broadcast and **can afford to lose events** → **Pub/Sub** (**NATS core** or **Redis**). Need fan-out where **events must not be lost** → **Event Log** (**Kafka** or **NATS JetStream**). Need a task queue for heavy jobs → **Message Queue** (or **NATS queue group**). Picking the wrong tool will make the system **misbehave** under real load.

### 4. Quick comparison: NATS core vs Redis Pub/Sub vs Kafka

Within the same family, three names usually come up:

- **NATS core:** Subject-based with **rich wildcards**, built-in **queue groups** (load balancing inside the broker), tiny binary (~20MB), **sub-ms** latency, very high **throughput**. No persistence in core mode; enable **JetStream** for persistence. Fits **internal microservices**, **IoT**, **RPC via request-reply**.
- **Redis Pub/Sub (classic):** Flat channels (no subject hierarchy), no real queue groups (broadcast only), **no persistence**. Strong when **Redis** is already in the stack for caching; limited for complex routing. **Redis Streams** is a different API with persistence — do not confuse.
- **Kafka:** **Persistent log** with **partitions** + **offsets**, consumer groups **split** partitions automatically, **replay** by offset. Heavier (broker + ZooKeeper/KRaft), latency in **ms** rather than **sub-ms**, but **no-loss** guarantees. Fits **event sourcing**, **data pipelines**, **CQRS**, **mandatory audit**.

None is universally **best** — choose based on the **guarantee** you need (persistence or not), **routing** (subject wildcards vs flat topics), and **scale** (team, throughput, operational cost).

### 5. When NATS core Pub/Sub is the right choice

NATS core is the **right** pick when **all three** of these hold:

- **Events can be lost without business damage.** E.g. updating a live online-user counter (missing one tick does not matter; the next will be correct); cache invalidation (a missed invalidation will self-heal via TTL); internal broadcasts like "config updated, reload".
- **You need very low latency.** Realtime chat, "user is typing" indicators, live score feeds, **IoT** telemetry — all need **< 10ms**, persistent brokers typically cannot match that.
- **Subscribers are always connected when they need to receive.** Usually 24/7 workers with **high availability**, or short-lived connections receiving realtime signals. If a subscriber can go **offline** and still needs the event, **do not use core** — switch to **JetStream** or **Kafka**.

Good example: **NATS** broadcasts **cache invalidation** among web servers ("key X just changed, invalidate"); a web server that restarts does not need old events because its cache is already empty.

### 6. When **not** to pick NATS core — signals for JetStream or Kafka

Avoid core Pub/Sub if **any** of these signals are present:

- **Events must be processed at least once, never lost.** Payment, order creation, financial audit — losing one event means lost money or broken compliance. Use **JetStream** (on the same NATS server) or **Kafka**.
- **You need historical replay.** Rebuilding Read Models in **CQRS**, debugging by replaying events against staging, keeping an audit trail — core keeps no history; JetStream and Kafka retain events per **retention policy**.
- **Subscribers can be offline for long periods.** Auxiliary services that restart, new deploys, outages — you need broker persistence to catch up; core loses everything during the downtime.
- **You need ordering guarantees or exactly-once semantics.** Core does not guarantee order across multiple publishers and has no consumer offset. **Kafka** (partition key + offset) and **JetStream** (stream + sequence) fit far better.
- **You need to scale consumers via load balancing.** Want 10 replicas to **share** the load on a subject — core Pub/Sub broadcasts, so all 10 would **duplicate** the work; use a **NATS queue group** inside NATS itself, or a **Kafka consumer group** when you also need persistence.

**Publish-Subscribe** is not a light version of Kafka — it is **a different tool with different guarantees**: it gives you **speed** and **absolute simplicity** in exchange for **losing messages when a subscriber is absent**. A mature **microservices** architecture typically uses **both**: **Kafka** (or **JetStream**) for **business events** (payment, orders, audit) that need persistence and replay; **NATS core** (or **Redis Pub/Sub**) for **edge signals** (cache bust, presence, live dashboards) where latency matters most. Match the tool to the **guarantee** the problem actually demands — that is the sign of an engineer who understands messaging semantics, not just the names.

# references
## 0
### alias
NATS — Documentation
### url
https://docs.nats.io/
## 1
### alias
NATS — Subject Design
### url
https://docs.nats.io/nats-concepts/subjects
## 2
### alias
NATS JetStream Overview
### url
https://docs.nats.io/nats-concepts/jetstream
## 3
### alias
Microservices.io — Messaging
### url
https://microservices.io/patterns/communication-style/messaging.html

# minutesRead
25
