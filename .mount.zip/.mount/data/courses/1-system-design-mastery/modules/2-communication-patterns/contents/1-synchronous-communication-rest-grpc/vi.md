# title
Giao tiếp đồng bộ — REST vs gRPC

# description
So sánh REST (HTTP/1.1 + JSON) và gRPC (HTTP/2 + Protobuf) cho giao tiếp đồng bộ giữa microservices, demo mô hình Hybrid REST ở biên + gRPC nội bộ, rồi đọc sâu về strong contract, streaming và failure mode.

# body

## I. Lời mở đầu

Phỏng vấn **Senior Backend**, câu hỏi gài hay rơi vào: *"Hệ thống **5 service** nội bộ nói chuyện với nhau bằng gì? **REST JSON** à? Nếu **10 triệu RPC nội bộ/giờ** thì **băng thông** và **độ trễ** em đo chưa?"*. **Beta** thường trả lời: *"em dùng **REST** hết cho đồng bộ"* — đáp án đó **làm lộ** ngay vấn đề: ở quy mô đó, **JSON text** cộng **HTTP/1.1** lên gấp vài lần payload thực, mỗi request một connection — **băng thông** và **độ trễ** cùng trả giá. Tệ hơn, không có **schema** chung, đội A đổi một field, đội B nhận bug lúc **runtime** mà không có bước **compile** nào bắt kịp.

Cách giải quyết đó là chọn đúng **giao thức đồng bộ** cho đúng chỗ: một kiểu cho client ngoài, một kiểu cho nội bộ. Ta dùng **REST** và **gRPC** ở phần sau để chạm bản chất — đọc tiếp.

## II. Demo trực quan và thực hành

**Ví dụ** dưới đây là ba **service** **NestJS** trong một **monorepo**: **`gateway`** (cổng **3000**, **REST**) tiếp nhận **HTTP/JSON** từ client và chuyển tiếp bằng **gRPC** tới hai backend **`user-service`** (**5001**) và **`product-service`** (**5002**). Hai backend **không** expose **REST** ra ngoài — chúng chỉ nói **gRPC** (**HTTP/2** + **Protobuf**). File **`.proto`** là **single source of truth** cho schema — mọi thay đổi field đều bắt đầu từ đó, cả **Gateway** lẫn backend đều generate code từ cùng một file.

**Clone** ở đây: [Synchronous REST + gRPC — demo (NestJS monorepo)](https://github.com/StarCi-Academy/resources/tree/main/system-design-mastery/synchronous-communication-rest-grpc)

| Thành phần | Cổng | Công nghệ | Trách nhiệm (rút gọn) |
|-------------|------|-----------|------------------------|
| **Gateway** | **3000** | **NestJS**, **REST** | Nhận **HTTP/JSON** từ client; gọi **gRPC** xuống backend; đổi response về **JSON** |
| **User Service** | **5001** | **NestJS**, **gRPC** | Nghiệp vụ user; chỉ nói **gRPC** (HTTP/2 + Protobuf) |
| **Product Service** | **5002** | **NestJS**, **gRPC** | Nghiệp vụ product; chỉ nói **gRPC** |

![Sơ đồ Hybrid REST + gRPC — Gateway REST, backend gRPC](https://starci.org/system-design-mastery/synchronous-communication-rest-grpc/0.svg)

*Hình 1. Sơ đồ kiến trúc hệ thống từ source code trên.*

Client chỉ thấy **REST** ở biên; nội bộ ba **service** nói với nhau bằng **gRPC** binary; file **`.proto`** làm schema chung.

### 1. Chuẩn bị và chạy môi trường

Giả định đã cài **Node.js** (LTS). Trong **repo** (đã **clone**):

1. Cài dependency:

```
npm install
```

2. Mở **ba terminal**, mỗi terminal một **service**:

```
npx nest start user-service --watch
```

```
npx nest start product-service --watch
```

```
npx nest start gateway --watch
```

**Kết quả mong đợi**

**User** lắng **5001** (gRPC), **Product** lắng **5002** (gRPC), **Gateway** lắng **3000** (REST). Client bên ngoài **chỉ** tiếp cận được **3000**.

**Kết luận**

**Hybrid** sẵn sàng: **REST** là duy nhất ở biên; hai backend **gRPC thuần**, không expose **HTTP/JSON** ra ngoài — giao tiếp nội bộ đi qua **HTTP/2** + **Protobuf**.

### 2. Luồng gọi qua Hybrid — REST ở biên, gRPC nội bộ

Bạn có thể **làm theo** bằng **app có giao diện** (**Postman**, **Insomnia**, **Bruno** …) **hoặc** bằng **`curl`** trên **Linux**, **macOS** hoặc **WSL2**.

**Các bước thực hiện:**

**Bước 1:** Lấy user qua **Gateway**.

- Method: **GET**
- URL: `http://localhost:3000/users/1`

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X GET http://localhost:3000/users/1
```

**Response** là **JSON** — Gateway đã decode **Protobuf** từ **User Service** và serialize lại **JSON** cho client.

**Bước 2:** Lấy product qua **Gateway**.

- Method: **GET**
- URL: `http://localhost:3000/products/1`

**Câu lệnh `curl` tương đương** — chạy trong **terminal** trên **Linux**, **macOS** hoặc **WSL2**:

```
curl -X GET http://localhost:3000/products/1
```

**Response** là **JSON** tương tự — Gateway gọi **Product Service** qua **gRPC** rồi chuyển sang **JSON**.

**Kết quả mong đợi**

Cả hai request vào **Gateway REST** đều trả đúng dữ liệu. Log **Gateway** ghi call **gRPC** xuống backend; log **backend** thấy request đến với **Content-Type: application/grpc** (không phải **JSON**). Payload trên đường **Gateway ↔ backend** là **binary Protobuf**, không phải text.

**Kết luận**

Client **không** cần biết **gRPC** tồn tại — chỉ thấy **REST JSON** quen thuộc. Nội bộ vẫn tận dụng **HTTP/2** **multiplexing** + **Protobuf binary** để giảm overhead so với **HTTP/1.1 + JSON**; đồng thời, **`.proto`** ép mọi field phải có **kiểu rõ** — lệch type thì lỗi ngay lúc generate, không phải runtime.

Sau luồng vừa chạy, tiếp theo là các **khái niệm** và **edge case** của **REST** / **gRPC** khi triển khai thật.

## III. Giải thích nâng cao và kết luận

### 1. REST và gRPC khác nhau ở đâu — so sánh theo trục

Cả hai đều là **giao tiếp đồng bộ** (caller đứng đợi reply), khác nhau ở **encoding**, **transport**, **contract**, và **tooling**:

- **Transport:** **REST** dùng **HTTP/1.1** (đa số) hoặc **HTTP/2** (ít phổ biến); mỗi request thường mở một connection mới (hoặc keep-alive nhưng không multiplex). **gRPC** bắt buộc **HTTP/2** — hỗ trợ **multiplexing** (nhiều RPC cùng một TCP connection), **server push**, **flow control**.
- **Encoding:** **REST** dùng **JSON** (text, tự mô tả, đọc mắt thường được) hoặc **XML**. **gRPC** dùng **Protocol Buffers** (binary, cần schema để decode). Với cùng một payload có **5 trường**, **Protobuf** thường **nhỏ hơn JSON 3–10 lần** và parse nhanh hơn (không phải string parsing).
- **Contract:** **REST** thường dựa vào **OpenAPI/Swagger** như document — **không bắt buộc**, dễ drift giữa code và doc. **gRPC** bắt đầu từ **`.proto`** — code của client và server đều được **code-gen** từ file đó, lệch type là **compile fail**.
- **Streaming:** **REST** chỉ có request-response truyền thống (hoặc SSE/WebSocket phải thiết lập riêng). **gRPC** có **4 kiểu**: unary, server-streaming, client-streaming, bidirectional — trả nhiều kết quả trên cùng một RPC.
- **Trình duyệt:** **REST** mọi browser đều gọi được. **gRPC** không chạy native trên browser — cần **gRPC-Web** (proxy) hoặc fallback sang REST ở biên.

### 2. Khi nào chọn REST

**REST** là mặc định đúng khi:

- **API công khai cho client ngoài** (web, mobile, bên thứ ba): mọi stack đều gọi được, **Postman/cURL** debug trong 30 giây, **cache HTTP** (CDN) dùng được theo header chuẩn.
- **Nghiệp vụ CRUD đơn giản**, payload vừa phải, không gọi hàng nghìn RPC/giây giữa hai service.
- **Team đa dạng stack**: PHP, Ruby, Python, Node — mọi ngôn ngữ đều có client HTTP gọn; không phải thêm toolchain **protoc**.
- **Audit / compliance** cần log người-đọc-được: **JSON** ở ELK hơn gấp nhiều lần đọc **hex dump** Protobuf.

### 3. Khi nào chọn gRPC

**gRPC** thắng khi:

- **Giao tiếp nội bộ microservice tần suất cao**: fan-out 1 request biên thành 5–20 RPC nội bộ; giảm **3–10× bandwidth** và **latency** là khác biệt thật sự.
- **Strong contract bắt buộc**: team lớn, nhiều service, đổi field mà không có schema chung dẫn đến **bug runtime**. **`.proto`** + **code-gen** giải quyết gốc.
- **Streaming**: server push metric, chat bidirectional, upload/download chunked — **gRPC streaming** gọn hơn tự cài SSE/WebSocket.
- **Đa ngôn ngữ nhất quán**: **protoc** sinh client cho Go, Java, Python, C++, Node… từ **cùng một file** — không ai viết SDK thủ công.

### 4. Trade-off và failure mode cần biết

Cả hai đều là **đồng bộ** — mà đồng bộ có vết thương riêng:

- **Tight coupling runtime.** Caller đứng chờ callee — callee chết hoặc chậm, caller kẹt. Giải: **timeout** rõ (mọi call đều phải có), **circuit breaker** (Hystrix/Resilience4j), **retry có backoff**, **bulkhead** (pool riêng cho mỗi downstream).
- **Cascading failure.** Một service chậm 100ms có thể lan ra cả chuỗi → sập hệ. Giải: **deadline propagation** (gRPC có sẵn **deadline** truyền xuyên suốt call chain), **fail-fast** thay vì retry vô hạn.
- **gRPC khó debug hơn REST.** Binary trên wire — Wireshark không đọc thẳng; phải dùng **grpcurl** hoặc bật **gRPC reflection**. Log nên decode Protobuf sang JSON trước khi ghi.
- **Versioning contract.** **Protobuf** có rule rõ: không đổi **field number**, chỉ thêm field **optional**, không xóa field đã release — mọi team phải học. REST "dễ" hơn về hình thức nhưng drift âm thầm nhiều hơn.
- **Mesh / service discovery.** Đồng bộ gọi nhau tần suất cao → cần **service discovery** (Consul, **Kubernetes DNS**) và **load balancing client-side**; với gRPC thường tích hợp **service mesh** (**Istio**, **Linkerd**) để handle mTLS, retry, metric ở tầng proxy.

### 5. Hybrid — REST ở biên, gRPC nội bộ

Mô hình phổ biến và hợp lý cho đa số hệ **microservices** cỡ vừa trở lên (demo ở phần trên là ví dụ nhỏ của mô hình này):

- **Client ngoài ↔ Gateway**: **REST** (hoặc **GraphQL**) để tận dụng **trình duyệt**, **CDN**, **debug dễ**, tương thích rộng.
- **Gateway ↔ service nội bộ**: **gRPC** để tiết kiệm **băng thông**, giữ **strong contract**, tận dụng **streaming** khi cần.
- **Service ↔ service nội bộ**: **gRPC** khi đồng bộ; **message queue** (**Kafka**, **RabbitMQ**) khi bất đồng bộ.

**Google**, **Netflix**, **Uber**, và phần lớn công ty có quy mô dùng mô hình này — không phải vì **gRPC** "hiện đại" mà vì bài toán của họ thật sự có **hàng triệu RPC nội bộ mỗi phút**, và chi phí **JSON over HTTP/1.1** ở quy mô đó là **không tự biện minh được**.

**REST vs gRPC** không phải lựa chọn **tốt-xấu** — đây là **chọn công cụ theo trục giao tiếp**: ngoài biên thì **tương thích và dễ tiêu thụ** thắng tối ưu; nội bộ thì **hiệu năng và contract** thắng sự quen thuộc. Tránh hai cực đoan: (1) dùng **REST cho mọi thứ** rồi lạm phát băng thông khi scale, và (2) ép **gRPC lên client web** rồi khổ với **gRPC-Web proxy** và debug tool. **Hybrid** khi đã đủ quy mô — đó là lý do hầu hết **senior architect** đều mặc định trả lời như vậy trong phỏng vấn.

# references
## 0
### alias
gRPC — Official Introduction
### url
https://grpc.io/docs/what-is-grpc/introduction/
## 1
### alias
NestJS — gRPC Microservice
### url
https://docs.nestjs.com/microservices/grpc
## 2
### alias
Google — Protocol Buffers
### url
https://protobuf.dev/overview/

# minutesRead
25
