# title
Communication Patterns

# description
Common communication patterns between services in a Microservices architecture. Learn when to use sync (REST/gRPC) vs async (Kafka), and how API Gateway, BFF, and Pub/Sub fit into real systems.

# previewContents
## 0
### text
API Gateway pattern: a single entry point for clients, routing, and basic auth.
## 1
### text
Backend for Frontend (BFF): tailor backends per client (web/mobile).
## 2
### text
Service-to-Service communication: REST vs gRPC.
## 3
### text
Event-Driven Architecture: asynchronous processing with Kafka.
## 4
### text
Publish–Subscribe: publish events with multiple consumers processing in parallel.
## 5
### text
Choose the right communication approach per problem.
## 6
### text
Understand when to use sync (REST/gRPC) vs async (Kafka).
## 7
### text
Know the roles of API Gateway and BFF in production systems.
## 8
### text
Understand Pub/Sub and apply it to common flows.
## 9
### text
After this module: design clear, sensible service communication flows and be ready for data/consistency patterns next.
