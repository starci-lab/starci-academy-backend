# title
Fullstack Mastery

# description
Xây dựng nền tảng vững chắc, kỹ năng thực chiến và tư duy engineering để đạt được công việc thực tập hoặc Fresher/Junior Developer. Học fullstack từ frontend đến backend với trọng tâm thực tế.

# prerequisites
## 0
### text
Kiến thức cơ bản JavaScript/TypeScript: biến, hàm, async/await.
## 1
### text
Kiến thức backend cơ bản: API, request/response và các chức năng CRUD đơn giản.

# qnas
## 0
### question
Mình dùng Java, .NET hoặc Python thì có học được không?
### answer
Hoàn toàn được. Khoá học sử dụng NestJS để giải thích rõ các concept backend, nhưng bản chất backend là tư duy hệ thống, không phải framework. Bạn sẽ được hướng dẫn cách áp dụng sang các stack khác.
## 1
### question
Có rất nhiều khoá backend — tại sao nên chọn khoá này?
### answer
Đây không phải khoá CRUD cơ bản. Khoá học tập trung vào backend thực tế: tư duy hệ thống, giải quyết vấn đề và xử lý bài toán production. Mục tiêu là giúp bạn hiểu sâu và áp dụng được.

# valuePropositions
## 0
### text
Lộ trình học dạng module từ nền tảng đến triển khai thực tế.
## 1
### text
Bài giảng chất lượng cao, giải thích trực tiếp, không lan man.
## 2
### text
Bài tập thực hành giúp nâng cao tư duy và kỹ năng engineering.
## 3
### text
Review CV 1:1 và hỗ trợ phân phối CV đến network tuyển dụng.

# originalPrice
1500000

# coverImageUrl
https://starci-academy.sgp1.cdn.digitaloceanspaces.com/fullstack-mastery.png

# livestreamSessions
## 0
### dayOfWeek
monday
### startTime
20:30:00
### expectedEndTime
22:30:00
### isOverridable
true

## 1
### dayOfWeek
friday
### startTime
20:30:00
### expectedEndTime
22:30:00
### isOverridable
true

# pricingPhases
## 0
### phase
pioneer
### price
990000
### slotAvailable
30

## 1
### phase
earlyBird
### price
1190000
### slotAvailable
50

## 2
### phase
regular
### price
null
### slotAvailable
null