# title
Làm chủ PostgreSQL với TypeORM

# description
Học cách định nghĩa Entity, thiết lập các mối quan hệ One-to-One, One-to-Many, Many-to-Many, và thực hành tích hợp TypeORM với PostgreSQL trong NestJS.

# body

## I. Lời mở đầu

Nhiều lập trình viên khi làm việc với cơ sở dữ liệu quan hệ thường viết trực tiếp các câu lệnh **SQL** dài dòng để tạo bảng, truy vấn và cập nhật dữ liệu. Cách làm này không chỉ mất thời gian mà còn dễ gặp lỗi khi hệ thống lớn dần với hàng chục bảng liên kết chồng chéo.

**TypeORM** xuất hiện để giải quyết vấn đề này — bạn chỉ cần định nghĩa các **Entity** bằng TypeScript, và TypeORM sẽ tự động dịch chúng thành các lệnh **SQL** tương ứng phía sau. Bài học này sẽ giúp bạn hiểu cách sử dụng TypeORM để quản lý schema, thiết lập quan hệ và thao tác dữ liệu một cách mạch lạc.

## II. Nội dung chính

### 1. TypeORM — Cầu nối giữa TypeScript và SQL

**TypeORM (Object-Relational Mapping)** là thư viện cho phép bạn định nghĩa cấu trúc cơ sở dữ liệu bằng các class TypeScript thay vì viết SQL thủ công. Mỗi class được đánh dấu bằng decorator `@Entity()` sẽ tương ứng với một bảng trong **PostgreSQL**.

- **Ví dụ:** Định nghĩa một Entity đơn giản:
    ```typescript
    @Entity('cats')
    export class CatEntity {
      @PrimaryGeneratedColumn()
      id: number;

      @Column({ type: 'varchar', length: 255 })
      name: string;

      @Column({ type: 'int' })
      age: number;
    }
    ```
    TypeORM sẽ tự động tạo bảng `cats` với các cột `id`, `name`, `age` trong PostgreSQL.

### 2. Các mối quan hệ (Relations)

Điểm mạnh của cơ sở dữ liệu quan hệ nằm ở khả năng liên kết dữ liệu giữa các bảng. **TypeORM** cung cấp các decorator chuyên dụng để thiết lập quan hệ:

- **Ví dụ 1:** Quan hệ **One-to-One** — Một con mèo (`Cat`) chỉ có một hộ chiếu (`CatPassport`). Sử dụng `@OneToOne()` và `@JoinColumn()` để chỉ định bảng nào giữ khóa ngoại.

- **Ví dụ 2:** Quan hệ **One-to-Many** — Một con mèo (`Cat`) có nhiều đồ chơi (`Toy`). Sử dụng `@OneToMany()` phía `Cat` và `@ManyToOne()` phía `Toy`.

- **Ví dụ 3:** Quan hệ **Many-to-Many** — Một con mèo (`Cat`) có nhiều chủ (`Owner`), và một chủ (`Owner`) có nhiều mèo. Sử dụng `@ManyToMany()` kết hợp `@JoinTable()`.

Lưu ý quan trọng: Khi sử dụng `cascade: true` trong các quan hệ, TypeORM sẽ tự động lưu các entity liên kết khi bạn lưu entity cha. Điều này giúp đơn giản hóa việc tạo dữ liệu nhưng cần cẩn thận để tránh lưu những dữ liệu không mong muốn.

### 3. Tối ưu hiệu năng với Indexing

Khi cơ sở dữ liệu có hàng triệu bản ghi, một truy vấn như `SELECT * FROM cats WHERE name = 'Tom'` sẽ buộc **PostgreSQL** quét toàn bộ bảng (**Full Table Scan**), gây ra độ trễ nghiêm trọng.

- **Ví dụ:** Bảng `cats` có **10 triệu** bản ghi. Truy vấn theo cột `name` không có index mất khoảng **500ms**. Sau khi thêm `@Index()` lên cột `name`, PostgreSQL xây dựng cấu trúc **B-Tree** để tra cứu, giảm thời gian xuống chỉ còn **2ms**. Hãy luôn index những cột thường xuất hiện trong mệnh đề `WHERE`.

### 4. Transactions — Đảm bảo toàn vẹn dữ liệu

**Transaction** đảm bảo rằng một nhóm thao tác cơ sở dữ liệu hoặc thành công toàn bộ, hoặc thất bại toàn bộ và tự động **Rollback** về trạng thái ban đầu.

- **Ví dụ:** User A chuyển **100$** cho User B. Quy trình gồm 2 bước: trừ tiền A và cộng tiền B. Nếu máy chủ gặp sự cố sau bước 1, **100$** sẽ "bốc hơi" khỏi hệ thống. Với **Transaction**, TypeORM sử dụng `QueryRunner` để đảm bảo cả 2 bước phải hoàn tất — nếu bước 2 thất bại, bước 1 sẽ tự động hoàn tác.

## III. Thực hành

> **Source code:** [TypeORM and PostgreSQL](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/typeorm-and-postgresql)

Trong phần này, chúng ta sẽ clone source code và chạy thử dự án TypeORM + PostgreSQL để hiểu cách các Entity, quan hệ và cascade hoạt động trong thực tế.

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
    - Bước 1: Khởi động PostgreSQL bằng Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up --build -d
      ```
    - Bước 2: Cài đặt dependencies:
      ```bash
      npm install
      ```
    - Bước 3: Chạy ứng dụng:
      ```bash
      npm run start:dev
      ```
- **Kết quả mong đợi:** Ứng dụng NestJS khởi động thành công, kết nối được với PostgreSQL. Terminal hiển thị log `Nest application successfully started` và TypeORM tự động tạo các bảng trong database.
- **Kết luận:** Môi trường phát triển đã sẵn sàng với PostgreSQL chạy trong Docker và ứng dụng NestJS kết nối thành công qua TypeORM.

### 2. Kiến trúc (Architecture)

| Thành phần | Vai trò |
|------------|---------|
| **CatEntity** | Entity chính đại diện cho bảng `cats` |
| **CatPassportEntity** | Quan hệ **One-to-One** với Cat (hộ chiếu mèo) |
| **ToyEntity** | Quan hệ **One-to-Many** với Cat (đồ chơi của mèo) |
| **OwnerEntity** | Quan hệ **Many-to-Many** với Cat (chủ sở hữu) |
| **CatsController** | Tiếp nhận HTTP request từ Client |
| **CatsService** | Xử lý logic nghiệp vụ, tương tác với Repository |
| **TypeORM Repository** | Tầng truy cập dữ liệu, dịch Entity thành SQL |

Luồng dữ liệu đi theo mô hình: **Controller** -> **Service** -> **Repository (TypeORM)** -> **PostgreSQL**.

Nhờ có `cascade: true` trong các quan hệ, khi tạo một `Cat` mới kèm theo `CatPassport`, `Toy` và `Owner`, TypeORM sẽ tự động lưu tất cả trong một lần gọi `save()`.

- **Các bước thực hiện:**
    - Bước 1: Mở file Entity chính (ví dụ `cat.entity.ts`) để xem cách định nghĩa các decorator `@OneToOne()`, `@OneToMany()`, `@ManyToMany()`.
    - Bước 2: Mở file Service để xem cách sử dụng Repository và cascade save.
- **Kết quả mong đợi:** Hiểu rõ cấu trúc Entity, cách khai báo quan hệ và cách TypeORM tự động tạo bảng tương ứng trong PostgreSQL.
- **Kết luận:** Kiến trúc phân tầng rõ ràng giúp tách biệt trách nhiệm giữa Controller, Service và Repository — dễ bảo trì và mở rộng.

### 3. Luồng hệ thống (System Flow)

```
[Client] ──HTTP Request──> [CatsController]
                                  │
                                  ▼
                           [CatsService]
                                  │
                           TypeORM Repository
                           (cascade: true)
                                  │
                                  ▼
                           [PostgreSQL]
                    ┌──────────┼──────────┐
                    │          │          │
               [cats]   [cat_passports]  [toys]
                    │                    │
                    └────[cats_owners]───┘
                        (Many-to-Many)
```

- **Các bước thực hiện:**
    - Bước 1: Client gửi **POST /cats** với body chứa thông tin Cat kèm theo Passport, Toys và Owners.
    - Bước 2: **CatsController** nhận request, chuyển xuống **CatsService**.
    - Bước 3: **CatsService** gọi `repository.save()` với `cascade: true`, TypeORM tự động tạo bản ghi ở tất cả các bảng liên quan.
- **Kết quả mong đợi:** Một request duy nhất tạo dữ liệu đồng thời ở các bảng `cats`, `cat_passports`, `toys` và bảng trung gian `cats_owners`.
- **Kết luận:** **Cascade save** giúp đơn giản hóa việc tạo dữ liệu có quan hệ phức tạp chỉ với một lần gọi `save()`.

### 4. Thử nghiệm (Try it out)

**Success path** — Tạo mèo mới và truy vấn dữ liệu:

- **Các bước thực hiện:**
    - Bước 1: Tạo một con mèo mới với đầy đủ quan hệ:
      ```bash
      curl -X POST http://localhost:3000/cats \
        -H "Content-Type: application/json" \
        -d '{
          "name": "Tom",
          "age": 3,
          "passport": { "issuedAt": "2024-01-01" },
          "toys": [{ "name": "Ball" }, { "name": "Mouse" }],
          "owners": [{ "name": "Alice" }, { "name": "Bob" }]
        }'
      ```
    - Bước 2: Lấy danh sách tất cả mèo:
      ```bash
      curl -X GET http://localhost:3000/cats
      ```
    - Bước 3: Lấy chi tiết một con mèo theo ID:
      ```bash
      curl -X GET http://localhost:3000/cats/1
      ```
- **Kết quả mong đợi:**
    1. **POST /cats** trả về object Cat mới kèm theo Passport, Toys và Owners đã được lưu thành công.
    2. **GET /cats** trả về danh sách tất cả các con mèo trong database.
    3. **GET /cats/1** trả về chi tiết con mèo có `id = 1` kèm các quan hệ liên kết.
- **Kết luận:** TypeORM với `cascade: true` xử lý toàn bộ việc lưu dữ liệu liên kết một cách tự động — chỉ cần một lệnh `save()` duy nhất.

**Failure path** — Gửi dữ liệu thiếu trường bắt buộc:

- **Các bước thực hiện:**
    - Bước 1: Gửi request tạo mèo không có trường `name`:
      ```bash
      curl -X POST http://localhost:3000/cats \
        -H "Content-Type: application/json" \
        -d '{ "age": 3 }'
      ```
    - Bước 2: Thử truy vấn một con mèo với ID không tồn tại:
      ```bash
      curl -X GET http://localhost:3000/cats/9999
      ```
- **Kết quả mong đợi:**
    1. Request thiếu trường bắt buộc sẽ trả về lỗi **400 Bad Request** hoặc **500 Internal Server Error** tùy theo cấu hình validation.
    2. Truy vấn ID không tồn tại sẽ trả về **null** hoặc lỗi **404 Not Found**.
- **Kết luận:** TypeORM và PostgreSQL tự động thực thi các ràng buộc schema — dữ liệu không hợp lệ sẽ bị từ chối trước khi ghi vào database.

## IV. Kết luận

**TypeORM** là cầu nối mạnh mẽ giữa **TypeScript** và **PostgreSQL**, giúp bạn định nghĩa schema bằng code, thiết lập quan hệ bằng decorator và tối ưu truy vấn bằng indexing. Cascade save đơn giản hóa việc thao tác dữ liệu phức tạp, trong khi Transaction đảm bảo tính toàn vẹn tuyệt đối.

**Kết luận:** Làm chủ TypeORM không chỉ là biết viết Entity — mà là hiểu cách thiết kế quan hệ, tối ưu hiệu năng và đảm bảo dữ liệu luôn nhất quán trong mọi tình huống.

# references
## 0
### alias
TypeORM Entities
### url
https://typeorm.io/entities
## 1
### alias
TypeORM Transactions
### url
https://typeorm.io/transactions

# minutesRead
30
