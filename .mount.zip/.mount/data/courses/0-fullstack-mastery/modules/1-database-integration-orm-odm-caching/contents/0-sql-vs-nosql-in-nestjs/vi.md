# title
SQL và NoSQL trong NestJS

# description
So sánh sự khác biệt cốt lõi giữa cơ sở dữ liệu Quan hệ (SQL) và Phi quan hệ (NoSQL), từ đó xác định khi nào nên dùng PostgreSQL, khi nào nên dùng MongoDB trong một dự án NestJS.

# body

## I. Lời mở đầu

Nhiều lập trình viên khi bắt đầu dự án Backend thường mặc định chọn **PostgreSQL** hoặc **MySQL** vì "ai cũng dùng thế". Nhưng khi hệ thống lớn dần, họ gặp phải những vấn đề như schema cứng nhắc không thể thay đổi nhanh, hoặc những truy vấn **JOIN** chồng chất làm chậm toàn bộ API.

Ngược lại, nhóm khác lại "cuồng" **MongoDB** vì sự tự do, để rồi khi cần đảm bảo tính toàn vẹn dữ liệu giao dịch tài chính, họ mới nhận ra NoSQL không phải viên đạn bạc. Bài học này sẽ giúp bạn hiểu bản chất của từng loại, để đưa ra quyết định đúng đắn thay vì chọn theo phong trào.

## II. Nội dung chính

### 1. Cơ sở dữ liệu Quan hệ — SQL (PostgreSQL)

**SQL (Structured Query Language)** là ngôn ngữ truy vấn cho các hệ quản trị cơ sở dữ liệu quan hệ. Dữ liệu được tổ chức thành các **Bảng (Table)**, **Hàng (Row)** và **Cột (Column)** với các ràng buộc chặt chẽ.

- **Ví dụ:** Hệ thống thanh toán điện tử cần đảm bảo tính **ACID (Atomicity, Consistency, Isolation, Durability)**. Khi User A chuyển tiền cho User B, hoặc cả hai bước đều thành công, hoặc không bước nào được thực thi. **PostgreSQL** đảm bảo điều này bằng cơ chế **Transaction**.

Nên mặc định sử dụng **PostgreSQL** khi:
- Cần tính toàn vẹn tuyệt đối cho dữ liệu tài chính, đơn hàng, ví điện tử.
- Các thực thể có mối quan hệ phức tạp cần truy vấn **JOIN** dẫn chéo — ví dụ: "Tìm tất cả khách hàng ở Hà Nội đã từng mua sản phẩm màu Xanh có giá trị đơn hàng trên 500k".
- Cấu trúc dữ liệu ổn định, ít thay đổi cốt lõi theo thời gian.

### 2. Cơ sở dữ liệu Phi quan hệ — NoSQL (MongoDB)

**NoSQL** là thuật ngữ chỉ các hệ cơ sở dữ liệu không sử dụng mô hình bảng quan hệ truyền thống. **MongoDB** lưu trữ dữ liệu dưới dạng **Document JSON** linh hoạt, không yêu cầu schema cố định.

- **Ví dụ:** Một startup đang trong giai đoạn **MVP (Minimum Viable Product)**, tuần này thêm trường `tuoi`, tuần sau thêm trường `so_thich`. Với **MongoDB**, bạn chỉ cần thêm trường trực tiếp vào document mà không cần tạo file **Migration** phức tạp như SQL.

Nên chuyển hướng dùng **MongoDB** khi:
- Phát triển nhanh với yêu cầu thay đổi dữ liệu liên tục, không muốn bị ràng buộc bởi migration.
- Dữ liệu có cấu trúc không đồng nhất — log hệ thống, lịch sử chat, cấu hình sản phẩm tùy biến.
- Cần tốc độ ghi cao, chấp nhận đánh đổi tính nhất quán nghiêm ngặt để đổi lấy hiệu năng.

### 3. So sánh trực tiếp SQL và NoSQL

| Tiêu chí | SQL (PostgreSQL) | NoSQL (MongoDB) |
|----------|-------------------|-----------------|
| **Cấu trúc** | Bảng, Hàng, Cột cố định | Document JSON linh hoạt |
| **Tính toàn vẹn** | **ACID** nghiêm ngặt | **Eventual Consistency** |
| **Truy vấn** | **JOIN** mạnh mẽ | **Embedding** và **Aggregation** |
| **Mở rộng** | **Vertical Scaling** (nâng cấp máy chủ) | **Horizontal Scaling** (thêm node) |
| **Phù hợp** | Tài chính, đơn hàng, quan hệ phức tạp | Log, IoT, MVP, dữ liệu vô định hình |

### 4. Kiến trúc Đa Database trong NestJS (Polyglot Persistence)

Trong thực tế, một hệ thống hiện đại thường không chỉ dùng một loại database duy nhất. **NestJS** hỗ trợ kết nối đồng thời nhiều nguồn dữ liệu trong cùng một dự án — bạn có thể sử dụng **TypeORM** (cho **PostgreSQL**) và **Mongoose** (cho **MongoDB**) song song.

- **Ví dụ:** Lưu thông tin **User** và **Đơn hàng** trong **PostgreSQL** để đảm bảo tính toàn vẹn giao dịch. Đồng thời đẩy toàn bộ **Lịch sử lượt web (Tracking Logs)** và **Nhật ký chat** sang **MongoDB** để tận dụng khả năng ghi nhanh và cấu trúc linh hoạt.

## III. Kết luận

Lựa chọn giữa **SQL** và **NoSQL** không phải là cuộc chiến "cái nào tốt hơn", mà là bài toán chọn đúng công cụ cho đúng mục đích. **PostgreSQL** là lựa chọn mặc định khi bạn cần tính toàn vẹn và quan hệ phức tạp. **MongoDB** phát huy thế mạnh khi dữ liệu linh hoạt, thay đổi nhanh và cần tốc độ ghi cao.

**Kết luận:** Kiến trúc sư hệ thống giỏi không trung thành với một công nghệ — họ thông thạo kết hợp nhiều loại database (Polyglot Persistence) để khai thác thế mạnh riêng của từng loại, tạo nên một hệ thống vừa mạnh mẽ vừa linh hoạt.

# references
## 0
### alias
NestJS Database Overview
### url
https://docs.nestjs.com/techniques/database

# minutesRead
15
