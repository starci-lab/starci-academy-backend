# title
Caching with Redis

# description
Learn how to integrate Redis into NestJS for caching data at 3 different layers: Response layer, Logic layer, and Database Query layer, reducing database load and improving response times.

# body

## I. Introduction

Both **PostgreSQL** and **MongoDB** store data on disk (SSD/HDD). Even with indexing and aggregation optimizations, every complex query still involves **disk I/O** — which is hundreds of times slower than RAM.

Imagine **1 million** users simultaneously accessing the "Top 10 Best Movies" leaderboard. If every request forces the database to recalculate from scratch — scanning tables, **GROUP BY**, sorting — the server will overload and crash within minutes. The solution is to place a **caching layer** between the application and the database, so frequently queried data does not need to be recalculated every time.

## II. Core Concepts

### 1. Redis — An In-Memory Data Store

**Redis** is a data store that keeps **key-value** data directly in the server's **RAM**, rather than on disk. As a result, reading data from Redis typically takes under **1ms**, compared to hundreds of ms when querying traditional databases.

- **Example:** The result of the "Top 10 Movies" query is stored in Redis with the key `top_10_movies`. When the next **999,999** requests ask the same question, the application simply reads from RAM instead of making the database recalculate — reducing database load and improving response times for users.

### 2. Three Caching Layers in NestJS

**NestJS** supports caching integration at **3 different layers**, each serving a distinct purpose:

- **Example 1:** **Response Layer** — Use `@UseInterceptors(CacheInterceptor)` on the Controller. NestJS automatically caches the entire endpoint response. Subsequent requests return the cached result without calling the Service or Database. Best suited for endpoints returning rarely changing data.

- **Example 2:** **Logic Layer** — Inject `CACHE_MANAGER` into the Service and use `cache.get()` / `cache.set()` manually. This allows precise control over what data to cache, with custom TTL and invalidation logic. Best suited when you need to cache a portion of complex computation results.

- **Example 3:** **Database Query Layer** — Use the `cache: true` option in TypeORM query configuration. TypeORM automatically caches SQL query results at the database layer. Best suited for heavy queries called repeatedly with the same parameters.

### 3. Cache Invalidation Strategies

When data in the database changes but the cache still holds the old version, users receive **stale data**. This is the hardest problem in caching.

- **Example 1:** **TTL (Time to Live)** — Assign a lifespan to each cache entry, for example **60 seconds**. After expiration, the cache is automatically deleted and the next request fetches fresh data from the database. Simple but accepts a small delay in data freshness.

- **Example 2:** **Event-Driven Invalidation** — When data in the database changes (e.g., a new movie is added), the application proactively deletes the corresponding cache entry in Redis. This ensures the next request always receives the latest data, but requires more complex logic.

### 4. When to Use Which Layer

Choosing the right caching layer depends on the data characteristics and business requirements:

- **Example:**
    - **Response Layer:** Endpoints returning static data like system configuration, country lists.
    - **Logic Layer:** Data requiring processing logic before caching, such as aggregated score calculations.
    - **Database Query Layer:** Heavy SQL queries called repeatedly with the same parameters, such as monthly revenue reports.

## III. Practice

> **Source code:** [Caching with Redis](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/caching-with-redis)

In this section, we will clone the source code and run the Caching with Redis project to experience the differences between the 3 caching layers in practice.

### 1. Setup & Run

- **Execution Steps:**
    - Step 1: Start PostgreSQL using Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up -d
      ```
    - Step 2: Start Redis using Docker:
      ```bash
      docker compose -f .docker/redis.yaml up -d
      ```
    - Step 3: Install dependencies:
      ```bash
      npm install --legacy-peer-deps
      ```
    - Step 4: Run the application:
      ```bash
      npm run start:dev
      ```
- **Expected Results:** The NestJS application starts successfully and connects simultaneously to **PostgreSQL** and **Redis**. The terminal displays `Nest application successfully started`.
- **Conclusion:** The development environment is ready with PostgreSQL and Redis running in Docker, and the NestJS application connected successfully to both.

### 2. Architecture

| Component | Role |
|-----------|------|
| **PostgreSQL** | Primary database storing cats data |
| **Redis** | In-Memory cache store used across multiple layers |
| **CacheInterceptor** | Response Layer — automatically caches endpoint responses |
| **CACHE_MANAGER** | Logic Layer — allows manual `get()`/`set()` in the Service |
| **TypeORM cache** | Database Query Layer — caches SQL query results |
| **CatsController** | Receives HTTP requests, routes to each endpoint by layer |
| **CatsService** | Handles business logic and interacts with caching layers |

Each endpoint uses a different caching layer:
- `GET /cats/response-layer` — uses **CacheInterceptor**
- `GET /cats/logic-layer` — uses **CACHE_MANAGER** (`get`/`set`)
- `GET /cats/db-layer` — uses **TypeORM cache** option

- **Execution Steps:**
    - Step 1: Open the Controller file to see how each endpoint is assigned to its corresponding caching layer.
    - Step 2: Open the Service file to see how `CACHE_MANAGER` is used with `cache.get()` and `cache.set()`.
    - Step 3: Review the TypeORM configuration to understand how `cache: true` is enabled for queries.
- **Expected Results:** Understand how each caching layer is configured and operates independently.
- **Conclusion:** The 3 caching layers serve 3 different purposes — automatic (Response), semi-manual (Logic), and automatic at query level (Database Query).

### 3. System Flow

```
[Client] ──GET /cats/response-layer──> [CacheInterceptor]
                                             │
                                    Cache hit? ──Yes──> Return cached response
                                             │
                                            No
                                             │
                                    [CatsService] -> [PostgreSQL]
                                             │
                                    Store in Redis -> Return response

[Client] ──GET /cats/logic-layer──> [CatsService]
                                         │
                                cache.get('cats') hit? ──Yes──> Return cached
                                         │
                                        No
                                         │
                                [PostgreSQL] -> cache.set('cats', data)
                                         │
                                    Return response

[Client] ──GET /cats/db-layer──> [CatsService]
                                      │
                               TypeORM query (cache: true)
                                      │
                              Query cache hit? ──Yes──> Return cached query
                                      │
                                     No
                                      │
                              [PostgreSQL] -> Cache query result
                                      │
                                 Return response
```

- **Execution Steps:**
    - Step 1: The first call to any endpoint **misses the cache** — data is fetched from PostgreSQL and stored in Redis.
    - Step 2: Subsequent calls to the same endpoint **hit the cache** — data is returned from Redis without querying PostgreSQL.
    - Step 3: Observe the terminal logs to see the difference between cache hits and cache misses.
- **Expected Results:** The first call is slower (due to database query), and subsequent calls are significantly faster (reading from cache). Terminal logs clearly show the difference.
- **Conclusion:** Caching significantly reduces the number of database queries — improving response times and reducing system load.

### 4. Try it out

**Success path** — Experience cache hits across all 3 layers:

- **Execution Steps:**
    - Step 1: Call the **Response Layer** endpoint for the first time (cache miss):
      ```bash
      curl -X GET http://localhost:3000/cats/response-layer
      ```
    - Step 2: Call the same endpoint again (cache hit — observe terminal logs):
      ```bash
      curl -X GET http://localhost:3000/cats/response-layer
      ```
    - Step 3: Call the **Logic Layer** endpoint for the first time (cache miss):
      ```bash
      curl -X GET http://localhost:3000/cats/logic-layer
      ```
    - Step 4: Call the Logic Layer endpoint again (cache hit):
      ```bash
      curl -X GET http://localhost:3000/cats/logic-layer
      ```
    - Step 5: Call the **Database Query Layer** endpoint:
      ```bash
      curl -X GET http://localhost:3000/cats/db-layer
      ```
    - Step 6: Call the Database Query Layer endpoint again (cache hit at TypeORM level):
      ```bash
      curl -X GET http://localhost:3000/cats/db-layer
      ```
- **Expected Results:**
    1. The first call to each endpoint executes a PostgreSQL query — the terminal displays SQL query logs.
    2. The second call to each endpoint returns results from cache — the terminal does **not** display SQL query logs.
    3. The response time for the second call is significantly faster than the first.
- **Conclusion:** All 3 caching layers work effectively — the difference lies in the level of control and where the cache is applied.

**Failure path** — Observe stale data:

- **Execution Steps:**
    - Step 1: Call the Response Layer endpoint to cache the current result:
      ```bash
      curl -X GET http://localhost:3000/cats/response-layer
      ```
    - Step 2: Add a new record directly to the database (via another endpoint or directly through a SQL tool).
    - Step 3: Call the Response Layer endpoint again immediately:
      ```bash
      curl -X GET http://localhost:3000/cats/response-layer
      ```
- **Expected Results:**
    1. The response still returns old data from the cache (not including the newly added record).
    2. After the **TTL** expires, the next request fetches fresh data from the database and updates the cache.
- **Conclusion:** Caching delivers speed but also carries the risk of **stale data**. Choose the appropriate invalidation strategy: **TTL** for less critical data, **Event-Driven** for data requiring immediate updates.

## IV. Conclusion

**Redis** is an indispensable tool in modern Backend architecture. With 3 caching layers — **Response**, **Logic**, and **Database Query** — NestJS provides maximum flexibility in choosing the right caching strategy for each specific use case.

**Conclusion:** Caching is not just "adding Redis to the system" — it is about understanding which data needs caching, at which layer, and when to invalidate the cache to ensure users always receive accurate data.

# references
## 0
### alias
NestJS Caching
### url
https://docs.nestjs.com/techniques/caching

# minutesRead
20
