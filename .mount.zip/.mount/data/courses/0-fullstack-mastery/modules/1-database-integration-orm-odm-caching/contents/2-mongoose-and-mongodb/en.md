# title
Document Modeling with MongoDB and Mongoose

# description
Learn how to use Mongoose ODM to define Schemas, configure indexes, leverage timestamps, and perform data operations with MongoDB in NestJS.

# body

## I. Introduction

When working with **MongoDB**, many beginners assume that "NoSQL means absolute freedom — no schema, no constraints." But as the project grows, inconsistent data starts appearing everywhere: a field exists in document A but is missing in document B, and data types become chaotic because nobody enforces them.

**Mongoose** was created to solve this problem — it establishes a **discipline layer** at the application level, forcing every document to conform to a predefined **Schema** before being written to the database. This lesson will help you understand how to leverage MongoDB's flexibility while maintaining data consistency.

## II. Core Concepts

### 1. Mongoose — ODM for MongoDB

**Mongoose (Object Document Mapper)** is a library that lets you define data structures for **MongoDB** using TypeScript classes. Although MongoDB does not inherently require a fixed schema, Mongoose allows you to set up constraints, validation, and default values at the application layer.

- **Example:** Defining a simple Schema:
    ```typescript
    @Schema({ timestamps: true })
    export class Cat {
      @Prop({ required: true, index: true })
      name: string;

      @Prop()
      age: number;

      @Prop({ type: Object })
      metadata: Record<string, any>;

      @Prop({ type: [String] })
      hobbies: string[];
    }
    export const CatSchema = SchemaFactory.createForClass(Cat);
    ```
    Mongoose will automatically create a `cats` collection with the defined fields, plus `createdAt` and `updatedAt` thanks to the `timestamps: true` option.

### 2. Indexes and Timestamps

**Indexes** are a mechanism that helps **MongoDB** look up data faster by building auxiliary data structures instead of scanning the entire collection.

- **Example:** In the Schema above, the `name` field is marked with `index: true`. When the collection has millions of documents, querying `find({ name: 'Tom' })` will use the index instead of scanning everything, reducing query time from hundreds of ms to just a few ms.

**Timestamps** (`timestamps: true`) automatically add two fields, `createdAt` and `updatedAt`, to every document. This helps track creation and modification times without writing extra code.

### 3. Flexible Data with Object and Array Types

The key advantage of **MongoDB** over relational databases is its ability to store data with non-fixed structures. Mongoose supports this through `Object` and `Array` types.

- **Example 1:** The `metadata` field with type `Object` allows storing any key-value pairs. One cat might have `{ color: "orange", weight: 4.5 }`, while another has `{ breed: "Persian", vaccinated: true }` — without changing the schema.

- **Example 2:** The `hobbies` field with type `[String]` allows storing a list of values directly inside the document. Instead of creating a separate table like in SQL, you simply embed the array `["sleeping", "eating", "playing"]` into the document.

### 4. Basic CRUD Operations with Mongoose

**Mongoose** provides intuitive methods for manipulating data with **MongoDB**:

- **Example:**
    - Create: `new this.catModel(data).save()` — creates a new document and saves it to the collection.
    - Query: `this.catModel.find().sort({ name: 1 }).exec()` — retrieves a list and sorts by name.
    - Update: `this.catModel.findByIdAndUpdate(id, updateData, { new: true })` — finds by ID and updates, returning the updated document.
    - The `.exec()` method returns a real **Promise** instead of a Mongoose Query, making asynchronous handling cleaner.

## III. Practice

> **Source code:** [Mongoose and MongoDB](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/mongoose-and-mongodb)

In this section, we will clone the source code and run the Mongoose + MongoDB project to understand how Schema, indexes, and CRUD operations work in practice.

### 1. Setup & Run

- **Execution Steps:**
    - Step 1: Start MongoDB using Docker:
      ```bash
      docker compose -f .docker/mongodb.yaml up --build -d
      ```
    - Step 2: Install dependencies:
      ```bash
      npm install
      ```
    - Step 3: Run the application:
      ```bash
      npm run start:dev
      ```
- **Expected Results:** The NestJS application starts successfully and connects to MongoDB. The terminal displays `Nest application successfully started` and Mongoose automatically creates the collection in the database.
- **Conclusion:** The development environment is ready with MongoDB running in Docker and the NestJS application connected successfully via Mongoose.

### 2. Architecture

| Component | Role |
|-----------|------|
| **CatSchema** | Schema defining the document structure with `index` on the `name` field, `timestamps`, a `metadata` field (Object), and a `hobbies` field (Array) |
| **CatsController** | Receives HTTP requests from the Client |
| **CatsService** | Handles business logic, interacts with the Mongoose Model |
| **Mongoose Model** | Data access layer, translates Schema into MongoDB operations |

The data flow follows: **Controller** -> **Service** -> **Model (Mongoose)** -> **MongoDB**.

- **Execution Steps:**
    - Step 1: Open the Schema file (e.g., `cat.schema.ts`) to examine how fields, indexes, and timestamps are defined.
    - Step 2: Open the Service file to see how the Model is used with methods like `save()`, `find()`, and `findByIdAndUpdate()`.
- **Expected Results:** Understand the Schema structure, how to use the `@Prop()` decorator, and how Mongoose interacts with MongoDB.
- **Conclusion:** The layered architecture is similar to TypeORM but replaces Repository with Model — making it easy to transition between SQL and NoSQL thinking.

### 3. System Flow

```
[Client] ──HTTP Request──> [CatsController]
                                  │
                                  ▼
                           [CatsService]
                                  │
                           Mongoose Model
                       (new model(data).save())
                                  │
                                  ▼
                           [MongoDB]
                              │
                         [cats collection]
                    { name, age, metadata,
                      hobbies, createdAt,
                      updatedAt }
```

- **Execution Steps:**
    - Step 1: The Client sends a **POST** request with a body containing Cat information.
    - Step 2: **CatsController** receives the request and delegates to **CatsService**.
    - Step 3: **CatsService** calls `new this.catModel(data).save()` to create a new document in MongoDB.
- **Expected Results:** A new document is created in the `cats` collection with all fields defined in the Schema, plus `createdAt` and `updatedAt` automatically.
- **Conclusion:** The data flow is simple and direct — Mongoose ensures every document conforms to the Schema before writing to MongoDB.

### 4. Try it out

**Success path** — Create a new cat and query the data:

- **Execution Steps:**
    - Step 1: Create a new cat with flexible data:
      ```bash
      curl -X POST http://localhost:3000/cats \
        -H "Content-Type: application/json" \
        -d '{
          "name": "Tom",
          "age": 3,
          "metadata": { "color": "orange", "weight": 4.5 },
          "hobbies": ["sleeping", "eating"]
        }'
      ```
    - Step 2: Retrieve the list of all cats (sorted):
      ```bash
      curl -X GET http://localhost:3000/cats
      ```
    - Step 3: Update a cat's information:
      ```bash
      curl -X PATCH http://localhost:3000/cats/{id} \
        -H "Content-Type: application/json" \
        -d '{ "age": 4 }'
      ```
- **Expected Results:**
    1. **POST** returns the new document with all fields, plus `createdAt` and `updatedAt` automatically generated.
    2. **GET** returns a sorted list of cats, with the `metadata` field containing a flexible Object and `hobbies` containing an array of values.
    3. **PATCH** returns the updated document with `updatedAt` changed accordingly.
- **Conclusion:** Mongoose handles creating, querying, and updating data intuitively with `save()`, `find().exec()`, and `findByIdAndUpdate()` methods.

**Failure path** — Send data missing required fields:

- **Execution Steps:**
    - Step 1: Send a request to create a cat without the `name` field (a required field):
      ```bash
      curl -X POST http://localhost:3000/cats \
        -H "Content-Type: application/json" \
        -d '{ "age": 3 }'
      ```
    - Step 2: Try updating a cat with an invalid ID:
      ```bash
      curl -X PATCH http://localhost:3000/cats/invalid-id \
        -H "Content-Type: application/json" \
        -d '{ "age": 5 }'
      ```
- **Expected Results:**
    1. The request missing the `name` field returns a **Validation Error** because the field is marked `required: true` in the Schema.
    2. The request with an invalid ID returns a **Cast Error** or **404 Not Found**.
- **Conclusion:** Mongoose enforces validation at the application layer before writing to MongoDB — invalid data is rejected early.

## IV. Conclusion

**Mongoose** provides the perfect balance between **MongoDB**'s flexibility and the discipline of schemas. With the ability to define **indexes**, **timestamps**, and store data as **Object** and **Array** types directly within documents, Mongoose is the ideal choice for projects that need rapid development speed while still ensuring data quality.

**Conclusion:** The power of MongoDB is not "no schema needed" — it is the ability to store flexible data while being protected by Mongoose's strict validation layer at the application level.

# references
## 0
### alias
NestJS Mongoose integration
### url
https://docs.nestjs.com/recipes/mongodb
## 1
### alias
Mongoose Schemas
### url
https://mongoosejs.com/docs/guide.html

# minutesRead
25
