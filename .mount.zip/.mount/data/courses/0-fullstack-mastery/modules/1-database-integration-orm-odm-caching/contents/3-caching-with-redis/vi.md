# title
Tăng tốc hệ thống với bộ nhớ đệm Redis

# description
Tìm hiểu cách tích hợp Redis vào NestJS để caching dữ liệu ở 3 tầng khác nhau: Response layer, Logic layer và Database Query layer, từ đó giảm tải cho database và tăng tốc độ phản hồi.

# body

## I. Lời mở đầu

Cả **PostgreSQL** lẫn **MongoDB** đều lưu trữ dữ liệu trên ổ cứng (SSD/HDD). Dù đã tối ưu bằng indexing hay aggregation, mọi truy vấn phức tạp vẫn phải thực hiện thao tác **I/O ổ cứng** — với tốc độ chậm hơn RAM hàng trăm lần.

Hãy tưởng tượng có **1 triệu** người dùng đồng thời truy cập để xem bảng xếp hạng "Top 10 Phim hay nhất". Nếu mọi request đều buộc database tính toán lại từ đầu — quét bảng, **GROUP BY**, sắp xếp — server sẽ quá tải và sụp đổ trong vài phút. Giải pháp là đặt một lớp **bộ nhớ đệm (Cache)** giữa ứng dụng và database, để những dữ liệu được truy vấn thường xuyên không cần phải tính toán lại mỗi lần.

## II. Nội dung chính

### 1. Redis — Cơ sở dữ liệu In-Memory

**Redis** là một hệ cơ sở dữ liệu lưu trữ dữ liệu dạng **key-value** trực tiếp trên **RAM** của máy chủ, thay vì trên ổ cứng. Nhờ vậy, thời gian đọc dữ liệu từ Redis thường chỉ mất dưới **1ms**, so với hàng trăm ms khi truy vấn từ database truyền thống.

- **Ví dụ:** Kết quả truy vấn "Top 10 Phim" được lưu vào Redis với key `top_10_movies`. Khi **999.999** request tiếp theo hỏi cùng câu hỏi đó, ứng dụng chỉ cần đọc từ RAM thay vì bắt database tính toán lại — giảm tải cho database và tăng tốc độ phản hồi cho người dùng.

### 2. Ba tầng Caching trong NestJS

**NestJS** hỗ trợ tích hợp caching ở **3 tầng** khác nhau, mỗi tầng phục vụ mục đích riêng:

- **Ví dụ 1:** **Response Layer** — Sử dụng `@UseInterceptors(CacheInterceptor)` trên Controller. NestJS tự động cache toàn bộ response của endpoint. Mọi request tiếp theo sẽ trả về kết quả từ cache mà không gọi vào Service hay Database. Phù hợp cho các endpoint trả về dữ liệu ít thay đổi.

- **Ví dụ 2:** **Logic Layer** — Inject `CACHE_MANAGER` vào Service và sử dụng `cache.get()` / `cache.set()` thủ công. Cho phép kiểm soát chính xác dữ liệu nào cần cache, với TTL và logic invalidation tùy chỉnh. Phù hợp khi cần cache một phần kết quả tính toán phức tạp.

- **Ví dụ 3:** **Database Query Layer** — Sử dụng tùy chọn `cache: true` trong cấu hình TypeORM query. TypeORM tự động cache kết quả truy vấn SQL ở tầng database. Phù hợp cho các truy vấn nặng được gọi lặp đi lặp lại với cùng tham số.

### 3. Chiến lược vô hiệu hóa Cache (Cache Invalidation)

Khi dữ liệu trong database thay đổi nhưng cache vẫn giữ phiên bản cũ, người dùng sẽ nhận được dữ liệu **lỗi thời (stale data)**. Đây là vấn đề khó nhất của caching.

- **Ví dụ 1:** **TTL (Time to Live)** — Gán thời gian sống cho mỗi cache entry, ví dụ **60 giây**. Sau khi hết hạn, cache tự động bị xóa và request tiếp theo sẽ lấy dữ liệu mới từ database. Đơn giản nhưng chấp nhận độ trễ nhỏ trong việc cập nhật.

- **Ví dụ 2:** **Event-Driven Invalidation** — Khi dữ liệu trong database thay đổi (ví dụ: thêm phim mới), ứng dụng chủ động gọi lệnh xóa cache tương ứng trên Redis. Điều này đảm bảo request tiếp theo luôn nhận được dữ liệu mới nhất, nhưng đòi hỏi logic phức tạp hơn.

### 4. Khi nào nên dùng tầng nào

Việc chọn tầng caching phù hợp phụ thuộc vào đặc điểm của dữ liệu và yêu cầu nghiệp vụ:

- **Ví dụ:**
    - **Response Layer:** Endpoint trả về dữ liệu tĩnh như cấu hình hệ thống, danh sách quốc gia.
    - **Logic Layer:** Dữ liệu cần xử lý logic trước khi cache, ví dụ kết quả tính toán điểm số tổng hợp.
    - **Database Query Layer:** Truy vấn SQL nặng được gọi lặp lại với cùng tham số, ví dụ thống kê doanh thu theo tháng.

## III. Thực hành

> **Source code:** [Caching with Redis](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/caching-with-redis)

Trong phần này, chúng ta sẽ clone source code và chạy thử dự án Caching với Redis để trải nghiệm sự khác biệt giữa 3 tầng caching trong thực tế.

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
    - Bước 1: Khởi động PostgreSQL bằng Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up -d
      ```
    - Bước 2: Khởi động Redis bằng Docker:
      ```bash
      docker compose -f .docker/redis.yaml up -d
      ```
    - Bước 3: Cài đặt dependencies:
      ```bash
      npm install --legacy-peer-deps
      ```
    - Bước 4: Chạy ứng dụng:
      ```bash
      npm run start:dev
      ```
- **Kết quả mong đợi:** Ứng dụng NestJS khởi động thành công, kết nối đồng thời với **PostgreSQL** và **Redis**. Terminal hiển thị log `Nest application successfully started`.
- **Kết luận:** Môi trường phát triển đã sẵn sàng với PostgreSQL và Redis chạy trong Docker, ứng dụng NestJS kết nối thành công với cả hai.

### 2. Kiến trúc (Architecture)

| Thành phần | Vai trò |
|------------|---------|
| **PostgreSQL** | Cơ sở dữ liệu chính lưu trữ dữ liệu cats |
| **Redis** | Bộ nhớ đệm In-Memory lưu cache ở nhiều tầng |
| **CacheInterceptor** | Tầng Response — tự động cache response của endpoint |
| **CACHE_MANAGER** | Tầng Logic — cho phép `get()`/`set()` thủ công trong Service |
| **TypeORM cache** | Tầng Database Query — cache kết quả truy vấn SQL |
| **CatsController** | Tiếp nhận HTTP request, định tuyến đến từng endpoint theo tầng |
| **CatsService** | Xử lý logic nghiệp vụ và tương tác với các tầng caching |

Mỗi endpoint sử dụng một tầng caching khác nhau:
- `GET /cats/response-layer` — sử dụng **CacheInterceptor**
- `GET /cats/logic-layer` — sử dụng **CACHE_MANAGER** (`get`/`set`)
- `GET /cats/db-layer` — sử dụng tùy chọn **TypeORM cache**

- **Các bước thực hiện:**
    - Bước 1: Mở file Controller để xem cách mỗi endpoint được gắn với tầng caching tương ứng.
    - Bước 2: Mở file Service để xem cách sử dụng `CACHE_MANAGER` với `cache.get()` và `cache.set()`.
    - Bước 3: Xem cấu hình TypeORM để hiểu cách bật `cache: true` cho truy vấn.
- **Kết quả mong đợi:** Hiểu rõ cách mỗi tầng caching được cấu hình và hoạt động độc lập.
- **Kết luận:** 3 tầng caching phục vụ 3 mục đích khác nhau — tự động (Response), bán thủ công (Logic) và tự động ở tầng truy vấn (Database Query).

### 3. Luồng hệ thống (System Flow)

```
[Client] ──GET /cats/response-layer──> [CacheInterceptor]
                                             │
                                    Cache hit? ──Yes──> Return cached response
                                             │
                                            No
                                             │
                                    [CatsService] -> [PostgreSQL]
                                             │
                                    Store in Redis -> Return response

[Client] ──GET /cats/logic-layer──> [CatsService]
                                         │
                                cache.get('cats') hit? ──Yes──> Return cached
                                         │
                                        No
                                         │
                                [PostgreSQL] -> cache.set('cats', data)
                                         │
                                    Return response

[Client] ──GET /cats/db-layer──> [CatsService]
                                      │
                               TypeORM query (cache: true)
                                      │
                              Query cache hit? ──Yes──> Return cached query
                                      │
                                     No
                                      │
                              [PostgreSQL] -> Cache query result
                                      │
                                 Return response
```

- **Các bước thực hiện:**
    - Bước 1: Lần gọi đầu tiên đến bất kỳ endpoint nào đều **miss cache** — dữ liệu được lấy từ PostgreSQL và lưu vào Redis.
    - Bước 2: Các lần gọi tiếp theo đến cùng endpoint sẽ **hit cache** — dữ liệu được trả về từ Redis mà không truy vấn PostgreSQL.
    - Bước 3: Quan sát terminal log để thấy sự khác biệt giữa cache hit và cache miss.
- **Kết quả mong đợi:** Lần gọi đầu tiên chậm hơn (do truy vấn database), các lần gọi sau nhanh hơn đáng kể (do đọc từ cache). Terminal log thể hiện rõ sự khác biệt.
- **Kết luận:** Cache giúp giảm đáng kể số lần truy vấn database — tăng tốc độ phản hồi và giảm tải cho hệ thống.

### 4. Thử nghiệm (Try it out)

**Success path** — Trải nghiệm cache hit ở cả 3 tầng:

- **Các bước thực hiện:**
    - Bước 1: Gọi endpoint **Response Layer** lần đầu (cache miss):
      ```bash
      curl -X GET http://localhost:3000/cats/response-layer
      ```
    - Bước 2: Gọi lại cùng endpoint (cache hit — quan sát terminal log):
      ```bash
      curl -X GET http://localhost:3000/cats/response-layer
      ```
    - Bước 3: Gọi endpoint **Logic Layer** lần đầu (cache miss):
      ```bash
      curl -X GET http://localhost:3000/cats/logic-layer
      ```
    - Bước 4: Gọi lại endpoint Logic Layer (cache hit):
      ```bash
      curl -X GET http://localhost:3000/cats/logic-layer
      ```
    - Bước 5: Gọi endpoint **Database Query Layer**:
      ```bash
      curl -X GET http://localhost:3000/cats/db-layer
      ```
    - Bước 6: Gọi lại endpoint Database Query Layer (cache hit ở tầng TypeORM):
      ```bash
      curl -X GET http://localhost:3000/cats/db-layer
      ```
- **Kết quả mong đợi:**
    1. Lần gọi đầu tiên của mỗi endpoint thực hiện truy vấn PostgreSQL — terminal hiển thị log truy vấn SQL.
    2. Lần gọi thứ hai của mỗi endpoint trả về kết quả từ cache — terminal **không** hiển thị log truy vấn SQL.
    3. Thời gian phản hồi lần 2 nhanh hơn đáng kể so với lần 1.
- **Kết luận:** Cả 3 tầng caching đều hoạt động hiệu quả — sự khác biệt nằm ở mức độ kiểm soát và vị trí cache được áp dụng.

**Failure path** — Quan sát dữ liệu lỗi thời (stale data):

- **Các bước thực hiện:**
    - Bước 1: Gọi endpoint Response Layer để cache kết quả hiện tại:
      ```bash
      curl -X GET http://localhost:3000/cats/response-layer
      ```
    - Bước 2: Thêm một bản ghi mới trực tiếp vào database (qua endpoint khác hoặc trực tiếp qua SQL tool).
    - Bước 3: Gọi lại endpoint Response Layer ngay lập tức:
      ```bash
      curl -X GET http://localhost:3000/cats/response-layer
      ```
- **Kết quả mong đợi:**
    1. Response vẫn trả về dữ liệu cũ từ cache (không bao gồm bản ghi mới vừa thêm).
    2. Sau khi **TTL** hết hạn, request tiếp theo sẽ lấy dữ liệu mới từ database và cập nhật cache.
- **Kết luận:** Cache mang lại tốc độ nhưng cũng mang rủi ro **stale data**. Cần chọn chiến lược invalidation phù hợp: **TTL** cho dữ liệu ít quan trọng, **Event-Driven** cho dữ liệu cần cập nhật tức thì.

## IV. Kết luận

**Redis** là công cụ không thể thiếu trong kiến trúc Backend hiện đại. Với 3 tầng caching — **Response**, **Logic** và **Database Query** — NestJS mang lại sự linh hoạt tối đa trong việc lựa chọn chiến lược cache phù hợp với từng trường hợp sử dụng cụ thể.

**Kết luận:** Caching không chỉ là "thêm Redis vào hệ thống" — mà là hiểu rõ dữ liệu nào cần cache, cache ở tầng nào, và khi nào cần vô hiệu hóa cache để đảm bảo người dùng luôn nhận được dữ liệu chính xác.

# references
## 0
### alias
NestJS Caching
### url
https://docs.nestjs.com/techniques/caching

# minutesRead
20
