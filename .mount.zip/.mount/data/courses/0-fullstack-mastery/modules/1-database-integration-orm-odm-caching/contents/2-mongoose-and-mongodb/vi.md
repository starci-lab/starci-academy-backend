# title
Lưu trữ NoSQL với MongoDB và Mongoose

# description
Tìm hiểu cách sử dụng Mongoose ODM để định nghĩa Schema, thiết lập index, sử dụng timestamps và thao tác dữ liệu với MongoDB trong NestJS.

# body

## I. Lời mở đầu

Khi làm việc với **MongoDB**, nhiều lập trình viên mới bắt đầu thường nghĩ rằng "NoSQL là tự do tuyệt đối — không cần schema, không cần ràng buộc". Nhưng khi dự án lớn dần, dữ liệu không nhất quán bắt đầu xuất hiện khắp nơi: trường này có ở document A nhưng mất tích ở document B, kiểu dữ liệu loạn xạ vì không ai kiểm soát.

**Mongoose** ra đời để giải quyết vấn đề này — nó đặt ra **lớp kỷ luật** ngay trên tầng ứng dụng, ép mọi document phải tuân theo **Schema** đã định nghĩa trước khi được ghi vào database. Bài học này sẽ giúp bạn hiểu cách tận dụng sự linh hoạt của MongoDB trong khi vẫn duy trì tính nhất quán dữ liệu.

## II. Nội dung chính

### 1. Mongoose — ODM cho MongoDB

**Mongoose (Object Document Mapper)** là thư viện giúp bạn định nghĩa cấu trúc dữ liệu cho **MongoDB** bằng các class TypeScript. Mặc dù MongoDB bản chất không yêu cầu schema cố định, Mongoose cho phép bạn thiết lập các ràng buộc, validation và giá trị mặc định ngay trên tầng ứng dụng.

- **Ví dụ:** Định nghĩa một Schema đơn giản:
    ```typescript
    @Schema({ timestamps: true })
    export class Cat {
      @Prop({ required: true, index: true })
      name: string;

      @Prop()
      age: number;

      @Prop({ type: Object })
      metadata: Record<string, any>;

      @Prop({ type: [String] })
      hobbies: string[];
    }
    export const CatSchema = SchemaFactory.createForClass(Cat);
    ```
    Mongoose sẽ tự động tạo collection `cats` với các trường đã định nghĩa, kèm theo `createdAt` và `updatedAt` nhờ tùy chọn `timestamps: true`.

### 2. Index và Timestamps

**Index** là cơ chế giúp **MongoDB** tra cứu dữ liệu nhanh hơn bằng cách xây dựng cấu trúc dữ liệu phụ trợ thay vì quét toàn bộ collection.

- **Ví dụ:** Trong Schema ở trên, trường `name` được đánh dấu `index: true`. Khi collection có hàng triệu document, truy vấn `find({ name: 'Tom' })` sẽ sử dụng index thay vì quét toàn bộ, giảm thời gian truy vấn từ hàng trăm ms xuống chỉ vài ms.

**Timestamps** (`timestamps: true`) tự động thêm hai trường `createdAt` và `updatedAt` vào mọi document. Điều này giúp theo dõi thời gian tạo và cập nhật mà không cần viết thêm code.

### 3. Dữ liệu linh hoạt với Object và Array

Điểm mạnh của **MongoDB** so với cơ sở dữ liệu quan hệ là khả năng lưu trữ dữ liệu có cấu trúc không cố định. Mongoose hỗ trợ điều này thông qua kiểu `Object` và `Array`.

- **Ví dụ 1:** Trường `metadata` có kiểu `Object` cho phép lưu bất kỳ cặp key-value nào. Một con mèo có thể có `{ color: "orange", weight: 4.5 }`, trong khi con mèo khác có `{ breed: "Persian", vaccinated: true }` — không cần thay đổi schema.

- **Ví dụ 2:** Trường `hobbies` có kiểu `[String]` cho phép lưu danh sách giá trị trực tiếp trong document. Thay vì tạo một bảng riêng như SQL, bạn đơn giản nhúng mảng `["sleeping", "eating", "playing"]` vào document.

### 4. Các thao tác CRUD cơ bản với Mongoose

**Mongoose** cung cấp các phương thức trực quan để thao tác dữ liệu với **MongoDB**:

- **Ví dụ:**
    - Tạo mới: `new this.catModel(data).save()` — tạo một document mới và lưu vào collection.
    - Truy vấn: `this.catModel.find().sort({ name: 1 }).exec()` — lấy danh sách và sắp xếp theo tên.
    - Cập nhật: `this.catModel.findByIdAndUpdate(id, updateData, { new: true })` — tìm theo ID và cập nhật, trả về document đã cập nhật.
    - Phương thức `.exec()` trả về một **Promise** thực sự thay vì Mongoose Query, giúp việc xử lý bất đồng bộ rõ ràng hơn.

## III. Thực hành

> **Source code:** [Mongoose and MongoDB](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/mongoose-and-mongodb)

Trong phần này, chúng ta sẽ clone source code và chạy thử dự án Mongoose + MongoDB để hiểu cách Schema, index và các thao tác CRUD hoạt động trong thực tế.

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
    - Bước 1: Khởi động MongoDB bằng Docker:
      ```bash
      docker compose -f .docker/mongodb.yaml up --build -d
      ```
    - Bước 2: Cài đặt dependencies:
      ```bash
      npm install
      ```
    - Bước 3: Chạy ứng dụng:
      ```bash
      npm run start:dev
      ```
- **Kết quả mong đợi:** Ứng dụng NestJS khởi động thành công, kết nối được với MongoDB. Terminal hiển thị log `Nest application successfully started` và Mongoose tự động tạo collection trong database.
- **Kết luận:** Môi trường phát triển đã sẵn sàng với MongoDB chạy trong Docker và ứng dụng NestJS kết nối thành công qua Mongoose.

### 2. Kiến trúc (Architecture)

| Thành phần | Vai trò |
|------------|---------|
| **CatSchema** | Schema định nghĩa cấu trúc document với `index` trên trường `name`, `timestamps`, trường `metadata` (Object) và `hobbies` (Array) |
| **CatsController** | Tiếp nhận HTTP request từ Client |
| **CatsService** | Xử lý logic nghiệp vụ, tương tác với Mongoose Model |
| **Mongoose Model** | Tầng truy cập dữ liệu, dịch Schema thành các thao tác MongoDB |

Luồng dữ liệu đi theo mô hình: **Controller** -> **Service** -> **Model (Mongoose)** -> **MongoDB**.

- **Các bước thực hiện:**
    - Bước 1: Mở file Schema (ví dụ `cat.schema.ts`) để xem cách định nghĩa các trường, index và timestamps.
    - Bước 2: Mở file Service để xem cách sử dụng Model với các phương thức `save()`, `find()`, `findByIdAndUpdate()`.
- **Kết quả mong đợi:** Hiểu rõ cấu trúc Schema, cách sử dụng decorator `@Prop()` và cách Mongoose tương tác với MongoDB.
- **Kết luận:** Kiến trúc phân tầng tương tự TypeORM nhưng thay Repository bằng Model — dễ chuyển đổi tư duy giữa SQL và NoSQL.

### 3. Luồng hệ thống (System Flow)

```
[Client] ──HTTP Request──> [CatsController]
                                  │
                                  ▼
                           [CatsService]
                                  │
                           Mongoose Model
                       (new model(data).save())
                                  │
                                  ▼
                           [MongoDB]
                              │
                         [cats collection]
                    { name, age, metadata,
                      hobbies, createdAt,
                      updatedAt }
```

- **Các bước thực hiện:**
    - Bước 1: Client gửi **POST** request với body chứa thông tin Cat.
    - Bước 2: **CatsController** nhận request, chuyển xuống **CatsService**.
    - Bước 3: **CatsService** gọi `new this.catModel(data).save()` để tạo document mới trong MongoDB.
- **Kết quả mong đợi:** Document mới được tạo trong collection `cats` với đầy đủ các trường đã định nghĩa trong Schema, kèm theo `createdAt` và `updatedAt` tự động.
- **Kết luận:** Luồng dữ liệu đơn giản và trực tiếp — Mongoose đảm bảo mọi document tuân theo Schema trước khi ghi vào MongoDB.

### 4. Thử nghiệm (Try it out)

**Success path** — Tạo mèo mới và truy vấn dữ liệu:

- **Các bước thực hiện:**
    - Bước 1: Tạo một con mèo mới với dữ liệu linh hoạt:
      ```bash
      curl -X POST http://localhost:3000/cats \
        -H "Content-Type: application/json" \
        -d '{
          "name": "Tom",
          "age": 3,
          "metadata": { "color": "orange", "weight": 4.5 },
          "hobbies": ["sleeping", "eating"]
        }'
      ```
    - Bước 2: Lấy danh sách tất cả mèo (có sắp xếp):
      ```bash
      curl -X GET http://localhost:3000/cats
      ```
    - Bước 3: Cập nhật thông tin một con mèo:
      ```bash
      curl -X PATCH http://localhost:3000/cats/{id} \
        -H "Content-Type: application/json" \
        -d '{ "age": 4 }'
      ```
- **Kết quả mong đợi:**
    1. **POST** trả về document mới với đầy đủ trường, kèm theo `createdAt` và `updatedAt` tự động.
    2. **GET** trả về danh sách mèo được sắp xếp, trường `metadata` chứa Object linh hoạt và `hobbies` chứa mảng giá trị.
    3. **PATCH** trả về document đã cập nhật với `updatedAt` thay đổi tương ứng.
- **Kết luận:** Mongoose xử lý tạo, truy vấn và cập nhật dữ liệu một cách trực quan với các phương thức `save()`, `find().exec()` và `findByIdAndUpdate()`.

**Failure path** — Gửi dữ liệu thiếu trường bắt buộc:

- **Các bước thực hiện:**
    - Bước 1: Gửi request tạo mèo không có trường `name` (trường required):
      ```bash
      curl -X POST http://localhost:3000/cats \
        -H "Content-Type: application/json" \
        -d '{ "age": 3 }'
      ```
    - Bước 2: Thử cập nhật một con mèo với ID không hợp lệ:
      ```bash
      curl -X PATCH http://localhost:3000/cats/invalid-id \
        -H "Content-Type: application/json" \
        -d '{ "age": 5 }'
      ```
- **Kết quả mong đợi:**
    1. Request thiếu trường `name` sẽ trả về lỗi **Validation Error** vì trường này được đánh dấu `required: true` trong Schema.
    2. Request với ID không hợp lệ sẽ trả về lỗi **Cast Error** hoặc **404 Not Found**.
- **Kết luận:** Mongoose thực thi validation ngay trên tầng ứng dụng trước khi ghi vào MongoDB — dữ liệu không hợp lệ sẽ bị từ chối sớm.

## IV. Kết luận

**Mongoose** mang lại sự cân bằng hoàn hảo giữa tính linh hoạt của **MongoDB** và tính kỷ luật của schema. Với khả năng định nghĩa **index**, **timestamps**, và lưu trữ dữ liệu dạng **Object** và **Array** trực tiếp trong document, Mongoose là lựa chọn lý tưởng cho các dự án cần tốc độ phát triển nhanh nhưng vẫn đảm bảo chất lượng dữ liệu.

**Kết luận:** Sức mạnh của MongoDB không phải là "không cần schema" — mà là khả năng lưu trữ dữ liệu linh hoạt trong khi vẫn được Mongoose bảo vệ bằng lớp validation nghiêm ngặt ở tầng ứng dụng.

# references
## 0
### alias
NestJS Mongoose integration
### url
https://docs.nestjs.com/recipes/mongodb
## 1
### alias
Mongoose Schemas
### url
https://mongoosejs.com/docs/guide.html

# minutesRead
25
