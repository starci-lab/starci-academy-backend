# title
Mastering PostgreSQL with TypeORM

# description
Learn how to define Entities, configure One-to-One, One-to-Many and Many-to-Many relationships, and practice integrating TypeORM with PostgreSQL in NestJS.

# body

## I. Introduction

Many developers working with relational databases write raw **SQL** statements to create tables, query and update data. This approach is not only time-consuming but also error-prone as the system grows with dozens of cross-linked tables.

**TypeORM** solves this problem — you define **Entities** using TypeScript classes, and TypeORM automatically translates them into the corresponding **SQL** statements behind the scenes. This lesson will help you understand how to use TypeORM to manage schemas, configure relationships, and manipulate data cleanly.

## II. Core Concepts

### 1. TypeORM — The Bridge Between TypeScript and SQL

**TypeORM (Object-Relational Mapping)** is a library that allows you to define your database structure using TypeScript classes instead of writing raw SQL. Each class decorated with `@Entity()` corresponds to a table in **PostgreSQL**.

- **Example:** Defining a simple Entity:
    ```typescript
    @Entity('cats')
    export class CatEntity {
      @PrimaryGeneratedColumn()
      id: number;

      @Column({ type: 'varchar', length: 255 })
      name: string;

      @Column({ type: 'int' })
      age: number;
    }
    ```
    TypeORM will automatically create a `cats` table with columns `id`, `name`, and `age` in PostgreSQL.

### 2. Relationships (Relations)

The strength of relational databases lies in their ability to link data across tables. **TypeORM** provides specialized decorators for configuring relationships:

- **Example 1:** **One-to-One** relationship — A cat (`Cat`) has exactly one passport (`CatPassport`). Use `@OneToOne()` and `@JoinColumn()` to specify which table holds the foreign key.

- **Example 2:** **One-to-Many** relationship — A cat (`Cat`) has many toys (`Toy`). Use `@OneToMany()` on the `Cat` side and `@ManyToOne()` on the `Toy` side.

- **Example 3:** **Many-to-Many** relationship — A cat (`Cat`) has many owners (`Owner`), and an owner (`Owner`) has many cats. Use `@ManyToMany()` combined with `@JoinTable()`.

Important note: When using `cascade: true` in relationships, TypeORM automatically saves related entities when you save the parent entity. This simplifies data creation but requires caution to avoid saving unintended data.

### 3. Performance Optimization with Indexing

When a database has millions of records, a query like `SELECT * FROM cats WHERE name = 'Tom'` forces **PostgreSQL** to scan the entire table (**Full Table Scan**), causing severe latency.

- **Example:** A `cats` table has **10 million** records. Querying the `name` column without an index takes around **500ms**. After adding `@Index()` to the `name` column, PostgreSQL builds a **B-Tree** structure for lookups, reducing the time to just **2ms**. Always index columns that frequently appear in `WHERE` clauses.

### 4. Transactions — Ensuring Data Integrity

**Transactions** guarantee that a group of database operations either all succeed or all fail and automatically **Rollback** to the original state.

- **Example:** User A transfers **$100** to User B. The process involves 2 steps: deduct from A and credit to B. If the server crashes after step 1, **$100** would "vanish" from the system. With **Transactions**, TypeORM uses `QueryRunner` to ensure both steps must complete — if step 2 fails, step 1 is automatically reversed.

## III. Practice

> **Source code:** [TypeORM and PostgreSQL](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/typeorm-and-postgresql)

In this section, we will clone the source code and run the TypeORM + PostgreSQL project to understand how Entities, relationships, and cascade work in practice.

### 1. Setup & Run

- **Execution Steps:**
    - Step 1: Start PostgreSQL using Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up --build -d
      ```
    - Step 2: Install dependencies:
      ```bash
      npm install
      ```
    - Step 3: Run the application:
      ```bash
      npm run start:dev
      ```
- **Expected Results:** The NestJS application starts successfully and connects to PostgreSQL. The terminal displays `Nest application successfully started` and TypeORM automatically creates the tables in the database.
- **Conclusion:** The development environment is ready with PostgreSQL running in Docker and the NestJS application connected successfully via TypeORM.

### 2. Architecture

| Component | Role |
|-----------|------|
| **CatEntity** | Primary Entity representing the `cats` table |
| **CatPassportEntity** | **One-to-One** relationship with Cat (cat passport) |
| **ToyEntity** | **One-to-Many** relationship with Cat (cat toys) |
| **OwnerEntity** | **Many-to-Many** relationship with Cat (cat owners) |
| **CatsController** | Receives HTTP requests from the Client |
| **CatsService** | Handles business logic, interacts with the Repository |
| **TypeORM Repository** | Data access layer, translates Entities into SQL |

The data flow follows: **Controller** -> **Service** -> **Repository (TypeORM)** -> **PostgreSQL**.

Thanks to `cascade: true` in the relationships, when creating a new `Cat` along with `CatPassport`, `Toy`, and `Owner`, TypeORM automatically saves everything in a single `save()` call.

- **Execution Steps:**
    - Step 1: Open the main Entity file (e.g., `cat.entity.ts`) to examine how `@OneToOne()`, `@OneToMany()`, and `@ManyToMany()` decorators are defined.
    - Step 2: Open the Service file to see how the Repository and cascade save are used.
- **Expected Results:** Understand the Entity structure, relationship declarations, and how TypeORM automatically creates corresponding tables in PostgreSQL.
- **Conclusion:** The clean layered architecture separates responsibilities between Controller, Service, and Repository — making the codebase easy to maintain and extend.

### 3. System Flow

```
[Client] ──HTTP Request──> [CatsController]
                                  │
                                  ▼
                           [CatsService]
                                  │
                           TypeORM Repository
                           (cascade: true)
                                  │
                                  ▼
                           [PostgreSQL]
                    ┌──────────┼──────────┐
                    │          │          │
               [cats]   [cat_passports]  [toys]
                    │                    │
                    └────[cats_owners]───┘
                        (Many-to-Many)
```

- **Execution Steps:**
    - Step 1: The Client sends **POST /cats** with a body containing Cat information along with Passport, Toys, and Owners.
    - Step 2: **CatsController** receives the request and delegates to **CatsService**.
    - Step 3: **CatsService** calls `repository.save()` with `cascade: true`, and TypeORM automatically creates records in all related tables.
- **Expected Results:** A single request creates data simultaneously in the `cats`, `cat_passports`, `toys`, and the junction table `cats_owners`.
- **Conclusion:** **Cascade save** simplifies creating complex relational data with just a single `save()` call.

### 4. Try it out

**Success path** — Create a new cat and query the data:

- **Execution Steps:**
    - Step 1: Create a new cat with all relationships:
      ```bash
      curl -X POST http://localhost:3000/cats \
        -H "Content-Type: application/json" \
        -d '{
          "name": "Tom",
          "age": 3,
          "passport": { "issuedAt": "2024-01-01" },
          "toys": [{ "name": "Ball" }, { "name": "Mouse" }],
          "owners": [{ "name": "Alice" }, { "name": "Bob" }]
        }'
      ```
    - Step 2: Retrieve the list of all cats:
      ```bash
      curl -X GET http://localhost:3000/cats
      ```
    - Step 3: Retrieve a specific cat by ID:
      ```bash
      curl -X GET http://localhost:3000/cats/1
      ```
- **Expected Results:**
    1. **POST /cats** returns the new Cat object with Passport, Toys, and Owners saved successfully.
    2. **GET /cats** returns a list of all cats in the database.
    3. **GET /cats/1** returns the details of the cat with `id = 1` including all related entities.
- **Conclusion:** TypeORM with `cascade: true` handles all relational data saving automatically — with just a single `save()` call.

**Failure path** — Send data missing required fields:

- **Execution Steps:**
    - Step 1: Send a request to create a cat without the `name` field:
      ```bash
      curl -X POST http://localhost:3000/cats \
        -H "Content-Type: application/json" \
        -d '{ "age": 3 }'
      ```
    - Step 2: Try querying a cat with a non-existent ID:
      ```bash
      curl -X GET http://localhost:3000/cats/9999
      ```
- **Expected Results:**
    1. The request missing required fields returns a **400 Bad Request** or **500 Internal Server Error** depending on the validation configuration.
    2. Querying a non-existent ID returns **null** or a **404 Not Found** error.
- **Conclusion:** TypeORM and PostgreSQL automatically enforce schema constraints — invalid data is rejected before being written to the database.

## IV. Conclusion

**TypeORM** is a powerful bridge between **TypeScript** and **PostgreSQL**, allowing you to define schemas with code, configure relationships with decorators, and optimize queries with indexing. Cascade save simplifies complex data operations, while Transactions ensure absolute data integrity.

**Conclusion:** Mastering TypeORM is not just about writing Entities — it is about understanding how to design relationships, optimize performance, and ensure data consistency in every scenario.

# references
## 0
### alias
TypeORM Entities
### url
https://typeorm.io/entities
## 1
### alias
TypeORM Transactions
### url
https://typeorm.io/transactions

# minutesRead
30
