# title
Blog API với Mongoose và MongoDB

# description
Xây dựng API quản lý bài viết blog với Mongoose, tận dụng tính linh hoạt của MongoDB để lưu trữ metadata tuỳ biến và mảng tags.

# requirements
Tạo `PostSchema` với các trường: title (required, indexed), content (required), author (required), tags ([String]), metadata (Object - linh hoạt), timestamps:true. Endpoint `POST /posts` tạo bài viết mới. `GET /posts` trả danh sách sắp xếp theo createdAt giảm dần. `GET /posts/:id` trả chi tiết một bài viết. `PATCH /posts/:id` cập nhật bài viết.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Docker (để chạy MongoDB)
- npm install

# steps

## 0
### title
Khởi tạo project và cấu hình MongoDB
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới bằng NestJS CLI:
    ```bash
    nest new mongoose-and-mongodb-easy
    ```
  - Bước 2: Di chuyển vào thư mục project:
    ```bash
    cd mongoose-and-mongodb-easy
    ```
  - Bước 3: Cài đặt các dependency cần thiết:
    ```bash
    npm install @nestjs/mongoose mongoose
    ```
  - Bước 4: Tạo file `docker-compose.yml` tại thư mục gốc để khởi động MongoDB:
    ```yaml
    services:
      mongo:
        image: mongo:7
        environment:
          MONGO_INITDB_ROOT_USERNAME: mongo
          MONGO_INITDB_ROOT_PASSWORD: mongo
        ports:
          - "27017:27017"
    ```
  - Bước 5: Khởi động MongoDB:
    ```bash
    docker compose up -d
    ```
  - Bước 6: Cấu hình `MongooseModule.forRoot()` trong `AppModule` với connection string `mongodb://mongo:mongo@localhost:27017/blog?authSource=admin`.
- **Kết quả mong đợi:** MongoDB chạy trong Docker, ứng dụng NestJS kết nối thành công tới database `blog`.
- **Kết luận:** Môi trường phát triển đã sẵn sàng với MongoDB và Mongoose được tích hợp vào NestJS.

## 1
### title
Định nghĩa Schema và Model
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `post.schema.ts`, định nghĩa `PostSchema` sử dụng decorator `@Schema({ timestamps: true })` để tự động thêm `createdAt` và `updatedAt`.
  - Bước 2: Thêm các trường với decorator `@Prop()`:
    - `title`: kiểu `string`, `required: true`, `index: true` để tối ưu truy vấn theo tiêu đề.
    - `content`: kiểu `string`, `required: true`.
    - `author`: kiểu `string`, `required: true`.
    - `tags`: kiểu `[String]`, mặc định là mảng rỗng `[]`.
    - `metadata`: kiểu `Object` (Schema.Types.Mixed), cho phép lưu trữ dữ liệu linh hoạt không cố định schema.
  - Bước 3: Export Schema bằng `SchemaFactory.createForClass(Post)`.
  - Bước 4: Đăng ký Schema trong module bằng `MongooseModule.forFeature([{ name: Post.name, schema: PostSchema }])`.
- **Kết quả mong đợi:** Schema `Post` được định nghĩa đúng cách với timestamps tự động, index trên trường `title`, và trường `metadata` linh hoạt.
- **Kết luận:** Mongoose Schema cho phép khai báo cấu trúc document rõ ràng trong khi vẫn giữ được tính linh hoạt của MongoDB thông qua trường Mixed type.

## 2
### title
Xây dựng Service và Controller
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `PostService` và inject Model bằng `@InjectModel(Post.name) private postModel: Model<Post>`.
  - Bước 2: Cài đặt hàm `create(data)` sử dụng `this.postModel.create(data)` để tạo document mới.
  - Bước 3: Cài đặt hàm `findAll()` sử dụng `this.postModel.find().sort({ createdAt: -1 }).exec()` để trả danh sách bài viết sắp xếp theo thời gian tạo giảm dần.
  - Bước 4: Cài đặt hàm `findOne(id)` sử dụng `this.postModel.findById(id).exec()`. Nếu không tìm thấy, ném `NotFoundException`.
  - Bước 5: Cài đặt hàm `update(id, data)` sử dụng `this.postModel.findByIdAndUpdate(id, data, { new: true }).exec()`. Nếu không tìm thấy, ném `NotFoundException`.
  - Bước 6: Tạo `PostController` với 4 endpoint:
    - `POST /posts` nhận body và gọi `postService.create(body)`.
    - `GET /posts` gọi `postService.findAll()`.
    - `GET /posts/:id` gọi `postService.findOne(id)`.
    - `PATCH /posts/:id` nhận body và gọi `postService.update(id, body)`.
- **Kết quả mong đợi:** Cả 4 endpoint hoạt động đúng, hỗ trợ tạo mới, truy vấn danh sách, truy vấn chi tiết và cập nhật bài viết.
- **Kết luận:** Service và Controller đã triển khai đầy đủ CRUD cơ bản với Mongoose, sử dụng đúng các phương thức truy vấn của Model.

## 3
### title
Kiểm thử các endpoint
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Tạo bài viết mới với tags và metadata linh hoạt:
    ```bash
    curl -X POST http://localhost:3000/posts \
      -H "Content-Type: application/json" \
      -d '{
        "title": "Getting Started with MongoDB",
        "content": "MongoDB is a document database...",
        "author": "Jane Doe",
        "tags": ["mongodb", "nosql", "tutorial"],
        "metadata": { "readTime": 5, "featured": true, "source": "internal" }
      }'
    ```
  - Bước 3: Tạo thêm bài viết thứ 2 với metadata khác cấu trúc:
    ```bash
    curl -X POST http://localhost:3000/posts \
      -H "Content-Type: application/json" \
      -d '{
        "title": "Mongoose Best Practices",
        "content": "Schema design is crucial...",
        "author": "Jane Doe",
        "tags": ["mongoose", "best-practices"],
        "metadata": { "series": "MongoDB Mastery", "part": 2 }
      }'
    ```
  - Bước 4: Lấy danh sách bài viết (xác nhận sắp xếp theo createdAt giảm dần):
    ```bash
    curl http://localhost:3000/posts
    ```
  - Bước 5: Cập nhật bài viết, thêm tag mới:
    ```bash
    curl -X PATCH http://localhost:3000/posts/<id> \
      -H "Content-Type: application/json" \
      -d '{
        "tags": ["mongodb", "nosql", "tutorial", "beginner"]
      }'
    ```
- **Kết quả mong đợi:**
  - `POST /posts` trả về document mới kèm `_id`, `createdAt`, `updatedAt` tự động.
  - `GET /posts` trả danh sách bài viết, bài viết mới nhất ở đầu.
  - `PATCH /posts/:id` trả về document đã cập nhật với trường `updatedAt` thay đổi.
  - Hai bài viết có trường `metadata` khác cấu trúc nhưng đều lưu thành công, chứng minh tính linh hoạt của MongoDB.
- **Kết luận:** Blog API hoạt động đúng với Mongoose và MongoDB, chứng minh khả năng lưu trữ dữ liệu linh hoạt qua trường Mixed type và mảng tags có độ dài không cố định.

# references
## 0
### alias
NestJS Mongoose Integration
### url
https://docs.nestjs.com/techniques/mongodb
## 1
### alias
Mongoose Schemas Guide
### url
https://mongoosejs.com/docs/guide.html
## 2
### alias
Mongoose Queries
### url
https://mongoosejs.com/docs/queries.html

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
Đúng cấu trúc Schema và Model
##### score
10
##### promptText
`PostSchema` có đầy đủ các trường `title` (required, indexed), `content` (required), `author` (required), `tags` ([String]), `metadata` (Mixed type), `timestamps: true`. Schema được đăng ký đúng cách trong module.
#### 1
##### title
Đúng kết quả endpoint
##### score
10
##### promptText
`POST /posts` tạo bài viết mới với tags và metadata linh hoạt. `GET /posts` trả danh sách sắp xếp theo `createdAt` giảm dần. `PATCH /posts/:id` cập nhật bài viết thành công, `updatedAt` thay đổi.

# difficulty
easy

# score
20
