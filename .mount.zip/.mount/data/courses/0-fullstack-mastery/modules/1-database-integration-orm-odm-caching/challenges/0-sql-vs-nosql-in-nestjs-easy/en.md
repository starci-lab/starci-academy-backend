# title
Analyze SQL vs NoSQL Selection for a Real-World System

# description
Analyze an e-commerce management system, determine which data fits SQL (PostgreSQL) and which fits NoSQL (MongoDB), and present technical reasoning for each choice.

# requirements
Write an analysis document for a mini e-commerce system consisting of: User, Order, Product (SQL) and ActivityLog, ProductReview (NoSQL). Explain why each data type fits its corresponding database type. Present the pros/cons of using a single database vs multiple databases (Polyglot Persistence). The document must include diagrams illustrating the data structure for each database type.

# prerequisites
- Basic knowledge of SQL and NoSQL
- Understanding of Relational Database and Document Database concepts
- Google Docs or equivalent document editing tool

# steps

## 0
### title
Analyze data requirements of the e-commerce system
### body
- **Steps to follow:**
  - Step 1: List the main data objects of the e-commerce system: User, Product, Order, ActivityLog, ProductReview.
  - Step 2: For each object, identify its characteristics: fixed or flexible structure, referential constraints between tables, read/write frequency, consistency requirements.
  - Step 3: Classify the objects into 2 groups: SQL-suited (fixed structure, referential constraints) and NoSQL-suited (flexible structure, few relationships, write-heavy).
- **Expected result:** A clear classification table of 5 objects into SQL and NoSQL groups with specific technical reasoning.
- **Conclusion:** Analyzing data characteristics before choosing a database helps avoid architectural mistakes from the start.

## 1
### title
Design data structure for the SQL group
### body
- **Steps to follow:**
  - Step 1: Design the `users` table with columns: id (PRIMARY KEY), email (UNIQUE), name, password_hash, created_at.
  - Step 2: Design the `products` table with columns: id (PRIMARY KEY), name, price, stock_quantity, category_id (FOREIGN KEY).
  - Step 3: Design the `orders` table with columns: id (PRIMARY KEY), user_id (FOREIGN KEY to users), total_amount, status, created_at. Add a junction table `order_items` to link Order and Product (Many-to-Many relationship).
  - Step 4: Draw an Entity-Relationship Diagram (ERD) of the 3 main tables and junction table, clearly showing PRIMARY KEY, FOREIGN KEY, and relationship types (One-to-Many, Many-to-Many).
- **Expected result:** A complete ERD showing tables, columns, primary keys, foreign keys, and their relationships.
- **Conclusion:** Data with fixed structure and referential integrity (User, Product, Order) fits SQL because it requires ACID compliance and efficient JOINs.

## 2
### title
Design data structure for the NoSQL group
### body
- **Steps to follow:**
  - Step 1: Design the `ActivityLog` document with a flexible structure:
    ```json
    {
      "userId": "abc123",
      "action": "view_product",
      "metadata": { "productId": "p001", "duration": 30, "source": "mobile" },
      "timestamp": "2024-01-15T10:30:00Z"
    }
    ```
    Explain why the `metadata` field needs to be flexible (each action type has different metadata).
  - Step 2: Design the `ProductReview` document with diverse review fields:
    ```json
    {
      "productId": "p001",
      "userId": "abc123",
      "rating": 4,
      "comment": "Great product",
      "images": ["url1.jpg", "url2.jpg"],
      "tags": ["quality", "fast-delivery"],
      "helpful_votes": 15
    }
    ```
    Explain why the variable-length `images` and `tags` arrays fit the document model.
  - Step 3: Compare what problems would arise if ActivityLog and ProductReview were stored in SQL (rigid schema, need for auxiliary tables, poor write performance at scale).
- **Expected result:** Two sample document schemas with analysis explaining why NoSQL was chosen for each data type.
- **Conclusion:** Data with frequently changing structure, few referential constraints, and write-speed priority fits NoSQL.

## 3
### title
Present Polyglot Persistence analysis and conclusion
### body
- **Steps to follow:**
  - Step 1: Write a comparison of pros/cons for 2 approaches:
    - **Approach 1 - Single database (SQL only):** simpler operations, but loses flexibility with unstructured data, poor log write performance at scale.
    - **Approach 2 - Polyglot Persistence (SQL + NoSQL):** optimized for each data type, but increases operational complexity, requires data synchronization between 2 systems.
  - Step 2: Provide a final recommendation for the mini e-commerce system: choose Polyglot Persistence with PostgreSQL for core business data and MongoDB for logs and reviews.
  - Step 3: Compile the complete document including: data classification table, ERD diagram (SQL), document schemas (NoSQL), pros/cons comparison table, and technical recommendation.
- **Expected result:** A complete analysis document with clear structure, illustrations, and convincing technical arguments.
- **Conclusion:** Polyglot Persistence is a common strategy in real-world systems, leveraging each database type's strengths for the right purpose.

# references
## 0
### alias
NestJS TypeORM Integration
### url
https://docs.nestjs.com/techniques/database
## 1
### alias
NestJS Mongoose Integration
### url
https://docs.nestjs.com/techniques/mongodb
## 2
### alias
MongoDB vs PostgreSQL Comparison
### url
https://www.mongodb.com/compare/mongodb-postgresql

# submissions
## 0
### type
googleDocsUrl
### title
SQL vs NoSQL Analysis Document Link
### description
Submit the Google Docs link containing your SQL vs NoSQL analysis document for the e-commerce system.
### score
20
### prompts
#### 0
##### title
Correct data classification and technical reasoning
##### score
10
##### promptText
Correctly classifies 5 data objects into SQL (User, Product, Order) and NoSQL (ActivityLog, ProductReview) groups with specific technical reasoning for each. Includes an ERD for the SQL part and sample document schemas for the NoSQL part.
#### 1
##### title
Complete Polyglot Persistence analysis
##### score
10
##### promptText
Clearly presents pros/cons of single database vs multiple databases, with specific technical recommendations for the e-commerce system. Arguments are convincing and practical.

# difficulty
easy

# score
20
