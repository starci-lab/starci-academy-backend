# title
Cache Product List with Redis

# description
Integrate Redis to cache the product list, reducing database load and improving API response speed.

# requirements
Integrate Redis into NestJS. Cache the response of `GET /products` endpoint using `CACHE_MANAGER` (Logic Layer) with a TTL of 60 seconds. When `POST /products` creates a new product, delete the corresponding cache key to ensure the latest data. The second call to `GET /products` must return from cache (no database query). Use in-memory data (array) instead of a real database to focus on the caching mechanism.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Docker (to run Redis)
- npm install

# steps

## 0
### title
Initialize the project and configure Redis
### body
- **Steps to follow:**
  - Step 1: Create a new project using NestJS CLI:
    ```bash
    nest new caching-with-redis-easy
    ```
  - Step 2: Navigate to the project directory:
    ```bash
    cd caching-with-redis-easy
    ```
  - Step 3: Install the required dependencies:
    ```bash
    npm install @nestjs/cache-manager cache-manager cache-manager-redis-store redis
    ```
  - Step 4: Create a `docker-compose.yml` file at the project root to start Redis:
    ```yaml
    services:
      redis:
        image: redis:7-alpine
        ports:
          - "6379:6379"
    ```
  - Step 5: Start Redis:
    ```bash
    docker compose up -d
    ```
  - Step 6: Configure `CacheModule.register()` in `AppModule` with `store` as `redisStore`, `host: 'localhost'`, `port: 6379`, and `ttl: 60` (seconds).
- **Expected result:** Redis runs in Docker, NestJS application connects successfully to the Redis server.
- **Conclusion:** The development environment is ready with Redis and Cache Manager integrated into NestJS.

## 1
### title
Create ProductModule with in-memory data
### body
- **Steps to follow:**
  - Step 1: Create `ProductModule`, `ProductService`, `ProductController`.
  - Step 2: In `ProductService`, initialize a sample data array:
    ```typescript
    private products = [
      { id: 1, name: 'Laptop', price: 999 },
      { id: 2, name: 'Phone', price: 699 },
      { id: 3, name: 'Tablet', price: 499 },
    ];
    ```
  - Step 3: Implement the `findAll()` method returning the entire products array.
  - Step 4: Implement the `create(data)` method adding a new product to the array with an auto-incrementing id.
  - Step 5: In `ProductController`, create endpoint `GET /products` calling `findAll()` and `POST /products` calling `create(body)`.
- **Expected result:** Both endpoints work correctly with in-memory data, without caching yet.
- **Conclusion:** The core business module is ready; the next step will add the caching layer with Redis.

## 2
### title
Integrate Cache Manager into Service
### body
- **Steps to follow:**
  - Step 1: Inject `CACHE_MANAGER` into `ProductService` using `@Inject(CACHE_MANAGER) private cacheManager: Cache`.
  - Step 2: Update the `findAll()` method with caching logic:
    - Check cache first: `const cached = await this.cacheManager.get('products')`.
    - If cache exists, return the cached data immediately.
    - If no cache, get data from the in-memory array, save to cache using `await this.cacheManager.set('products', this.products, 60)`, then return the data.
  - Step 3: Add console logs to distinguish responses from cache vs data source:
    - When serving from cache: `console.log('Serving from cache')`.
    - When serving from data source: `console.log('Serving from data source')`.
  - Step 4: Update the `create(data)` method: after adding the new product, delete the cache using `await this.cacheManager.del('products')` to ensure the next `GET /products` call fetches the latest data.
- **Expected result:** The first `GET /products` call fetches from the data source and saves to cache. The second call returns from cache. After `POST /products`, cache is deleted and the next `GET /products` call fetches from the data source again.
- **Conclusion:** Proper cache invalidation ensures data consistency between cache and data source.

## 3
### title
Test the caching flow
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Call `GET /products` for the first time:
    ```bash
    curl http://localhost:3000/products
    ```
    Check the terminal log shows `Serving from data source`.
  - Step 3: Call `GET /products` a second time immediately:
    ```bash
    curl http://localhost:3000/products
    ```
    Check the terminal log shows `Serving from cache`.
  - Step 4: Create a new product (trigger cache invalidation):
    ```bash
    curl -X POST http://localhost:3000/products \
      -H "Content-Type: application/json" \
      -d '{ "name": "Monitor", "price": 399 }'
    ```
  - Step 5: Call `GET /products` again:
    ```bash
    curl http://localhost:3000/products
    ```
    Check the terminal log shows `Serving from data source` (cache was deleted). Verify the response includes the newly created product.
  - Step 6: Call `GET /products` once more to confirm cache has been recreated:
    ```bash
    curl http://localhost:3000/products
    ```
    Check the terminal log shows `Serving from cache`.
- **Expected result:**
  - Call 1: data source, response contains 3 initial products.
  - Call 2: cache, response same as call 1.
  - After `POST /products`: cache is deleted.
  - Call 3: data source, response contains 4 products (including the new product).
  - Call 4: cache, response same as call 3.
- **Conclusion:** The complete caching flow has been demonstrated: cache hits speed up responses, cache invalidation when data changes ensures consistency, and cache automatically recreates after being deleted.

# references
## 0
### alias
NestJS Caching
### url
https://docs.nestjs.com/techniques/caching
## 1
### alias
cache-manager npm
### url
https://www.npmjs.com/package/cache-manager
## 2
### alias
Redis Documentation
### url
https://redis.io/docs/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
Correct Redis and Cache Manager configuration
##### score
10
##### promptText
Redis is correctly integrated via `CacheModule` and `CACHE_MANAGER`. The `findAll()` method checks cache before querying the data source. The `create()` method deletes the cache key after adding new data.
#### 1
##### title
Correct cache hit and cache invalidation flow
##### score
10
##### promptText
First `GET /products` fetches from data source, second fetches from cache. After `POST /products`, cache is deleted and the next `GET /products` fetches from data source with the latest data.

# difficulty
easy

# score
20
