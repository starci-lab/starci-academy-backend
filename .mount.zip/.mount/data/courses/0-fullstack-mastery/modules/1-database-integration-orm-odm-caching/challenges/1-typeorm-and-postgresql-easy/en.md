# title
Book Library Management with TypeORM and PostgreSQL

# description
Build a book library management system with relationships between Book, Author, and Category using TypeORM and PostgreSQL in NestJS.

# requirements
Create `BookEntity` (id, title, isbn, publishedYear), `AuthorEntity` (id, name, bio) with `@ManyToOne`/`@OneToMany` relationship (one Author has many Books). Create `CategoryEntity` (id, name) with `@ManyToMany` relationship with Book. Endpoint `POST /books` creates a new book with author and categories (cascade). Endpoint `GET /books` returns the list of books with relations. Endpoint `GET /books/:id` returns details of a single book with author and categories.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Docker (to run PostgreSQL)
- npm install

# steps

## 0
### title
Initialize the project and configure PostgreSQL
### body
- **Steps to follow:**
  - Step 1: Create a new project using NestJS CLI:
    ```bash
    nest new typeorm-and-postgresql-easy
    ```
  - Step 2: Navigate to the project directory:
    ```bash
    cd typeorm-and-postgresql-easy
    ```
  - Step 3: Install the required dependencies:
    ```bash
    npm install @nestjs/typeorm typeorm pg
    ```
  - Step 4: Create a `docker-compose.yml` file at the project root to start PostgreSQL:
    ```yaml
    services:
      postgres:
        image: postgres:16
        environment:
          POSTGRES_USER: postgres
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: library
        ports:
          - "5432:5432"
    ```
  - Step 5: Start PostgreSQL:
    ```bash
    docker compose up -d
    ```
  - Step 6: Configure `TypeOrmModule.forRoot()` in `AppModule` with PostgreSQL connection details, enable `synchronize: true` so TypeORM auto-creates tables.
- **Expected result:** PostgreSQL runs in Docker, NestJS application connects successfully to the `library` database.
- **Conclusion:** The development environment is ready with PostgreSQL and TypeORM integrated into NestJS.

## 1
### title
Define Entities and relationships
### body
- **Steps to follow:**
  - Step 1: Create `AuthorEntity` with columns: `id` (PrimaryGeneratedColumn), `name` (varchar), `bio` (text, nullable). Add the decorator `@OneToMany(() => BookEntity, (book) => book.author)` to establish the one-to-many relationship with Book.
  - Step 2: Create `CategoryEntity` with columns: `id` (PrimaryGeneratedColumn), `name` (varchar, unique).
  - Step 3: Create `BookEntity` with columns: `id` (PrimaryGeneratedColumn), `title` (varchar), `isbn` (varchar, unique), `publishedYear` (int). Add:
    - `@ManyToOne(() => AuthorEntity, (author) => author.books, { cascade: true, eager: true })` for the `author` field.
    - `@ManyToMany(() => CategoryEntity, { cascade: true, eager: true })` combined with `@JoinTable()` for the `categories` field.
  - Step 4: Register all 3 Entities in `TypeOrmModule.forFeature([BookEntity, AuthorEntity, CategoryEntity])` of the corresponding module.
- **Expected result:** On application startup, TypeORM auto-creates 3 tables `books`, `authors`, `categories` and a junction table `books_categories_categories` in PostgreSQL.
- **Conclusion:** Entities with ManyToOne and ManyToMany relationships are correctly defined, and TypeORM auto-generates the corresponding schema.

## 2
### title
Build Service and Controller
### body
- **Steps to follow:**
  - Step 1: Create `BookService` and inject `Repository<BookEntity>` via `@InjectRepository(BookEntity)`.
  - Step 2: Implement the `create(data)` method using `this.bookRepository.save(data)`. Thanks to `cascade: true`, when passing a Book object with new Author and Categories, TypeORM will automatically create records in all related tables.
  - Step 3: Implement the `findAll()` method using `this.bookRepository.find({ relations: ['author', 'categories'] })` to return the book list with relations.
  - Step 4: Implement the `findOne(id)` method using `this.bookRepository.findOne({ where: { id }, relations: ['author', 'categories'] })`. If not found, throw `NotFoundException`.
  - Step 5: Create `BookController` with 3 endpoints:
    - `POST /books` accepts a body and calls `bookService.create(body)`.
    - `GET /books` calls `bookService.findAll()`.
    - `GET /books/:id` calls `bookService.findOne(id)`.
- **Expected result:** All 3 endpoints work correctly, allowing book creation and querying the list or details with relations.
- **Conclusion:** Service and Controller have been fully implemented with basic CRUD, cascade save, and eager loading of relations.

## 3
### title
Test the endpoints
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Create a new book with author and categories:
    ```bash
    curl -X POST http://localhost:3000/books \
      -H "Content-Type: application/json" \
      -d '{
        "title": "NestJS in Action",
        "isbn": "978-0-13-468599-1",
        "publishedYear": 2024,
        "author": { "name": "John Doe", "bio": "Backend developer" },
        "categories": [{ "name": "Programming" }, { "name": "Backend" }]
      }'
    ```
  - Step 3: Get the list of all books:
    ```bash
    curl http://localhost:3000/books
    ```
  - Step 4: Get details of a single book by id:
    ```bash
    curl http://localhost:3000/books/1
    ```
  - Step 5: Create another book with an existing author to verify the ManyToOne relationship:
    ```bash
    curl -X POST http://localhost:3000/books \
      -H "Content-Type: application/json" \
      -d '{
        "title": "Advanced TypeORM",
        "isbn": "978-0-13-468599-2",
        "publishedYear": 2025,
        "author": { "id": 1 },
        "categories": [{ "name": "Programming" }]
      }'
    ```
- **Expected result:**
  - `POST /books` returns a new Book object with Author and Categories saved successfully.
  - `GET /books` returns the list of all books with relations.
  - `GET /books/1` returns the details of the book with id = 1 including author and categories.
- **Conclusion:** The book library management system works correctly with ManyToOne and ManyToMany relationships, cascade save and eager loading are both verified through endpoint results.

# references
## 0
### alias
TypeORM Entities
### url
https://typeorm.io/entities
## 1
### alias
TypeORM Relations
### url
https://typeorm.io/relations
## 2
### alias
NestJS Database Integration
### url
https://docs.nestjs.com/techniques/database

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
Correct Entity structure and relationships
##### score
10
##### promptText
Has all `BookEntity`, `AuthorEntity`, `CategoryEntity` with `@ManyToOne`/`@OneToMany` between Book-Author and `@ManyToMany` between Book-Category. Cascade is correctly configured.
#### 1
##### title
Correct endpoint results
##### score
10
##### promptText
`POST /books` creates a new book with author and categories successfully. `GET /books` returns the book list with relations. `GET /books/:id` returns book details with author and categories.

# difficulty
easy

# score
20
