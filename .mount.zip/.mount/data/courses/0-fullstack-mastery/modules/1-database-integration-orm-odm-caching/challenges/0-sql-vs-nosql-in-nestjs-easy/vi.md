# title
Phân tích lựa chọn SQL vs NoSQL cho hệ thống thực tế

# description
Phân tích một hệ thống quản lý thương mại điện tử, xác định dữ liệu nào phù hợp với SQL (PostgreSQL) và dữ liệu nào phù hợp với NoSQL (MongoDB), trình bày lý do kỹ thuật cho từng lựa chọn.

# requirements
Viết tài liệu phân tích cho hệ thống e-commerce mini gồm: User, Order, Product (SQL) và ActivityLog, ProductReview (NoSQL). Giải thích tại sao mỗi loại dữ liệu phù hợp với loại database tương ứng. Trình bày ưu/nhược điểm khi dùng đơn database vs đa database (Polyglot Persistence). Tài liệu phải có sơ đồ minh hoạ cấu trúc dữ liệu của từng loại database.

# prerequisites
- Kiến thức cơ bản về SQL và NoSQL
- Hiểu khái niệm về Relational Database và Document Database
- Google Docs hoặc công cụ soạn tài liệu tương đương

# steps

## 0
### title
Phân tích yêu cầu dữ liệu của hệ thống e-commerce
### body
- **Các bước thực hiện:**
  - Bước 1: Liệt kê các đối tượng dữ liệu chính của hệ thống e-commerce: User, Product, Order, ActivityLog, ProductReview.
  - Bước 2: Với mỗi đối tượng, xác định các đặc điểm: cấu trúc cố định hay linh hoạt, có quan hệ ràng buộc giữa các bảng không, tần suất đọc/ghi, yêu cầu về tính nhất quán (consistency).
  - Bước 3: Phân loại các đối tượng thành 2 nhóm: nhóm phù hợp với SQL (dữ liệu có cấu trúc cố định, quan hệ ràng buộc) và nhóm phù hợp với NoSQL (dữ liệu linh hoạt, ít quan hệ, ghi nhiều).
- **Kết quả mong đợi:** Có bảng phân loại rõ ràng 5 đối tượng vào 2 nhóm SQL và NoSQL kèm lý do kỹ thuật cụ thể.
- **Kết luận:** Việc phân tích đặc điểm dữ liệu trước khi chọn database giúp tránh sai lầm kiến trúc ngay từ đầu.

## 1
### title
Thiết kế cấu trúc dữ liệu cho nhóm SQL
### body
- **Các bước thực hiện:**
  - Bước 1: Thiết kế bảng `users` với các cột: id (PRIMARY KEY), email (UNIQUE), name, password_hash, created_at.
  - Bước 2: Thiết kế bảng `products` với các cột: id (PRIMARY KEY), name, price, stock_quantity, category_id (FOREIGN KEY).
  - Bước 3: Thiết kế bảng `orders` với các cột: id (PRIMARY KEY), user_id (FOREIGN KEY tới users), total_amount, status, created_at. Thêm bảng trung gian `order_items` để liên kết Order và Product (quan hệ Many-to-Many).
  - Bước 4: Vẽ sơ đồ quan hệ (ERD) giữa 3 bảng chính và bảng trung gian, chỉ rõ PRIMARY KEY, FOREIGN KEY và kiểu quan hệ (One-to-Many, Many-to-Many).
- **Kết quả mong đợi:** Sơ đồ ERD hoàn chỉnh thể hiện các bảng, cột, khoá chính, khoá ngoại và mối quan hệ giữa chúng.
- **Kết luận:** Dữ liệu có cấu trúc cố định và ràng buộc toàn vẹn (User, Product, Order) phù hợp với SQL vì cần đảm bảo ACID và JOIN hiệu quả.

## 2
### title
Thiết kế cấu trúc dữ liệu cho nhóm NoSQL
### body
- **Các bước thực hiện:**
  - Bước 1: Thiết kế document `ActivityLog` với cấu trúc linh hoạt:
    ```json
    {
      "userId": "abc123",
      "action": "view_product",
      "metadata": { "productId": "p001", "duration": 30, "source": "mobile" },
      "timestamp": "2024-01-15T10:30:00Z"
    }
    ```
    Giải thích tại sao trường `metadata` cần linh hoạt (mỗi loại action có metadata khác nhau).
  - Bước 2: Thiết kế document `ProductReview` với trường đánh giá đa dạng:
    ```json
    {
      "productId": "p001",
      "userId": "abc123",
      "rating": 4,
      "comment": "Sản phẩm tốt",
      "images": ["url1.jpg", "url2.jpg"],
      "tags": ["chất lượng", "giao hàng nhanh"],
      "helpful_votes": 15
    }
    ```
    Giải thích tại sao mảng `images` và `tags` có độ dài không cố định phù hợp với document model.
  - Bước 3: So sánh nếu lưu ActivityLog và ProductReview vào SQL sẽ gặp vấn đề gì (schema cứng nhắc, cần nhiều bảng phụ, hiệu năng ghi kém khi dữ liệu lớn).
- **Kết quả mong đợi:** Có 2 document schema mẫu kèm phân tích lý do chọn NoSQL cho từng loại dữ liệu.
- **Kết luận:** Dữ liệu có cấu trúc thay đổi thường xuyên, ít ràng buộc quan hệ và ưu tiên tốc độ ghi phù hợp với NoSQL.

## 3
### title
Trình bày phân tích Polyglot Persistence và kết luận
### body
- **Các bước thực hiện:**
  - Bước 1: Viết phần so sánh ưu/nhược điểm của 2 phương án:
    - **Phương án 1 - Đơn database (chỉ SQL):** đơn giản vận hành, nhưng mất linh hoạt với dữ liệu phi cấu trúc, hiệu năng ghi log kém khi scale.
    - **Phương án 2 - Polyglot Persistence (SQL + NoSQL):** tối ưu cho từng loại dữ liệu, nhưng tăng độ phức tạp vận hành, cần đồng bộ dữ liệu giữa 2 hệ thống.
  - Bước 2: Đưa ra khuyến nghị cuối cùng cho hệ thống e-commerce mini: chọn Polyglot Persistence với PostgreSQL cho dữ liệu nghiệp vụ chính và MongoDB cho log và review.
  - Bước 3: Tổng hợp tài liệu hoàn chỉnh gồm: bảng phân loại dữ liệu, sơ đồ ERD (SQL), document schema (NoSQL), bảng so sánh ưu/nhược điểm, và khuyến nghị kỹ thuật.
- **Kết quả mong đợi:** Tài liệu phân tích hoàn chỉnh, có cấu trúc rõ ràng, có minh hoạ và lập luận kỹ thuật thuyết phục.
- **Kết luận:** Polyglot Persistence là chiến lược phổ biến trong hệ thống thực tế, giúp tận dụng thế mạnh của từng loại database cho đúng mục đích.

# references
## 0
### alias
NestJS TypeORM Integration
### url
https://docs.nestjs.com/techniques/database
## 1
### alias
NestJS Mongoose Integration
### url
https://docs.nestjs.com/techniques/mongodb
## 2
### alias
MongoDB vs PostgreSQL Comparison
### url
https://www.mongodb.com/compare/mongodb-postgresql

# submissions
## 0
### type
googleDocsUrl
### title
Link tài liệu phân tích SQL vs NoSQL
### description
Nộp link Google Docs chứa tài liệu phân tích lựa chọn SQL vs NoSQL cho hệ thống e-commerce.
### score
20
### prompts
#### 0
##### title
Đúng phân loại dữ liệu và lập luận kỹ thuật
##### score
10
##### promptText
Phân loại đúng 5 đối tượng dữ liệu vào nhóm SQL (User, Product, Order) và NoSQL (ActivityLog, ProductReview) với lý do kỹ thuật cụ thể cho từng loại. Có sơ đồ ERD cho phần SQL và document schema mẫu cho phần NoSQL.
#### 1
##### title
Phân tích Polyglot Persistence đầy đủ
##### score
10
##### promptText
Trình bày rõ ưu/nhược điểm của đơn database vs đa database, có khuyến nghị kỹ thuật cụ thể cho hệ thống e-commerce. Lập luận có tính thuyết phục và thực tế.

# difficulty
easy

# score
20
