# title
Quản lý thư viện sách với TypeORM và PostgreSQL

# description
Xây dựng hệ thống quản lý thư viện sách với các quan hệ giữa Book, Author và Category sử dụng TypeORM và PostgreSQL trong NestJS.

# requirements
Tạo `BookEntity` (id, title, isbn, publishedYear), `AuthorEntity` (id, name, bio) với quan hệ `@ManyToOne`/`@OneToMany` (một Author có nhiều Book). Tạo `CategoryEntity` (id, name) với quan hệ `@ManyToMany` với Book. Endpoint `POST /books` tạo sách mới kèm author và categories (cascade). Endpoint `GET /books` trả danh sách sách kèm relations. Endpoint `GET /books/:id` trả chi tiết một cuốn sách kèm author và categories.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Docker (để chạy PostgreSQL)
- npm install

# steps

## 0
### title
Khởi tạo project và cấu hình PostgreSQL
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới bằng NestJS CLI:
    ```bash
    nest new typeorm-and-postgresql-easy
    ```
  - Bước 2: Di chuyển vào thư mục project:
    ```bash
    cd typeorm-and-postgresql-easy
    ```
  - Bước 3: Cài đặt các dependency cần thiết:
    ```bash
    npm install @nestjs/typeorm typeorm pg
    ```
  - Bước 4: Tạo file `docker-compose.yml` tại thư mục gốc để khởi động PostgreSQL:
    ```yaml
    services:
      postgres:
        image: postgres:16
        environment:
          POSTGRES_USER: postgres
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: library
        ports:
          - "5432:5432"
    ```
  - Bước 5: Khởi động PostgreSQL:
    ```bash
    docker compose up -d
    ```
  - Bước 6: Cấu hình `TypeOrmModule.forRoot()` trong `AppModule` với thông tin kết nối tới PostgreSQL, bật `synchronize: true` để TypeORM tự động tạo bảng.
- **Kết quả mong đợi:** PostgreSQL chạy trong Docker, ứng dụng NestJS kết nối thành công tới database `library`.
- **Kết luận:** Môi trường phát triển đã sẵn sàng với PostgreSQL và TypeORM được tích hợp vào NestJS.

## 1
### title
Định nghĩa Entity và quan hệ
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `AuthorEntity` với các cột: `id` (PrimaryGeneratedColumn), `name` (varchar), `bio` (text, nullable). Thêm decorator `@OneToMany(() => BookEntity, (book) => book.author)` để thiết lập quan hệ một-nhiều với Book.
  - Bước 2: Tạo `CategoryEntity` với các cột: `id` (PrimaryGeneratedColumn), `name` (varchar, unique).
  - Bước 3: Tạo `BookEntity` với các cột: `id` (PrimaryGeneratedColumn), `title` (varchar), `isbn` (varchar, unique), `publishedYear` (int). Thêm:
    - `@ManyToOne(() => AuthorEntity, (author) => author.books, { cascade: true, eager: true })` cho trường `author`.
    - `@ManyToMany(() => CategoryEntity, { cascade: true, eager: true })` kết hợp `@JoinTable()` cho trường `categories`.
  - Bước 4: Đăng ký cả 3 Entity trong `TypeOrmModule.forFeature([BookEntity, AuthorEntity, CategoryEntity])` của module tương ứng.
- **Kết quả mong đợi:** Khởi động ứng dụng, TypeORM tự động tạo 3 bảng `books`, `authors`, `categories` và bảng trung gian `books_categories_categories` trong PostgreSQL.
- **Kết luận:** Các Entity với quan hệ ManyToOne và ManyToMany đã được định nghĩa đúng cách, TypeORM tự động sinh schema tương ứng.

## 2
### title
Xây dựng Service và Controller
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `BookService` và inject `Repository<BookEntity>` qua `@InjectRepository(BookEntity)`.
  - Bước 2: Cài đặt hàm `create(data)` sử dụng `this.bookRepository.save(data)`. Nhờ `cascade: true`, khi truyền object Book kèm Author và Categories mới, TypeORM sẽ tự động tạo bản ghi ở tất cả các bảng liên quan.
  - Bước 3: Cài đặt hàm `findAll()` sử dụng `this.bookRepository.find({ relations: ['author', 'categories'] })` để trả danh sách sách kèm relations.
  - Bước 4: Cài đặt hàm `findOne(id)` sử dụng `this.bookRepository.findOne({ where: { id }, relations: ['author', 'categories'] })`. Nếu không tìm thấy, ném `NotFoundException`.
  - Bước 5: Tạo `BookController` với 3 endpoint:
    - `POST /books` nhận body và gọi `bookService.create(body)`.
    - `GET /books` gọi `bookService.findAll()`.
    - `GET /books/:id` gọi `bookService.findOne(id)`.
- **Kết quả mong đợi:** Cả 3 endpoint hoạt động đúng, có thể tạo sách mới và truy vấn danh sách hoặc chi tiết sách kèm quan hệ.
- **Kết luận:** Service và Controller đã triển khai đầy đủ CRUD cơ bản với cascade save và eager loading relations.

## 3
### title
Kiểm thử các endpoint
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Tạo một cuốn sách mới kèm author và categories:
    ```bash
    curl -X POST http://localhost:3000/books \
      -H "Content-Type: application/json" \
      -d '{
        "title": "NestJS in Action",
        "isbn": "978-0-13-468599-1",
        "publishedYear": 2024,
        "author": { "name": "John Doe", "bio": "Backend developer" },
        "categories": [{ "name": "Programming" }, { "name": "Backend" }]
      }'
    ```
  - Bước 3: Lấy danh sách tất cả sách:
    ```bash
    curl http://localhost:3000/books
    ```
  - Bước 4: Lấy chi tiết một cuốn sách theo id:
    ```bash
    curl http://localhost:3000/books/1
    ```
  - Bước 5: Tạo thêm một cuốn sách với author đã tồn tại để kiểm tra quan hệ ManyToOne:
    ```bash
    curl -X POST http://localhost:3000/books \
      -H "Content-Type: application/json" \
      -d '{
        "title": "Advanced TypeORM",
        "isbn": "978-0-13-468599-2",
        "publishedYear": 2025,
        "author": { "id": 1 },
        "categories": [{ "name": "Programming" }]
      }'
    ```
- **Kết quả mong đợi:**
  - `POST /books` trả về object Book mới kèm Author và Categories đã được lưu.
  - `GET /books` trả danh sách tất cả sách kèm relations.
  - `GET /books/1` trả chi tiết cuốn sách có id = 1 kèm author và categories.
- **Kết luận:** Hệ thống quản lý thư viện sách hoạt động đúng với các quan hệ ManyToOne và ManyToMany, cascade save và eager loading đều được chứng minh qua kết quả endpoint.

# references
## 0
### alias
TypeORM Entities
### url
https://typeorm.io/entities
## 1
### alias
TypeORM Relations
### url
https://typeorm.io/relations
## 2
### alias
NestJS Database Integration
### url
https://docs.nestjs.com/techniques/database

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
Đúng cấu trúc Entity và quan hệ
##### score
10
##### promptText
Có đầy đủ `BookEntity`, `AuthorEntity`, `CategoryEntity` với quan hệ `@ManyToOne`/`@OneToMany` giữa Book-Author và `@ManyToMany` giữa Book-Category. Cascade được cấu hình đúng cách.
#### 1
##### title
Đúng kết quả endpoint
##### score
10
##### promptText
`POST /books` tạo sách mới kèm author và categories thành công. `GET /books` trả danh sách sách kèm relations. `GET /books/:id` trả chi tiết sách kèm author và categories.

# difficulty
easy

# score
20
