# title
Cache danh sách sản phẩm với Redis

# description
Tích hợp Redis để cache danh sách sản phẩm, giảm tải cho database và tăng tốc độ phản hồi API.

# requirements
Tích hợp Redis vào NestJS. Cache response của endpoint `GET /products` bằng `CACHE_MANAGER` (Logic Layer) với TTL 60 giây. Khi `POST /products` tạo sản phẩm mới, xoá cache key tương ứng để đảm bảo dữ liệu mới nhất. Endpoint `GET /products` lần gọi thứ 2 phải trả về từ cache (không query database). Sử dụng dữ liệu in-memory (mảng) thay vì database thực để tập trung vào cơ chế caching.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Docker (để chạy Redis)
- npm install

# steps

## 0
### title
Khởi tạo project và cấu hình Redis
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới bằng NestJS CLI:
    ```bash
    nest new caching-with-redis-easy
    ```
  - Bước 2: Di chuyển vào thư mục project:
    ```bash
    cd caching-with-redis-easy
    ```
  - Bước 3: Cài đặt các dependency cần thiết:
    ```bash
    npm install @nestjs/cache-manager cache-manager cache-manager-redis-store redis
    ```
  - Bước 4: Tạo file `docker-compose.yml` tại thư mục gốc để khởi động Redis:
    ```yaml
    services:
      redis:
        image: redis:7-alpine
        ports:
          - "6379:6379"
    ```
  - Bước 5: Khởi động Redis:
    ```bash
    docker compose up -d
    ```
  - Bước 6: Cấu hình `CacheModule.register()` trong `AppModule` với `store` là `redisStore`, `host: 'localhost'`, `port: 6379`, và `ttl: 60` (giây).
- **Kết quả mong đợi:** Redis chạy trong Docker, ứng dụng NestJS kết nối thành công tới Redis server.
- **Kết luận:** Môi trường phát triển đã sẵn sàng với Redis và Cache Manager được tích hợp vào NestJS.

## 1
### title
Tạo ProductModule với dữ liệu in-memory
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `ProductModule`, `ProductService`, `ProductController`.
  - Bước 2: Trong `ProductService`, khởi tạo mảng dữ liệu mẫu:
    ```typescript
    private products = [
      { id: 1, name: 'Laptop', price: 999 },
      { id: 2, name: 'Phone', price: 699 },
      { id: 3, name: 'Tablet', price: 499 },
    ];
    ```
  - Bước 3: Cài đặt hàm `findAll()` trả toàn bộ mảng products.
  - Bước 4: Cài đặt hàm `create(data)` thêm product mới vào mảng với id tự tăng.
  - Bước 5: Trong `ProductController`, tạo endpoint `GET /products` gọi `findAll()` và `POST /products` gọi `create(body)`.
- **Kết quả mong đợi:** Cả 2 endpoint hoạt động đúng với dữ liệu in-memory, chưa có caching.
- **Kết luận:** Module nghiệp vụ cơ bản đã sẵn sàng, bước tiếp theo sẽ thêm lớp caching bằng Redis.

## 2
### title
Tích hợp Cache Manager vào Service
### body
- **Các bước thực hiện:**
  - Bước 1: Inject `CACHE_MANAGER` vào `ProductService` bằng `@Inject(CACHE_MANAGER) private cacheManager: Cache`.
  - Bước 2: Cập nhật hàm `findAll()` theo logic caching:
    - Kiểm tra cache trước: `const cached = await this.cacheManager.get('products')`.
    - Nếu có cache, trả về dữ liệu từ cache ngay lập tức.
    - Nếu không có cache, lấy dữ liệu từ mảng in-memory, lưu vào cache `await this.cacheManager.set('products', this.products, 60)`, rồi trả về.
  - Bước 3: Thêm log console để phân biệt response từ cache và từ data source:
    - Khi trả từ cache: `console.log('Serving from cache')`.
    - Khi trả từ data source: `console.log('Serving from data source')`.
  - Bước 4: Cập nhật hàm `create(data)`: sau khi thêm product mới, xoá cache bằng `await this.cacheManager.del('products')` để đảm bảo lần gọi `GET /products` tiếp theo sẽ lấy dữ liệu mới nhất.
- **Kết quả mong đợi:** Lần gọi `GET /products` đầu tiên lấy từ data source và lưu cache. Lần gọi thứ 2 trả từ cache. Sau khi `POST /products`, cache bị xoá và lần gọi `GET /products` tiếp theo lại lấy từ data source.
- **Kết luận:** Cache invalidation đúng cách đảm bảo dữ liệu luôn nhất quán giữa cache và data source.

## 3
### title
Kiểm thử luồng caching
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Gọi `GET /products` lần đầu tiên:
    ```bash
    curl http://localhost:3000/products
    ```
    Kiểm tra terminal log hiển thị `Serving from data source`.
  - Bước 3: Gọi `GET /products` lần thứ 2 ngay lập tức:
    ```bash
    curl http://localhost:3000/products
    ```
    Kiểm tra terminal log hiển thị `Serving from cache`.
  - Bước 4: Tạo sản phẩm mới (trigger cache invalidation):
    ```bash
    curl -X POST http://localhost:3000/products \
      -H "Content-Type: application/json" \
      -d '{ "name": "Monitor", "price": 399 }'
    ```
  - Bước 5: Gọi `GET /products` lần nữa:
    ```bash
    curl http://localhost:3000/products
    ```
    Kiểm tra terminal log hiển thị `Serving from data source` (cache đã bị xoá). Xác nhận response chứa sản phẩm mới vừa tạo.
  - Bước 6: Gọi `GET /products` thêm lần nữa để xác nhận cache đã được tái tạo:
    ```bash
    curl http://localhost:3000/products
    ```
    Kiểm tra terminal log hiển thị `Serving from cache`.
- **Kết quả mong đợi:**
  - Lần gọi 1: data source, response chứa 3 sản phẩm ban đầu.
  - Lần gọi 2: cache, response giống lần 1.
  - Sau `POST /products`: cache bị xoá.
  - Lần gọi 3: data source, response chứa 4 sản phẩm (bao gồm sản phẩm mới).
  - Lần gọi 4: cache, response giống lần 3.
- **Kết luận:** Luồng caching hoàn chỉnh đã được chứng minh: cache hit tăng tốc response, cache invalidation khi dữ liệu thay đổi đảm bảo tính nhất quán, và cache tự động tái tạo sau khi bị xoá.

# references
## 0
### alias
NestJS Caching
### url
https://docs.nestjs.com/techniques/caching
## 1
### alias
cache-manager npm
### url
https://www.npmjs.com/package/cache-manager
## 2
### alias
Redis Documentation
### url
https://redis.io/docs/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
Đúng cấu hình Redis và Cache Manager
##### score
10
##### promptText
Redis được tích hợp đúng cách qua `CacheModule` và `CACHE_MANAGER`. Hàm `findAll()` kiểm tra cache trước khi truy vấn data source. Hàm `create()` xoá cache key sau khi thêm dữ liệu mới.
#### 1
##### title
Đúng luồng cache hit và cache invalidation
##### score
10
##### promptText
`GET /products` lần đầu lấy từ data source, lần thứ 2 lấy từ cache. Sau `POST /products`, cache bị xoá và `GET /products` tiếp theo lại lấy từ data source với dữ liệu mới nhất.

# difficulty
easy

# score
20
