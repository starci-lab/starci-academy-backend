# title
Blog API with Mongoose and MongoDB

# description
Build a blog post management API with Mongoose, leveraging MongoDB's flexibility to store custom metadata and tags arrays.

# requirements
Create a `PostSchema` with the following fields: title (required, indexed), content (required), author (required), tags ([String]), metadata (Object - flexible), timestamps:true. Endpoint `POST /posts` creates a new post. `GET /posts` returns the list sorted by createdAt descending. `GET /posts/:id` returns details of a single post. `PATCH /posts/:id` updates a post.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Docker (to run MongoDB)
- npm install

# steps

## 0
### title
Initialize the project and configure MongoDB
### body
- **Steps to follow:**
  - Step 1: Create a new project using NestJS CLI:
    ```bash
    nest new mongoose-and-mongodb-easy
    ```
  - Step 2: Navigate to the project directory:
    ```bash
    cd mongoose-and-mongodb-easy
    ```
  - Step 3: Install the required dependencies:
    ```bash
    npm install @nestjs/mongoose mongoose
    ```
  - Step 4: Create a `docker-compose.yml` file at the project root to start MongoDB:
    ```yaml
    services:
      mongo:
        image: mongo:7
        environment:
          MONGO_INITDB_ROOT_USERNAME: mongo
          MONGO_INITDB_ROOT_PASSWORD: mongo
        ports:
          - "27017:27017"
    ```
  - Step 5: Start MongoDB:
    ```bash
    docker compose up -d
    ```
  - Step 6: Configure `MongooseModule.forRoot()` in `AppModule` with the connection string `mongodb://mongo:mongo@localhost:27017/blog?authSource=admin`.
- **Expected result:** MongoDB runs in Docker, NestJS application connects successfully to the `blog` database.
- **Conclusion:** The development environment is ready with MongoDB and Mongoose integrated into NestJS.

## 1
### title
Define Schema and Model
### body
- **Steps to follow:**
  - Step 1: Create `post.schema.ts`, define `PostSchema` using the decorator `@Schema({ timestamps: true })` to automatically add `createdAt` and `updatedAt`.
  - Step 2: Add fields with the `@Prop()` decorator:
    - `title`: type `string`, `required: true`, `index: true` to optimize queries by title.
    - `content`: type `string`, `required: true`.
    - `author`: type `string`, `required: true`.
    - `tags`: type `[String]`, default is an empty array `[]`.
    - `metadata`: type `Object` (Schema.Types.Mixed), allows storing flexible data without a fixed schema.
  - Step 3: Export the Schema using `SchemaFactory.createForClass(Post)`.
  - Step 4: Register the Schema in the module using `MongooseModule.forFeature([{ name: Post.name, schema: PostSchema }])`.
- **Expected result:** The `Post` Schema is correctly defined with automatic timestamps, an index on the `title` field, and a flexible `metadata` field.
- **Conclusion:** Mongoose Schema allows declaring a clear document structure while maintaining MongoDB's flexibility through the Mixed type field.

## 2
### title
Build Service and Controller
### body
- **Steps to follow:**
  - Step 1: Create `PostService` and inject the Model using `@InjectModel(Post.name) private postModel: Model<Post>`.
  - Step 2: Implement the `create(data)` method using `this.postModel.create(data)` to create a new document.
  - Step 3: Implement the `findAll()` method using `this.postModel.find().sort({ createdAt: -1 }).exec()` to return the post list sorted by creation time descending.
  - Step 4: Implement the `findOne(id)` method using `this.postModel.findById(id).exec()`. If not found, throw `NotFoundException`.
  - Step 5: Implement the `update(id, data)` method using `this.postModel.findByIdAndUpdate(id, data, { new: true }).exec()`. If not found, throw `NotFoundException`.
  - Step 6: Create `PostController` with 4 endpoints:
    - `POST /posts` accepts a body and calls `postService.create(body)`.
    - `GET /posts` calls `postService.findAll()`.
    - `GET /posts/:id` calls `postService.findOne(id)`.
    - `PATCH /posts/:id` accepts a body and calls `postService.update(id, body)`.
- **Expected result:** All 4 endpoints work correctly, supporting creation, list query, detail query, and post update.
- **Conclusion:** Service and Controller have been fully implemented with basic CRUD using Mongoose, correctly utilizing Model query methods.

## 3
### title
Test the endpoints
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Create a new post with tags and flexible metadata:
    ```bash
    curl -X POST http://localhost:3000/posts \
      -H "Content-Type: application/json" \
      -d '{
        "title": "Getting Started with MongoDB",
        "content": "MongoDB is a document database...",
        "author": "Jane Doe",
        "tags": ["mongodb", "nosql", "tutorial"],
        "metadata": { "readTime": 5, "featured": true, "source": "internal" }
      }'
    ```
  - Step 3: Create a second post with differently structured metadata:
    ```bash
    curl -X POST http://localhost:3000/posts \
      -H "Content-Type: application/json" \
      -d '{
        "title": "Mongoose Best Practices",
        "content": "Schema design is crucial...",
        "author": "Jane Doe",
        "tags": ["mongoose", "best-practices"],
        "metadata": { "series": "MongoDB Mastery", "part": 2 }
      }'
    ```
  - Step 4: Get the list of posts (verify sorted by createdAt descending):
    ```bash
    curl http://localhost:3000/posts
    ```
  - Step 5: Update a post, adding a new tag:
    ```bash
    curl -X PATCH http://localhost:3000/posts/<id> \
      -H "Content-Type: application/json" \
      -d '{
        "tags": ["mongodb", "nosql", "tutorial", "beginner"]
      }'
    ```
- **Expected result:**
  - `POST /posts` returns the new document with auto-generated `_id`, `createdAt`, `updatedAt`.
  - `GET /posts` returns the post list with the newest post first.
  - `PATCH /posts/:id` returns the updated document with the `updatedAt` field changed.
  - Two posts have differently structured `metadata` fields but both save successfully, demonstrating MongoDB's flexibility.
- **Conclusion:** The Blog API works correctly with Mongoose and MongoDB, demonstrating flexible data storage through the Mixed type field and variable-length tags array.

# references
## 0
### alias
NestJS Mongoose Integration
### url
https://docs.nestjs.com/techniques/mongodb
## 1
### alias
Mongoose Schemas Guide
### url
https://mongoosejs.com/docs/guide.html
## 2
### alias
Mongoose Queries
### url
https://mongoosejs.com/docs/queries.html

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
Correct Schema and Model structure
##### score
10
##### promptText
`PostSchema` has all fields: `title` (required, indexed), `content` (required), `author` (required), `tags` ([String]), `metadata` (Mixed type), `timestamps: true`. Schema is correctly registered in the module.
#### 1
##### title
Correct endpoint results
##### score
10
##### promptText
`POST /posts` creates a new post with tags and flexible metadata. `GET /posts` returns the list sorted by `createdAt` descending. `PATCH /posts/:id` updates the post successfully, `updatedAt` changes.

# difficulty
easy

# score
20
