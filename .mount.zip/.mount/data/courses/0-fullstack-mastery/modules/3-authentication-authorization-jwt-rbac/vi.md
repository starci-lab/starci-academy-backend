# title
Authentication & Authorization (JWT + RBAC)

# description
Triển khai authentication với JWT (access/refresh token), Guards, Role-based access control; tích hợp OAuth2 (Google); bảo mật API theo best practices.

# previewContents
## 0
### text
Triển khai JWT (access token / refresh token) theo flow thực tế.
## 1
### text
Xây dựng Guards và cơ chế phân quyền RBAC (role-based access control).
## 2
### text
Thiết kế chiến lược refresh token (rotation / revoke) hợp lý.
## 3
### text
Tích hợp OAuth2 (Google) cho login nhanh và tiện lợi.
## 4
### text
Chuẩn hóa xử lý auth error để frontend tích hợp ổn định.
## 5
### text
Hiểu cách xây dựng authentication production-ready từ A đến Z.
## 6
### text
Thiết kế hệ thống phân quyền rõ ràng theo role và permission.
## 7
### text
Bảo vệ API đúng cách thay vì chỉ kiểm tra token đơn giản.
## 8
### text
Tự triển khai hệ thống đăng nhập và phân quyền hoàn chỉnh cho dự án thực tế.
