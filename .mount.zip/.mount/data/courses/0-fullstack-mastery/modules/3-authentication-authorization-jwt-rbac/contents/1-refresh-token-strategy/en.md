# title
Refresh Token Strategy

# description
Understand why Access Tokens must have short lifespans, how to build a production-grade Refresh Token Rotation flow, and how to revoke tokens on logout.

# body

## I. Introduction

After mastering the JWT authentication flow, a natural question arises: if an **Access Token** is stolen, the attacker can impersonate the user until the token expires. Because JWT is **Stateless**, the server cannot unilaterally invalidate an already-issued token — unless you build an additional **Blocklist** system on **Redis**, which contradicts the stateless philosophy.

The solution is to split tokens into two types: an **Access Token** with a very short lifespan (**15 minutes**) to minimize damage when compromised, and a **Refresh Token** with a longer lifespan (**7 days**) used solely to request new Access Tokens. This is the standard security strategy widely adopted in production systems.

## II. Core Concepts

### 1. Access Token vs Refresh Token

The **Access Token (AT)** is the credential for accessing APIs, with a short lifespan (typically **15 minutes**). When the AT expires, the client can no longer access protected resources.

The **Refresh Token (RT)** is the renewal credential, with a longer lifespan (typically **7 days**). The RT serves one single purpose: it is sent to the server to exchange for a new pair of AT and RT.

- **Example:** A user logs in at 9:00 AM and receives an AT (expires at 9:15 AM) along with an RT (expires in 7 days). At 9:16 AM, when the AT has expired, the frontend automatically sends the RT to `POST /auth/refresh` to receive a new AT without requiring the user to log in again.

### 2. Secure Token Storage

How you store tokens determines the security level of your entire system.

- **Access Token:** Because of its short lifespan, storing it in **LocalStorage** is acceptable despite the risk of **XSS** attacks.
- **Refresh Token:** This is the most valuable asset in the authentication system. It must be stored in an **HttpOnly Cookie** combined with the **Secure** flag, making it completely inaccessible to any **JavaScript** code running in the browser.

- **Example:** If an attacker exploits an XSS vulnerability and steals the AT, they can only use it for a maximum of **15 minutes**. But if the RT is compromised, the attacker can continuously renew access. Therefore, the RT must receive the strictest protection.

### 3. Token Rotation Mechanism

**Token Rotation** is an advanced security technique: every time the client uses an RT to refresh, the server issues not only a new AT but also a new RT. The old RT is immediately invalidated.

This means if an attacker steals an old RT and attempts to use it, the server detects that the RT has already been replaced and rejects it. The server can also invalidate the entire token chain for that user to ensure safety.

- **Example:** A user logs in and receives RT1. Upon refreshing, the server issues AT2 and RT2 while deleting RT1. If a hacker tries to use RT1, the server returns an error because RT1 is no longer valid.

### 4. Token Revocation

When a user clicks **"Logout"**, the server needs to invalidate the RT to ensure no one can continue renewing tokens.

Implementation: the server stores the **hash of the RT** (using **bcrypt**) in the `users` table of the database. When the user logs out, the server updates the `hashedRefreshToken` field to `null`. Any RT existing outside the system immediately loses its validity because there is no stored value to compare against.

- **Example:** A user clicks "Logout from all devices". The server sets `hashedRefreshToken = null`. All active sessions on their phone, tablet, and laptop lose access simultaneously.

## III. Practice

> **Source code:** [Refresh Token Strategy](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/refresh-token-strategy)

In this section, we will build a Refresh Token system with complete **Rotation** and **Revocation** mechanisms in **NestJS**.

### 1. Setup & Run

- **Execution Steps:**
    - Step 1: Start PostgreSQL using Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up -d
      ```
    - Step 2: Install dependencies:
      ```bash
      npm install
      ```
    - Step 3: Run the application in development mode:
      ```bash
      npm run start:dev
      ```
- **Expected Results:** The NestJS application starts successfully at port **3000**, PostgreSQL connection is ready.
- **Conclusion:** The environment is set up and ready for testing the Refresh Token flow.

### 2. Architecture

| Component | Role |
|-----------|------|
| **AuthService.signIn()** | Validates credentials, generates AT + RT pair, hashes RT, and saves to database. |
| **AuthService.refresh()** | Verifies RT, compares against hash in database, issues new AT + RT pair (Rotation). |
| **AuthService.logout()** | Clears `hashedRefreshToken` in the database (Revocation). |
| **JwtStrategy** | Verifies AT from the `Authorization` header. |
| **RefreshTokenGuard** | Verifies RT when the client sends a refresh request. |

- **Execution Steps:** Read the source code, focusing on the `auth.service.ts` file to understand the hashing, comparison, and rotation logic.
- **Expected Results:** Full understanding of the data flow from sign-in, through refresh, to logout.
- **Conclusion:** Every operation (sign in, refresh, logout) directly affects the `hashedRefreshToken` field in the database.

### 3. System Flow

```
[Client] ──POST /auth/signin──> [AuthService]
                                      │
                              Validate credentials
                              Generate AT (15m) + RT (7d)
                              Hash RT -> save to DB
                                      │
                              Return { access_token, refresh_token }

--- After 15 minutes, AT expires ---

[Client] ──POST /auth/refresh──> [RefreshTokenGuard]
           Refresh Token              │
                              Verify RT signature
                              Compare with hash in DB
                                      │
                              Generate new AT + new RT (Rotation)
                              Hash new RT -> update DB
                              Old RT invalidated
                                      │
                              Return { access_token, refresh_token }

--- Logout ---

[Client] ──POST /auth/logout──> [AuthService]
                                      │
                              Set hashedRefreshToken = null
                              All existing RTs invalidated
```

- **Execution Steps:** Trace the flow from sign-in, through refresh, to logout.
- **Expected Results:** Understand that each refresh generates a completely new token pair and invalidates the old one.
- **Conclusion:** The Rotation mechanism ensures each RT can only be used once, minimizing damage when a token is compromised.

### 4. Try it out

**Success path** — Sign in, refresh token, and logout successfully:

- **Execution Steps:**
    - Step 1: Sign in to receive the AT and RT pair:
      ```bash
      curl -X POST http://localhost:3000/auth/signin \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456"}'
      ```
    - Step 2: Use the RT to refresh the token:
      ```bash
      curl -X POST http://localhost:3000/auth/refresh \
        -H "Authorization: Bearer <refresh_token>"
      ```
    - Step 3: Logout to revoke the RT:
      ```bash
      curl -X POST http://localhost:3000/auth/logout \
        -H "Authorization: Bearer <access_token>"
      ```
- **Expected Results:**
    1. Step 1 returns `{ "access_token": "...", "refresh_token": "..." }`.
    2. Step 2 returns a completely new AT and RT pair.
    3. Step 3 returns logout confirmation, `hashedRefreshToken` in the database is set to `null`.
- **Conclusion:** The Refresh Token flow works correctly: issuance, rotation, and revocation all operate as expected.

**Failure path** — Using an old RT after it has been rotated (Rotation protection):

- **Execution Steps:**
    - Step 1: Sign in and receive RT1:
      ```bash
      curl -X POST http://localhost:3000/auth/signin \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456"}'
      ```
    - Step 2: Refresh the token, receive RT2 (RT1 is invalidated):
      ```bash
      curl -X POST http://localhost:3000/auth/refresh \
        -H "Authorization: Bearer <RT1>"
      ```
    - Step 3: Attempt to reuse RT1 (already invalidated):
      ```bash
      curl -X POST http://localhost:3000/auth/refresh \
        -H "Authorization: Bearer <RT1>"
      ```
- **Expected Results:**
    1. Steps 1 and 2 succeed normally.
    2. Step 3 returns **401 Unauthorized** because RT1 no longer matches the hash in the database.
- **Conclusion:** The **Rotation** mechanism works effectively — each RT can only be used once, preventing reuse of stolen old tokens.

## IV. Conclusion

The **Refresh Token** strategy is the indispensable second security layer after JWT. With the AT's short lifespan, the system minimizes damage when a token is compromised. With **Rotation**, each RT can only be used once and is replaced immediately. With **Revocation**, the user can close all active sessions with a single logout action.

**Conclusion:** A production authentication system does not just need JWT — it needs a complete token lifecycle management strategy, including issuance, rotation, and revocation, to ensure end-to-end security.

# references
## 0
### alias
Token Revocation Best Practices
### url
https://auth0.com/blog/refresh-tokens-what-are-they-and-when-to-use-them/

# minutesRead
25
