# title
Luồng xác thực JWT (JSON Web Token)

# description
Hiểu rõ cơ chế xác thực Stateless bằng JWT, so sánh với Session truyền thống, và thực hành xây dựng luồng đăng nhập hoàn chỉnh với NestJS.

# body

## I. Lời mở đầu

Trước khi **JWT** xuất hiện, phần lớn hệ thống web quản lý phiên đăng nhập bằng **Session**. Khi người dùng đăng nhập, server tạo một bản ghi trong bộ nhớ (RAM hoặc **Redis**) và gửi lại một `session_id` qua cookie. Mọi request tiếp theo phải tra cứu lại bộ nhớ đó để xác minh. Mô hình này hoạt động tốt với một server duy nhất, nhưng khi hệ thống mở rộng thành nhiều instance, việc đồng bộ trạng thái phiên giữa các máy trở thành gánh nặng lớn.

**JSON Web Token (JWT)** giải quyết vấn đề này bằng tính chất **Stateless (Phi trạng thái)**. Token được ký số bằng một khóa bí mật và gửi về cho client. Mỗi lần client gửi request, server chỉ cần xác minh chữ ký bằng thuật toán mã hóa mà không cần truy vấn cơ sở dữ liệu. Đây là nền tảng của xác thực hiện đại trong kiến trúc **Microservices**.

## II. Nội dung chính

### 1. So sánh Session và JWT

**Session-based Authentication** lưu trữ trạng thái phía server. Mọi request cần tra cứu bộ nhớ để xác minh phiên. Điều này tạo ra **Single Point of Failure** khi hệ thống có nhiều server, bởi tất cả đều phải chia sẻ cùng một kho lưu trữ phiên.

**JWT-based Authentication** chuyển toàn bộ thông tin xác thực vào trong token. Server không cần lưu bất kỳ trạng thái nào. Chỉ cần kiểm tra chữ ký hợp lệ là đủ để tin tưởng request.

- **Ví dụ:** Một hệ thống **Microservices** có 10 instance backend chạy đồng thời. Với Session, bạn cần một lớp **Redis** trung tâm để đồng bộ phiên giữa tất cả các instance. Với JWT, mỗi instance đọc và xác minh token độc lập mà không cần giao tiếp với bất kỳ dịch vụ nào khác.

### 2. Cấu trúc của JWT

Một chuỗi JWT gồm ba phần được ngăn cách bởi dấu chấm: `Header.Payload.Signature`.

- **Header:** Khai báo thuật toán mã hóa được sử dụng (ví dụ: **HS256**, **RS256**).
- **Payload:** Chứa dữ liệu công khai như `userId`, `role`. Đây không phải là dữ liệu được mã hóa ẩn — bất kỳ ai cũng có thể giải mã **Base64** để đọc nội dung. Vì vậy, tuyệt đối không đặt **password** hay thông tin nhạy cảm vào Payload.
- **Signature:** Kết quả của việc ký số Header và Payload bằng **Secret Key** của server. Nếu Hacker thay đổi bất kỳ trường nào trong Payload, chữ ký sẽ không còn khớp và server tự động từ chối token.

- **Ví dụ:** Token có Payload `{"userId": 1, "role": "user"}`. Nếu kẻ tấn công sửa `role` thành `"admin"`, phần Signature sẽ không khớp với nội dung đã bị thay đổi, và server trả về lỗi **401 Unauthorized**.

### 3. Vòng đời xác thực

Luồng xác thực JWT trong **NestJS** diễn ra theo trình tự chặt chẽ:

1. Client gửi `email` và `password` đến endpoint `POST /auth/login`.
2. **AuthService** truy vấn database, tìm user theo email và so sánh mật khẩu bằng **bcrypt**.
3. Nếu hợp lệ, server tạo JWT chứa `{ sub: userId }` và ký bằng **JWT_SECRET**.
4. Client nhận `access_token` và lưu trữ (trong **LocalStorage** hoặc **HttpOnly Cookie**).
5. Mọi request tiếp theo, client gửi token trong header: `Authorization: Bearer <token>`.
6. **JwtAuthGuard** tự động xác minh chữ ký token trước khi cho phép request đi vào Controller.

- **Ví dụ:** Người dùng gọi `GET /users/profile` kèm header `Authorization: Bearer eyJhbG...`. **JwtStrategy** giải mã token, trích xuất `userId`, và gắn vào `req.user`. Controller chỉ cần đọc `req.user` mà không cần bất kỳ logic xác thực nào.

## III. Thực hành

> **Source code:** [JWT Authentication Flow](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/jwt-authentication-flow)

Trong phần này, chúng ta sẽ xây dựng luồng xác thực JWT hoàn chỉnh với **NestJS**, **TypeORM** và **PostgreSQL**.

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
    - Bước 1: Khởi động PostgreSQL bằng Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up -d
      ```
    - Bước 2: Cài đặt dependencies:
      ```bash
      npm install
      ```
    - Bước 3: Chạy ứng dụng ở chế độ development:
      ```bash
      npm run start:dev
      ```
- **Kết quả mong đợi:** Ứng dụng NestJS khởi động thành công tại port **3000**, kết nối PostgreSQL sẵn sàng.
- **Kết luận:** Môi trường phát triển đã thiết lập xong, sẵn sàng thử nghiệm luồng xác thực.

### 2. Kiến trúc (Architecture)

| Thành phần | Vai trò |
|------------|---------|
| **AuthController** | Tiếp nhận request đăng ký và đăng nhập tại `/auth/signup` và `/auth/signin`. |
| **AuthService** | Xử lý logic xác thực: hash password, so sánh password, tạo JWT. |
| **JwtStrategy** | Xác minh và giải mã token từ header `Authorization`. |
| **JwtAuthGuard** | Guard bảo vệ các route cần xác thực, tự động kích hoạt JwtStrategy. |
| **UsersService** | Quản lý dữ liệu người dùng trong database. |

- **Các bước thực hiện:** Đọc source code, xác định các file `auth.service.ts`, `jwt.strategy.ts`, `jwt-auth.guard.ts` và hiểu cách chúng liên kết với nhau.
- **Kết quả mong đợi:** Hiểu rõ từng thành phần chịu trách nhiệm gì trong luồng xác thực.
- **Kết luận:** Kiến trúc phân tầng rõ ràng giúp tách biệt logic xác thực khỏi logic nghiệp vụ.

### 3. Luồng hệ thống (System Flow)

```
[Client] ──POST /auth/signin──> [AuthController]
                                      │
                              AuthService.login()
                              Validate password (bcrypt)
                                      │
                              Generate JWT (sign)
                                      │
                              Return { access_token }
                                      │
[Client] ──GET /users/profile──> [JwtAuthGuard]
           Authorization: Bearer      │
                              JwtStrategy.validate()
                              Verify signature
                                      │
                              Attach user to req.user
                                      │
                              [UsersController] -> Response
```

- **Các bước thực hiện:** Theo dõi luồng từ lúc client gửi credentials cho đến khi nhận được profile.
- **Kết quả mong đợi:** Hiểu rõ ràng mọi request bảo vệ đều phải đi qua JwtAuthGuard trước khi đến Controller.
- **Kết luận:** Guard đóng vai trò như trạm kiểm soát — mọi request không có token hợp lệ đều bị chặn lại trước khi chạm đến logic nghiệp vụ.

### 4. Thử nghiệm (Try it out)

**Success path** — Đăng ký, đăng nhập và truy cập profile thành công:

- **Các bước thực hiện:**
    - Bước 1: Đăng ký tài khoản mới:
      ```bash
      curl -X POST http://localhost:3000/auth/signup \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456"}'
      ```
    - Bước 2: Đăng nhập để nhận token:
      ```bash
      curl -X POST http://localhost:3000/auth/signin \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456"}'
      ```
    - Bước 3: Truy cập profile với token nhận được:
      ```bash
      curl -X GET http://localhost:3000/users/profile \
        -H "Authorization: Bearer <access_token>"
      ```
- **Kết quả mong đợi:**
    1. Bước 1 trả về thông tin user vừa tạo.
    2. Bước 2 trả về `{ "access_token": "eyJhbG..." }`.
    3. Bước 3 trả về thông tin profile của user đã xác thực.
- **Kết luận:** Luồng xác thực JWT hoạt động chính xác — chỉ những request có token hợp lệ mới truy cập được tài nguyên được bảo vệ.

**Failure path** — Truy cập profile không có token:

- **Các bước thực hiện:**
    - Bước 1: Gửi request đến profile mà không kèm token:
      ```bash
      curl -X GET http://localhost:3000/users/profile
      ```
    - Bước 2: Gửi request với token sai:
      ```bash
      curl -X GET http://localhost:3000/users/profile \
        -H "Authorization: Bearer invalid-token-here"
      ```
- **Kết quả mong đợi:**
    1. Cả hai bước đều trả về **401 Unauthorized**.
    2. Server từ chối truy cập vì token không tồn tại hoặc chữ ký không hợp lệ.
- **Kết luận:** **JwtAuthGuard** bảo vệ hiệu quả — mọi request thiếu token hoặc token không hợp lệ đều bị chặn ngay tại tầng Guard.

## IV. Kết luận

**JWT** chuyển đổi mô hình xác thực từ **Stateful** (phụ thuộc bộ nhớ server) sang **Stateless** (phụ thuộc chữ ký mã hóa). Điều này loại bỏ nhu cầu đồng bộ phiên giữa các instance và giúp hệ thống dễ mở rộng theo chiều ngang.

**Kết luận:** Việc nắm vững luồng xác thực JWT — từ cách tạo token, lưu trữ, gửi kèm trong header, đến cách Guard xác minh — là nền tảng bắt buộc trước khi tiến đến các chủ đề nâng cao hơn như **Refresh Token**, **RBAC** và **OAuth2**.

# references
## 0
### alias
NestJS Authentication
### url
https://docs.nestjs.com/security/authentication

# minutesRead
20
