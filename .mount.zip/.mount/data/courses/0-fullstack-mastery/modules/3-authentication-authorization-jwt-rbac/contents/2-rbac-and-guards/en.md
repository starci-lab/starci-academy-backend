# title
Role-Based Access Control (RBAC) and Guards

# description
Clearly distinguish between Authentication and Authorization, then build a multi-layered RBAC system using custom Decorators and Guards in NestJS.

# body

## I. Introduction

Successfully authenticating with JWT only answers the question "Who is this person?". In a real system, knowing who the user is alone is not enough — you need to control **what they are allowed to do**. A user with the **Guest** role cannot delete accounts reserved for **Admin**, even if they possess a perfectly valid Access Token.

This is the core difference between **Authentication (AuthN)** and **Authorization (AuthZ)**. AuthN verifies identity, AuthZ controls permissions. Without either one, the system will either reject legitimate users or allow attackers to perform privilege escalation.

## II. Core Concepts

### 1. Authentication vs Authorization

**Authentication** is the process of verifying identity: "Who are you?". A client presenting a valid **JWT** is sufficient to pass the authentication checkpoint. In NestJS, this layer is handled by **JwtAuthGuard**.

**Authorization** is the process of checking permissions: "What are you allowed to do?". After identifying the user, the system needs to verify whether their role has sufficient privileges to execute the requested operation.

- **Example:** A user with the **User** role sends a request to `DELETE /users/5` — an endpoint restricted to **Admin**. Even though their Access Token is perfectly valid (AuthN succeeds), the system returns **403 Forbidden** because the role lacks sufficient permissions (AuthZ fails).

### 2. Building the @Roles() Decorator

Instead of writing role-checking logic using scattered `if-else` statements in every Controller, **NestJS** provides a **Metadata** mechanism that allows you to attach permission information directly to each endpoint.

You create a custom decorator `@Roles()` using `SetMetadata`:

```typescript
export const ROLES_KEY = 'roles';
export const Roles = (...roles: string[]) => SetMetadata(ROLES_KEY, roles);
```

When applied, simply attach the decorator to the endpoint that needs protection:

```typescript
@Roles('ADMIN')
@Delete(':id')
deleteUser() { ... }
```

- **Example:** The endpoint `POST /courses` requires the **ADMIN** or **MANAGER** role. Simply attach `@Roles('ADMIN', 'MANAGER')` above the method, and the Guard system will automatically verify permissions at runtime.

### 3. Building a Multi-Layer RolesGuard

**RolesGuard** is the second layer of protection, executing after **JwtAuthGuard**. It uses the **Reflector** to read the `@Roles()` metadata on the Controller and compares it against the `role` field in the `req.user` object (which was attached by JwtAuthGuard in the previous step).

```typescript
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<string[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!requiredRoles) { return true; }

    const { user } = context.switchToHttp().getRequest();
    return requiredRoles.includes(user.role);
  }
}
```

When combining `@UseGuards(JwtAuthGuard, RolesGuard)`, the system performs two sequential checks: first it authenticates the token (JwtAuthGuard), then it verifies permissions (RolesGuard).

- **Example:** A request is sent to an endpoint decorated with `@Roles('ADMIN')` carrying a token containing `role: "user"`. JwtAuthGuard confirms the token is valid (step 1 passes), but RolesGuard detects that `"user"` is not in the list `['ADMIN']` and returns **403 Forbidden** (step 2 fails).

## III. Practice

> **Source code:** [RBAC and Guards](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/rbac-and-guards)

In this section, we will build a complete **RBAC** system with multi-layer Guards in **NestJS**.

### 1. Setup & Run

- **Execution Steps:**
    - Step 1: Start PostgreSQL using Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up -d
      ```
    - Step 2: Install dependencies:
      ```bash
      npm install
      ```
    - Step 3: Run the application in development mode:
      ```bash
      npm run start:dev
      ```
- **Expected Results:** The NestJS application starts successfully at port **3000**, PostgreSQL connection is ready.
- **Conclusion:** The environment is set up and ready for testing RBAC permissions.

### 2. Architecture

| Component | Role |
|-----------|------|
| **Role Enum** | Defines the available roles in the system: `ADMIN`, `USER`. |
| **@Roles() Decorator** | Attaches required role metadata to each endpoint. |
| **JwtAuthGuard** | Layer 1 — Authenticates the token, attaches `user` to `req.user`. |
| **RolesGuard** | Layer 2 — Reads `@Roles()` metadata, compares with `req.user.role`. |
| **Reflector** | NestJS utility for reading decorator metadata at runtime. |

- **Execution Steps:** Read the source code, focusing on `roles.guard.ts`, `roles.decorator.ts`, and how they are applied in the Controller.
- **Expected Results:** Clear understanding of how the two-layer Guard mechanism operates sequentially.
- **Conclusion:** RBAC is implemented through two independent Guard layers, each responsible for a distinct task.

### 3. System Flow

```
[Client] ──Request + Bearer Token──> [JwtAuthGuard] (Layer 1)
                                          │
                                  Verify token signature
                                  Extract user from payload
                                  Attach to req.user
                                          │
                                     [RolesGuard] (Layer 2)
                                          │
                                  Read @Roles() metadata
                                  Compare with req.user.role
                                          │
                                  Match? -> Controller executes
                                  No match? -> 403 Forbidden
```

- **Execution Steps:** Trace the flow from when the request hits JwtAuthGuard, through RolesGuard, to the Controller.
- **Expected Results:** Understand that requests must pass through both Guard layers before reaching business logic.
- **Conclusion:** The multi-layer Guard model ensures every request is checked for both identity and permissions before processing.

### 4. Try it out

**Success path** — Admin accessing an admin-only route:

- **Execution Steps:**
    - Step 1: Register an account with the Admin role:
      ```bash
      curl -X POST http://localhost:3000/auth/signup \
        -H "Content-Type: application/json" \
        -d '{"email": "admin@test.com", "password": "123456", "role": "ADMIN"}'
      ```
    - Step 2: Sign in with the Admin account:
      ```bash
      curl -X POST http://localhost:3000/auth/signin \
        -H "Content-Type: application/json" \
        -d '{"email": "admin@test.com", "password": "123456"}'
      ```
    - Step 3: Access the admin-only route with the Admin token:
      ```bash
      curl -X GET http://localhost:3000/admin/dashboard \
        -H "Authorization: Bearer <admin_access_token>"
      ```
- **Expected Results:**
    1. Step 1 successfully creates a user with the **ADMIN** role.
    2. Step 2 returns `{ "access_token": "..." }`.
    3. Step 3 returns dashboard data successfully because the role matches the requirement.
- **Conclusion:** Users with the appropriate role can access endpoints protected by RBAC.

**Failure path** — Regular user accessing an admin-only route:

- **Execution Steps:**
    - Step 1: Register an account with the User role:
      ```bash
      curl -X POST http://localhost:3000/auth/signup \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456", "role": "USER"}'
      ```
    - Step 2: Sign in with the User account:
      ```bash
      curl -X POST http://localhost:3000/auth/signin \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456"}'
      ```
    - Step 3: Attempt to access the admin route with the User token:
      ```bash
      curl -X GET http://localhost:3000/admin/dashboard \
        -H "Authorization: Bearer <user_access_token>"
      ```
- **Expected Results:**
    1. Steps 1 and 2 succeed normally.
    2. Step 3 returns **403 Forbidden** because the `USER` role is not in the allowed roles list (`ADMIN`).
- **Conclusion:** **RolesGuard** effectively blocks privilege escalation — even with a valid token, users cannot perform operations outside their role's scope.

## IV. Conclusion

**RBAC (Role-Based Access Control)** is an essential permission mechanism in any backend system. Combining **JwtAuthGuard** (authentication) and **RolesGuard** (authorization) creates a two-layer security model where every request must prove both its identity and its permissions before being processed.

**Conclusion:** Authentication only opens the door; authorization determines how far you can go. A system without RBAC is like a building with a locked front entrance but every room inside left wide open.

# references
## 0
### alias
NestJS Authorization
### url
https://docs.nestjs.com/security/authorization

# minutesRead
20
