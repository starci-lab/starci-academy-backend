# title
JWT Authentication Flow

# description
Understand the core mechanism of stateless authentication using JSON Web Tokens, compare it with traditional session-based approaches, and build a complete login flow with NestJS.

# body

## I. Introduction

Before **JWT** existed, most web systems managed login sessions using **Sessions**. When a user logged in, the server created a record in its memory (RAM or **Redis**) and sent back a `session_id` cookie. Every subsequent request required a lookup against that memory store. This model works well with a single server, but when the system scales to multiple instances, synchronizing session state across machines becomes a significant burden.

**JSON Web Token (JWT)** solves this problem through its **Stateless** nature. The token is cryptographically signed with a secret key and sent to the client. On each request, the server only needs to verify the signature using a mathematical algorithm without querying any database. This is the foundation of modern authentication in **Microservices** architectures.

## II. Core Concepts

### 1. Session vs JWT Comparison

**Session-based Authentication** stores state on the server side. Every request requires a memory lookup to verify the session. This creates a **Single Point of Failure** when the system has multiple servers, because all of them must share the same session store.

**JWT-based Authentication** embeds all authentication information inside the token itself. The server does not need to store any state. Simply verifying a valid signature is enough to trust the request.

- **Example:** A **Microservices** system with 10 backend instances running simultaneously. With Sessions, you need a centralized **Redis** layer to synchronize sessions across all instances. With JWT, each instance reads and verifies the token independently without communicating with any other service.

### 2. Anatomy of a JWT

A JWT string consists of three parts separated by dots: `Header.Payload.Signature`.

- **Header:** Declares the signing algorithm used (e.g., **HS256**, **RS256**).
- **Payload:** Contains public data such as `userId`, `role`. This is not encrypted data — anyone can decode the **Base64** content to read it. Therefore, never put **passwords** or sensitive information in the Payload.
- **Signature:** The result of cryptographically signing the Header and Payload with the server's **Secret Key**. If a hacker modifies any field in the Payload, the signature will no longer match and the server automatically rejects the token.

- **Example:** A token has Payload `{"userId": 1, "role": "user"}`. If an attacker changes `role` to `"admin"`, the Signature will not match the modified content, and the server returns **401 Unauthorized**.

### 3. The Authentication Lifecycle

The JWT authentication flow in **NestJS** follows a strict sequence:

1. Client sends `email` and `password` to the `POST /auth/login` endpoint.
2. **AuthService** queries the database, finds the user by email, and compares the password using **bcrypt**.
3. If valid, the server creates a JWT containing `{ sub: userId }` and signs it with **JWT_SECRET**.
4. Client receives the `access_token` and stores it (in **LocalStorage** or an **HttpOnly Cookie**).
5. For every subsequent request, the client sends the token in the header: `Authorization: Bearer <token>`.
6. **JwtAuthGuard** automatically verifies the token signature before allowing the request to reach the Controller.

- **Example:** A user calls `GET /users/profile` with the header `Authorization: Bearer eyJhbG...`. **JwtStrategy** decodes the token, extracts the `userId`, and attaches it to `req.user`. The Controller simply reads `req.user` without any authentication logic.

## III. Practice

> **Source code:** [JWT Authentication Flow](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/jwt-authentication-flow)

In this section, we will build a complete JWT authentication flow with **NestJS**, **TypeORM**, and **PostgreSQL**.

### 1. Setup & Run

- **Execution Steps:**
    - Step 1: Start PostgreSQL using Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up -d
      ```
    - Step 2: Install dependencies:
      ```bash
      npm install
      ```
    - Step 3: Run the application in development mode:
      ```bash
      npm run start:dev
      ```
- **Expected Results:** The NestJS application starts successfully at port **3000**, PostgreSQL connection is ready.
- **Conclusion:** The development environment is set up and ready for testing the authentication flow.

### 2. Architecture

| Component | Role |
|-----------|------|
| **AuthController** | Receives signup and signin requests at `/auth/signup` and `/auth/signin`. |
| **AuthService** | Handles authentication logic: hash password, compare password, generate JWT. |
| **JwtStrategy** | Verifies and decodes tokens from the `Authorization` header. |
| **JwtAuthGuard** | Guard that protects routes requiring authentication, automatically triggers JwtStrategy. |
| **UsersService** | Manages user data in the database. |

- **Execution Steps:** Read the source code, identify the files `auth.service.ts`, `jwt.strategy.ts`, `jwt-auth.guard.ts`, and understand how they connect.
- **Expected Results:** Clear understanding of what each component is responsible for in the authentication flow.
- **Conclusion:** A well-layered architecture separates authentication logic from business logic cleanly.

### 3. System Flow

```
[Client] ──POST /auth/signin──> [AuthController]
                                      │
                              AuthService.login()
                              Validate password (bcrypt)
                                      │
                              Generate JWT (sign)
                                      │
                              Return { access_token }
                                      │
[Client] ──GET /users/profile──> [JwtAuthGuard]
           Authorization: Bearer      │
                              JwtStrategy.validate()
                              Verify signature
                                      │
                              Attach user to req.user
                                      │
                              [UsersController] -> Response
```

- **Execution Steps:** Trace the flow from when the client sends credentials to when the profile response is returned.
- **Expected Results:** Understand that every protected request must pass through JwtAuthGuard before reaching the Controller.
- **Conclusion:** The Guard acts as a checkpoint — any request without a valid token is blocked before it touches business logic.

### 4. Try it out

**Success path** — Sign up, sign in, and access profile successfully:

- **Execution Steps:**
    - Step 1: Register a new account:
      ```bash
      curl -X POST http://localhost:3000/auth/signup \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456"}'
      ```
    - Step 2: Sign in to receive a token:
      ```bash
      curl -X POST http://localhost:3000/auth/signin \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456"}'
      ```
    - Step 3: Access profile with the received token:
      ```bash
      curl -X GET http://localhost:3000/users/profile \
        -H "Authorization: Bearer <access_token>"
      ```
- **Expected Results:**
    1. Step 1 returns the newly created user information.
    2. Step 2 returns `{ "access_token": "eyJhbG..." }`.
    3. Step 3 returns the authenticated user's profile information.
- **Conclusion:** The JWT authentication flow works correctly — only requests with valid tokens can access protected resources.

**Failure path** — Accessing profile without a token:

- **Execution Steps:**
    - Step 1: Send a request to profile without a token:
      ```bash
      curl -X GET http://localhost:3000/users/profile
      ```
    - Step 2: Send a request with an invalid token:
      ```bash
      curl -X GET http://localhost:3000/users/profile \
        -H "Authorization: Bearer invalid-token-here"
      ```
- **Expected Results:**
    1. Both steps return **401 Unauthorized**.
    2. The server rejects access because the token is missing or the signature is invalid.
- **Conclusion:** **JwtAuthGuard** provides effective protection — any request missing a token or carrying an invalid token is blocked at the Guard layer.

## IV. Conclusion

**JWT** transforms the authentication model from **Stateful** (dependent on server memory) to **Stateless** (dependent on cryptographic signatures). This eliminates the need to synchronize sessions across instances and allows the system to scale horizontally with ease.

**Conclusion:** Mastering the JWT authentication flow — from token creation, storage, header attachment, to Guard verification — is a mandatory foundation before advancing to more complex topics such as **Refresh Tokens**, **RBAC**, and **OAuth2**.

# references
## 0
### alias
NestJS Authentication
### url
https://docs.nestjs.com/security/authentication

# minutesRead
20
