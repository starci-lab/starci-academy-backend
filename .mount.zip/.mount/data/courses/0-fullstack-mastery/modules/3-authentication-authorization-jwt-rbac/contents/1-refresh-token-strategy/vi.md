# title
Chiến lược Refresh Token

# description
Hiểu tại sao Access Token phải có thời gian sống ngắn, cách xây dựng luồng Refresh Token Rotation chuẩn production, và cơ chế thu hồi token khi đăng xuất.

# body

## I. Lời mở đầu

Sau khi nắm vững luồng xác thực JWT, một câu hỏi tự nhiên xuất hiện: nếu **Access Token** bị đánh cắp, kẻ tấn công có thể mạo danh người dùng cho đến khi token hết hạn. Bởi vì JWT là **Stateless**, server không thể đơn phương vô hiệu hóa một token đã phát hành — trừ khi xây thêm một hệ thống **Blocklist** trên **Redis**, điều này đi ngược lại tinh thần phi trạng thái ban đầu.

Giải pháp là chia token thành hai loại: **Access Token** có thời gian sống rất ngắn (**15 phút**) để giảm thiệt hại khi bị lộ, và **Refresh Token** có thời gian sống dài (**7 ngày**) dùng duy nhất để xin cấp mới Access Token. Đây là chiến lược bảo mật chuẩn được áp dụng rộng rãi trong các hệ thống production.

## II. Nội dung chính

### 1. Phân biệt Access Token và Refresh Token

**Access Token (AT)** là chứng chỉ truy cập API, có thời gian sống ngắn (thường là **15 phút**). Khi AT hết hạn, client không thể tiếp tục truy cập tài nguyên được bảo vệ.

**Refresh Token (RT)** là chứng chỉ gia hạn, có thời gian sống dài (thường là **7 ngày**). RT chỉ được sử dụng cho một mục đích duy nhất: gửi đến server để đổi lấy cặp AT và RT mới.

- **Ví dụ:** Người dùng đăng nhập lúc 9h sáng và nhận AT (hết hạn lúc 9h15) cùng RT (hết hạn sau 7 ngày). Đến 9h16, khi AT đã hết hạn, frontend tự động gửi RT đến `POST /auth/refresh` để nhận AT mới mà người dùng không cần đăng nhập lại.

### 2. Lưu trữ token an toàn

Cách lưu trữ token quyết định mức độ bảo mật của toàn bộ hệ thống.

- **Access Token:** Vì thời gian sống ngắn, việc lưu trong **LocalStorage** là chấp nhận được dù có rủi ro bị tấn công **XSS**.
- **Refresh Token:** Là tài sản giá trị nhất trong hệ thống xác thực. Phải được lưu trong **HttpOnly Cookie** kết hợp với cờ **Secure**, khiến cho không một dòng mã **JavaScript** nào có thể truy cập được nó từ phía trình duyệt.

- **Ví dụ:** Nếu kẻ tấn công khai thác lỗ hổng XSS và đánh cắp AT, chúng chỉ có thể sử dụng trong tối đa **15 phút**. Nhưng nếu RT bị lộ, kẻ tấn công có thể liên tục gia hạn quyền truy cập. Vì vậy, RT phải được bảo vệ nghiêm ngặt nhất.

### 3. Cơ chế Rotation (Xoay vòng)

**Token Rotation** là kỹ thuật bảo mật nâng cao: mỗi lần client sử dụng RT để gia hạn, server không chỉ cấp AT mới mà còn cấp luôn RT mới. RT cũ lập tức bị vô hiệu hóa.

Điều này có nghĩa là nếu kẻ tấn công đánh cắp một RT cũ và cố gắng sử dụng nó, server sẽ phát hiện RT đó đã bị thay thế và từ chối. Đồng thời, server có thể vô hiệu hóa toàn bộ chuỗi token của người dùng đó để đảm bảo an toàn.

- **Ví dụ:** Người dùng đăng nhập và nhận RT1. Khi gia hạn, server cấp AT2 và RT2, đồng thời xóa RT1. Nếu Hacker cố gắng dùng RT1, server trả về lỗi vì RT1 đã không còn hợp lệ.

### 4. Cơ chế thu hồi (Revocation)

Khi người dùng nhấn **"Đăng xuất"**, server cần vô hiệu hóa RT để đảm bảo không ai có thể tiếp tục gia hạn token.

Cách thực hiện: server lưu **hash của RT** (bằng **bcrypt**) trong bảng `users` của database. Khi người dùng đăng xuất, server cập nhật trường `hashedRefreshToken` về `null`. Mọi RT đang tồn tại ngoài hệ thống sẽ mất hiệu lực ngay lập tức vì không còn giá trị nào để so sánh.

- **Ví dụ:** Người dùng nhấn "Đăng xuất khỏi mọi thiết bị". Server đặt `hashedRefreshToken = null`. Tất cả các phiên đăng nhập trên điện thoại, máy tính bảng và laptop đều mất quyền truy cập cùng lúc.

## III. Thực hành

> **Source code:** [Refresh Token Strategy](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/refresh-token-strategy)

Trong phần này, chúng ta sẽ xây dựng hệ thống Refresh Token với cơ chế **Rotation** và **Revocation** hoàn chỉnh trong **NestJS**.

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
    - Bước 1: Khởi động PostgreSQL bằng Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up -d
      ```
    - Bước 2: Cài đặt dependencies:
      ```bash
      npm install
      ```
    - Bước 3: Chạy ứng dụng ở chế độ development:
      ```bash
      npm run start:dev
      ```
- **Kết quả mong đợi:** Ứng dụng NestJS khởi động thành công tại port **3000**, kết nối PostgreSQL sẵn sàng.
- **Kết luận:** Môi trường đã sẵn sàng để thử nghiệm luồng Refresh Token.

### 2. Kiến trúc (Architecture)

| Thành phần | Vai trò |
|------------|---------|
| **AuthService.signIn()** | Xác thực credentials, tạo cặp AT + RT, hash RT và lưu vào database. |
| **AuthService.refresh()** | Xác minh RT, so sánh với hash trong database, cấp cặp AT + RT mới (Rotation). |
| **AuthService.logout()** | Xóa `hashedRefreshToken` trong database (Revocation). |
| **JwtStrategy** | Xác minh AT từ header `Authorization`. |
| **RefreshTokenGuard** | Xác minh RT khi client gửi request gia hạn. |

- **Các bước thực hiện:** Đọc source code, tập trung vào các file `auth.service.ts` để hiểu logic hash, so sánh và rotation.
- **Kết quả mong đợi:** Hiểu được toàn bộ luồng dữ liệu từ đăng nhập, gia hạn, đến đăng xuất.
- **Kết luận:** Mọi thao tác (sign in, refresh, logout) đều có tác động trực tiếp đến trường `hashedRefreshToken` trong database.

### 3. Luồng hệ thống (System Flow)

```
[Client] ──POST /auth/signin──> [AuthService]
                                      │
                              Validate credentials
                              Generate AT (15m) + RT (7d)
                              Hash RT -> save to DB
                                      │
                              Return { access_token, refresh_token }

--- Sau 15 phút, AT hết hạn ---

[Client] ──POST /auth/refresh──> [RefreshTokenGuard]
           Refresh Token              │
                              Verify RT signature
                              Compare with hash in DB
                                      │
                              Generate new AT + new RT (Rotation)
                              Hash new RT -> update DB
                              Old RT invalidated
                                      │
                              Return { access_token, refresh_token }

--- Đăng xuất ---

[Client] ──POST /auth/logout──> [AuthService]
                                      │
                              Set hashedRefreshToken = null
                              All existing RTs invalidated
```

- **Các bước thực hiện:** Theo dõi luồng từ sign in, qua refresh, đến logout.
- **Kết quả mong đợi:** Hiểu rõ ràng mỗi lần refresh tạo ra cặp token hoàn toàn mới và vô hiệu hóa cặp cũ.
- **Kết luận:** Cơ chế Rotation đảm bảo mỗi RT chỉ sử dụng được một lần duy nhất, giảm thiệt hại tối đa khi token bị lộ.

### 4. Thử nghiệm (Try it out)

**Success path** — Đăng nhập, gia hạn token và đăng xuất thành công:

- **Các bước thực hiện:**
    - Bước 1: Đăng nhập để nhận cặp AT và RT:
      ```bash
      curl -X POST http://localhost:3000/auth/signin \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456"}'
      ```
    - Bước 2: Sử dụng RT để gia hạn token:
      ```bash
      curl -X POST http://localhost:3000/auth/refresh \
        -H "Authorization: Bearer <refresh_token>"
      ```
    - Bước 3: Đăng xuất để thu hồi RT:
      ```bash
      curl -X POST http://localhost:3000/auth/logout \
        -H "Authorization: Bearer <access_token>"
      ```
- **Kết quả mong đợi:**
    1. Bước 1 trả về `{ "access_token": "...", "refresh_token": "..." }`.
    2. Bước 2 trả về cặp AT và RT hoàn toàn mới.
    3. Bước 3 trả về xác nhận đăng xuất thành công, `hashedRefreshToken` trong database được đặt về `null`.
- **Kết luận:** Luồng Refresh Token hoạt động đúng: cấp mới, xoay vòng và thu hồi đều diễn ra chính xác.

**Failure path** — Sử dụng RT cũ sau khi đã gia hạn (Rotation protection):

- **Các bước thực hiện:**
    - Bước 1: Đăng nhập và nhận RT1:
      ```bash
      curl -X POST http://localhost:3000/auth/signin \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456"}'
      ```
    - Bước 2: Gia hạn token, nhận RT2 (RT1 bị vô hiệu hóa):
      ```bash
      curl -X POST http://localhost:3000/auth/refresh \
        -H "Authorization: Bearer <RT1>"
      ```
    - Bước 3: Thử dùng lại RT1 (đã bị vô hiệu hóa):
      ```bash
      curl -X POST http://localhost:3000/auth/refresh \
        -H "Authorization: Bearer <RT1>"
      ```
- **Kết quả mong đợi:**
    1. Bước 1 và Bước 2 thành công bình thường.
    2. Bước 3 trả về **401 Unauthorized** vì RT1 không còn khớp với hash trong database.
- **Kết luận:** Cơ chế **Rotation** hoạt động hiệu quả — mỗi RT chỉ sử dụng được duy nhất một lần, ngăn chặn việc tái sử dụng token cũ bị đánh cắp.

## IV. Kết luận

Chiến lược **Refresh Token** là lớp bảo mật thứ hai không thể thiếu sau JWT. Với thời gian sống ngắn của AT, hệ thống giảm thiểu thiệt hại khi token bị lộ. Với cơ chế **Rotation**, mỗi RT chỉ sử dụng một lần và bị thay thế ngay lập tức. Với cơ chế **Revocation**, người dùng có thể đóng toàn bộ phiên đăng nhập chỉ bằng một thao tác đăng xuất.

**Kết luận:** Một hệ thống xác thực production không chỉ cần JWT — nó cần cả chiến lược quản lý vòng đời token hoàn chỉnh, bao gồm cấp phối, xoay vòng và thu hồi, để đảm bảo bảo mật từ đầu đến cuối.

# references
## 0
### alias
Token Revocation Best Practices
### url
https://auth0.com/blog/refresh-tokens-what-are-they-and-when-to-use-them/

# minutesRead
25
