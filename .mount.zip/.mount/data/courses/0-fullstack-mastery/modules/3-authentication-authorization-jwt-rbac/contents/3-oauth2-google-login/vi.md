# title
Tích hợp OAuth2 và Google Login

# description
Tích hợp đăng nhập bằng Google vào hệ thống NestJS sử dụng OAuth2, loại bỏ quy trình đăng ký truyền thống và chuyển đổi token Google thành JWT nội bộ.

# body

## I. Lời mở đầu

Yêu cầu người dùng tạo tài khoản với email và mật khẩu truyền thống làm tăng tỷ lệ bỏ ngang (drop-off rate) đáng kể. Người dùng phải nghĩ ra một mật khẩu đủ mạnh, xác nhận email, và ghi nhớ thông tin đăng nhập cho từng ứng dụng. Đối với nhà phát triển, việc lưu trữ và bảo vệ mật khẩu cũng mang theo rủi ro bảo mật lớn.

**OAuth2** giải quyết cả hai vấn đề bằng cách ủy quyền xác thực cho các nhà cung cấp danh tính đáng tin cậy như **Google**, **Facebook**, hoặc **Apple**. Backend không cần xử lý mật khẩu — chỉ cần nhận một token từ nhà cung cấp, xác minh danh tính người dùng, và phát hành **JWT** nội bộ. Đây là mô hình **Single Sign-On (SSO)** được áp dụng rộng rãi trong các ứng dụng hiện đại.

## II. Nội dung chính

### 1. OAuth2 và Single Sign-On (SSO)

**OAuth2** là một giao thức ủy quyền cho phép ứng dụng của bạn yêu cầu người dùng đăng nhập thông qua một dịch vụ bên thứ ba (như **Google**) thay vì tự quản lý credentials. Sau khi người dùng xác thực thành công với Google, ứng dụng nhận được thông tin hồ sơ (email, tên, ảnh đại diện) mà không bao giờ chạm vào mật khẩu của họ.

**SSO (Single Sign-On)** cho phép người dùng đăng nhập một lần với tài khoản Google và truy cập nhiều ứng dụng khác nhau mà không cần tạo tài khoản riêng cho từng ứng dụng.

- **Ví dụ:** Người dùng nhấn nút "Đăng nhập bằng Google" trên ứng dụng của bạn. Họ được chuyển đến trang đăng nhập Google, nhập thông tin tài khoản Google của họ, và được chuyển lại ứng dụng với thông tin hồ sơ đã xác thực. Toàn bộ quy trình không yêu cầu họ tạo mật khẩu mới.

### 2. Cấu hình Google Cloud Console

Trước khi tích hợp, bạn cần đăng ký ứng dụng của mình với **Google Cloud Console** để nhận hai thông tin bảo mật quan trọng:

- **Client ID:** Định danh công khai của ứng dụng.
- **Client Secret:** Khóa bí mật để xác minh danh tính ứng dụng với Google.
- **Redirect URI:** Địa chỉ callback mà Google sẽ gửi người dùng trở lại sau khi xác thực (ví dụ: `http://localhost:3000/auth/google/callback`).

- **Ví dụ:** Vào Google Cloud Console, tạo một **OAuth 2.0 Client ID** thuộc loại "Web application". Đặt **Authorized redirect URIs** là `http://localhost:3000/auth/google/callback`. Lưu lại **Client ID** và **Client Secret** vào file `.env` của dự án.

### 3. GoogleStrategy và luồng xác thực

**NestJS** sử dụng thư viện **Passport.js** và strategy `passport-google-oauth20` để xử lý luồng OAuth2. Bạn tạo một **GoogleStrategy** để cấu hình kết nối với Google và định nghĩa cách xử lý dữ liệu người dùng sau khi xác thực thành công.

```typescript
@Injectable()
export class GoogleStrategy extends PassportStrategy(Strategy, 'google') {
  constructor() {
    super({
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: 'http://localhost:3000/auth/google/callback',
      scope: ['email', 'profile'],
    });
  }

  async validate(accessToken: string, refreshToken: string, profile: any, done: VerifyCallback) {
    const user = {
      email: profile.emails[0].value,
      firstName: profile.name.givenName,
      lastName: profile.name.familyName,
      picture: profile.photos[0].value,
    };
    done(null, user);
  }
}
```

Luồng xử lý diễn ra theo trình tự:

1. Frontend gọi endpoint `GET /auth/google` (được bảo vệ bởi `AuthGuard('google')`). NestJS tự động chuyển hướng người dùng đến trang đăng nhập Google.
2. Người dùng đăng nhập thành công trên Google. Google gửi mã xác thực (authorization code) trở lại endpoint `GET /auth/google/callback`.
3. **GoogleStrategy** tự động đổi mã xác thực lấy thông tin hồ sơ người dùng.
4. **AuthService** kiểm tra email trong database: nếu chưa tồn tại, tự động tạo tài khoản mới (silent registration); nếu đã tồn tại, lấy thông tin người dùng.
5. Server phát hành **AccessToken** và **RefreshToken** nội bộ, gửi về cho client qua **HttpOnly Cookie** hoặc redirect.

- **Ví dụ:** Người dùng mới nhấn "Login with Google" lần đầu. Sau khi xác thực với Google, hệ thống nhận được email `user@gmail.com`. AuthService kiểm tra database, không tìm thấy email này, tự động tạo một user mới với tên và ảnh đại diện từ Google, rồi phát hành JWT nội bộ để người dùng bắt đầu sử dụng ứng dụng ngay lập tức.

## III. Thực hành

> **Source code:** [OAuth2 Google Login](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/oauth2-google-login)

Trong phần này, chúng ta sẽ tích hợp **Google Login** vào ứng dụng **NestJS** với luồng OAuth2 hoàn chỉnh.

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
    - Bước 1: Cấu hình Google Cloud Console:
        - Truy cập [Google Cloud Console](https://console.cloud.google.com/).
        - Tạo project mới hoặc chọn project hiện có.
        - Vào **APIs & Services** > **Credentials** > **Create Credentials** > **OAuth 2.0 Client ID**.
        - Chọn Application Type là **Web application**.
        - Thêm `http://localhost:3000/auth/google/callback` vào **Authorized redirect URIs**.
        - Sao chép **Client ID** và **Client Secret**.
    - Bước 2: Tạo file `.env` với nội dung:
      ```
      GOOGLE_CLIENT_ID=your-client-id
      GOOGLE_CLIENT_SECRET=your-client-secret
      ```
    - Bước 3: Khởi động PostgreSQL bằng Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up -d
      ```
    - Bước 4: Cài đặt dependencies:
      ```bash
      npm install
      ```
    - Bước 5: Chạy ứng dụng ở chế độ development:
      ```bash
      npm run start:dev
      ```
- **Kết quả mong đợi:** Ứng dụng NestJS khởi động thành công tại port **3000**, kết nối PostgreSQL và Google OAuth2 sẵn sàng.
- **Kết luận:** Môi trường đã sẵn sàng để thử nghiệm luồng đăng nhập bằng Google.

### 2. Kiến trúc (Architecture)

| Thành phần | Vai trò |
|------------|---------|
| **GoogleStrategy** | Cấu hình OAuth2 với Google, xử lý callback và trích xuất thông tin người dùng. |
| **AuthGuard('google')** | Guard kích hoạt luồng OAuth2, chuyển hướng người dùng đến Google. |
| **AuthController** | Định nghĩa hai endpoint: `/auth/google` (khởi tạo) và `/auth/google/callback` (nhận kết quả). |
| **AuthService** | Kiểm tra database, tạo user mới nếu cần, phát hành JWT nội bộ. |

- **Các bước thực hiện:** Đọc source code, tập trung vào file `google.strategy.ts` và các endpoint trong `auth.controller.ts`.
- **Kết quả mong đợi:** Hiểu rõ từng bước trong luồng OAuth2 từ redirect đến callback.
- **Kết luận:** Google Strategy xử lý toàn bộ giao tiếp với Google, AuthService chỉ cần tập trung vào logic nghiệp vụ nội bộ.

### 3. Luồng hệ thống (System Flow)

```
[Client] ──Click "Login with Google"──> GET /auth/google
                                              │
                                     AuthGuard('google')
                                     Redirect to Google Login
                                              │
[Google] ──User authenticates──> GET /auth/google/callback
                                              │
                                     GoogleStrategy.validate()
                                     Extract email, name, picture
                                              │
                                     AuthService: Check DB
                                     Email exists? -> Load user
                                     Email new? -> Create user
                                              │
                                     Generate internal AT + RT
                                     Set HttpOnly Cookie / Redirect
                                              │
                                     [Client] <── Authenticated
```

- **Các bước thực hiện:** Theo dõi luồng từ khi người dùng nhấn nút đăng nhập đến khi nhận được JWT nội bộ.
- **Kết quả mong đợi:** Hiểu rằng Google chỉ đóng vai trò xác thực danh tính, hệ thống vẫn sử dụng JWT nội bộ để quản lý phiên.
- **Kết luận:** OAuth2 là cơ chế ủy quyền xác thực — hệ thống nội bộ vẫn tự quản lý vòng đời token của riêng mình.

### 4. Thử nghiệm (Try it out)

**Success path** — Đăng nhập bằng Google thành công:

- **Các bước thực hiện:**
    - Bước 1: Mở trình duyệt và truy cập:
      ```
      http://localhost:3000/auth/google
      ```
    - Bước 2: Trình duyệt tự động chuyển hướng đến trang đăng nhập Google. Nhập tài khoản Google của bạn và cấp quyền cho ứng dụng.
    - Bước 3: Sau khi xác thực thành công, Google chuyển hướng về `http://localhost:3000/auth/google/callback`. Hệ thống xử lý callback và trả về JWT.
- **Kết quả mong đợi:**
    1. Trình duyệt chuyển hướng đến trang Google OAuth consent.
    2. Sau khi đăng nhập, hệ thống tạo user mới (nếu chưa tồn tại) hoặc load user hiện có.
    3. Server trả về **access_token** và **refresh_token** nội bộ.
- **Kết luận:** Luồng OAuth2 hoạt động chính xác — người dùng đăng nhập chỉ bằng tài khoản Google mà không cần tạo mật khẩu riêng.

**Failure path** — Cấu hình sai Redirect URI:

- **Các bước thực hiện:**
    - Bước 1: Trong Google Cloud Console, thay đổi **Authorized redirect URIs** thành một địa chỉ khác (ví dụ: `http://localhost:3000/wrong-callback`).
    - Bước 2: Thử truy cập lại `http://localhost:3000/auth/google`.
- **Kết quả mong đợi:**
    1. Google hiển thị lỗi **redirect_uri_mismatch**.
    2. Luồng OAuth2 bị gián đoạn vì callback URL không khớp với cấu hình trên Google Cloud Console.
- **Kết luận:** **Redirect URI** phải khớp chính xác giữa cấu hình Google Cloud Console và mã nguồn ứng dụng. Đây là cơ chế bảo mật ngăn chặn tấn công chuyển hướng (redirect attack).

## IV. Kết luận

**OAuth2** và **Google Login** chuyển đổi quy trình đăng ký từ việc yêu cầu người dùng tạo mật khẩu thành việc ủy quyền xác thực cho nhà cung cấp đáng tin cậy. Backend chỉ cần nhận thông tin hồ sơ đã xác thực và phát hành JWT nội bộ, loại bỏ hoàn toàn gánh nặng lưu trữ và bảo vệ mật khẩu.

**Kết luận:** OAuth2 không thay thế hệ thống xác thực nội bộ của bạn — nó bổ sung thêm một kênh đăng nhập tiện lợi và an toàn. Hệ thống vẫn cần JWT, Refresh Token và RBAC để quản lý phiên và phân quyền. OAuth2 chỉ là cửa vào, các lớp bảo mật phía sau vẫn phải hoạt động đầy đủ.

# references
## 0
### alias
OAuth2 Login NestJS
### url
https://dev.to/imichaelowolabi/how-to-implement-login-with-google-in-nestjs-2aoa

# minutesRead
25
