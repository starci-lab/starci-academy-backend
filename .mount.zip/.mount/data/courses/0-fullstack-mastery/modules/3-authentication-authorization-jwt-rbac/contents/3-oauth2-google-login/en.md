# title
OAuth2 and Google Login Integration

# description
Integrate Google Login into a NestJS application using OAuth2, eliminate traditional registration flows, and convert Google tokens into internal JWTs.

# body

## I. Introduction

Requiring users to create accounts with email and password significantly increases drop-off rates. Users must invent a strong enough password, confirm their email, and remember login credentials for each application. For developers, storing and protecting passwords also carries substantial security risks.

**OAuth2** solves both problems by delegating authentication to trusted identity providers like **Google**, **Facebook**, or **Apple**. The backend never handles passwords — it simply receives a token from the provider, verifies the user's identity, and issues an internal **JWT**. This is the **Single Sign-On (SSO)** model widely adopted in modern applications.

## II. Core Concepts

### 1. OAuth2 and Single Sign-On (SSO)

**OAuth2** is an authorization protocol that allows your application to request users to authenticate through a third-party service (like **Google**) instead of managing credentials directly. After the user successfully authenticates with Google, the application receives profile information (email, name, avatar) without ever touching the user's password.

**SSO (Single Sign-On)** enables users to log in once with their Google account and access multiple different applications without creating separate accounts for each one.

- **Example:** A user clicks the "Login with Google" button on your application. They are redirected to the Google login page, enter their Google credentials, and are redirected back to the application with authenticated profile information. The entire process requires no new password creation.

### 2. Google Cloud Console Configuration

Before integrating, you need to register your application with **Google Cloud Console** to receive two critical security credentials:

- **Client ID:** The public identifier for your application.
- **Client Secret:** A secret key to verify your application's identity with Google.
- **Redirect URI:** The callback address where Google will send the user back after authentication (e.g., `http://localhost:3000/auth/google/callback`).

- **Example:** Go to Google Cloud Console, create an **OAuth 2.0 Client ID** of type "Web application". Set **Authorized redirect URIs** to `http://localhost:3000/auth/google/callback`. Save the **Client ID** and **Client Secret** to your project's `.env` file.

### 3. GoogleStrategy and the Authentication Flow

**NestJS** uses the **Passport.js** library and the `passport-google-oauth20` strategy to handle the OAuth2 flow. You create a **GoogleStrategy** to configure the connection with Google and define how to process user data after successful authentication.

```typescript
@Injectable()
export class GoogleStrategy extends PassportStrategy(Strategy, 'google') {
  constructor() {
    super({
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: 'http://localhost:3000/auth/google/callback',
      scope: ['email', 'profile'],
    });
  }

  async validate(accessToken: string, refreshToken: string, profile: any, done: VerifyCallback) {
    const user = {
      email: profile.emails[0].value,
      firstName: profile.name.givenName,
      lastName: profile.name.familyName,
      picture: profile.photos[0].value,
    };
    done(null, user);
  }
}
```

The processing flow follows this sequence:

1. Frontend calls the `GET /auth/google` endpoint (protected by `AuthGuard('google')`). NestJS automatically redirects the user to the Google login page.
2. The user authenticates successfully on Google. Google sends an authorization code back to the `GET /auth/google/callback` endpoint.
3. **GoogleStrategy** automatically exchanges the authorization code for user profile information.
4. **AuthService** checks the email in the database: if it does not exist, it automatically creates a new account (silent registration); if it already exists, it loads the existing user.
5. The server issues internal **AccessToken** and **RefreshToken**, sent to the client via **HttpOnly Cookie** or redirect.

- **Example:** A new user clicks "Login with Google" for the first time. After authenticating with Google, the system receives the email `user@gmail.com`. AuthService checks the database, finds no matching email, automatically creates a new user with the name and avatar from Google, then issues an internal JWT so the user can start using the application immediately.

## III. Practice

> **Source code:** [OAuth2 Google Login](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/oauth2-google-login)

In this section, we will integrate **Google Login** into a **NestJS** application with a complete OAuth2 flow.

### 1. Setup & Run

- **Execution Steps:**
    - Step 1: Configure Google Cloud Console:
        - Go to [Google Cloud Console](https://console.cloud.google.com/).
        - Create a new project or select an existing one.
        - Navigate to **APIs & Services** > **Credentials** > **Create Credentials** > **OAuth 2.0 Client ID**.
        - Select Application Type as **Web application**.
        - Add `http://localhost:3000/auth/google/callback` to **Authorized redirect URIs**.
        - Copy the **Client ID** and **Client Secret**.
    - Step 2: Create a `.env` file with the following content:
      ```
      GOOGLE_CLIENT_ID=your-client-id
      GOOGLE_CLIENT_SECRET=your-client-secret
      ```
    - Step 3: Start PostgreSQL using Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up -d
      ```
    - Step 4: Install dependencies:
      ```bash
      npm install
      ```
    - Step 5: Run the application in development mode:
      ```bash
      npm run start:dev
      ```
- **Expected Results:** The NestJS application starts successfully at port **3000**, PostgreSQL and Google OAuth2 connections are ready.
- **Conclusion:** The environment is set up and ready for testing the Google Login flow.

### 2. Architecture

| Component | Role |
|-----------|------|
| **GoogleStrategy** | Configures OAuth2 with Google, handles callback, and extracts user information. |
| **AuthGuard('google')** | Guard that triggers the OAuth2 flow, redirecting the user to Google. |
| **AuthController** | Defines two endpoints: `/auth/google` (initiate) and `/auth/google/callback` (receive result). |
| **AuthService** | Checks the database, creates a new user if needed, issues internal JWT. |

- **Execution Steps:** Read the source code, focusing on `google.strategy.ts` and the endpoints in `auth.controller.ts`.
- **Expected Results:** Clear understanding of each step in the OAuth2 flow from redirect to callback.
- **Conclusion:** Google Strategy handles all communication with Google, while AuthService focuses solely on internal business logic.

### 3. System Flow

```
[Client] ──Click "Login with Google"──> GET /auth/google
                                              │
                                     AuthGuard('google')
                                     Redirect to Google Login
                                              │
[Google] ──User authenticates──> GET /auth/google/callback
                                              │
                                     GoogleStrategy.validate()
                                     Extract email, name, picture
                                              │
                                     AuthService: Check DB
                                     Email exists? -> Load user
                                     Email new? -> Create user
                                              │
                                     Generate internal AT + RT
                                     Set HttpOnly Cookie / Redirect
                                              │
                                     [Client] <── Authenticated
```

- **Execution Steps:** Trace the flow from when the user clicks the login button to when they receive the internal JWT.
- **Expected Results:** Understand that Google only serves as the identity verifier; the system still uses internal JWT to manage sessions.
- **Conclusion:** OAuth2 is an authentication delegation mechanism — the internal system still manages its own token lifecycle independently.

### 4. Try it out

**Success path** — Logging in with Google successfully:

- **Execution Steps:**
    - Step 1: Open a browser and navigate to:
      ```
      http://localhost:3000/auth/google
      ```
    - Step 2: The browser automatically redirects to the Google login page. Enter your Google account credentials and grant permissions to the application.
    - Step 3: After successful authentication, Google redirects back to `http://localhost:3000/auth/google/callback`. The system processes the callback and returns JWT tokens.
- **Expected Results:**
    1. The browser redirects to the Google OAuth consent screen.
    2. After logging in, the system creates a new user (if not existing) or loads the existing user.
    3. The server returns an internal **access_token** and **refresh_token**.
- **Conclusion:** The OAuth2 flow works correctly — users can log in using only their Google account without creating a separate password.

**Failure path** — Misconfigured Redirect URI:

- **Execution Steps:**
    - Step 1: In Google Cloud Console, change the **Authorized redirect URIs** to a different address (e.g., `http://localhost:3000/wrong-callback`).
    - Step 2: Attempt to access `http://localhost:3000/auth/google` again.
- **Expected Results:**
    1. Google displays a **redirect_uri_mismatch** error.
    2. The OAuth2 flow is interrupted because the callback URL does not match the configuration on Google Cloud Console.
- **Conclusion:** The **Redirect URI** must match exactly between the Google Cloud Console configuration and the application source code. This is a security mechanism that prevents redirect attacks.

## IV. Conclusion

**OAuth2** and **Google Login** transform the registration process from requiring users to create passwords to delegating authentication to a trusted provider. The backend simply receives the already-verified profile information and issues an internal JWT, completely eliminating the burden of storing and protecting passwords.

**Conclusion:** OAuth2 does not replace your internal authentication system — it adds a convenient and secure login channel. The system still needs JWT, Refresh Tokens, and RBAC to manage sessions and permissions. OAuth2 is just the entry point; the security layers behind it must remain fully operational.

# references
## 0
### alias
Implementing OAuth2 with Passport
### url
https://dev.to/imichaelowolabi/how-to-implement-login-with-google-in-nestjs-2aoa

# minutesRead
25
