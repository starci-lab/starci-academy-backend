# title
Phân quyền theo vai trò (RBAC) và Guards

# description
Phân biệt rõ ràng giữa Authentication và Authorization, xây dựng hệ thống phân quyền RBAC đa tầng với custom Decorators và Guards trong NestJS.

# body

## I. Lời mở đầu

Xác thực thành công bằng JWT chỉ trả lời được câu hỏi "Người này là ai?". Nhưng trong một hệ thống thực tế, việc biết người dùng là ai chưa đủ — cần phải kiểm soát được họ **được phép làm gì**. Một người dùng có vai trò **Guest** không thể thực hiện thao tác xóa tài khoản chỉ dành cho **Admin**, dù họ sở hữu một Access Token hoàn toàn hợp lệ.

Đây là sự khác biệt cốt lõi giữa **Authentication (AuthN)** và **Authorization (AuthZ)**. AuthN xác minh danh tính, AuthZ kiểm soát quyền hạn. Thiếu một trong hai, hệ thống sẽ hoặc từ chối người dùng hợp lệ, hoặc cho phép kẻ tấn công thực hiện các thao tác vượt quyền.

## II. Nội dung chính

### 1. Phân biệt Authentication và Authorization

**Authentication (Xác thực)** là quá trình xác minh danh tính: "Bạn là ai?". Client trình **JWT** hợp lệ là đủ điều kiện vượt qua cổng xác thực. Trong NestJS, lớp này được xử lý bởi **JwtAuthGuard**.

**Authorization (Phân quyền)** là quá trình kiểm tra quyền hạn: "Bạn được phép làm gì?". Sau khi đã biết người dùng là ai, hệ thống cần kiểm tra vai trò của họ có đủ thẩm quyền để thực hiện thao tác yêu cầu hay không.

- **Ví dụ:** Một người dùng có vai trò **User** gửi request `DELETE /users/5` — một endpoint chỉ dành cho **Admin**. Dù Access Token của họ hoàn toàn hợp lệ (AuthN thành công), hệ thống vẫn trả về **403 Forbidden** vì vai trò không đủ quyền (AuthZ thất bại).

### 2. Tạo Decorator phân quyền với @Roles()

Thay vì viết logic kiểm tra vai trò bằng các câu lệnh `if-else` rời rạc trong mỗi Controller, **NestJS** cung cấp cơ chế **Metadata** cho phép gắn thông tin phân quyền trực tiếp lên từng endpoint.

Bạn tạo một custom decorator `@Roles()` sử dụng `SetMetadata`:

```typescript
export const ROLES_KEY = 'roles';
export const Roles = (...roles: string[]) => SetMetadata(ROLES_KEY, roles);
```

Khi áp dụng, chỉ cần gắn decorator lên endpoint cần bảo vệ:

```typescript
@Roles('ADMIN')
@Delete(':id')
deleteUser() { ... }
```

- **Ví dụ:** Endpoint `POST /courses` cần vai trò **ADMIN** hoặc **MANAGER**. Chỉ cần gắn `@Roles('ADMIN', 'MANAGER')` phía trên method, và hệ thống Guard sẽ tự động kiểm tra tại runtime.

### 3. Xây dựng RolesGuard đa tầng

**RolesGuard** là lớp bảo vệ thứ hai, hoạt động sau **JwtAuthGuard**. Nó sử dụng **Reflector** để đọc metadata `@Roles()` trên Controller và so sánh với trường `role` trong đối tượng `req.user` (đã được JwtAuthGuard gán từ bước trước).

```typescript
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<string[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!requiredRoles) { return true; }

    const { user } = context.switchToHttp().getRequest();
    return requiredRoles.includes(user.role);
  }
}
```

Khi kết hợp `@UseGuards(JwtAuthGuard, RolesGuard)`, hệ thống thực hiện hai bước kiểm tra tuần tự: trước tiên xác thực token (JwtAuthGuard), sau đó kiểm tra quyền hạn (RolesGuard).

- **Ví dụ:** Request gửi đến endpoint `@Roles('ADMIN')` với token chứa `role: "user"`. JwtAuthGuard xác nhận token hợp lệ (bước 1 thành công), nhưng RolesGuard phát hiện `"user"` không nằm trong danh sách `['ADMIN']` và trả về **403 Forbidden** (bước 2 thất bại).

## III. Thực hành

> **Source code:** [RBAC and Guards](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/rbac-and-guards)

Trong phần này, chúng ta sẽ xây dựng hệ thống **RBAC** hoàn chỉnh với Guard đa tầng trong **NestJS**.

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
    - Bước 1: Khởi động PostgreSQL bằng Docker:
      ```bash
      docker compose -f .docker/postgresql.yaml up -d
      ```
    - Bước 2: Cài đặt dependencies:
      ```bash
      npm install
      ```
    - Bước 3: Chạy ứng dụng ở chế độ development:
      ```bash
      npm run start:dev
      ```
- **Kết quả mong đợi:** Ứng dụng NestJS khởi động thành công tại port **3000**, kết nối PostgreSQL sẵn sàng.
- **Kết luận:** Môi trường đã sẵn sàng để thử nghiệm phân quyền RBAC.

### 2. Kiến trúc (Architecture)

| Thành phần | Vai trò |
|------------|---------|
| **Role Enum** | Định nghĩa các vai trò trong hệ thống: `ADMIN`, `USER`. |
| **@Roles() Decorator** | Gắn metadata vai trò yêu cầu lên từng endpoint. |
| **JwtAuthGuard** | Tầng 1 — Xác thực token, gắn `user` vào `req.user`. |
| **RolesGuard** | Tầng 2 — Đọc metadata `@Roles()`, so sánh với `req.user.role`. |
| **Reflector** | Công cụ NestJS để đọc metadata từ decorator tại runtime. |

- **Các bước thực hiện:** Đọc source code, tập trung vào file `roles.guard.ts`, `roles.decorator.ts` và cách chúng được áp dụng trong Controller.
- **Kết quả mong đợi:** Hiểu rõ cơ chế hai tầng Guard hoạt động tuần tự như thế nào.
- **Kết luận:** RBAC được triển khai qua hai lớp Guard độc lập, mỗi lớp chịu trách nhiệm một nhiệm vụ riêng biệt.

### 3. Luồng hệ thống (System Flow)

```
[Client] ──Request + Bearer Token──> [JwtAuthGuard] (Tầng 1)
                                          │
                                  Verify token signature
                                  Extract user from payload
                                  Attach to req.user
                                          │
                                     [RolesGuard] (Tầng 2)
                                          │
                                  Read @Roles() metadata
                                  Compare with req.user.role
                                          │
                                  Match? -> Controller executes
                                  No match? -> 403 Forbidden
```

- **Các bước thực hiện:** Theo dõi luồng từ khi request đến cổng JwtAuthGuard, qua RolesGuard, đến Controller.
- **Kết quả mong đợi:** Hiểu rằng request phải vượt qua cả hai tầng Guard trước khi đến được logic nghiệp vụ.
- **Kết luận:** Mô hình Guard đa tầng đảm bảo mỗi request đều được kiểm tra cả danh tính lẫn quyền hạn trước khi xử lý.

### 4. Thử nghiệm (Try it out)

**Success path** — Admin truy cập route dành riêng cho Admin:

- **Các bước thực hiện:**
    - Bước 1: Đăng ký tài khoản với vai trò Admin:
      ```bash
      curl -X POST http://localhost:3000/auth/signup \
        -H "Content-Type: application/json" \
        -d '{"email": "admin@test.com", "password": "123456", "role": "ADMIN"}'
      ```
    - Bước 2: Đăng nhập với tài khoản Admin:
      ```bash
      curl -X POST http://localhost:3000/auth/signin \
        -H "Content-Type: application/json" \
        -d '{"email": "admin@test.com", "password": "123456"}'
      ```
    - Bước 3: Truy cập route chỉ dành cho Admin với token Admin:
      ```bash
      curl -X GET http://localhost:3000/admin/dashboard \
        -H "Authorization: Bearer <admin_access_token>"
      ```
- **Kết quả mong đợi:**
    1. Bước 1 tạo thành công user với vai trò **ADMIN**.
    2. Bước 2 trả về `{ "access_token": "..." }`.
    3. Bước 3 trả về dữ liệu dashboard thành công vì vai trò khớp với yêu cầu.
- **Kết luận:** Người dùng có vai trò phù hợp có thể truy cập các endpoint được bảo vệ bởi RBAC.

**Failure path** — User thường truy cập route dành cho Admin:

- **Các bước thực hiện:**
    - Bước 1: Đăng ký tài khoản với vai trò User:
      ```bash
      curl -X POST http://localhost:3000/auth/signup \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456", "role": "USER"}'
      ```
    - Bước 2: Đăng nhập với tài khoản User:
      ```bash
      curl -X POST http://localhost:3000/auth/signin \
        -H "Content-Type: application/json" \
        -d '{"email": "user@test.com", "password": "123456"}'
      ```
    - Bước 3: Thử truy cập route Admin với token của User:
      ```bash
      curl -X GET http://localhost:3000/admin/dashboard \
        -H "Authorization: Bearer <user_access_token>"
      ```
- **Kết quả mong đợi:**
    1. Bước 1 và Bước 2 thành công bình thường.
    2. Bước 3 trả về **403 Forbidden** vì vai trò `USER` không nằm trong danh sách vai trò được phép (`ADMIN`).
- **Kết luận:** **RolesGuard** chặn hiệu quả các truy cập vượt quyền — dù token hợp lệ, người dùng vẫn không thể thực hiện thao tác ngoài phạm vi vai trò của mình.

## IV. Kết luận

**RBAC (Role-Based Access Control)** là cơ chế phân quyền thiết yếu trong bất kỳ hệ thống backend nào. Việc kết hợp **JwtAuthGuard** (xác thực) và **RolesGuard** (phân quyền) tạo ra mô hình bảo mật hai tầng, nơi mỗi request đều phải chứng minh cả danh tính lẫn quyền hạn trước khi được xử lý.

**Kết luận:** Xác thực chỉ mở cửa, phân quyền mới quyết định bạn được đi đến đâu. Một hệ thống thiếu RBAC giống như một tòa nhà có khóa cửa chính nhưng để ngỏ toàn bộ các phòng bên trong.

# references
## 0
### alias
NestJS Authorization
### url
https://docs.nestjs.com/security/authorization

# minutesRead
20
