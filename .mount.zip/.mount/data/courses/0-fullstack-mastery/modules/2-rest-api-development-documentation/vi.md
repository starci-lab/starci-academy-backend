# title
Xác thực & phân quyền (JWT + RBAC)

# description
Triển khai authentication với JWT (access/refresh token), Guards, phân quyền theo vai trò (RBAC); tích hợp OAuth2 (Google); bảo mật API theo best practices.

# previewContents
## 0
### text
Triển khai JWT (access token / refresh token) theo flow thực tế.
## 1
### text
Xây dựng Guards và cơ chế phân quyền RBAC (role-based access control).
## 2
### text
Thiết kế chiến lược refresh token (rotation / revoke) hợp lý và an toàn.
## 3
### text
Tích hợp OAuth2 (Google) cho đăng nhập nhanh và thuận tiện.
## 4
### text
Chuẩn hóa xử lý lỗi auth để frontend tích hợp ổn định.
## 5
### text
Hiểu cách xây dựng authentication sẵn sàng cho môi trường production.
## 6
### text
Thiết kế hệ thống phân quyền rõ ràng theo role và permission.
## 7
### text
Bảo vệ API đúng cách, không dừng ở việc chỉ kiểm tra có token hay không.
## 8
### text
Tự tin triển khai hệ thống đăng nhập và phân quyền cho dự án thực tế.
