# title
Authentication & Authorization (JWT + RBAC)

# description
Implement authentication with JWT (access and refresh tokens), Guards, and role-based access control; integrate OAuth2 (Google); and secure APIs following best practices.

# previewContents
## 0
### text
Implement JWT flows with access and refresh tokens as used in production.
## 1
### text
Build Guards and RBAC (role-based access control) for clear, enforceable authorization.
## 2
### text
Design refresh-token strategies (rotation, revocation) that stay maintainable and secure.
## 3
### text
Integrate OAuth2 (Google) for fast, familiar sign-in.
## 4
### text
Standardize auth errors so the frontend can handle sessions and failures predictably.
## 5
### text
Understand how to build production-ready authentication end to end.
## 6
### text
Model permissions by role and permission so access rules stay explicit and auditable.
## 7
### text
Protect APIs beyond "token present" checks: scopes, roles, and consistent policy application.
## 8
### text
Gain confidence shipping sign-in and authorization for real projects.
