# title
Build a RESTful Task Management API

# description
Build a REST API for managing tasks following RESTful conventions, using correct HTTP methods and returning accurate HTTP status codes.

# requirements
Create `TasksController` and `TasksService` to manage a list of tasks (in-memory array). Endpoints: `POST /tasks` (201 Created), `GET /tasks` (200 OK), `GET /tasks/:id` (200 or 404), `PATCH /tasks/:id` (200 or 404), `DELETE /tasks/:id` (204 No Content or 404). URLs must use plural nouns and must not contain verbs.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install

# steps

## 0
### title
Initialize the NestJS project
### body
- **Steps to follow:**
  - Step 1: Create a new project using the CLI:
    ```bash
    nest new restful-api-crud-best-practices-easy
    ```
  - Step 2: Navigate to the project directory and start the app:
    ```bash
    cd restful-api-crud-best-practices-easy
    npm run start:dev
    ```
- **Expected result:** The application starts successfully on port 3000, terminal displays NestJS startup logs.
- **Conclusion:** The base environment is ready for building the REST API.

## 1
### title
Create TasksModule, TasksService and TasksController
### body
- **Steps to follow:**
  - Step 1: Create `TasksModule`, `TasksService`, `TasksController` using the CLI or manually.
  - Step 2: In `TasksService`, declare an in-memory array to store tasks. Each task has fields: `id` (auto-incrementing number or UUID string), `title` (string), `description` (string), `status` (string, default `"open"`).
  - Step 3: Register `TasksService` in `providers` and `TasksController` in `controllers` of `TasksModule`.
  - Step 4: Import `TasksModule` into `AppModule`.
- **Expected result:** The module is recognized by NestJS, no errors on startup.
- **Conclusion:** The basic module structure is ready for implementing CRUD endpoints.

## 2
### title
Implement all CRUD endpoints
### body
- **Steps to follow:**
  - Step 1: In `TasksService`, implement the following methods:
    - `create(data)`: add a new task to the array, return the created task.
    - `findAll()`: return the entire task array.
    - `findOne(id)`: find a task by id, throw `NotFoundException` if not found.
    - `update(id, data)`: update a task by id, throw `NotFoundException` if not found.
    - `remove(id)`: delete a task by id, throw `NotFoundException` if not found.
  - Step 2: In `TasksController`, create endpoints with correct HTTP methods and status codes:
    - `@Post()` for `POST /tasks` with `@HttpCode(HttpStatus.CREATED)` -> calls `create()`.
    - `@Get()` for `GET /tasks` -> calls `findAll()`.
    - `@Get(':id')` for `GET /tasks/:id` -> calls `findOne()`.
    - `@Patch(':id')` for `PATCH /tasks/:id` -> calls `update()`.
    - `@Delete(':id')` for `DELETE /tasks/:id` with `@HttpCode(HttpStatus.NO_CONTENT)` -> calls `remove()`.
  - Step 3: Ensure URLs use plural nouns (`/tasks`), no verbs like `/createTask` or `/deleteTask`.
- **Expected result:** All 5 endpoints work correctly with the appropriate HTTP methods and status codes.
- **Conclusion:** The REST API follows RESTful conventions for naming and HTTP semantics.

## 3
### title
Test the endpoints
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Create a new task:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\":\"Learn REST\",\"description\":\"Study RESTful conventions\"}"
    ```
    Verify the response returns status 201 with the created task in the body.
  - Step 3: Get the list of tasks:
    ```bash
    curl http://localhost:3000/tasks
    ```
    Verify it returns the task array with status 200.
  - Step 4: Get a task by id:
    ```bash
    curl http://localhost:3000/tasks/1
    ```
    Verify it returns the corresponding task with status 200. Call with a non-existent id to confirm 404.
  - Step 5: Update a task:
    ```bash
    curl -X PATCH http://localhost:3000/tasks/1 -H "Content-Type: application/json" -d "{\"status\":\"done\"}"
    ```
    Verify it returns the updated task with status 200.
  - Step 6: Delete a task:
    ```bash
    curl -X DELETE http://localhost:3000/tasks/1
    ```
    Verify it returns status 204 with an empty body.
- **Expected result:**
  - `POST /tasks` -> 201 Created with task body.
  - `GET /tasks` -> 200 OK with task array.
  - `GET /tasks/:id` -> 200 OK or 404 Not Found.
  - `PATCH /tasks/:id` -> 200 OK or 404 Not Found.
  - `DELETE /tasks/:id` -> 204 No Content or 404 Not Found.
- **Conclusion:** If all endpoints return correct status codes and data, the REST API fully conforms to RESTful standards.

# references
## 0
### alias
NestJS Controllers
### url
https://docs.nestjs.com/controllers
## 1
### alias
NestJS Providers
### url
https://docs.nestjs.com/providers
## 2
### alias
HTTP Status Codes - MDN
### url
https://developer.mozilla.org/en-US/docs/Web/HTTP/Status

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
Correct REST naming and HTTP methods
##### score
10
##### promptText
URLs use plural nouns (`/tasks`), no verbs. `POST` to create, `GET` to read, `PATCH` to update, `DELETE` to remove. Controller uses correct decorators (`@Post`, `@Get`, `@Patch`, `@Delete`).
#### 1
##### title
Correct HTTP status codes
##### score
10
##### promptText
`POST /tasks` returns 201 Created. `GET /tasks` and `GET /tasks/:id` return 200 OK. `PATCH /tasks/:id` returns 200 OK. `DELETE /tasks/:id` returns 204 No Content. Cases where the resource is not found return 404 Not Found via `NotFoundException`.

# difficulty
easy

# score
20
