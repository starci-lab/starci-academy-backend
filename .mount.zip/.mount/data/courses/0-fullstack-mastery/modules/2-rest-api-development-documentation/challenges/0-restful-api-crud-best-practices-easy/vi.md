# title
Xây dựng REST API quản lý Task

# description
Xây dựng REST API quản lý công việc (Task) theo đúng chuẩn RESTful, sử dụng đúng HTTP methods và trả về HTTP status codes chính xác.

# requirements
Tạo `TasksController` và `TasksService` quản lý danh sách task (in-memory array). Endpoint: `POST /tasks` (201 Created), `GET /tasks` (200 OK), `GET /tasks/:id` (200 hoặc 404), `PATCH /tasks/:id` (200 hoặc 404), `DELETE /tasks/:id` (204 No Content hoặc 404). URL phải dùng danh từ số nhiều, không chứa động từ.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install

# steps

## 0
### title
Khởi tạo project NestJS
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới bằng CLI:
    ```bash
    nest new restful-api-crud-best-practices-easy
    ```
  - Bước 2: Di chuyển vào thư mục project và chạy thử:
    ```bash
    cd restful-api-crud-best-practices-easy
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng khởi động thành công trên cổng 3000, terminal hiển thị log NestJS sẵn sàng nhận request.
- **Kết luận:** Môi trường nền đã sẵn sàng để triển khai REST API.

## 1
### title
Tạo TasksModule, TasksService và TasksController
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `TasksModule`, `TasksService`, `TasksController` bằng CLI hoặc thủ công.
  - Bước 2: Trong `TasksService`, khai báo một mảng in-memory lưu danh sách task. Mỗi task có các trường: `id` (string UUID hoặc number tự tăng), `title` (string), `description` (string), `status` (string, mặc định `"open"`).
  - Bước 3: Đăng ký `TasksService` trong `providers` và `TasksController` trong `controllers` của `TasksModule`.
  - Bước 4: Import `TasksModule` vào `AppModule`.
- **Kết quả mong đợi:** Module được NestJS nhận diện, không có lỗi khi khởi động ứng dụng.
- **Kết luận:** Cấu trúc module cơ bản đã sẵn sàng để implement các endpoint CRUD.

## 2
### title
Implement đầy đủ các endpoint CRUD
### body
- **Các bước thực hiện:**
  - Bước 1: Trong `TasksService`, implement các hàm:
    - `create(data)`: thêm task mới vào mảng, trả về task vừa tạo.
    - `findAll()`: trả toàn bộ mảng task.
    - `findOne(id)`: tìm task theo id, ném `NotFoundException` nếu không tìm thấy.
    - `update(id, data)`: cập nhật task theo id, ném `NotFoundException` nếu không tồn tại.
    - `remove(id)`: xóa task theo id, ném `NotFoundException` nếu không tồn tại.
  - Bước 2: Trong `TasksController`, tạo các endpoint với HTTP method và status code chính xác:
    - `@Post()` cho `POST /tasks` kèm `@HttpCode(HttpStatus.CREATED)` -> gọi `create()`.
    - `@Get()` cho `GET /tasks` -> gọi `findAll()`.
    - `@Get(':id')` cho `GET /tasks/:id` -> gọi `findOne()`.
    - `@Patch(':id')` cho `PATCH /tasks/:id` -> gọi `update()`.
    - `@Delete(':id')` cho `DELETE /tasks/:id` kèm `@HttpCode(HttpStatus.NO_CONTENT)` -> gọi `remove()`.
  - Bước 3: Đảm bảo URL dùng dạng từ số nhiều (`/tasks`), không chứa động từ như `/createTask` hay `/deleteTask`.
- **Kết quả mong đợi:** Tất cả 5 endpoint hoạt động đúng với HTTP method và status code tương ứng.
- **Kết luận:** REST API đã tuân thủ đúng chuẩn RESTful về naming convention và HTTP semantics.

## 3
### title
Kiểm thử các endpoint
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Tạo một task mới:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\":\"Learn REST\",\"description\":\"Study RESTful conventions\"}"
    ```
    Xác nhận response trả về status 201 và body chứa task vừa tạo.
  - Bước 3: Lấy danh sách task:
    ```bash
    curl http://localhost:3000/tasks
    ```
    Xác nhận trả về mảng task với status 200.
  - Bước 4: Lấy task theo id:
    ```bash
    curl http://localhost:3000/tasks/1
    ```
    Xác nhận trả về task tương ứng với status 200. Gọi với id không tồn tại xác nhận trả 404.
  - Bước 5: Cập nhật task:
    ```bash
    curl -X PATCH http://localhost:3000/tasks/1 -H "Content-Type: application/json" -d "{\"status\":\"done\"}"
    ```
    Xác nhận trả về task đã cập nhật với status 200.
  - Bước 6: Xóa task:
    ```bash
    curl -X DELETE http://localhost:3000/tasks/1
    ```
    Xác nhận trả về status 204 và body rỗng.
- **Kết quả mong đợi:**
  - `POST /tasks` -> 201 Created với body chứa task.
  - `GET /tasks` -> 200 OK với mảng task.
  - `GET /tasks/:id` -> 200 OK hoặc 404 Not Found.
  - `PATCH /tasks/:id` -> 200 OK hoặc 404 Not Found.
  - `DELETE /tasks/:id` -> 204 No Content hoặc 404 Not Found.
- **Kết luận:** Nếu tất cả endpoint trả đúng status code và dữ liệu, REST API đã tuân thủ đầy đủ chuẩn RESTful.

# references
## 0
### alias
NestJS Controllers
### url
https://docs.nestjs.com/controllers
## 1
### alias
NestJS Providers
### url
https://docs.nestjs.com/providers
## 2
### alias
HTTP Status Codes - MDN
### url
https://developer.mozilla.org/en-US/docs/Web/HTTP/Status

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
Đúng chuẩn REST naming và HTTP methods
##### score
10
##### promptText
URL dùng danh từ số nhiều (`/tasks`), không chứa động từ. `POST` để tạo, `GET` để đọc, `PATCH` để cập nhật, `DELETE` để xóa. Controller sử dụng đúng decorator tương ứng (`@Post`, `@Get`, `@Patch`, `@Delete`).
#### 1
##### title
Đúng HTTP status codes
##### score
10
##### promptText
`POST /tasks` trả 201 Created. `GET /tasks` và `GET /tasks/:id` trả 200 OK. `PATCH /tasks/:id` trả 200 OK. `DELETE /tasks/:id` trả 204 No Content. Các trường hợp không tìm thấy resource trả 404 Not Found thông qua `NotFoundException`.

# difficulty
easy

# score
20
