# title
Tài liệu API tự động với Swagger

# description
Tích hợp Swagger vào dự án NestJS để tự động sinh tài liệu API song từ code, cho phép Frontend thử nghiệm trực tiếp trên giao diện web.

# requirements
Cài `@nestjs/swagger` và cấu hình Swagger UI tại đường dẫn `/docs`. Gắn `@ApiTags()` lên controller. Gắn `@ApiOperation()` và `@ApiResponse()` cho mỗi endpoint. Thêm `@ApiProperty()` với `example` cho mỗi thuộc tính trong DTO. Bật `addBearerAuth()` trong DocumentBuilder.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install
- @nestjs/swagger

# steps

## 0
### title
Khởi tạo project và cài đặt Swagger
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới:
    ```bash
    nest new swagger-api-documentation-easy
    ```
  - Bước 2: Di chuyển vào thư mục project và cài đặt thư viện Swagger:
    ```bash
    cd swagger-api-documentation-easy
    npm install @nestjs/swagger
    ```
  - Bước 3: Chạy thử ứng dụng:
    ```bash
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng khởi động thành công, thư viện `@nestjs/swagger` đã có trong `node_modules`.
- **Kết luận:** Môi trường đã sẵn sàng để cấu hình Swagger.

## 1
### title
Cấu hình Swagger trong main.ts
### body
- **Các bước thực hiện:**
  - Bước 1: Trong `main.ts`, import `SwaggerModule` và `DocumentBuilder` từ `@nestjs/swagger`.
  - Bước 2: Tạo cấu hình Swagger bằng `DocumentBuilder`:
    ```typescript
    const config = new DocumentBuilder()
      .setTitle('Task Management API')
      .setDescription('API tài liệu tự động cho quản lý Task')
      .setVersion('1.0')
      .addBearerAuth()
      .build();
    ```
  - Bước 3: Tạo document và mount Swagger UI:
    ```typescript
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('docs', app, document);
    ```
  - Bước 4: Chạy ứng dụng và truy cập `http://localhost:3000/docs` trên trình duyệt.
- **Kết quả mong đợi:** Giao diện Swagger UI hiển thị tại `/docs` với tiêu đề, mô tả và nút Authorize cho Bearer token.
- **Kết luận:** Swagger đã được tích hợp thành công, sẵn sàng gắn decorator vào controller và DTO.

## 2
### title
Gắn Swagger decorators cho Controller và DTO
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `TasksModule` với `TasksController` và `TasksService` (nếu chưa có). Implement ít nhất 2 endpoint: `POST /tasks` và `GET /tasks`.
  - Bước 2: Tạo `CreateTaskDto` với các trường `title` và `description`. Gắn `@ApiProperty()` với `example` cho mỗi trường:
    ```typescript
    @ApiProperty({ example: 'Fix login bug', description: 'Tiêu đề của task' })
    title: string;

    @ApiProperty({ example: 'Sửa lỗi không đăng nhập được', description: 'Mô tả chi tiết', required: false })
    description?: string;
    ```
  - Bước 3: Gắn `@ApiTags('Tasks')` lên `TasksController`.
  - Bước 4: Gắn `@ApiOperation()` và `@ApiResponse()` cho mỗi endpoint:
    ```typescript
    @Post()
    @ApiOperation({ summary: 'Tạo task mới' })
    @ApiResponse({ status: 201, description: 'Task đã được tạo thành công' })
    @ApiResponse({ status: 400, description: 'Dữ liệu đầu vào không hợp lệ' })
    create(@Body() dto: CreateTaskDto) { ... }
    ```
  - Bước 5: Lặp lại tương tự cho `GET /tasks` với `@ApiOperation()` và `@ApiResponse()` phù hợp.
- **Kết quả mong đợi:** Swagger UI hiển thị đầy đủ các endpoint với tag, mô tả, request body schema (có example), và các response status.
- **Kết luận:** Tài liệu API đã được sinh tự động từ code, Frontend có thể đọc và hiểu API mà không cần tài liệu riêng.

## 3
### title
Kiểm thử Swagger UI và thử nghiệm trực tiếp
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Mở trình duyệt và truy cập `http://localhost:3000/docs`.
  - Bước 3: Kiểm tra giao diện Swagger UI:
    - Xác nhận có nhóm `Tasks` hiển thị các endpoint.
    - Xác nhận mỗi endpoint có mô tả (`summary`) và các response status.
    - Xác nhận `POST /tasks` có schema request body với example từ `@ApiProperty`.
  - Bước 4: Sử dụng nút "Try it out" trên Swagger UI để gửi `POST /tasks` với body mẫu:
    ```json
    {
      "title": "Test from Swagger",
      "description": "Testing API documentation"
    }
    ```
    Xác nhận nhận được response 201 thành công.
  - Bước 5: Sử dụng "Try it out" để gửi `GET /tasks` và xác nhận trả về danh sách task.
  - Bước 6: Nhấn nút "Authorize", nhập một Bearer token bất kỳ và xác nhận nút Authorize hoạt động (dù chưa có logic xác thực).
- **Kết quả mong đợi:**
  - Swagger UI tại `/docs` hiển thị đầy đủ endpoint với tag, summary, response codes.
  - Request body của `POST /tasks` có schema với example values.
  - "Try it out" gửi request thành công và nhận response.
  - Nút Authorize hiển thị và hoạt động.
- **Kết luận:** Nếu Swagger UI hiển thị đầy đủ thông tin và cho phép thử nghiệm API trực tiếp, tài liệu API tự động đã hoàn thành.

# references
## 0
### alias
NestJS OpenAPI (Swagger)
### url
https://docs.nestjs.com/openapi/introduction
## 1
### alias
NestJS OpenAPI Decorators
### url
https://docs.nestjs.com/openapi/decorators
## 2
### alias
NestJS OpenAPI Types and Parameters
### url
https://docs.nestjs.com/openapi/types-and-parameters

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
Swagger cấu hình đúng và decorators đầy đủ
##### score
10
##### promptText
`DocumentBuilder` cấu hình đầy đủ `title`, `description`, `version` và `addBearerAuth()`. `SwaggerModule.setup()` mount tại `/docs`. Controller có `@ApiTags()`. Mỗi endpoint có `@ApiOperation()` và `@ApiResponse()`.
#### 1
##### title
DTO có ApiProperty đầy đủ
##### score
10
##### promptText
Mỗi thuộc tính trong `CreateTaskDto` có `@ApiProperty()` với `example` cụ thể. Swagger UI hiển thị schema request body với example values. Không có thuộc tính nào thiếu decorator `@ApiProperty`.

# difficulty
easy

# score
20
