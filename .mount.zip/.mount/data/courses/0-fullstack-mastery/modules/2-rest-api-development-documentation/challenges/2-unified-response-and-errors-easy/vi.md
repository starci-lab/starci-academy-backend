# title
Đồng bộ Response và Xử lý lỗi toàn cục

# description
Xây dựng TransformInterceptor và AllExceptionsFilter để chuẩn hóa mọi response thành cấu trúc JSON thống nhất cho cả trường hợp thành công và thất bại.

# requirements
TransformInterceptor bọc mọi response thành `{ statusCode, message, data, timestamp }`. AllExceptionsFilter bắt mọi exception và trả `{ statusCode, error, message, timestamp }` mà không lộ stack trace. Cả hai đăng ký toàn cục trong `main.ts`. `GET /tasks` trả response bọc chuẩn. Throw error bất kỳ thì filter bắt và trả JSON an toàn.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install

# steps

## 0
### title
Khởi tạo project và tạo TasksModule cơ bản
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới:
    ```bash
    nest new unified-response-and-errors-easy
    ```
  - Bước 2: Di chuyển vào thư mục project:
    ```bash
    cd unified-response-and-errors-easy
    ```
  - Bước 3: Tạo `TasksModule`, `TasksService`, `TasksController` với endpoint `GET /tasks` trả mảng task mẫu và `GET /tasks/:id` ném `NotFoundException` khi không tìm thấy.
  - Bước 4: Chạy thử ứng dụng:
    ```bash
    npm run start:dev
    ```
- **Kết quả mong đợi:** `GET /tasks` trả mảng task, `GET /tasks/999` trả lỗi 404 mặc định của NestJS.
- **Kết luận:** Module cơ bản đã sẵn sàng, response hiện tại chưa được chuẩn hóa.

## 1
### title
Xây dựng TransformInterceptor
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `transform.interceptor.ts` trong thư mục `common/interceptors/`.
  - Bước 2: Implement class `TransformInterceptor` implement `NestInterceptor`. Trong hàm `intercept()`, sử dụng `pipe(map(data => ...))` để bọc response thành cấu trúc:
    ```typescript
    {
      statusCode: context.switchToHttp().getResponse().statusCode,
      message: 'Success',
      data: data,
      timestamp: new Date().toISOString(),
    }
    ```
  - Bước 3: Đăng ký toàn cục trong `main.ts`:
    ```typescript
    app.useGlobalInterceptors(new TransformInterceptor());
    ```
- **Kết quả mong đợi:** Mọi response thành công đều có cấu trúc `{ statusCode, message, data, timestamp }`.
- **Kết luận:** TransformInterceptor đã chuẩn hóa format response cho trường hợp thành công.

## 2
### title
Xây dựng AllExceptionsFilter
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `all-exceptions.filter.ts` trong thư mục `common/filters/`.
  - Bước 2: Implement class `AllExceptionsFilter` implement `ExceptionFilter` với decorator `@Catch()` (không truyền tham số để bắt mọi loại exception).
  - Bước 3: Trong hàm `catch(exception, host)`:
    - Nếu `exception` là `HttpException`, lấy `statusCode` và `message` từ exception.
    - Nếu không phải `HttpException`, trả `statusCode: 500` và `message: 'Internal Server Error'`.
    - Trả response JSON dạng:
      ```typescript
      {
        statusCode: status,
        error: HttpStatus[status] || 'Internal Server Error',
        message: message,
        timestamp: new Date().toISOString(),
      }
      ```
    - Không bao giờ trả `stack trace` ra ngoài.
  - Bước 4: Đăng ký toàn cục trong `main.ts`:
    ```typescript
    app.useGlobalFilters(new AllExceptionsFilter());
    ```
- **Kết quả mong đợi:** Mọi exception đều trả JSON an toàn với cấu trúc thống nhất, không lộ stack trace.
- **Kết luận:** AllExceptionsFilter đã bảo vệ ứng dụng khỏi việc lộ thông tin nhạy cảm qua error response.

## 3
### title
Kiểm thử response thống nhất
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Gọi endpoint thành công:
    ```bash
    curl http://localhost:3000/tasks
    ```
    Xác nhận response có dạng:
    ```json
    {
      "statusCode": 200,
      "message": "Success",
      "data": [...],
      "timestamp": "2025-..."
    }
    ```
  - Bước 3: Gọi endpoint với id không tồn tại (NotFoundException):
    ```bash
    curl http://localhost:3000/tasks/999
    ```
    Xác nhận response có dạng:
    ```json
    {
      "statusCode": 404,
      "error": "Not Found",
      "message": "...",
      "timestamp": "2025-..."
    }
    ```
  - Bước 4: Tạo một endpoint tạm `GET /tasks/crash` trong controller để throw `new Error('Unexpected')` (error không phải HttpException). Gọi endpoint này:
    ```bash
    curl http://localhost:3000/tasks/crash
    ```
    Xác nhận response trả 500 với JSON an toàn, không chứa stack trace.
- **Kết quả mong đợi:**
  - `GET /tasks` -> `{ statusCode: 200, message: "Success", data: [...], timestamp }`.
  - `GET /tasks/999` -> `{ statusCode: 404, error: "Not Found", message, timestamp }`.
  - `GET /tasks/crash` -> `{ statusCode: 500, error: "Internal Server Error", message, timestamp }` không lộ stack trace.
- **Kết luận:** Nếu mọi response (cả thành công và thất bại) đều có cấu trúc JSON thống nhất và không lộ thông tin nhạy cảm, hệ thống đã đạt yêu cầu.

# references
## 0
### alias
NestJS Interceptors
### url
https://docs.nestjs.com/interceptors
## 1
### alias
NestJS Exception Filters
### url
https://docs.nestjs.com/exception-filters
## 2
### alias
NestJS First Steps
### url
https://docs.nestjs.com/first-steps

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
Interceptor bọc response đúng format
##### score
10
##### promptText
`TransformInterceptor` được đăng ký toàn cục và bọc mọi response thành công thành `{ statusCode, message, data, timestamp }`. Response từ `GET /tasks` phải có cấu trúc bọc chuẩn, không trả data thô.
#### 1
##### title
Filter bắt mọi exception an toàn
##### score
10
##### promptText
`AllExceptionsFilter` được đăng ký toàn cục, bắt cả `HttpException` và non-HTTP exception. Response lỗi có cấu trúc `{ statusCode, error, message, timestamp }`. Không lộ stack trace trong bất kỳ trường hợp nào.

# difficulty
easy

# score
20
