# title
Automatic API Documentation with Swagger

# description
Integrate Swagger into a NestJS project to automatically generate live API documentation from code, allowing Frontend to test directly on the web interface.

# requirements
Install `@nestjs/swagger` and configure Swagger UI at the `/docs` path. Apply `@ApiTags()` to the controller. Apply `@ApiOperation()` and `@ApiResponse()` to each endpoint. Add `@ApiProperty()` with `example` to every property in the DTO. Enable `addBearerAuth()` in DocumentBuilder.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install
- @nestjs/swagger

# steps

## 0
### title
Initialize the project and install Swagger
### body
- **Steps to follow:**
  - Step 1: Create a new project:
    ```bash
    nest new swagger-api-documentation-easy
    ```
  - Step 2: Navigate to the project directory and install the Swagger library:
    ```bash
    cd swagger-api-documentation-easy
    npm install @nestjs/swagger
    ```
  - Step 3: Start the application:
    ```bash
    npm run start:dev
    ```
- **Expected result:** The application starts successfully, `@nestjs/swagger` is installed in `node_modules`.
- **Conclusion:** The environment is ready for configuring Swagger.

## 1
### title
Configure Swagger in main.ts
### body
- **Steps to follow:**
  - Step 1: In `main.ts`, import `SwaggerModule` and `DocumentBuilder` from `@nestjs/swagger`.
  - Step 2: Create the Swagger configuration using `DocumentBuilder`:
    ```typescript
    const config = new DocumentBuilder()
      .setTitle('Task Management API')
      .setDescription('Auto-generated API documentation for Task management')
      .setVersion('1.0')
      .addBearerAuth()
      .build();
    ```
  - Step 3: Create the document and mount Swagger UI:
    ```typescript
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('docs', app, document);
    ```
  - Step 4: Start the application and navigate to `http://localhost:3000/docs` in the browser.
- **Expected result:** Swagger UI is displayed at `/docs` with the title, description, and an Authorize button for Bearer token.
- **Conclusion:** Swagger has been successfully integrated, ready to attach decorators to controllers and DTOs.

## 2
### title
Apply Swagger decorators to Controller and DTO
### body
- **Steps to follow:**
  - Step 1: Create `TasksModule` with `TasksController` and `TasksService` (if not already created). Implement at least 2 endpoints: `POST /tasks` and `GET /tasks`.
  - Step 2: Create `CreateTaskDto` with fields `title` and `description`. Apply `@ApiProperty()` with `example` to each field:
    ```typescript
    @ApiProperty({ example: 'Fix login bug', description: 'Title of the task' })
    title: string;

    @ApiProperty({ example: 'Fix the login failure issue', description: 'Detailed description', required: false })
    description?: string;
    ```
  - Step 3: Apply `@ApiTags('Tasks')` to `TasksController`.
  - Step 4: Apply `@ApiOperation()` and `@ApiResponse()` to each endpoint:
    ```typescript
    @Post()
    @ApiOperation({ summary: 'Create a new task' })
    @ApiResponse({ status: 201, description: 'Task created successfully' })
    @ApiResponse({ status: 400, description: 'Invalid input data' })
    create(@Body() dto: CreateTaskDto) { ... }
    ```
  - Step 5: Repeat similarly for `GET /tasks` with appropriate `@ApiOperation()` and `@ApiResponse()`.
- **Expected result:** Swagger UI displays all endpoints with tags, descriptions, request body schema (with examples), and response statuses.
- **Conclusion:** API documentation is automatically generated from code, Frontend can read and understand the API without separate documentation.

## 3
### title
Test Swagger UI and try live requests
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Open a browser and navigate to `http://localhost:3000/docs`.
  - Step 3: Verify the Swagger UI interface:
    - Confirm the `Tasks` group displays the endpoints.
    - Confirm each endpoint has a summary and response statuses.
    - Confirm `POST /tasks` has a request body schema with examples from `@ApiProperty`.
  - Step 4: Use the "Try it out" button on Swagger UI to send `POST /tasks` with a sample body:
    ```json
    {
      "title": "Test from Swagger",
      "description": "Testing API documentation"
    }
    ```
    Verify you receive a 201 success response.
  - Step 5: Use "Try it out" to send `GET /tasks` and verify it returns the list of tasks.
  - Step 6: Click the "Authorize" button, enter any Bearer token, and confirm the Authorize button works (even without actual authentication logic).
- **Expected result:**
  - Swagger UI at `/docs` displays all endpoints with tags, summaries, and response codes.
  - Request body of `POST /tasks` has a schema with example values.
  - "Try it out" sends requests successfully and receives responses.
  - The Authorize button is displayed and functional.
- **Conclusion:** If Swagger UI displays complete information and allows testing the API directly, the automatic API documentation is complete.

# references
## 0
### alias
NestJS OpenAPI (Swagger)
### url
https://docs.nestjs.com/openapi/introduction
## 1
### alias
NestJS OpenAPI Decorators
### url
https://docs.nestjs.com/openapi/decorators
## 2
### alias
NestJS OpenAPI Types and Parameters
### url
https://docs.nestjs.com/openapi/types-and-parameters

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
Swagger config and decorators complete
##### score
10
##### promptText
`DocumentBuilder` is configured with `title`, `description`, `version`, and `addBearerAuth()`. `SwaggerModule.setup()` mounts at `/docs`. Controller has `@ApiTags()`. Each endpoint has `@ApiOperation()` and `@ApiResponse()`.
#### 1
##### title
DTO has complete ApiProperty
##### score
10
##### promptText
Every property in `CreateTaskDto` has `@ApiProperty()` with a specific `example`. Swagger UI displays the request body schema with example values. No property is missing the `@ApiProperty` decorator.

# difficulty
easy

# score
20
