# title
Protect API with DTO and ValidationPipe

# description
Implement an input data protection layer for a REST API using DTOs combined with ValidationPipe, preventing junk data and missing required fields.

# requirements
Create `CreateTaskDto` with fields: `title` (`@IsString`, `@MinLength(3)`), `description` (`@IsString`, `@IsOptional`), `priority` (`@IsEnum(['low','medium','high'])`). Enable `ValidationPipe` globally with `whitelist: true` and `forbidNonWhitelisted: true`. `POST /tasks` with a body missing `title` returns 400 Bad Request. `POST /tasks` with an unknown field `role: "admin"` is rejected.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install
- class-validator
- class-transformer

# steps

## 0
### title
Initialize the project and install dependencies
### body
- **Steps to follow:**
  - Step 1: Create a new project:
    ```bash
    nest new dtos-and-validation-easy
    ```
  - Step 2: Navigate to the project directory and install required libraries:
    ```bash
    cd dtos-and-validation-easy
    npm install class-validator class-transformer
    ```
  - Step 3: Start the application:
    ```bash
    npm run start:dev
    ```
- **Expected result:** The application starts successfully, `class-validator` and `class-transformer` are installed in `node_modules`.
- **Conclusion:** The environment is ready for implementing DTOs and validation.

## 1
### title
Create TasksModule and basic POST /tasks endpoint
### body
- **Steps to follow:**
  - Step 1: Create `TasksModule`, `TasksService`, `TasksController` using the CLI or manually.
  - Step 2: In `TasksService`, declare an in-memory array and implement a `create(data)` method that adds a new task.
  - Step 3: In `TasksController`, create a `@Post()` endpoint that accepts a body and calls `TasksService.create()`.
  - Step 4: Import `TasksModule` into `AppModule`.
- **Expected result:** `POST /tasks` with a valid body creates a new task and returns 201.
- **Conclusion:** The basic endpoint is working, ready to attach DTO and validation.

## 2
### title
Create CreateTaskDto with class-validator decorators
### body
- **Steps to follow:**
  - Step 1: Create file `create-task.dto.ts` in the `tasks/dto/` directory.
  - Step 2: Declare class `CreateTaskDto` with fields and decorators:
    - `title`: apply `@IsString()` and `@MinLength(3)`.
    - `description`: apply `@IsString()` and `@IsOptional()`.
    - `priority`: apply `@IsEnum(['low', 'medium', 'high'])`.
  - Step 3: In `TasksController`, change the body parameter type from `any` to `CreateTaskDto`:
    ```typescript
    @Post()
    create(@Body() createTaskDto: CreateTaskDto) { ... }
    ```
  - Step 4: Enable `ValidationPipe` globally in `main.ts`:
    ```typescript
    app.useGlobalPipes(new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
    }));
    ```
- **Expected result:** `POST /tasks` with a body missing `title` or `title` shorter than 3 characters returns 400 Bad Request with a specific error message.
- **Conclusion:** DTO and ValidationPipe now protect the endpoint from invalid data.

## 3
### title
Test validation and whitelist behavior
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Send a valid request:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\":\"Fix bug\",\"priority\":\"high\"}"
    ```
    Verify it returns 201 with the created task.
  - Step 3: Send a request missing `title`:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"priority\":\"low\"}"
    ```
    Verify it returns 400 Bad Request with a message indicating `title` is required.
  - Step 4: Send a request with `title` too short:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\":\"AB\",\"priority\":\"low\"}"
    ```
    Verify it returns 400 with a message indicating `title` must have at least 3 characters.
  - Step 5: Send a request with an unknown field `role`:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\":\"Fix bug\",\"priority\":\"high\",\"role\":\"admin\"}"
    ```
    Verify it returns 400 with a message indicating `role` is not allowed (`forbidNonWhitelisted`).
  - Step 6: Send a request with invalid `priority` value:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\":\"Fix bug\",\"priority\":\"urgent\"}"
    ```
    Verify it returns 400 with a message indicating `priority` must be a valid enum value.
- **Expected result:**
  - Valid body -> 201 Created.
  - Missing `title` -> 400 Bad Request.
  - `title` < 3 characters -> 400 Bad Request.
  - Unknown field `role` -> 400 Bad Request (forbidNonWhitelisted).
  - Invalid `priority` enum -> 400 Bad Request.
- **Conclusion:** If all cases return the correct status code and appropriate error messages, DTO and ValidationPipe are working correctly.

# references
## 0
### alias
NestJS Validation
### url
https://docs.nestjs.com/techniques/validation
## 1
### alias
class-validator GitHub
### url
https://github.com/typestack/class-validator
## 2
### alias
NestJS Pipes
### url
https://docs.nestjs.com/pipes

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
DTO decorators correct
##### score
10
##### promptText
`CreateTaskDto` has all required fields: `title` (`@IsString`, `@MinLength(3)`), `description` (`@IsString`, `@IsOptional`), `priority` (`@IsEnum`). Controller uses `CreateTaskDto` as the type for `@Body()` parameter.
#### 1
##### title
ValidationPipe configured correctly
##### score
10
##### promptText
`ValidationPipe` is enabled globally in `main.ts` with `whitelist: true` and `forbidNonWhitelisted: true`. Body missing required fields returns 400. Body containing unknown fields is rejected with a clear error.

# difficulty
easy

# score
20
