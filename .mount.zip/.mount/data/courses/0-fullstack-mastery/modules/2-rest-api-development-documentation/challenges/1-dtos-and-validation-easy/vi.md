# title
Bảo vệ API bằng DTO và ValidationPipe

# description
Triển khai lớp bảo vệ dữ liệu đầu vào cho REST API bằng DTO kết hợp ValidationPipe, ngăn chặn dữ liệu rác và dữ liệu thiếu trường bắt buộc.

# requirements
Tạo `CreateTaskDto` với các trường: `title` (`@IsString`, `@MinLength(3)`), `description` (`@IsString`, `@IsOptional`), `priority` (`@IsEnum(['low','medium','high'])`). Kích hoạt `ValidationPipe` toàn cục với `whitelist: true` và `forbidNonWhitelisted: true`. `POST /tasks` với body thiếu `title` trả 400 Bad Request. `POST /tasks` với field lạ `role: "admin"` bị reject.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install
- class-validator
- class-transformer

# steps

## 0
### title
Khởi tạo project và cài đặt thư viện
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới:
    ```bash
    nest new dtos-and-validation-easy
    ```
  - Bước 2: Di chuyển vào thư mục project và cài đặt các thư viện cần thiết:
    ```bash
    cd dtos-and-validation-easy
    npm install class-validator class-transformer
    ```
  - Bước 3: Chạy thử ứng dụng:
    ```bash
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng khởi động thành công, các thư viện `class-validator` và `class-transformer` đã có trong `node_modules`.
- **Kết luận:** Môi trường đã sẵn sàng để triển khai DTO và validation.

## 1
### title
Tạo TasksModule và endpoint POST /tasks cơ bản
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `TasksModule`, `TasksService`, `TasksController` bằng CLI hoặc thủ công.
  - Bước 2: Trong `TasksService`, khai báo mảng in-memory và implement hàm `create(data)` thêm task mới vào mảng.
  - Bước 3: Trong `TasksController`, tạo endpoint `@Post()` nhận body và gọi `TasksService.create()`.
  - Bước 4: Import `TasksModule` vào `AppModule`.
- **Kết quả mong đợi:** `POST /tasks` với body hợp lệ tạo được task mới và trả về 201.
- **Kết luận:** Endpoint cơ bản đã hoạt động, sẵn sàng gắn DTO và validation.

## 2
### title
Tạo CreateTaskDto với class-validator decorators
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `create-task.dto.ts` trong thư mục `tasks/dto/`.
  - Bước 2: Khai báo class `CreateTaskDto` với các trường và decorator:
    - `title`: gắn `@IsString()` và `@MinLength(3)`.
    - `description`: gắn `@IsString()` và `@IsOptional()`.
    - `priority`: gắn `@IsEnum(['low', 'medium', 'high'])`.
  - Bước 3: Trong `TasksController`, thay kiểu tham số body từ `any` thành `CreateTaskDto`:
    ```typescript
    @Post()
    create(@Body() createTaskDto: CreateTaskDto) { ... }
    ```
  - Bước 4: Kích hoạt `ValidationPipe` toàn cục trong `main.ts`:
    ```typescript
    app.useGlobalPipes(new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
    }));
    ```
- **Kết quả mong đợi:** `POST /tasks` với body thiếu `title` hoặc `title` ít hơn 3 ký tự sẽ trả 400 Bad Request với thông báo lỗi cụ thể.
- **Kết luận:** DTO và ValidationPipe đã bảo vệ endpoint khỏi dữ liệu không hợp lệ.

## 3
### title
Kiểm thử validation và whitelist
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Gửi request hợp lệ:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\":\"Fix bug\",\"priority\":\"high\"}"
    ```
    Xác nhận trả về 201 với task vừa tạo.
  - Bước 3: Gửi request thiếu trường `title`:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"priority\":\"low\"}"
    ```
    Xác nhận trả về 400 Bad Request với message chỉ rõ `title` là bắt buộc.
  - Bước 4: Gửi request với `title` quá ngắn:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\":\"AB\",\"priority\":\"low\"}"
    ```
    Xác nhận trả về 400 với message chỉ rõ `title` phải có ít nhất 3 ký tự.
  - Bước 5: Gửi request với field lạ `role`:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\":\"Fix bug\",\"priority\":\"high\",\"role\":\"admin\"}"
    ```
    Xác nhận trả về 400 với message chỉ rõ `role` không được phép (`forbidNonWhitelisted`).
  - Bước 6: Gửi request với `priority` không nằm trong enum:
    ```bash
    curl -X POST http://localhost:3000/tasks -H "Content-Type: application/json" -d "{\"title\":\"Fix bug\",\"priority\":\"urgent\"}"
    ```
    Xác nhận trả về 400 với message chỉ rõ `priority` phải là giá trị enum hợp lệ.
- **Kết quả mong đợi:**
  - Body hợp lệ -> 201 Created.
  - Thiếu `title` -> 400 Bad Request.
  - `title` < 3 ký tự -> 400 Bad Request.
  - Field lạ `role` -> 400 Bad Request (forbidNonWhitelisted).
  - `priority` sai enum -> 400 Bad Request.
- **Kết luận:** Nếu tất cả trường hợp đều trả đúng status code và thông báo lỗi phù hợp, DTO và ValidationPipe đã hoạt động chính xác.

# references
## 0
### alias
NestJS Validation
### url
https://docs.nestjs.com/techniques/validation
## 1
### alias
class-validator GitHub
### url
https://github.com/typestack/class-validator
## 2
### alias
NestJS Pipes
### url
https://docs.nestjs.com/pipes

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
DTO decorators chính xác
##### score
10
##### promptText
`CreateTaskDto` có đầy đủ các trường `title` (`@IsString`, `@MinLength(3)`), `description` (`@IsString`, `@IsOptional`), `priority` (`@IsEnum`). Controller sử dụng đúng kiểu `CreateTaskDto` cho tham số `@Body()`.
#### 1
##### title
ValidationPipe cấu hình đúng
##### score
10
##### promptText
`ValidationPipe` được kích hoạt toàn cục trong `main.ts` với `whitelist: true` và `forbidNonWhitelisted: true`. Body thiếu trường bắt buộc trả 400. Body chứa field lạ bị reject với lỗi rõ ràng.

# difficulty
easy

# score
20
