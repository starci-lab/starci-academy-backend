# title
Viết tài liệu API với Swagger OpenAPI

# description
Cấu hình tự động sinh tài liệu API sống, tương tác trực quan bằng Swagger và Scalar ngay từ trong code NestJS, thay thế hoàn toàn cách viết tài liệu thủ công.

# body

## I. Lời mở đầu

Viết xong API mà không có tài liệu đi kèm thì đội ngũ **Frontend** và **Mobile** sẽ không biết gọi đường dẫn nào, truyền tham số gì, hay kỳ vọng response như thế nào. Cách truyền thống như chia sẻ file **Postman** hay viết **Excel** thường nhanh chóng bị lỗi thời khi code thay đổi. **Swagger** (tiêu chuẩn **OpenAPI**) giải quyết vấn đề này bằng cách đọc trực tiếp code và tự động tạo ra một trang tài liệu web **sống**, luôn đồng bộ với trạng thái hiện tại của API.

## II. Nội dung chính

### 1. Giá trị của tài liệu API sống

Tài liệu API truyền thống (Word, Excel, Postman collection) có một điểm yếu chí mạng: chúng bị **lỗi thời** ngay khi developer sửa code mà quên cập nhật file. **Swagger** loại bỏ vấn đề này bằng cách sinh tài liệu tự động từ chính source code, đảm bảo tài liệu luôn phản ánh đúng các endpoint, tham số, và response đang hoạt động.

- **Ví dụ:** Khi bạn thêm một trường mới vào DTO và gắn `@ApiProperty()`, giao diện Swagger tự động hiển thị trường đó trong phần request body mà không cần chỉnh sửa bất kỳ file tài liệu nào.

### 2. Cấu hình Swagger trong main.ts

Để kích hoạt Swagger, bạn cài thư viện `@nestjs/swagger` và cấu hình trong file `main.ts` trước khi gọi `app.listen()`.

- **Ví dụ:** Cấu hình cơ bản:

```typescript
const config = new DocumentBuilder()
  .setTitle('StarCi Academy Backend')
  .setDescription('API documentation')
  .setVersion('1.0')
  .addBearerAuth()
  .build();

const document = SwaggerModule.createDocument(app, config);
SwaggerModule.setup('swagger', app, document);
```

Sau khi cấu hình, truy cập `http://localhost:3000/swagger` để xem giao diện tài liệu Swagger classic. Dự án này cũng tích hợp **Scalar** tại đường dẫn `/scalar` với giao diện hiện đại hơn.

### 3. Swagger Decorators

Để giao diện tài liệu thêm chi tiết và hữu ích, bạn sử dụng các **decorator** của Swagger trong Controller. Mỗi decorator bổ sung thông tin mô tả cho từng endpoint, giúp Frontend hiểu rõ chức năng mà không cần đọc code.

- **Ví dụ:** Sử dụng decorator trong Controller:

```typescript
@ApiTags('Cats Module')
@Controller('cats')
export class CatsController {

  @Get()
  @ApiOperation({ summary: 'Retrieve all cats' })
  @ApiResponse({ status: 200, description: 'List of cats returned successfully' })
  findAll() { return this.catsService.findAll(); }

  @Post()
  @ApiOperation({ summary: 'Create a new cat' })
  @ApiResponse({ status: 201, description: 'Cat created successfully' })
  @ApiResponse({ status: 400, description: 'Invalid payload' })
  create(@Body() dto: CreateCatDto) { return this.catsService.create(dto); }
}
```

### 4. Hiển thị DTO với @ApiProperty()

**TypeScript** bị xóa cấu trúc kiểu khi build ra **JavaScript**, nên Swagger không thể tự động nhận biết các trường bên trong DTO. Bạn phải sử dụng `@ApiProperty()` để khai báo từng thuộc tính, giúp Swagger hiển thị đầy đủ thông tin và tạo sẵn mock data trên giao diện.

- **Ví dụ:** Khai báo DTO với ApiProperty:

```typescript
export class CreateCatDto {
  @ApiProperty({ example: 'Persian', description: 'Breed of the cat' })
  @IsString()
  breed: string;

  @ApiProperty({ example: 2, description: 'Age in years' })
  @IsNumber()
  age: number;
}
```

Trên giao diện Swagger, trường `breed` và `age` sẽ hiển thị đầy đủ với dữ liệu mẫu, cho phép Frontend thử nghiệm trực tiếp mà không cần tự điền dữ liệu.

## III. Thực hành

> **Source code:** [Swagger API Documentation](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/swagger-api-documentation)

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
  - Bước 1: Clone repository và di chuyển vào thư mục dự án.
  - Bước 2: Cài đặt các dependencies:

```bash
npm install
```

  - Bước 3: Khởi chạy server ở chế độ development:

```bash
npm run start:dev
```

- **Kết quả mong đợi:** Server khởi động thành công tại `http://localhost:3000`. Hai đường dẫn tài liệu sẵn sàng: `/scalar` (giao diện hiện đại) và `/swagger` (giao diện classic).
- **Kết luận:** Môi trường đã sẵn sàng để khám phá giao diện tài liệu API tự động.

### 2. Kiến trúc (Architecture)

- **Các bước thực hiện:**
  - Bước 1: Mở file `src/main.ts` để xem cấu hình **DocumentBuilder** và **SwaggerModule.setup()** đăng ký Swagger toàn cục.
  - Bước 2: Mở file Controller (ví dụ `src/cats/cats.controller.ts`) để xem các decorator **@ApiTags()**, **@ApiOperation()**, **@ApiResponse()** được sử dụng.
  - Bước 3: Mở file DTO (ví dụ `src/cats/dto/create-cat.dto.ts`) để xem **@ApiProperty()** khai báo từng thuộc tính.
  - Bước 4: Kiểm tra các file **TransformInterceptor** và **AllExceptionsFilter** được đăng ký toàn cục (tương tự bài unified-response-and-errors).

- **Kết quả mong đợi:** Swagger được cấu hình toàn cục trong `main.ts`. Controller sử dụng decorator để mô tả endpoint. DTO sử dụng `@ApiProperty()` để khai báo thuộc tính.
- **Kết luận:** Tài liệu API được sinh tự động từ chính các decorator trong code, không cần bất kỳ file tài liệu nào bên ngoài.

### 3. Luồng hệ thống (System Flow)

- **Các bước thực hiện:**
  - Bước 1: Khi server khởi động, **SwaggerModule** quét toàn bộ các Controller và DTO đã đăng ký.
  - Bước 2: Module đọc các decorator **@ApiTags()**, **@ApiOperation()**, **@ApiResponse()**, **@ApiProperty()** để xây dựng tài liệu OpenAPI spec.
  - Bước 3: Tài liệu được phục vụ tại đường dẫn `/swagger` (giao diện Swagger UI classic) và `/scalar` (giao diện Scalar hiện đại).
  - Bước 4: Frontend hoặc QA truy cập giao diện web để xem và thử nghiệm trực tiếp các endpoint.

- **Kết quả mong đợi:** Giao diện tài liệu hiển thị đầy đủ các endpoint, tham số, response schema, và cho phép gửi request trực tiếp.
- **Kết luận:** Tài liệu API luôn đồng bộ với code hiện tại, loại bỏ hoàn toàn nguy cơ tài liệu bị lỗi thời.

### 4. Thử nghiệm (Try it out)

- **Các bước thực hiện:**

**Nhánh thành công (Success Path):**

  - Bước 1: Mở trình duyệt và truy cập `http://localhost:3000/scalar` để xem giao diện tài liệu hiện đại.
  - Bước 2: Tìm endpoint `GET /cats` trong danh sách.
  - Bước 3: Gửi request trực tiếp từ giao diện hoặc dùng curl:

```bash
curl http://localhost:3000/cats
```

  - Bước 4: Kiểm tra response trả về cấu trúc JSON chuẩn với `statusCode`, `message`, `data`, và `timestamp` (nhờ **TransformInterceptor**).

**Nhánh thất bại (Failure Path):**

  - Bước 1: Tìm endpoint `GET /cats/error-demo` trong giao diện tài liệu.
  - Bước 2: Gửi request để kích hoạt lỗi:

```bash
curl http://localhost:3000/cats/error-demo
```

  - Bước 3: Kiểm tra response trả về cấu trúc lỗi JSON chuẩn với `statusCode`, `error`, `message`, và `timestamp` (nhờ **AllExceptionsFilter**).

- **Kết quả mong đợi:**
  - Nhánh thành công: Giao diện tài liệu hiển thị đúng các endpoint. Request `GET /cats` trả về response thành công theo cấu trúc chuẩn.
  - Nhánh thất bại: Request `GET /cats/error-demo` trả về response lỗi theo cấu trúc chuẩn.

- **Kết luận:** **Swagger** và **Scalar** cung cấp giao diện trực quan để khám phá và thử nghiệm API, kết hợp với **TransformInterceptor** và **AllExceptionsFilter** đảm bảo mọi response đều nhất quán.

## IV. Kết luận

**Swagger** biến việc viết tài liệu API từ một công việc thủ công nhàm chán thành một quy trình **tự động hóa hoàn toàn**. Khi kết hợp với **Scalar**, đội ngũ có hai giao diện tài liệu để lựa chọn. Các decorator như **@ApiProperty()**, **@ApiOperation()**, **@ApiResponse()** đảm bảo tài liệu luôn chính xác và đồng bộ với code.

**Kết luận:** Tài liệu API sống là một phần không thể thiếu của mọi hệ thống **production-ready** — nó không chỉ phục vụ Frontend mà còn là công cụ giao tiếp giữa toàn bộ đội ngũ kỹ thuật.

# references
## 0
### alias
OpenAPI Setup
### url
https://docs.nestjs.com/openapi/introduction

# minutesRead
20
