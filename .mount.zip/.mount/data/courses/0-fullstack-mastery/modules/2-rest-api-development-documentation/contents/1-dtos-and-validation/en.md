# title
DTOs and Data Validation

# description
Protect your application from bad data. Learn to construct Data Transfer Objects (DTOs) and systematically enforce validation rules using ValidationPipe in NestJS.

# body

## I. Introduction

When building APIs, a common mistake is trusting data from the Client. Many developers use the `any` type to receive request body data, inadvertently opening the door for **garbage data**, **malicious payloads**, or **missing required fields** to flood the system. **DTO** (Data Transfer Object) combined with **ValidationPipe** serves as the mandatory defense shield, ensuring only valid data proceeds deeper into the **Service** and **Database** layers.

## II. Core Concepts

### 1. What is a DTO

A **DTO** (Data Transfer Object) is a class that explicitly defines the structure of data the Client is allowed to send to the server. Instead of using the vague and dangerous `any` type, you declare each field and its type precisely.

- **Example:** Comparing unsafe data handling versus using a DTO:

```typescript
// Dangerous: no idea what body contains
@Post()
create(@Body() body: any) {}

// Safe: data is constrained by CreateUserDto
@Post()
create(@Body() createUserDto: CreateUserDto) {}
```

### 2. Using class-validator and class-transformer

**NestJS** leverages two libraries — **class-validator** and **class-transformer** — to attach validation rules directly to each property of a DTO. Each decorator corresponds to a specific constraint such as email format, minimum length, or data type.

- **Example:** Declaring a DTO with validation decorators:

```typescript
import { IsEmail, IsString, MinLength } from 'class-validator';

export class CreateUserDto {
  @IsEmail()
  email: string;

  @IsString()
  @MinLength(8, { message: 'Password is too short' })
  password: string;
}
```

With this configuration, if the Client sends an email missing the `@` symbol or a password shorter than **8 characters**, the system automatically rejects the request.

### 3. Activating ValidationPipe Globally

For the validation decorators to take effect, you must register the **ValidationPipe** at the global level in `main.ts`. This pipe acts as the front gate of the application, inspecting every request before it reaches the Controller.

- **Example:** Configuring ValidationPipe with security options:

```typescript
app.useGlobalPipes(new ValidationPipe({
  whitelist: true,
  forbidNonWhitelisted: true,
  transform: true,
}));
```

  - **whitelist: true** — Automatically strips fields not defined in the DTO. If the Client sends `{ "role": "admin" }` but the DTO does not declare a `role` field, that field is silently removed.
  - **forbidNonWhitelisted: true** — Instead of silently stripping, the system returns `400 Bad Request` when extra fields are detected.
  - **transform: true** — Automatically converts data types, for example transforming the param `"123"` from string to number.

### 4. Overall Data Processing Flow

The entire data protection process occurs before any business logic executes. **ValidationPipe** acts as an automated checkpoint, ensuring every piece of data entering the system is valid.

- **Example:** The sequential processing flow: **Client** sends request -> **ValidationPipe** validates and filters data -> **Controller** receives validated data -> **Service** processes business logic. If the data is invalid, **ValidationPipe** immediately returns a `400 Bad Request` error without the Controller ever being affected.

## III. Practice

> **Source code:** [DTOs and Validation](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/dtos-and-validation)

### 1. Setup & Run

- **Execution Steps:**
  - Step 1: Clone the repository and navigate into the project directory.
  - Step 2: Install dependencies:

```bash
npm install
```

  - Step 3: Start the server in development mode:

```bash
npm run start:dev
```

- **Expected Results:** The server starts successfully at `http://localhost:3000`. The terminal displays logs confirming the application is ready.
- **Conclusion:** The environment is ready for testing data validation with **DTO** and **ValidationPipe**.

### 2. Architecture

- **Execution Steps:**
  - Step 1: Open the DTO file (e.g., `src/users/dto/create-user.dto.ts`) to examine the **@IsEmail()**, **@IsString()**, **@MinLength()** decorators attached to each property.
  - Step 2: Open `src/main.ts` to review the global **ValidationPipe** configuration with `whitelist`, `forbidNonWhitelisted`, and `transform` options.
  - Step 3: Open the Controller file to see how the DTO is used as the type for the `@Body()` parameter.

- **Expected Results:** The DTO defines the data structure with validation constraints. The **ValidationPipe** is registered globally to automatically inspect every request.
- **Conclusion:** Data protection occurs at the **Pipe** layer, completely separated from business logic in the **Service**.

### 3. System Flow

- **Execution Steps:**
  - Step 1: The Client sends **POST /users** with a JSON body containing `email` and `password` fields.
  - Step 2: **ValidationPipe** compares the data against the DTO, checking each field according to the declared decorators.
  - Step 3: If the data is valid, the request proceeds to the **Controller**.
  - Step 4: The **Controller** calls the **Service** to process the User creation logic.
  - Step 5: If the data is invalid, **ValidationPipe** automatically returns `400 Bad Request` with a detailed list of errors.

- **Expected Results:** Valid data continues into the system; invalid data is blocked at the Pipe layer.
- **Conclusion:** **ValidationPipe** acts as an automatic filter, protecting the entire system without requiring manual validation code in the Controller.

### 4. Try it out

- **Execution Steps:**

**Success Path:**

  - Step 1: Send a request to create a User with valid data:

```bash
curl -X POST http://localhost:3000/users -H "Content-Type: application/json" -d "{\"email\": \"test@example.com\", \"password\": \"securepass123\"}"
```

  - Step 2: Verify the response returns `201 Created` with the newly created User data.

**Failure Path:**

  - Step 1: Send a request with an invalid email and a password that is too short:

```bash
curl -X POST http://localhost:3000/users -H "Content-Type: application/json" -d "{\"email\": \"not-an-email\", \"password\": \"123\"}"
```

  - Step 2: Verify the response returns `400 Bad Request` with a message array detailing each validation error (invalid email, password too short).

  - Step 3: Send a request with an empty body:

```bash
curl -X POST http://localhost:3000/users -H "Content-Type: application/json" -d "{}"
```

  - Step 4: Verify the response returns `400 Bad Request` because all required fields are missing.

- **Expected Results:**
  - Success Path: The server accepts the data and returns `201 Created`.
  - Failure Path: The server rejects invalid data and returns `400 Bad Request` with specific error details.

- **Conclusion:** **ValidationPipe** automatically protects the application from invalid data without requiring any validation code in the Controller or Service.

## IV. Conclusion

**DTO** and **ValidationPipe** are two indispensable tools in any serious **NestJS** application. The DTO defines the **data blueprint**, while ValidationPipe ensures **every piece of data conforms to that blueprint** before entering the system. This combination completely eliminates the risk of garbage data, malicious payloads, and logic errors caused by incorrect data.

**Conclusion:** Protecting input data is not optional — it is a mandatory responsibility of every Backend engineer building a **production-ready** system.

# references
## 0
### alias
Validation Techniques
### url
https://docs.nestjs.com/techniques/validation

# minutesRead
20
