# title
Unified Responses and Exception Filters

# description
Build an automatic mechanism that wraps all return data into a unified JSON structure, while handling every system error safely and consistently in NestJS.

# body

## I. Introduction

When working in a team, each Backend developer has their own style of returning data: one returns an array `[]`, another returns an object `{ data: [] }`, and yet another returns a string `"OK"`. The result is that **Frontend** must write specialized handlers for each endpoint. The problem worsens when errors occur — some endpoints return default HTML pages, others return unstructured JSON. **TransformInterceptor** and **AllExceptionsFilter** are two tools that establish a **single JSON contract** for the entire system.

## II. Core Concepts

### 1. The Problem of Inconsistent APIs

When multiple developers build APIs without a shared standard, the **Frontend** team faces many different response formats. This leads to complex processing code, difficult maintenance, and bugs during integration.

- **Example:** The endpoint `/users` returns `[{...}]`, but the endpoint `/posts` returns `{ data: [{...}], total: 10 }`. Frontend must write separate logic for each endpoint instead of using one unified handler.

### 2. TransformInterceptor — Unifying Success Responses

The **TransformInterceptor** is a **NestJS Interceptor** placed at the Controller's output gate, automatically wrapping every return value into a unified JSON structure containing `statusCode`, `message`, `data`, and `timestamp`.

- **Example:** The TransformInterceptor structure:

```typescript
@Injectable()
export class TransformInterceptor<T> implements NestInterceptor<T, any> {
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const ctx = context.switchToHttp();
    const statusCode = ctx.getResponse().statusCode;

    return next.handle().pipe(
      map(data => ({
        statusCode: statusCode,
        message: 'Success',
        data: data || null,
        timestamp: new Date().toISOString(),
      })),
    );
  }
}
```

Even if a Controller only returns the string `"OK"`, the Client still receives `{ "statusCode": 200, "message": "Success", "data": "OK", "timestamp": "..." }`.

### 3. AllExceptionsFilter — Collecting and Unifying Errors

By default, **NestJS** handles **HttpExceptions** well, but when unexpected errors occur such as **TypeError** or **database crashes**, the application may return a default HTML error page or leak sensitive information. The **AllExceptionsFilter** catches all errors and converts them into a safe JSON structure.

- **Example:** The AllExceptionsFilter structure:

```typescript
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  catch(exception: unknown, host: ArgumentsHost) {
    const response = host.switchToHttp().getResponse();

    const status =
      exception instanceof HttpException
        ? exception.getStatus()
        : HttpStatus.INTERNAL_SERVER_ERROR;

    response.status(status).json({
      statusCode: status,
      error: status === 500 ? 'Internal Error' : 'Bad Request',
      message: exception instanceof HttpException
        ? exception.message
        : 'An unexpected error occurred',
      timestamp: new Date().toISOString(),
    });
  }
}
```

### 4. Custom decorator @ResponseMessage

To customize the `message` content in success responses instead of always using `"Success"`, you can create a **custom decorator** called `@ResponseMessage()`. This decorator attaches a metadata string to the handler, and the **TransformInterceptor** reads that metadata to replace the default message.

- **Example:** Using `@ResponseMessage('User created successfully')` on a Controller handler. When that handler is called, the response contains `"message": "User created successfully"` instead of `"message": "Success"`.

## III. Practice

> **Source code:** [Unified Response and Errors](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/unified-response-and-errors)

### 1. Setup & Run

- **Execution Steps:**
  - Step 1: Clone the repository and navigate into the project directory.
  - Step 2: Install dependencies:

```bash
npm install
```

  - Step 3: Start the server in development mode:

```bash
npm run start:dev
```

- **Expected Results:** The server starts successfully at `http://localhost:3000`. The terminal displays logs confirming the application is ready.
- **Conclusion:** The environment is ready for testing the unified response and error handling mechanisms.

### 2. Architecture

- **Execution Steps:**
  - Step 1: Open `src/common/interceptors/transform.interceptor.ts` to examine how the **TransformInterceptor** wraps responses into `{ statusCode, message, data, timestamp }`.
  - Step 2: Open `src/common/filters/all-exceptions.filter.ts` to examine how the **AllExceptionsFilter** converts errors into `{ statusCode, error, message, timestamp }`.
  - Step 3: Open `src/main.ts` to see both registered globally using `app.useGlobalInterceptors()` and `app.useGlobalFilters()`.

- **Expected Results:** The **TransformInterceptor** handles success responses, and the **AllExceptionsFilter** handles error responses, both producing a consistent JSON structure.
- **Conclusion:** These two components operate independently but complement each other, ensuring every response from the server follows the same format.

### 3. System Flow

- **Execution Steps:**
  - Step 1: The Client sends a request to an endpoint, for example `GET /users`.
  - Step 2: The Controller processes the request and returns successful data.
  - Step 3: The **TransformInterceptor** captures the result and wraps it into the `{ statusCode, message, data, timestamp }` structure before sending it to the Client.
  - Step 4: If an error occurs (e.g., the endpoint throws an **HttpException** or encounters a bug), the **AllExceptionsFilter** catches the error and returns `{ statusCode, error, message, timestamp }`.

- **Expected Results:** Every response follows the same JSON structure, whether successful or failed.
- **Conclusion:** Frontend only needs one single function to handle responses from any endpoint.

### 4. Try it out

- **Execution Steps:**

**Success Path:**

  - Step 1: Send a request to retrieve the list of Users:

```bash
curl http://localhost:3000/users
```

  - Step 2: Verify the response returns a standardized JSON structure:

```json
{
  "statusCode": 200,
  "message": "Success",
  "data": [...],
  "timestamp": "2025-01-01T00:00:00.000Z"
}
```

**Failure Path:**

  - Step 1: Send a request to create a User with an empty body to trigger a validation error:

```bash
curl -X POST http://localhost:3000/users -H "Content-Type: application/json" -d "{}"
```

  - Step 2: Verify the response returns a standardized error JSON structure:

```json
{
  "statusCode": 400,
  "error": "Bad Request",
  "message": "Validation failed",
  "timestamp": "2025-01-01T00:00:00.000Z"
}
```

- **Expected Results:**
  - Success Path: The response is wrapped in the standard structure with `statusCode`, `message`, `data`, and `timestamp`.
  - Failure Path: The error is wrapped in the standard structure with `statusCode`, `error`, `message`, and `timestamp`.

- **Conclusion:** Both success and error cases return consistently structured JSON, enabling Frontend to handle responses easily and predictably.

## IV. Conclusion

**TransformInterceptor** and **AllExceptionsFilter** are two mandatory components for bringing a Backend API to **production-ready** status. They ensure every response follows the same JSON format, completely eliminating inconsistent responses across endpoints. Frontend only needs to write one response handler for the entire application.

**Conclusion:** A professional API does not just return the right data — it returns data following a **consistent contract** that the entire team can trust and rely upon.

# references
## 0
### alias
Nest Interceptors
### url
https://docs.nestjs.com/interceptors
## 1
### alias
Nest Exception Filters
### url
https://docs.nestjs.com/exception-filters

# minutesRead
25
