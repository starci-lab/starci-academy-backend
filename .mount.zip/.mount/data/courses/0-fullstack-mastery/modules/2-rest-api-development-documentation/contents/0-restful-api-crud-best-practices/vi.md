# title
Thiết kế RESTful CRUD API chuẩn mực

# description
Làm chủ các nguyên tắc cốt lõi để xây dựng REST API. Nắm rõ cách định dạng URL, kết hợp HTTP methods và trả HTTP status codes chính xác trong NestJS.

# body

## I. Lời mở đầu

Nhiều lập trình viên khi bắt đầu xây dựng API thường đặt tên đường dẫn theo bản năng: `/layNguoiDung`, `/taoUser`, `/capNhatDonHang`. Cách tiếp cận này không sai về mặt chức năng, nhưng nó tạo ra một hệ thống **không nhất quán**, khó bảo trì và gây khó khăn cho bất kỳ ai tích hợp phía **Frontend** hoặc **Mobile**. **REST** (Representational State Transfer) ra đời như một phong cách kiến trúc chuẩn hóa, giúp mọi thành viên trong đội nói cùng một ngôn ngữ khi thiết kế API.

## II. Nội dung chính

### 1. Tinh thần của REST

**REST** không phải là một giao thức nghiêm ngặt mà là một tập hợp các ràng buộc kiến trúc. Mỗi thực thể trong hệ thống được coi là một **Resource** (tài nguyên) như **User**, **Product**, **Order**. Ta tương tác với các tài nguyên này thông qua các **HTTP Methods** chuẩn: **GET**, **POST**, **PUT**, **PATCH**, **DELETE**.

- **Ví dụ:** Thay vì tạo riêng một đường dẫn cho mỗi hành động, ta sử dụng cùng một URL `/users` nhưng phân biệt hành động bằng HTTP method. **GET /users** để lấy danh sách, **POST /users** để tạo mới, **DELETE /users/:id** để xóa.

### 2. Quy tắc đặt tên URL

Quy tắc vàng trong REST là **không bao giờ đưa động từ vào URL**. Hành động đã được thể hiện qua HTTP method, URL chỉ chứa **danh từ số nhiều** đại diện cho tài nguyên.

- **Ví dụ 1:** Cách đặt tên sai: `GET /getUsers`, `POST /createUser`, `POST /updateUser/1`. Đây là phong cách nghiệp dư, trộn lẫn hành động vào đường dẫn.
- **Ví dụ 2:** Cách đặt tên chuẩn:
  - `GET /users` — Lấy danh sách tất cả Users
  - `POST /users` — Tạo một User mới
  - `GET /users/:id` — Lấy thông tin một User cụ thể
  - `PUT /users/:id` — Thay thế hoàn toàn dữ liệu User
  - `PATCH /users/:id` — Cập nhật một phần dữ liệu User
  - `DELETE /users/:id` — Xóa User

### 3. Triển khai CRUD trong NestJS

**NestJS** cung cấp bộ **Decorators** ánh xạ trực tiếp các HTTP methods vào các hàm xử lý trong Controller, giúp code gọn gàng và trực quan.

- **Ví dụ:**

```typescript
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  findAll() { return this.usersService.findAll(); }

  @Get(':id')
  findOne(@Param('id') id: string) { return this.usersService.findOne(id); }

  @Post()
  create(@Body() payload: any) { return this.usersService.create(payload); }

  @Put(':id')
  update(@Param('id') id: string, @Body() payload: any) { return this.usersService.update(id, payload); }

  @Delete(':id')
  remove(@Param('id') id: string) { return this.usersService.remove(id); }
}
```

### 4. Bảng mã trạng thái HTTP

Trả sai **HTTP status code** là một lỗi nghiêm trọng ảnh hưởng trực tiếp đến logic xử lý phía **Frontend**. Mỗi phản hồi từ server phải mang đúng mã trạng thái tương ứng với kết quả thực tế.

- **Ví dụ:** Các mã trạng thái thường gặp nhất trong REST API:
  - `200 OK` — Thành công cho **GET**, **PUT**, **PATCH**
  - `201 Created` — Thành công cho **POST**, xác nhận record đã được tạo
  - `204 No Content` — Thành công cho **DELETE**, không cần trả dữ liệu
  - `400 Bad Request` — Client gửi dữ liệu sai định dạng hoặc thiếu trường bắt buộc
  - `401 Unauthorized` — Thiếu hoặc sai **Token** xác thực
  - `403 Forbidden` — Có Token nhưng không đủ quyền truy cập tài nguyên
  - `404 Not Found` — Tài nguyên không tồn tại trong database
  - `500 Internal Server Error` — Lỗi phía server, thường do bug trong code

## III. Thực hành

> **Source code:** [RESTful API CRUD Best Practices](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/restful-api-crud-best-practices)

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
  - Bước 1: Clone repository và di chuyển vào thư mục dự án.
  - Bước 2: Cài đặt các dependencies:

```bash
npm install
```

  - Bước 3: Khởi chạy server ở chế độ development:

```bash
npm run start:dev
```

- **Kết quả mong đợi:** Server khởi động thành công tại `http://localhost:3000`. Terminal hiển thị log xác nhận **NestJS** đã sẵn sàng nhận request.
- **Kết luận:** Môi trường đã sẵn sàng để thực hành toàn bộ các thao tác CRUD trên tài nguyên **User**.

### 2. Kiến trúc (Architecture)

- **Các bước thực hiện:**
  - Bước 1: Mở file `src/users/users.controller.ts` để xem các route được khai báo với **@Get()**, **@Post()**, **@Put()**, **@Patch()**, **@Delete()**.
  - Bước 2: Mở file `src/users/users.service.ts` để xem logic xử lý CRUD sử dụng mảng trong bộ nhớ (in-memory array).

- **Kết quả mong đợi:** Controller định nghĩa 5 endpoint tương ứng với 5 HTTP methods. Service xử lý logic tạo, đọc, cập nhật, xóa trên mảng dữ liệu.
- **Kết luận:** Kiến trúc tách biệt rõ ràng giữa **Controller** (nhận request) và **Service** (xử lý logic), tuân thủ nguyên tắc **Separation of Concerns**.

### 3. Luồng hệ thống (System Flow)

- **Các bước thực hiện:**
  - Bước 1: Client gửi HTTP request đến một endpoint, ví dụ `POST /users`.
  - Bước 2: **NestJS** định tuyến request đến hàm tương ứng trong **UsersController** dựa trên decorator `@Post()`.
  - Bước 3: Controller gọi **UsersService** để xử lý logic nghiệp vụ.
  - Bước 4: Service thực hiện thao tác trên dữ liệu và trả kết quả về Controller.
  - Bước 5: Controller trả response về Client với HTTP status code phù hợp.

- **Kết quả mong đợi:** Luồng dữ liệu di chuyển theo một chiều: **Client -> Controller -> Service -> Response**.
- **Kết luận:** Mọi request đều đi qua một luồng xử lý nhất quán, đảm bảo tính dự đoán và dễ debug.

### 4. Thử nghiệm (Try it out)

- **Các bước thực hiện:**

**Nhánh thành công (Success Path):**

  - Bước 1: Tạo một User mới bằng lệnh curl:

```bash
curl -X POST http://localhost:3000/users -H "Content-Type: application/json" -d "{\"name\": \"Nguyen Van A\", \"email\": \"a@example.com\"}"
```

  - Bước 2: Xác nhận User đã được tạo bằng cách lấy danh sách:

```bash
curl http://localhost:3000/users
```

  - Bước 3: Xóa User vừa tạo (thay `1` bằng ID thực tế):

```bash
curl -X DELETE http://localhost:3000/users/1
```

  - Bước 4: Xác nhận User đã bị xóa bằng cách gọi lại danh sách:

```bash
curl http://localhost:3000/users
```

**Nhánh thất bại (Failure Path):**

  - Bước 1: Thử lấy thông tin một User không tồn tại:

```bash
curl http://localhost:3000/users/9999
```

  - Bước 2: Kiểm tra response trả về mã `404 Not Found`.

- **Kết quả mong đợi:**
  - Nhánh thành công: **POST** trả về `201 Created` với dữ liệu User mới. **GET** trả về danh sách chứa User. **DELETE** trả về `200 OK` hoặc `204 No Content`. Sau khi xóa, danh sách không còn User đó.
  - Nhánh thất bại: **GET /users/9999** trả về `404 Not Found` vì ID không tồn tại.

- **Kết luận:** API phản hồi đúng HTTP status code tương ứng với từng tình huống, giúp Frontend phân biệt rõ ràng giữa thành công và lỗi.

## IV. Kết luận

Thiết kế **RESTful API** không chỉ là việc chọn đúng HTTP method, mà là xây dựng một **giao diện giao tiếp nhất quán** giữa Backend và Frontend. Khi URL được đặt tên theo **danh từ số nhiều**, HTTP method thể hiện hành động, và status code phản ánh đúng kết quả, toàn bộ đội ngũ có thể làm việc trên cùng một hệ thống mà không cần giải thích thêm.

**Kết luận:** Một API chuẩn REST là nền tảng để xây dựng mọi hệ thống **scalable** và **maintainable** — nó là ngôn ngữ chung mà mọi kỹ sư phần mềm đều phải thành thạo.

# references
## 0
### alias
Controllers in NestJS
### url
https://docs.nestjs.com/controllers

# minutesRead
15
