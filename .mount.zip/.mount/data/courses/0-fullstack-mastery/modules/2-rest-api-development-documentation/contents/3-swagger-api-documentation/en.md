# title
API Documentation with Swagger

# description
Configure automatic generation of live, interactive API documentation using Swagger and Scalar directly from NestJS code, completely replacing manual documentation methods.

# body

## I. Introduction

Building an API without documentation leaves the **Frontend** and **Mobile** teams guessing about which endpoints to call, what parameters to send, and what responses to expect. Traditional approaches like sharing **Postman** files or writing **Excel** spreadsheets quickly become outdated as the code changes. **Swagger** (the **OpenAPI** standard) solves this by reading the code directly and automatically generating a **live** documentation web page that stays in sync with the current state of the API.

## II. Core Concepts

### 1. The Value of Live API Documentation

Traditional API documentation (Word, Excel, Postman collections) shares one fatal flaw: it becomes **outdated** the moment a developer changes the code but forgets to update the document. **Swagger** eliminates this problem by generating documentation automatically from the source code itself, ensuring the documentation always reflects the actual endpoints, parameters, and responses currently running.

- **Example:** When you add a new field to a DTO and attach `@ApiProperty()`, the Swagger interface automatically displays that field in the request body section without editing any documentation file.

### 2. Configuring Swagger in main.ts

To activate Swagger, install the `@nestjs/swagger` library and configure it in `main.ts` before calling `app.listen()`.

- **Example:** Basic configuration:

```typescript
const config = new DocumentBuilder()
  .setTitle('StarCi Academy Backend')
  .setDescription('API documentation')
  .setVersion('1.0')
  .addBearerAuth()
  .build();

const document = SwaggerModule.createDocument(app, config);
SwaggerModule.setup('swagger', app, document);
```

After configuration, visit `http://localhost:3000/swagger` to view the classic Swagger UI. This project also integrates **Scalar** at the `/scalar` path, providing a more modern documentation interface.

### 3. Swagger Decorators

To make the documentation interface more detailed and useful, you use Swagger **decorators** in the Controller. Each decorator adds descriptive information to individual endpoints, helping Frontend understand the functionality without reading the code.

- **Example:** Using decorators in a Controller:

```typescript
@ApiTags('Cats Module')
@Controller('cats')
export class CatsController {

  @Get()
  @ApiOperation({ summary: 'Retrieve all cats' })
  @ApiResponse({ status: 200, description: 'List of cats returned successfully' })
  findAll() { return this.catsService.findAll(); }

  @Post()
  @ApiOperation({ summary: 'Create a new cat' })
  @ApiResponse({ status: 201, description: 'Cat created successfully' })
  @ApiResponse({ status: 400, description: 'Invalid payload' })
  create(@Body() dto: CreateCatDto) { return this.catsService.create(dto); }
}
```

### 4. DTO Introspection with @ApiProperty()

**TypeScript** strips type information when compiling to **JavaScript**, so Swagger cannot automatically detect the fields inside a DTO. You must use `@ApiProperty()` to declare each property, enabling Swagger to display complete information and generate mock data on the interface.

- **Example:** Declaring a DTO with ApiProperty:

```typescript
export class CreateCatDto {
  @ApiProperty({ example: 'Persian', description: 'Breed of the cat' })
  @IsString()
  breed: string;

  @ApiProperty({ example: 2, description: 'Age in years' })
  @IsNumber()
  age: number;
}
```

On the Swagger interface, the `breed` and `age` fields appear with sample data, allowing Frontend to test directly without manually entering data.

## III. Practice

> **Source code:** [Swagger API Documentation](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/swagger-api-documentation)

### 1. Setup & Run

- **Execution Steps:**
  - Step 1: Clone the repository and navigate into the project directory.
  - Step 2: Install dependencies:

```bash
npm install
```

  - Step 3: Start the server in development mode:

```bash
npm run start:dev
```

- **Expected Results:** The server starts successfully at `http://localhost:3000`. Two documentation paths are available: `/scalar` (modern interface) and `/swagger` (classic interface).
- **Conclusion:** The environment is ready for exploring the auto-generated API documentation interface.

### 2. Architecture

- **Execution Steps:**
  - Step 1: Open `src/main.ts` to examine the **DocumentBuilder** and **SwaggerModule.setup()** configuration registering Swagger globally.
  - Step 2: Open the Controller file (e.g., `src/cats/cats.controller.ts`) to see how **@ApiTags()**, **@ApiOperation()**, **@ApiResponse()** decorators are used.
  - Step 3: Open the DTO file (e.g., `src/cats/dto/create-cat.dto.ts`) to see **@ApiProperty()** declaring each property.
  - Step 4: Check the **TransformInterceptor** and **AllExceptionsFilter** files registered globally (same pattern as the unified-response-and-errors lesson).

- **Expected Results:** Swagger is configured globally in `main.ts`. The Controller uses decorators to describe endpoints. The DTO uses `@ApiProperty()` to declare properties.
- **Conclusion:** API documentation is generated automatically from the decorators in the code, requiring no external documentation files.

### 3. System Flow

- **Execution Steps:**
  - Step 1: When the server starts, **SwaggerModule** scans all registered Controllers and DTOs.
  - Step 2: The module reads **@ApiTags()**, **@ApiOperation()**, **@ApiResponse()**, **@ApiProperty()** decorators to build the OpenAPI spec document.
  - Step 3: The documentation is served at `/swagger` (classic Swagger UI) and `/scalar` (modern Scalar interface).
  - Step 4: Frontend or QA accesses the web interface to view and test endpoints directly.

- **Expected Results:** The documentation interface displays all endpoints, parameters, response schemas, and allows sending requests directly.
- **Conclusion:** API documentation stays in sync with the current code, completely eliminating the risk of outdated documentation.

### 4. Try it out

- **Execution Steps:**

**Success Path:**

  - Step 1: Open a browser and navigate to `http://localhost:3000/scalar` to view the modern documentation interface.
  - Step 2: Find the `GET /cats` endpoint in the list.
  - Step 3: Send a request directly from the interface or use curl:

```bash
curl http://localhost:3000/cats
```

  - Step 4: Verify the response returns a standardized JSON structure with `statusCode`, `message`, `data`, and `timestamp` (via the **TransformInterceptor**).

**Failure Path:**

  - Step 1: Find the `GET /cats/error-demo` endpoint in the documentation interface.
  - Step 2: Send a request to trigger an error:

```bash
curl http://localhost:3000/cats/error-demo
```

  - Step 3: Verify the response returns a standardized error JSON structure with `statusCode`, `error`, `message`, and `timestamp` (via the **AllExceptionsFilter**).

- **Expected Results:**
  - Success Path: The documentation interface correctly displays all endpoints. The `GET /cats` request returns a successful response in the standard structure.
  - Failure Path: The `GET /cats/error-demo` request returns an error response in the standard structure.

- **Conclusion:** **Swagger** and **Scalar** provide an intuitive interface for exploring and testing APIs, combined with **TransformInterceptor** and **AllExceptionsFilter** to ensure every response is consistent.

## IV. Conclusion

**Swagger** transforms API documentation from a tedious manual task into a **fully automated** process. When combined with **Scalar**, the team has two documentation interfaces to choose from. Decorators like **@ApiProperty()**, **@ApiOperation()**, and **@ApiResponse()** ensure the documentation is always accurate and in sync with the code.

**Conclusion:** Live API documentation is an essential part of any **production-ready** system — it not only serves Frontend but also acts as a communication tool across the entire engineering team.

# references
## 0
### alias
OpenAPI Setup
### url
https://docs.nestjs.com/openapi/introduction

# minutesRead
20
