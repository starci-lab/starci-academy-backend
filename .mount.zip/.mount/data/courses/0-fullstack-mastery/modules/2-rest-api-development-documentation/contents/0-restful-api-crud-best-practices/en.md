# title
RESTful CRUD API Best Practices

# description
Understand the core principles of building predictable, standard REST APIs mapped to proper HTTP methods and status codes in NestJS.

# body

## I. Introduction

Many developers instinctively name API endpoints after actions: `/getUsers`, `/createUser`, `/updateOrder`. While functionally correct, this approach produces an **inconsistent** system that is difficult to maintain and painful for any **Frontend** or **Mobile** team to integrate with. **REST** (Representational State Transfer) provides a standardized architectural style that establishes a common language for API design across the entire team.

## II. Core Concepts

### 1. The Essence of REST

**REST** is not a strict protocol but a set of architectural constraints. Every entity in the system is treated as a **Resource** such as **User**, **Product**, or **Order**. Interactions with these resources happen through standard **HTTP Methods**: **GET**, **POST**, **PUT**, **PATCH**, **DELETE**.

- **Example:** Instead of creating a separate URL for each action, you use the same URL `/users` and differentiate actions by HTTP method. **GET /users** retrieves the list, **POST /users** creates a new entry, **DELETE /users/:id** removes one.

### 2. Resource Naming Conventions

The golden rule of REST is to **never put verbs in the URL**. The HTTP method already describes the action, so the URL should only contain **plural nouns** representing the resource.

- **Example 1:** Incorrect naming: `GET /getUsers`, `POST /createUser`, `POST /updateUser/1`. This style mixes actions into the path.
- **Example 2:** Correct naming following REST conventions:
  - `GET /users` — Retrieve a list of all Users
  - `POST /users` — Create a new User
  - `GET /users/:id` — Retrieve a specific User
  - `PUT /users/:id` — Completely replace a User
  - `PATCH /users/:id` — Partially update a User
  - `DELETE /users/:id` — Delete a User

### 3. Implementing CRUD in NestJS

**NestJS** provides a set of **Decorators** that directly map HTTP methods to handler functions inside a Controller, making the code concise and intuitive.

- **Example:**

```typescript
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  findAll() { return this.usersService.findAll(); }

  @Get(':id')
  findOne(@Param('id') id: string) { return this.usersService.findOne(id); }

  @Post()
  create(@Body() payload: any) { return this.usersService.create(payload); }

  @Put(':id')
  update(@Param('id') id: string, @Body() payload: any) { return this.usersService.update(id, payload); }

  @Delete(':id')
  remove(@Param('id') id: string) { return this.usersService.remove(id); }
}
```

### 4. HTTP Status Codes

Returning the wrong **HTTP status code** is a critical mistake that directly impacts **Frontend** logic. Every server response must carry the correct status code matching the actual result.

- **Example:** The most common status codes in REST APIs:
  - `200 OK` — Success for **GET**, **PUT**, **PATCH**
  - `201 Created` — Success for **POST**, confirming the record was created
  - `204 No Content` — Success for **DELETE**, no response body needed
  - `400 Bad Request` — Client sent invalid or incomplete data
  - `401 Unauthorized` — Missing or invalid authentication **Token**
  - `403 Forbidden` — Valid Token but insufficient permissions for the resource
  - `404 Not Found` — Resource does not exist in the database
  - `500 Internal Server Error` — Server-side error, typically a bug in the code

## III. Practice

> **Source code:** [RESTful API CRUD Best Practices](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/restful-api-crud-best-practices)

### 1. Setup & Run

- **Execution Steps:**
  - Step 1: Clone the repository and navigate into the project directory.
  - Step 2: Install dependencies:

```bash
npm install
```

  - Step 3: Start the server in development mode:

```bash
npm run start:dev
```

- **Expected Results:** The server starts successfully at `http://localhost:3000`. The terminal displays logs confirming **NestJS** is ready to accept requests.
- **Conclusion:** The environment is ready for practicing all CRUD operations on the **User** resource.

### 2. Architecture

- **Execution Steps:**
  - Step 1: Open `src/users/users.controller.ts` to examine the routes declared with **@Get()**, **@Post()**, **@Put()**, **@Patch()**, **@Delete()**.
  - Step 2: Open `src/users/users.service.ts` to review the CRUD logic using an in-memory array.

- **Expected Results:** The Controller defines 5 endpoints corresponding to 5 HTTP methods. The Service handles create, read, update, and delete operations on the data array.
- **Conclusion:** The architecture clearly separates **Controller** (receiving requests) from **Service** (processing logic), following the **Separation of Concerns** principle.

### 3. System Flow

- **Execution Steps:**
  - Step 1: The client sends an HTTP request to an endpoint, for example `POST /users`.
  - Step 2: **NestJS** routes the request to the corresponding handler in **UsersController** based on the `@Post()` decorator.
  - Step 3: The Controller calls **UsersService** to process the business logic.
  - Step 4: The Service performs the operation on the data and returns the result to the Controller.
  - Step 5: The Controller sends the response back to the Client with the appropriate HTTP status code.

- **Expected Results:** Data flows in one direction: **Client -> Controller -> Service -> Response**.
- **Conclusion:** Every request follows a consistent processing flow, ensuring predictability and ease of debugging.

### 4. Try it out

- **Execution Steps:**

**Success Path:**

  - Step 1: Create a new User using curl:

```bash
curl -X POST http://localhost:3000/users -H "Content-Type: application/json" -d "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}"
```

  - Step 2: Verify the User was created by retrieving the list:

```bash
curl http://localhost:3000/users
```

  - Step 3: Delete the User just created (replace `1` with the actual ID):

```bash
curl -X DELETE http://localhost:3000/users/1
```

  - Step 4: Confirm the User was deleted by fetching the list again:

```bash
curl http://localhost:3000/users
```

**Failure Path:**

  - Step 1: Attempt to retrieve a User that does not exist:

```bash
curl http://localhost:3000/users/9999
```

  - Step 2: Verify the response returns `404 Not Found`.

- **Expected Results:**
  - Success Path: **POST** returns `201 Created` with the new User data. **GET** returns the list containing the User. **DELETE** returns `200 OK` or `204 No Content`. After deletion, the list no longer contains that User.
  - Failure Path: **GET /users/9999** returns `404 Not Found` because the ID does not exist.

- **Conclusion:** The API responds with the correct HTTP status code for each scenario, allowing Frontend to clearly distinguish between success and error states.

## IV. Conclusion

Designing a **RESTful API** is not just about choosing the right HTTP method — it is about building a **consistent communication interface** between Backend and Frontend. When URLs follow **plural noun** conventions, HTTP methods represent actions, and status codes accurately reflect outcomes, the entire team can work on the same system without extra explanation.

**Conclusion:** A well-designed REST API is the foundation for building any **scalable** and **maintainable** system — it is the common language every software engineer must master.

# references
## 0
### alias
Controllers in NestJS
### url
https://docs.nestjs.com/controllers

# minutesRead
15
