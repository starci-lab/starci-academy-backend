# title
Đồng bộ Response và Trạm gác lỗi (Exception Filter)

# description
Xây dựng cơ chế tự động bọc toàn bộ dữ liệu trả về thành chuẩn JSON thống nhất, đồng thời xử lý mọi lỗi hệ thống một cách an toàn và nhất quán trong NestJS.

# body

## I. Lời mở đầu

Khi làm việc trong đội nhóm, mỗi Backend developer có một phong cách trả dữ liệu riêng: người trả mảng `[]`, người trả object `{ data: [] }`, người lại trả chuỗi `"OK"`. Kết quả là **Frontend** phải viết hàng loạt hàm xử lý đặc biệt cho từng endpoint. Vấn đề này còn tồi tệ hơn khi lỗi xảy ra — một số endpoint trả HTML mặc định, một số trả JSON không có cấu trúc. **TransformInterceptor** và **AllExceptionsFilter** là hai công cụ giúp thiết lập một **khế ước JSON duy nhất** cho toàn bộ hệ thống.

## II. Nội dung chính

### 1. Vấn đề của API không nhất quán

Khi nhiều developer cùng xây dựng API mà không có quy chuẩn chung, **Frontend** phải đối mặt với nhiều định dạng response khác nhau. Điều này dẫn đến code xử lý phức tạp, khó bảo trì và dễ phát sinh bug khi tích hợp.

- **Ví dụ:** Endpoint `/users` trả về `[{...}]`, nhưng endpoint `/posts` trả về `{ data: [{...}], total: 10 }`. Frontend phải viết logic riêng cho từng endpoint thay vì sử dụng một hàm xử lý chung.

### 2. TransformInterceptor — Đồng bộ response thành công

**TransformInterceptor** là một **NestJS Interceptor** đứng ở cổng ra của Controller, tự động bọc mọi kết quả trả về vào một cấu trúc JSON thống nhất bao gồm `statusCode`, `message`, `data`, và `timestamp`.

- **Ví dụ:** Cấu trúc TransformInterceptor:

```typescript
@Injectable()
export class TransformInterceptor<T> implements NestInterceptor<T, any> {
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const ctx = context.switchToHttp();
    const statusCode = ctx.getResponse().statusCode;

    return next.handle().pipe(
      map(data => ({
        statusCode: statusCode,
        message: 'Success',
        data: data || null,
        timestamp: new Date().toISOString(),
      })),
    );
  }
}
```

Dù Controller chỉ trả về chuỗi `"OK"`, Client vẫn nhận được `{ "statusCode": 200, "message": "Success", "data": "OK", "timestamp": "..." }`.

### 3. AllExceptionsFilter — Thu gom và đồng bộ lỗi

Mặc định **NestJS** xử lý tốt các **HttpException**, nhưng khi xảy ra lỗi không dự kiến như **TypeError** hoặc **lỗi database**, ứng dụng có thể trả về trang HTML lỗi mặc định hoặc lộ thông tin nhạy cảm. **AllExceptionsFilter** bắt toàn bộ lỗi và chuyển chúng thành một cấu trúc JSON an toàn.

- **Ví dụ:** Cấu trúc AllExceptionsFilter:

```typescript
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  catch(exception: unknown, host: ArgumentsHost) {
    const response = host.switchToHttp().getResponse();

    const status =
      exception instanceof HttpException
        ? exception.getStatus()
        : HttpStatus.INTERNAL_SERVER_ERROR;

    response.status(status).json({
      statusCode: status,
      error: status === 500 ? 'Internal Error' : 'Bad Request',
      message: exception instanceof HttpException
        ? exception.message
        : 'An unexpected error occurred',
      timestamp: new Date().toISOString(),
    });
  }
}
```

### 4. Custom decorator @ResponseMessage

Để tùy chỉnh nội dung `message` trong response thành công thay vì luôn là `"Success"`, ta có thể tạo một **custom decorator** `@ResponseMessage()`. Decorator này gắn một metadata string lên handler, và **TransformInterceptor** đọc metadata đó để thay thế message mặc định.

- **Ví dụ:** Sử dụng `@ResponseMessage('User created successfully')` trên một handler trong Controller. Khi handler đó được gọi, response sẽ chứa `"message": "User created successfully"` thay vì `"message": "Success"`.

## III. Thực hành

> **Source code:** [Unified Response and Errors](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/unified-response-and-errors)

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
  - Bước 1: Clone repository và di chuyển vào thư mục dự án.
  - Bước 2: Cài đặt các dependencies:

```bash
npm install
```

  - Bước 3: Khởi chạy server ở chế độ development:

```bash
npm run start:dev
```

- **Kết quả mong đợi:** Server khởi động thành công tại `http://localhost:3000`. Terminal hiển thị log xác nhận ứng dụng đã sẵn sàng.
- **Kết luận:** Môi trường đã sẵn sàng để kiểm tra cơ chế đồng bộ response và xử lý lỗi.

### 2. Kiến trúc (Architecture)

- **Các bước thực hiện:**
  - Bước 1: Mở file `src/common/interceptors/transform.interceptor.ts` để xem cấu trúc **TransformInterceptor** bọc response thành `{ statusCode, message, data, timestamp }`.
  - Bước 2: Mở file `src/common/filters/all-exceptions.filter.ts` để xem cấu trúc **AllExceptionsFilter** chuyển lỗi thành `{ statusCode, error, message, timestamp }`.
  - Bước 3: Mở file `src/main.ts` để xem cả hai được đăng ký toàn cục bằng `app.useGlobalInterceptors()` và `app.useGlobalFilters()`.

- **Kết quả mong đợi:** **TransformInterceptor** xử lý response thành công, **AllExceptionsFilter** xử lý response lỗi, cả hai đều tạo ra cấu trúc JSON nhất quán.
- **Kết luận:** Hai thành phần này hoạt động độc lập nhưng bổ sung cho nhau, đảm bảo mọi response từ server đều có cùng một định dạng.

### 3. Luồng hệ thống (System Flow)

- **Các bước thực hiện:**
  - Bước 1: Client gửi request đến một endpoint, ví dụ `GET /users`.
  - Bước 2: Controller xử lý và trả về dữ liệu thành công.
  - Bước 3: **TransformInterceptor** bắt kết quả và bọc vào cấu trúc `{ statusCode, message, data, timestamp }` trước khi gửi về Client.
  - Bước 4: Nếu xảy ra lỗi (ví dụ endpoint ném **HttpException** hoặc gặp bug), **AllExceptionsFilter** bắt lỗi và trả về `{ statusCode, error, message, timestamp }`.

- **Kết quả mong đợi:** Mọi response đều có cùng một cấu trúc JSON, bất kể thành công hay thất bại.
- **Kết luận:** Frontend chỉ cần một hàm duy nhất để xử lý response từ bất kỳ endpoint nào.

### 4. Thử nghiệm (Try it out)

- **Các bước thực hiện:**

**Nhánh thành công (Success Path):**

  - Bước 1: Gửi request lấy danh sách Users:

```bash
curl http://localhost:3000/users
```

  - Bước 2: Kiểm tra response trả về cấu trúc JSON chuẩn:

```json
{
  "statusCode": 200,
  "message": "Success",
  "data": [...],
  "timestamp": "2025-01-01T00:00:00.000Z"
}
```

**Nhánh thất bại (Failure Path):**

  - Bước 1: Gửi request tạo User với body rỗng để kích hoạt lỗi validation:

```bash
curl -X POST http://localhost:3000/users -H "Content-Type: application/json" -d "{}"
```

  - Bước 2: Kiểm tra response trả về cấu trúc lỗi JSON chuẩn:

```json
{
  "statusCode": 400,
  "error": "Bad Request",
  "message": "Validation failed",
  "timestamp": "2025-01-01T00:00:00.000Z"
}
```

- **Kết quả mong đợi:**
  - Nhánh thành công: Response được bọc trong cấu trúc chuẩn với `statusCode`, `message`, `data`, và `timestamp`.
  - Nhánh thất bại: Lỗi được bọc trong cấu trúc chuẩn với `statusCode`, `error`, `message`, và `timestamp`.

- **Kết luận:** Cả hai trường hợp thành công và lỗi đều trả về JSON có cấu trúc nhất quán, giúp Frontend xử lý response một cách dễ dàng và dự đoán được.

## IV. Kết luận

**TransformInterceptor** và **AllExceptionsFilter** là hai thành phần bắt buộc để đưa API Backend lên mức **production-ready**. Chúng đảm bảo mọi response đều có cùng một định dạng JSON, loại bỏ hoàn toàn tình trạng response tùy hứng giữa các endpoint. Frontend chỉ cần viết một bộ xử lý response duy nhất cho toàn bộ ứng dụng.

**Kết luận:** Một API chuyên nghiệp không chỉ trả đúng dữ liệu — nó trả dữ liệu theo một **khế ước nhất quán** mà toàn bộ đội ngũ có thể tin tưởng và dựa vào.

# references
## 0
### alias
Nest Interceptors
### url
https://docs.nestjs.com/interceptors
## 1
### alias
Nest Exception Filters
### url
https://docs.nestjs.com/exception-filters

# minutesRead
25
