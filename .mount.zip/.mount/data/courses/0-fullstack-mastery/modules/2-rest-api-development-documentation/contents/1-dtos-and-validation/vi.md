# title
Khái niệm DTO và Kỹ thuật Validation

# description
Bắt lấy chắn phòng thủ cho Backend. Ngăn rác thải tràn vào Database thông qua Data Transfer Object (DTO) và ValidationPipe chuyên sâu trong NestJS.

# body

## I. Lời mở đầu

Khi xây dựng API, một sai lầm phổ biến là tin tưởng dữ liệu từ Client. Nhiều lập trình viên sử dụng kiểu `any` để nhận dữ liệu từ request body, vô tình mở cửa cho **dữ liệu rác**, **dữ liệu độc hại**, hoặc **dữ liệu thiếu trường bắt buộc** tràn vào hệ thống. **DTO** (Data Transfer Object) kết hợp với **ValidationPipe** chính là lớp chắn phòng thủ bắt buộc, đảm bảo chỉ có dữ liệu hợp lệ mới được đi sâu hơn vào tầng **Service** và **Database**.

## II. Nội dung chính

### 1. DTO là gì

**DTO** (Data Transfer Object) là một lớp (class) định nghĩa chính xác cấu trúc dữ liệu mà Client được phép gửi lên server. Thay vì dùng kiểu `any` mơ hồ và nguy hiểm, ta khai báo rõ ràng từng trường dữ liệu và kiểu của nó.

- **Ví dụ:** So sánh giữa cách nhận dữ liệu không an toàn và cách sử dụng DTO:

```typescript
// Nguy hiểm: không biết body chứa gì
@Post()
create(@Body() body: any) {}

// An toàn: dữ liệu được ràng buộc bởi CreateUserDto
@Post()
create(@Body() createUserDto: CreateUserDto) {}
```

### 2. Trang bị class-validator và class-transformer

**NestJS** sử dụng hai thư viện **class-validator** và **class-transformer** để gắn các quy tắc xác thực trực tiếp lên từng thuộc tính của DTO. Mỗi decorator tương ứng với một ràng buộc cụ thể như kiểm tra email, độ dài tối thiểu, hay kiểu dữ liệu.

- **Ví dụ:** Khai báo DTO với các decorator xác thực:

```typescript
import { IsEmail, IsString, MinLength } from 'class-validator';

export class CreateUserDto {
  @IsEmail()
  email: string;

  @IsString()
  @MinLength(8, { message: 'Password is too short' })
  password: string;
}
```

Với cấu hình này, nếu Client gửi email thiếu ký tự `@` hoặc password ngắn hơn **8 ký tự**, hệ thống sẽ tự động từ chối request.

### 3. Kích hoạt ValidationPipe toàn cục

Để các decorator xác thực có hiệu lực, bạn phải đăng ký **ValidationPipe** ở cấp toàn cục trong file `main.ts`. Đây là bộ lọc đứng ở cửa chính của ứng dụng, kiểm tra mọi request trước khi nó chạm đến Controller.

- **Ví dụ:** Cấu hình ValidationPipe với các tùy chọn bảo mật:

```typescript
app.useGlobalPipes(new ValidationPipe({
  whitelist: true,
  forbidNonWhitelisted: true,
  transform: true,
}));
```

  - **whitelist: true** — Tự động loại bỏ các trường không được định nghĩa trong DTO. Nếu Client gửi thêm `{ "role": "admin" }` mà DTO không khai báo trường `role`, trường đó sẽ bị gọt bỏ.
  - **forbidNonWhitelisted: true** — Thay vì im lặng gọt bỏ, hệ thống trả lời `400 Bad Request` nếu phát hiện trường thừa.
  - **transform: true** — Tự động chuyển đổi kiểu dữ liệu, ví dụ chuyển param `"123"` từ string sang number.

### 4. Luồng xử lý dữ liệu tổng thể

Toàn bộ quy trình bảo vệ dữ liệu diễn ra trước khi code nghiệp vụ được thực thi. **ValidationPipe** đóng vai trò như một trạm kiểm soát tự động, đảm bảo mọi dữ liệu đi vào hệ thống đều hợp lệ.

- **Ví dụ:** Luồng xử lý tuần tự: **Client** gửi request -> **ValidationPipe** kiểm tra và lọc dữ liệu -> **Controller** nhận dữ liệu đã hợp lệ -> **Service** xử lý logic nghiệp vụ. Nếu dữ liệu không hợp lệ, **ValidationPipe** trả về lỗi `400 Bad Request` ngay lập tức mà Controller không hề bị ảnh hưởng.

## III. Thực hành

> **Source code:** [DTOs and Validation](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/dtos-and-validation)

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
  - Bước 1: Clone repository và di chuyển vào thư mục dự án.
  - Bước 2: Cài đặt các dependencies:

```bash
npm install
```

  - Bước 3: Khởi chạy server ở chế độ development:

```bash
npm run start:dev
```

- **Kết quả mong đợi:** Server khởi động thành công tại `http://localhost:3000`. Terminal hiển thị log xác nhận ứng dụng đã sẵn sàng.
- **Kết luận:** Môi trường đã sẵn sàng để kiểm tra cơ chế xác thực dữ liệu với **DTO** và **ValidationPipe**.

### 2. Kiến trúc (Architecture)

- **Các bước thực hiện:**
  - Bước 1: Mở file DTO (ví dụ `src/users/dto/create-user.dto.ts`) để xem các decorator **@IsEmail()**, **@IsString()**, **@MinLength()** được gắn trên từng thuộc tính.
  - Bước 2: Mở file `src/main.ts` để xem cấu hình **ValidationPipe** toàn cục với các tùy chọn `whitelist`, `forbidNonWhitelisted`, `transform`.
  - Bước 3: Mở file Controller để xem cách DTO được sử dụng làm kiểu dữ liệu cho tham số `@Body()`.

- **Kết quả mong đợi:** DTO định nghĩa cấu trúc dữ liệu với các ràng buộc xác thực. **ValidationPipe** được đăng ký toàn cục để tự động kiểm tra mọi request.
- **Kết luận:** Kiến trúc bảo vệ dữ liệu diễn ra ở tầng **Pipe**, tách biệt hoàn toàn khỏi logic nghiệp vụ trong **Service**.

### 3. Luồng hệ thống (System Flow)

- **Các bước thực hiện:**
  - Bước 1: Client gửi **POST /users** với body JSON chứa các trường `email` và `password`.
  - Bước 2: **ValidationPipe** so sánh dữ liệu với DTO, kiểm tra từng trường theo các decorator đã khai báo.
  - Bước 3: Nếu dữ liệu hợp lệ, request được chuyển tiếp đến **Controller**.
  - Bước 4: **Controller** gọi **Service** để xử lý logic tạo User.
  - Bước 5: Nếu dữ liệu không hợp lệ, **ValidationPipe** tự động trả về `400 Bad Request` kèm danh sách lỗi chi tiết.

- **Kết quả mong đợi:** Dữ liệu hợp lệ đi tiếp vào hệ thống; dữ liệu không hợp lệ bị chặn ngay tại tầng Pipe.
- **Kết luận:** **ValidationPipe** đóng vai trò như bộ lọc tự động, bảo vệ toàn bộ hệ thống mà không cần viết code kiểm tra thủ công trong Controller.

### 4. Thử nghiệm (Try it out)

- **Các bước thực hiện:**

**Nhánh thành công (Success Path):**

  - Bước 1: Gửi request tạo User với dữ liệu hợp lệ:

```bash
curl -X POST http://localhost:3000/users -H "Content-Type: application/json" -d "{\"email\": \"test@example.com\", \"password\": \"securepass123\"}"
```

  - Bước 2: Kiểm tra response trả về `201 Created` với dữ liệu User mới được tạo.

**Nhánh thất bại (Failure Path):**

  - Bước 1: Gửi request với email sai định dạng và password quá ngắn:

```bash
curl -X POST http://localhost:3000/users -H "Content-Type: application/json" -d "{\"email\": \"not-an-email\", \"password\": \"123\"}"
```

  - Bước 2: Kiểm tra response trả về `400 Bad Request` với mảng message mô tả chi tiết từng lỗi xác thực (email không hợp lệ, password quá ngắn).

  - Bước 3: Gửi request với body rỗng:

```bash
curl -X POST http://localhost:3000/users -H "Content-Type: application/json" -d "{}"
```

  - Bước 4: Kiểm tra response trả về `400 Bad Request` vì thiếu tất cả các trường bắt buộc.

- **Kết quả mong đợi:**
  - Nhánh thành công: Server chấp nhận dữ liệu và trả về `201 Created`.
  - Nhánh thất bại: Server từ chối dữ liệu sai và trả về `400 Bad Request` với danh sách lỗi cụ thể.

- **Kết luận:** **ValidationPipe** tự động bảo vệ ứng dụng khỏi dữ liệu không hợp lệ mà không cần viết bất kỳ dòng code kiểm tra nào trong Controller hay Service.

## IV. Kết luận

**DTO** và **ValidationPipe** là hai công cụ không thể thiếu trong bất kỳ ứng dụng **NestJS** nghiêm túc nào. DTO định nghĩa **khuôn mẫu dữ liệu**, còn ValidationPipe đảm bảo **mọi dữ liệu đều phải khớp khuôn** trước khi đi vào hệ thống. Sự kết hợp này loại bỏ hoàn toàn nguy cơ dữ liệu rác, dữ liệu độc hại, và các lỗi logic do dữ liệu sai gây ra.

**Kết luận:** Bảo vệ dữ liệu đầu vào không phải là một tùy chọn — đó là nghĩa vụ bắt buộc của mọi Backend engineer khi xây dựng hệ thống **production-ready**.

# references
## 0
### alias
Validation Techniques
### url
https://docs.nestjs.com/techniques/validation

# minutesRead
20
