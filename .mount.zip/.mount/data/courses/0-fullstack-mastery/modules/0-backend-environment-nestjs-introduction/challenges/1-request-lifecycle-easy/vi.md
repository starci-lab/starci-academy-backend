# title
Xây dựng Pipeline Request cơ bản trong NestJS

# description
Tạo một project NestJS mới, triển khai đủ các thành phần trong vòng đời request (Middleware, Guard, Pipe, Interceptor, Exception Filter) cho một domain tự chọn, chứng minh mỗi tầng xử lý đúng trách nhiệm.

# requirements
Xây dựng ứng dụng NestJS với module `TaskModule` quản lý danh sách công việc. Triển khai đầy đủ: `LoggerMiddleware` ghi log mọi request, `RoleGuard` kiểm tra header `x-role`, `ParsePositiveIntPipe` validate tham số id, `ResponseInterceptor` chuẩn hoá format response thành `{ data, timestamp }`, và `HttpExceptionFilter` trả lỗi JSON an toàn. Endpoint `GET /tasks/:id` trả task theo id, `GET /tasks` trả danh sách tất cả task.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install

# steps

## 0
### title
Khởi tạo project và cài đặt
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới bằng CLI:
    ```bash
    nest new request-lifecycle-easy
    ```
  - Bước 2: Di chuyển vào thư mục project:
    ```bash
    cd request-lifecycle-easy
    ```
  - Bước 3: Chạy thử ứng dụng:
    ```bash
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng khởi động thành công trên cổng 3000, terminal hiển thị log NestJS sẵn sàng nhận request.
- **Kết luận:** Môi trường nền đã sẵn sàng để triển khai các thành phần pipeline.

## 1
### title
Tạo TaskModule với dữ liệu mẫu
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `TaskModule`, `TaskService`, `TaskController` bằng CLI hoặc thủ công.
  - Bước 2: Trong `TaskService`, khởi tạo mảng dữ liệu mẫu gồm ít nhất 3 task, mỗi task có `id` (number) và `name` (string).
  - Bước 3: Cài đặt hàm `findAll()` trả toàn bộ mảng task, và hàm `findById(id: number)` trả task theo id hoặc ném `NotFoundException` nếu không tìm thấy.
  - Bước 4: Trong `TaskController`, tạo endpoint `GET /tasks` gọi `findAll()` và `GET /tasks/:id` gọi `findById()`.
- **Kết quả mong đợi:** Gọi `GET /tasks` trả mảng task, gọi `GET /tasks/1` trả task có id = 1.
- **Kết luận:** Module nghiệp vụ cơ bản đã sẵn sàng, các bước tiếp theo sẽ bọc thêm các tầng pipeline xung quanh.

## 2
### title
Triển khai Middleware và Guard
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `LoggerMiddleware` implement `NestMiddleware`. Trong hàm `use()`, ghi log method và URL của request ra console (ví dụ: `[LOG] GET /tasks`).
  - Bước 2: Đăng ký `LoggerMiddleware` trong `AppModule` bằng `configure()` của `NestModule`, apply cho tất cả routes (`forRoutes('*')`).
  - Bước 3: Tạo `RoleGuard` implement `CanActivate`. Kiểm tra header `x-role`: nếu giá trị là `admin` thì trả `true`, ngược lại ném `ForbiddenException`.
  - Bước 4: Gắn `RoleGuard` vào endpoint `GET /tasks/:id` bằng decorator `@UseGuards(RoleGuard)`.
- **Kết quả mong đợi:** Mọi request đều được ghi log. Request đến `GET /tasks/:id` mà không có header `x-role: admin` sẽ bị trả lỗi 403.
- **Kết luận:** Middleware xử lý logging xuyên suốt, Guard kiểm soát quyền truy cập trước khi request vào sâu hơn.

## 3
### title
Triển khai Pipe, Interceptor và Exception Filter
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `ParsePositiveIntPipe` implement `PipeTransform`. Nhận giá trị tham số, parse sang số nguyên. Nếu không phải số dương, ném `BadRequestException`.
  - Bước 2: Gắn `ParsePositiveIntPipe` vào tham số `id` của endpoint `GET /tasks/:id` bằng `@Param('id', ParsePositiveIntPipe)`.
  - Bước 3: Tạo `ResponseInterceptor` implement `NestInterceptor`. Trong hàm `intercept()`, dùng `pipe(map(...))` để bọc data trả về thành `{ data, timestamp: new Date().toISOString() }`.
  - Bước 4: Đăng ký `ResponseInterceptor` ở cấp global bằng `APP_INTERCEPTOR` trong `AppModule`.
  - Bước 5: Tạo `HttpExceptionFilter` implement `ExceptionFilter`. Trong hàm `catch()`, lấy status và message từ exception, trả response JSON dạng `{ statusCode, message, timestamp }`.
  - Bước 6: Đăng ký `HttpExceptionFilter` ở cấp global bằng `APP_FILTER` trong `AppModule`.
- **Kết quả mong đợi:** Request với id không hợp lệ (ví dụ `/tasks/-1` hoặc `/tasks/abc`) bị Pipe chặn trả 400. Response hợp lệ được Interceptor bọc đúng format. Lỗi được Filter format thành JSON an toàn.
- **Kết luận:** Pipe, Interceptor và Filter mỗi thành phần đảm nhận đúng một trách nhiệm, cùng tạo nên pipeline hoàn chỉnh.

## 4
### title
Kiểm thử toàn bộ pipeline
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Gọi endpoint lấy danh sách task (Success path, không qua Guard):
    ```bash
    curl http://localhost:3000/tasks
    ```
    Xác nhận response có format `{ data: [...], timestamp: "..." }`.
  - Bước 3: Gọi endpoint lấy task theo id với header hợp lệ:
    ```bash
    curl -H "x-role: admin" http://localhost:3000/tasks/1
    ```
    Xác nhận trả đúng task và format chuẩn.
  - Bước 4: Gọi endpoint thiếu header role (Guard chặn):
    ```bash
    curl http://localhost:3000/tasks/1
    ```
    Xác nhận trả lỗi 403.
  - Bước 5: Gọi endpoint với id không hợp lệ (Pipe chặn):
    ```bash
    curl -H "x-role: admin" http://localhost:3000/tasks/-1
    ```
    Xác nhận trả lỗi 400.
  - Bước 6: Gọi endpoint với id không tồn tại (NotFoundException từ Service):
    ```bash
    curl -H "x-role: admin" http://localhost:3000/tasks/999
    ```
    Xác nhận trả lỗi 404 qua Exception Filter.
  - Bước 7: Kiểm tra terminal log: mọi request đều phải có dòng log từ `LoggerMiddleware`.
- **Kết quả mong đợi:**
  - `GET /tasks` -> `{ data: [...], timestamp }` (200)
  - `GET /tasks/1` + `x-role: admin` -> `{ data: { id: 1, ... }, timestamp }` (200)
  - `GET /tasks/1` không header -> 403
  - `GET /tasks/-1` + `x-role: admin` -> 400
  - `GET /tasks/999` + `x-role: admin` -> 404
- **Kết luận:** Pipeline hoàn chỉnh đã chứng minh đúng thứ tự: Middleware -> Guard -> Pipe -> Controller -> Interceptor -> Exception Filter.

# references
## 0
### alias
NestJS Request Lifecycle
### url
https://docs.nestjs.com/faq/request-lifecycle
## 1
### alias
NestJS Middleware
### url
https://docs.nestjs.com/middleware
## 2
### alias
NestJS Guards
### url
https://docs.nestjs.com/guards

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
Đủ thành phần pipeline
##### score
10
##### promptText
Có đầy đủ `LoggerMiddleware`, `RoleGuard`, `ParsePositiveIntPipe`, `ResponseInterceptor`, `HttpExceptionFilter` được đăng ký đúng cách.
#### 1
##### title
Đúng kết quả endpoint
##### score
10
##### promptText
`GET /tasks` trả danh sách task bọc trong `{ data, timestamp }`. `GET /tasks/:id` với `x-role: admin` trả đúng task. Thiếu header trả 403, id không hợp lệ trả 400, id không tồn tại trả 404.

# difficulty
easy

# score
20
