# title
Set Up NestJS Core with Module and DI

# description
Initialize a new NestJS project, organize basic modules, and prove Dependency Injection works through a cat-and-dog communication context.

# requirements
Create a NestJS project using the CLI, build a `CatModule` with `CatController` + `CatService`, and add a `DogModule` that reuses `CatService` through the module export/import mechanism. Endpoint `GET /cats/mew` returns `mew~`, endpoint `GET /dogs/bark-at-cat` returns `woof-heard-mew~`.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install

# steps

## 0
### title
Initialize the project using NestJS CLI
### body
- **Steps to follow:**
  - Step 1: Create a new project:
    ```bash
    nest new environment-setup-and-nestjs-core-easy
    ```
  - Step 2: Navigate to the project directory and start the application:
    ```bash
    cd environment-setup-and-nestjs-core-easy
    npm run start:dev
    ```
- **Expected result:** The application runs successfully on the default port, terminal shows NestJS startup logs.
- **Conclusion:** The base project environment is ready for implementing modules and DI.

## 1
### title
Create CatModule and test endpoint
### body
- **Steps to follow:**
  - Step 1: Create the main files for `CatModule` (`cat.module.ts`, `cat.service.ts`, `cat.controller.ts`) using the CLI or manually.
  - Step 2: In `CatService`, implement a `mew(): string` method that returns the string `mew~`.
  - Step 3: In `CatController`, create endpoint `GET /cats/mew` calling `this.catService.mew()`.
  - Step 4: Ensure `CatService` is in `providers` and `CatController` is in `controllers` of `CatModule`.
- **Expected result:** Calling `GET /cats/mew` returns `mew~`.
- **Conclusion:** The cat module works correctly with the Controller -> Service flow.

## 2
### title
Create DogModule reusing CatService via DI
### body
- **Steps to follow:**
  - Step 1: Export `CatService` from `CatModule` via the `exports` array.
  - Step 2: Create `DogModule`, `DogService`, `DogController`.
  - Step 3: Import `CatModule` into `DogModule`.
  - Step 4: Inject `CatService` into the constructor of `DogService`.
  - Step 5: In `DogService`, create a method that returns `woof-heard-${this.catService.mew()}`.
  - Step 6: In `DogController`, create endpoint `GET /dogs/bark-at-cat` returning data from `DogService`.
- **Expected result:** Endpoint `GET /dogs/bark-at-cat` can use data from `CatService` through DI.
- **Conclusion:** The module export/import mechanism and constructor injection are set up correctly.

## 3
### title
Test the successful flow
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Call the endpoint to test the cat module:
    ```bash
    curl http://localhost:3000/cats/mew
    ```
  - Step 3: Call the endpoint to test DogModule reusing CatService:
    ```bash
    curl http://localhost:3000/dogs/bark-at-cat
    ```
- **Expected result:**
  - `GET /cats/mew` returns `mew~`.
  - `GET /dogs/bark-at-cat` returns `woof-heard-mew~`.
- **Conclusion:** If both endpoints return the correct results, the cross-module DI system works correctly.

# references
## 0
### alias
NestJS First Steps
### url
https://docs.nestjs.com/first-steps
## 1
### alias
NestJS Modules
### url
https://docs.nestjs.com/modules

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
Correct module structure and DI
##### score
10
##### promptText
`DogModule` imports `CatModule`, `CatService` is exported and injected correctly, endpoints work as required.
#### 1
##### title
Correct endpoint results
##### score
10
##### promptText
`GET /cats/mew` returns `mew~` and `GET /dogs/bark-at-cat` returns `woof-heard-mew~`.

# difficulty
easy

# score
20
