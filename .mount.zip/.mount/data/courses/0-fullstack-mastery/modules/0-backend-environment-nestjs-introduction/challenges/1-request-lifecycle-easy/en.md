# title
Build a Basic Request Pipeline in NestJS

# description
Create a new NestJS project, implement all components of the request lifecycle (Middleware, Guard, Pipe, Interceptor, Exception Filter) for a chosen domain, and prove each layer handles its own responsibility.

# requirements
Build a NestJS application with a `TaskModule` managing a list of tasks. Implement: `LoggerMiddleware` to log every request, `RoleGuard` to check the `x-role` header, `ParsePositiveIntPipe` to validate the id parameter, `ResponseInterceptor` to standardize response format as `{ data, timestamp }`, and `HttpExceptionFilter` to return safe JSON errors. Endpoint `GET /tasks/:id` returns a task by id, `GET /tasks` returns all tasks.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install

# steps

## 0
### title
Initialize the project
### body
- **Steps to follow:**
  - Step 1: Create a new project using the CLI:
    ```bash
    nest new request-lifecycle-easy
    ```
  - Step 2: Navigate to the project directory:
    ```bash
    cd request-lifecycle-easy
    ```
  - Step 3: Start the application:
    ```bash
    npm run start:dev
    ```
- **Expected result:** The application starts successfully on port 3000, terminal shows NestJS ready logs.
- **Conclusion:** The base environment is ready for implementing pipeline components.

## 1
### title
Create TaskModule with sample data
### body
- **Steps to follow:**
  - Step 1: Create `TaskModule`, `TaskService`, `TaskController` using the CLI or manually.
  - Step 2: In `TaskService`, initialize a sample array with at least 3 tasks, each having `id` (number) and `name` (string).
  - Step 3: Implement `findAll()` returning all tasks, and `findById(id: number)` returning a task by id or throwing `NotFoundException` if not found.
  - Step 4: In `TaskController`, create endpoint `GET /tasks` calling `findAll()` and `GET /tasks/:id` calling `findById()`.
- **Expected result:** `GET /tasks` returns the task array, `GET /tasks/1` returns the task with id = 1.
- **Conclusion:** The core business module is ready; the next steps will wrap pipeline layers around it.

## 2
### title
Implement Middleware and Guard
### body
- **Steps to follow:**
  - Step 1: Create `LoggerMiddleware` implementing `NestMiddleware`. In the `use()` method, log the request method and URL to the console (e.g., `[LOG] GET /tasks`).
  - Step 2: Register `LoggerMiddleware` in `AppModule` using `configure()` from `NestModule`, applied to all routes (`forRoutes('*')`).
  - Step 3: Create `RoleGuard` implementing `CanActivate`. Check the `x-role` header: if the value is `admin`, return `true`; otherwise, throw `ForbiddenException`.
  - Step 4: Attach `RoleGuard` to the `GET /tasks/:id` endpoint using the `@UseGuards(RoleGuard)` decorator.
- **Expected result:** All requests are logged. Requests to `GET /tasks/:id` without the `x-role: admin` header receive a 403 error.
- **Conclusion:** Middleware handles cross-cutting logging, Guard controls access before the request goes deeper.

## 3
### title
Implement Pipe, Interceptor, and Exception Filter
### body
- **Steps to follow:**
  - Step 1: Create `ParsePositiveIntPipe` implementing `PipeTransform`. Parse the parameter value to an integer. If not a positive number, throw `BadRequestException`.
  - Step 2: Attach `ParsePositiveIntPipe` to the `id` parameter of `GET /tasks/:id` using `@Param('id', ParsePositiveIntPipe)`.
  - Step 3: Create `ResponseInterceptor` implementing `NestInterceptor`. In `intercept()`, use `pipe(map(...))` to wrap the returned data as `{ data, timestamp: new Date().toISOString() }`.
  - Step 4: Register `ResponseInterceptor` globally using `APP_INTERCEPTOR` in `AppModule`.
  - Step 5: Create `HttpExceptionFilter` implementing `ExceptionFilter`. In `catch()`, extract status and message from the exception, and return a JSON response as `{ statusCode, message, timestamp }`.
  - Step 6: Register `HttpExceptionFilter` globally using `APP_FILTER` in `AppModule`.
- **Expected result:** Requests with invalid id (e.g., `/tasks/-1` or `/tasks/abc`) are blocked by the Pipe with a 400 error. Valid responses are wrapped by the Interceptor in the correct format. Errors are formatted as safe JSON by the Filter.
- **Conclusion:** Pipe, Interceptor, and Filter each handle exactly one responsibility, forming a complete pipeline.

## 4
### title
Test the entire pipeline
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Call the endpoint to list all tasks (Success path, no Guard):
    ```bash
    curl http://localhost:3000/tasks
    ```
    Verify the response has the format `{ data: [...], timestamp: "..." }`.
  - Step 3: Call the endpoint to get a task by id with a valid header:
    ```bash
    curl -H "x-role: admin" http://localhost:3000/tasks/1
    ```
    Verify it returns the correct task in the standard format.
  - Step 4: Call the endpoint without the role header (Guard blocks):
    ```bash
    curl http://localhost:3000/tasks/1
    ```
    Verify it returns a 403 error.
  - Step 5: Call the endpoint with an invalid id (Pipe blocks):
    ```bash
    curl -H "x-role: admin" http://localhost:3000/tasks/-1
    ```
    Verify it returns a 400 error.
  - Step 6: Call the endpoint with a non-existent id (NotFoundException from Service):
    ```bash
    curl -H "x-role: admin" http://localhost:3000/tasks/999
    ```
    Verify it returns a 404 error through the Exception Filter.
  - Step 7: Check the terminal logs: every request must have a log entry from `LoggerMiddleware`.
- **Expected result:**
  - `GET /tasks` -> `{ data: [...], timestamp }` (200)
  - `GET /tasks/1` + `x-role: admin` -> `{ data: { id: 1, ... }, timestamp }` (200)
  - `GET /tasks/1` without header -> 403
  - `GET /tasks/-1` + `x-role: admin` -> 400
  - `GET /tasks/999` + `x-role: admin` -> 404
- **Conclusion:** The complete pipeline proves the correct order: Middleware -> Guard -> Pipe -> Controller -> Interceptor -> Exception Filter.

# references
## 0
### alias
NestJS Request Lifecycle
### url
https://docs.nestjs.com/faq/request-lifecycle
## 1
### alias
NestJS Middleware
### url
https://docs.nestjs.com/middleware
## 2
### alias
NestJS Guards
### url
https://docs.nestjs.com/guards

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
All pipeline components present
##### score
10
##### promptText
Has `LoggerMiddleware`, `RoleGuard`, `ParsePositiveIntPipe`, `ResponseInterceptor`, `HttpExceptionFilter` all registered correctly.
#### 1
##### title
Correct endpoint results
##### score
10
##### promptText
`GET /tasks` returns the task list wrapped in `{ data, timestamp }`. `GET /tasks/:id` with `x-role: admin` returns the correct task. Missing header returns 403, invalid id returns 400, non-existent id returns 404.

# difficulty
easy

# score
20
