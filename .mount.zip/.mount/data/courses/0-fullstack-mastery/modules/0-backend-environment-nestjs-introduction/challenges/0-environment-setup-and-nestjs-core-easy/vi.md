# title
Thiết lập NestJS Core với Module và DI

# description
Khởi tạo một project NestJS mới, tổ chức module cơ bản và chứng minh Dependency Injection hoạt động qua ngữ cảnh giao tiếp giữa mèo và chó.

# requirements
Tạo project NestJS bằng CLI, xây dựng `CatModule` với `CatController` + `CatService`, và thêm `DogModule` gọi lại `CatService` thông qua cơ chế export/import module. Endpoint `/cats/mew` trả `mew~`, endpoint `/dogs/bark-at-cat` trả `woof-heard-mew~`.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install

# steps

## 0
### title
Khởi tạo project bằng NestJS CLI
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy lệnh tạo project mới:
    ```bash
    nest new environment-setup-and-nestjs-core-easy
    ```
  - Bước 2: Di chuyển vào thư mục project và chạy ứng dụng:
    ```bash
    cd environment-setup-and-nestjs-core-easy
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng chạy thành công trên cổng mặc định, terminal hiển thị log NestJS đã khởi động.
- **Kết luận:** Môi trường dự án nền đã sẵn sàng để triển khai module và DI.

## 1
### title
Tạo CatModule và endpoint kiểm tra
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo các file chính của `CatModule` (`cat.module.ts`, `cat.service.ts`, `cat.controller.ts`) bằng CLI hoặc thủ công.
  - Bước 2: Trong `CatService`, cài đặt hàm `mew(): string` và trả đúng chuỗi `mew~`.
  - Bước 3: Trong `CatController`, tạo endpoint `GET /cats/mew` gọi `this.catService.mew()`.
  - Bước 4: Kiểm tra `CatService` nằm trong `providers` và `CatController` nằm trong `controllers` của `CatModule`.
- **Kết quả mong đợi:** Gọi `GET /cats/mew` trả về đúng `mew~`.
- **Kết luận:** Module mèo đã hoạt động đúng với luồng Controller -> Service.

## 2
### title
Tạo DogModule dùng lại CatService qua DI
### body
- **Các bước thực hiện:**
  - Bước 1: Export `CatService` trong `CatModule` qua mảng `exports`.
  - Bước 2: Tạo `DogModule`, `DogService`, `DogController`.
  - Bước 3: Import `CatModule` vào `DogModule`.
  - Bước 4: Inject `CatService` vào constructor của `DogService`.
  - Bước 5: Trong `DogService`, tạo hàm trả `woof-heard-${this.catService.mew()}`.
  - Bước 6: Trong `DogController`, tạo endpoint `GET /dogs/bark-at-cat` và trả dữ liệu từ `DogService`.
- **Kết quả mong đợi:** Endpoint `GET /dogs/bark-at-cat` có thể dùng được dữ liệu từ `CatService` thông qua DI.
- **Kết luận:** Cơ chế export/import module và constructor injection đã được thiết lập đúng.

## 3
### title
Kiểm thử luồng thành công
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Gọi endpoint kiểm tra module mèo:
    ```bash
    curl http://localhost:3000/cats/mew
    ```
  - Bước 3: Gọi endpoint kiểm tra DogModule dùng lại CatService:
    ```bash
    curl http://localhost:3000/dogs/bark-at-cat
    ```
- **Kết quả mong đợi:**
  - `GET /cats/mew` trả `mew~`.
  - `GET /dogs/bark-at-cat` trả `woof-heard-mew~`.
- **Kết luận:** Nếu cả hai endpoint trả đúng kết quả, hệ thống DI xuyên module đã hoạt động chính xác.

# references
## 0
### alias
NestJS First Steps
### url
https://docs.nestjs.com/first-steps
## 1
### alias
NestJS Modules
### url
https://docs.nestjs.com/modules

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
Đúng cấu trúc module và DI
##### score
10
##### promptText
`DogModule` có import `CatModule`, `CatService` được export và inject đúng cách, endpoint hoạt động theo yêu cầu.
#### 1
##### title
Đúng kết quả endpoint
##### score
10
##### promptText
`GET /cats/mew` trả `mew~` và `GET /dogs/bark-at-cat` trả `woof-heard-mew~`.

# difficulty
easy

# score
20
