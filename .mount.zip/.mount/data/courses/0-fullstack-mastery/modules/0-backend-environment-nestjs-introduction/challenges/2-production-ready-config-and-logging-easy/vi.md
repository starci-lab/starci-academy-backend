# title
Cấu hình Multi-Environment và Logging cơ bản với NestJS

# description
Tạo một project NestJS mới, thiết lập hệ thống cấu hình đa môi trường bằng ConfigModule với registerAs(), tích hợp Winston Logger, và xây dựng Response Interceptor + Exception Filter chuẩn hoá output cho toàn bộ ứng dụng.

# requirements
Xây dựng ứng dụng NestJS với `BookModule` quản lý danh sách sách. Thiết lập `ConfigModule` với 2 file `.env.local` và `.env.production`, dùng `registerAs()` tạo namespace `app` chứa `port` và `environment`. Tích hợp **Winston** thay thế logger mặc định: ở local log dạng text ra console, ở production log dạng JSON. Triển khai `ResponseInterceptor` bọc mọi response thành `{ statusCode, message, data }` và `AllExceptionsFilter` trả lỗi JSON an toàn không lộ stack trace.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install

# steps

## 0
### title
Khởi tạo project và cài đặt dependencies
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới:
    ```bash
    nest new production-ready-config-and-logging-easy
    ```
  - Bước 2: Di chuyển vào thư mục project:
    ```bash
    cd production-ready-config-and-logging-easy
    ```
  - Bước 3: Cài đặt các package cần thiết:
    ```bash
    npm install @nestjs/config winston nest-winston
    ```
  - Bước 4: Chạy thử ứng dụng:
    ```bash
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng khởi động thành công, các package config và winston đã được cài.
- **Kết luận:** Môi trường nền và dependencies đã sẵn sàng cho việc thiết lập cấu hình và logging.

## 1
### title
Thiết lập ConfigModule đa môi trường
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `.env.local` ở thư mục gốc project với nội dung:
    ```
    APP_PORT=3000
    APP_ENV=local
    ```
  - Bước 2: Tạo file `.env.production` với nội dung:
    ```
    APP_PORT=8080
    APP_ENV=production
    ```
  - Bước 3: Tạo file config `src/config/app.config.ts`, dùng `registerAs('app', ...)` để đăng ký namespace `app` đọc biến `APP_PORT` và `APP_ENV`.
  - Bước 4: Đăng ký `ConfigModule.forRoot()` trong `AppModule` với option `isGlobal: true` và `envFilePath` dựa trên `NODE_ENV` (mặc định load `.env.local`).
  - Bước 5: Tạo endpoint `GET /config` trong `AppController` inject `ConfigService`, trả về `{ port, environment }` để xác nhận config đã load đúng.
- **Kết quả mong đợi:** Gọi `GET /config` trả đúng giá trị từ file `.env.local`. Khi chạy với `NODE_ENV=production`, trả giá trị từ `.env.production`.
- **Kết luận:** Hệ thống cấu hình đa môi trường hoạt động chính xác, thay đổi môi trường chỉ cần thay biến `NODE_ENV`.

## 2
### title
Tích hợp Winston Logger
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `src/config/winston.config.ts` cấu hình Winston với 2 transport:
    - Console transport: format dạng text có màu cho môi trường local.
    - Console transport dạng JSON cho môi trường production.
  - Bước 2: Đăng ký `WinstonModule.forRootAsync()` trong `AppModule`, inject `ConfigService` để quyết định transport dựa trên biến `APP_ENV`.
  - Bước 3: Trong `BookService`, inject logger (`@Inject(WINSTON_MODULE_PROVIDER)`) và ghi log khi truy vấn sách.
- **Kết quả mong đợi:** Ở local, log hiển thị dạng text có màu. Khi chạy với `NODE_ENV=production`, log chuyển sang JSON có cấu trúc.
- **Kết luận:** Winston thay thế hoàn toàn logger mặc định, output thay đổi tự động theo môi trường.

## 3
### title
Triển khai BookModule, ResponseInterceptor và AllExceptionsFilter
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `BookModule`, `BookService`, `BookController`.
  - Bước 2: Trong `BookService`, khởi tạo mảng dữ liệu mẫu gồm ít nhất 3 cuốn sách, mỗi cuốn có `id`, `title`, `author`. Cài đặt hàm `findAll()` và `findById(id)` (ném `NotFoundException` nếu không tìm thấy).
  - Bước 3: Tạo `ResponseInterceptor` bọc mọi response thành `{ statusCode: 200, message: 'Success', data: ... }`.
  - Bước 4: Tạo `AllExceptionsFilter` bắt mọi exception, ghi log lỗi qua Winston, và trả response dạng `{ statusCode, message, timestamp }` không chứa stack trace.
  - Bước 5: Đăng ký cả hai ở cấp global trong `AppModule` bằng `APP_INTERCEPTOR` và `APP_FILTER`.
- **Kết quả mong đợi:** Mọi response thành công được bọc đúng format. Mọi lỗi trả JSON an toàn và được ghi log chi tiết phía server.
- **Kết luận:** Response và error handling đã được chuẩn hoá cho toàn bộ ứng dụng.

## 4
### title
Kiểm thử toàn bộ hệ thống
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng ở chế độ local:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Kiểm tra config đã load đúng:
    ```bash
    curl http://localhost:3000/config
    ```
    Xác nhận trả `{ port: 3000, environment: "local" }` bọc trong response chuẩn.
  - Bước 3: Lấy danh sách sách:
    ```bash
    curl http://localhost:3000/books
    ```
    Xác nhận response có format `{ statusCode: 200, message: "Success", data: [...] }`.
  - Bước 4: Lấy sách theo id hợp lệ:
    ```bash
    curl http://localhost:3000/books/1
    ```
  - Bước 5: Lấy sách theo id không tồn tại (kiểm tra Exception Filter):
    ```bash
    curl http://localhost:3000/books/999
    ```
    Xác nhận trả lỗi 404 dạng `{ statusCode: 404, message: "...", timestamp: "..." }`, không lộ stack trace.
  - Bước 6: Kiểm tra terminal log: Winston phải ghi log chi tiết cho request thành công lẫn lỗi.
  - Bước 7 (tuỳ chọn): Chạy lại với `NODE_ENV=production` và so sánh format log.
- **Kết quả mong đợi:**
  - `GET /config` -> config đúng theo môi trường.
  - `GET /books` -> danh sách sách bọc chuẩn format.
  - `GET /books/1` -> sách cụ thể bọc chuẩn format.
  - `GET /books/999` -> lỗi 404 JSON an toàn.
  - Log trên terminal đúng format theo môi trường.
- **Kết luận:** Hệ thống cấu hình, logging và chuẩn hoá response/error đã hoạt động đầy đủ, sẵn sàng cho production.

# references
## 0
### alias
NestJS Configuration
### url
https://docs.nestjs.com/techniques/configuration
## 1
### alias
Winston Logger for NestJS
### url
https://github.com/gremo/nest-winston
## 2
### alias
NestJS Exception Filters
### url
https://docs.nestjs.com/exception-filters

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
ConfigModule và Winston đúng cấu hình
##### score
10
##### promptText
`ConfigModule` dùng `registerAs()` với namespace, `WinstonModule` tích hợp đúng với `ConfigService`, log format thay đổi theo môi trường.
#### 1
##### title
Response/Error chuẩn hoá và endpoint đúng
##### score
10
##### promptText
`ResponseInterceptor` bọc response thành `{ statusCode, message, data }`. `AllExceptionsFilter` trả lỗi JSON an toàn. `GET /books` và `GET /books/:id` hoạt động đúng, `GET /books/999` trả 404.

# difficulty
easy

# score
20
