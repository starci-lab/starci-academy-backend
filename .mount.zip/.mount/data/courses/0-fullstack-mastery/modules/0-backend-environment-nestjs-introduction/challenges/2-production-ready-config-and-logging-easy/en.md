# title
Basic Multi-Environment Config and Logging with NestJS

# description
Create a new NestJS project, set up a multi-environment configuration system using ConfigModule with registerAs(), integrate Winston Logger, and build a Response Interceptor + Exception Filter to standardize output across the entire application.

# requirements
Build a NestJS application with a `BookModule` managing a list of books. Set up `ConfigModule` with 2 files `.env.local` and `.env.production`, using `registerAs()` to create an `app` namespace containing `port` and `environment`. Integrate **Winston** to replace the default logger: in local mode log as text to the console, in production mode log as JSON. Implement `ResponseInterceptor` wrapping every response as `{ statusCode, message, data }` and `AllExceptionsFilter` returning safe JSON errors without exposing stack traces.

# prerequisites
- Node.js >= 18
- NestJS CLI
- npm install

# steps

## 0
### title
Initialize the project and install dependencies
### body
- **Steps to follow:**
  - Step 1: Create a new project:
    ```bash
    nest new production-ready-config-and-logging-easy
    ```
  - Step 2: Navigate to the project directory:
    ```bash
    cd production-ready-config-and-logging-easy
    ```
  - Step 3: Install required packages:
    ```bash
    npm install @nestjs/config winston nest-winston
    ```
  - Step 4: Start the application:
    ```bash
    npm run start:dev
    ```
- **Expected result:** The application starts successfully, config and winston packages are installed.
- **Conclusion:** The base environment and dependencies are ready for setting up configuration and logging.

## 1
### title
Set up ConfigModule for multiple environments
### body
- **Steps to follow:**
  - Step 1: Create a `.env.local` file at the project root with the content:
    ```
    APP_PORT=3000
    APP_ENV=local
    ```
  - Step 2: Create a `.env.production` file with the content:
    ```
    APP_PORT=8080
    APP_ENV=production
    ```
  - Step 3: Create a config file `src/config/app.config.ts`, using `registerAs('app', ...)` to register the `app` namespace reading `APP_PORT` and `APP_ENV` variables.
  - Step 4: Register `ConfigModule.forRoot()` in `AppModule` with `isGlobal: true` option and `envFilePath` based on `NODE_ENV` (defaults to loading `.env.local`).
  - Step 5: Create a `GET /config` endpoint in `AppController` that injects `ConfigService` and returns `{ port, environment }` to confirm the config loaded correctly.
- **Expected result:** Calling `GET /config` returns the correct values from `.env.local`. When running with `NODE_ENV=production`, it returns values from `.env.production`.
- **Conclusion:** The multi-environment configuration system works correctly; switching environments only requires changing the `NODE_ENV` variable.

## 2
### title
Integrate Winston Logger
### body
- **Steps to follow:**
  - Step 1: Create `src/config/winston.config.ts` configuring Winston with 2 transports:
    - Console transport: text format with colors for the local environment.
    - Console transport with JSON format for the production environment.
  - Step 2: Register `WinstonModule.forRootAsync()` in `AppModule`, injecting `ConfigService` to determine the transport based on the `APP_ENV` variable.
  - Step 3: In `BookService`, inject the logger (`@Inject(WINSTON_MODULE_PROVIDER)`) and log when querying books.
- **Expected result:** In local mode, logs display as colored text. When running with `NODE_ENV=production`, logs switch to structured JSON.
- **Conclusion:** Winston fully replaces the default logger, and output changes automatically based on the environment.

## 3
### title
Implement BookModule, ResponseInterceptor, and AllExceptionsFilter
### body
- **Steps to follow:**
  - Step 1: Create `BookModule`, `BookService`, `BookController`.
  - Step 2: In `BookService`, initialize a sample data array with at least 3 books, each having `id`, `title`, `author`. Implement `findAll()` and `findById(id)` (throw `NotFoundException` if not found).
  - Step 3: Create `ResponseInterceptor` wrapping every response as `{ statusCode: 200, message: 'Success', data: ... }`.
  - Step 4: Create `AllExceptionsFilter` catching all unhandled exceptions, logging errors via Winston, and returning a response as `{ statusCode, message, timestamp }` without stack traces.
  - Step 5: Register both globally in `AppModule` using `APP_INTERCEPTOR` and `APP_FILTER`.
- **Expected result:** All successful responses are wrapped in the correct format. All errors return safe JSON and are logged in detail on the server.
- **Conclusion:** Response and error handling are standardized across the entire application.

## 4
### title
Test the entire system
### body
- **Steps to follow:**
  - Step 1: Start the application in local mode:
    ```bash
    npm run start:dev
    ```
  - Step 2: Verify the config loaded correctly:
    ```bash
    curl http://localhost:3000/config
    ```
    Confirm it returns `{ port: 3000, environment: "local" }` wrapped in the standard response.
  - Step 3: Get the list of books:
    ```bash
    curl http://localhost:3000/books
    ```
    Confirm the response has the format `{ statusCode: 200, message: "Success", data: [...] }`.
  - Step 4: Get a book by valid id:
    ```bash
    curl http://localhost:3000/books/1
    ```
  - Step 5: Get a book by non-existent id (test Exception Filter):
    ```bash
    curl http://localhost:3000/books/999
    ```
    Confirm it returns a 404 error as `{ statusCode: 404, message: "...", timestamp: "..." }` without exposing stack traces.
  - Step 6: Check terminal logs: Winston must log details for both successful requests and errors.
  - Step 7 (optional): Run again with `NODE_ENV=production` and compare log formats.
- **Expected result:**
  - `GET /config` -> correct config per environment.
  - `GET /books` -> book list wrapped in standard format.
  - `GET /books/1` -> specific book wrapped in standard format.
  - `GET /books/999` -> safe 404 JSON error.
  - Terminal logs in the correct format per environment.
- **Conclusion:** The configuration, logging, and response/error standardization system works fully and is production-ready.

# references
## 0
### alias
NestJS Configuration
### url
https://docs.nestjs.com/techniques/configuration
## 1
### alias
Winston Logger for NestJS
### url
https://github.com/gremo/nest-winston
## 2
### alias
NestJS Exception Filters
### url
https://docs.nestjs.com/exception-filters

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
ConfigModule and Winston correctly configured
##### score
10
##### promptText
`ConfigModule` uses `registerAs()` with namespaces, `WinstonModule` is properly integrated with `ConfigService`, log format changes based on environment.
#### 1
##### title
Response/Error standardized and endpoints correct
##### score
10
##### promptText
`ResponseInterceptor` wraps responses as `{ statusCode, message, data }`. `AllExceptionsFilter` returns safe JSON errors. `GET /books` and `GET /books/:id` work correctly, `GET /books/999` returns 404.

# difficulty
easy

# score
20
