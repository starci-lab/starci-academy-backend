# title
Environment Setup, NestJS Core & Dependency Injection

# description
Set up a robust Node.js environment, initialize a NestJS application using the CLI, understand the production folder structure, and master Dependency Injection with the Module System.

# body

## I. Introduction

Most beginners start backend development by writing a single **Express** file, manually importing every dependency, and calling `new` on every class. This works for a weekend prototype, but the moment a second developer joins or the project grows past a few endpoints, the codebase turns into a tangled mess of circular imports, untestable singletons, and copy-pasted boilerplate.

**NestJS** was designed to eliminate these problems from day one. It enforces a strict modular architecture, replaces manual instantiation with **Dependency Injection (DI)**, and provides a **CLI** that scaffolds production-grade projects in seconds. Before writing any business logic, the first step is to build the right environment and understand the core mechanisms that make **NestJS** fundamentally different from a raw **Express** setup.

## II. Core Concepts

### 1. Setting up the Environment

A stable development environment is the foundation of every backend project. Without version control on the runtime itself, teams quickly run into "works on my machine" issues.

- **Example:** Use an **LTS** (Long Term Support) version of **Node.js** (e.g., **v18** or **v20**). Install **nvm** (Node Version Manager) so you can switch versions per project. For the package manager, prefer **pnpm** or **yarn** over the default **npm** for faster installs and stricter lockfiles.

### 2. Initializing a NestJS Application

**NestJS** provides a powerful **CLI** that scaffolds applications following standardized architectural patterns, saving hours of manual setup.

- **Example:** Install the CLI globally and create a new project:

```bash
npm i -g @nestjs/cli
nest new starci-backend
```

The generated project includes a root module, a sample controller, and a sample service, all wired together out of the box.

### 3. Understanding the Folder Structure

A freshly scaffolded **NestJS** project contains four key files that define the entire application skeleton.

- **Example:** The default files and their roles:
    - `main.ts` is the entry file. It uses **NestFactory** to create the application instance and start the **HTTP** listener.
    - `app.module.ts` is the root module that bundles all feature modules together.
    - `app.controller.ts` is a basic routing controller that maps **HTTP** verbs to handler methods.
    - `app.service.ts` holds the business logic, separated from the routing layer.

### 4. Structuring for Production

The default flat structure works for tutorials but collapses under real team collaboration. Production applications use **domain-driven** grouping.

- **Example:** Instead of one `controllers/` folder and one `services/` folder, group files by feature:

```text
src/
├── modules/
│   ├── users/
│   │   ├── dto/
│   │   ├── users.controller.ts
│   │   ├── users.service.ts
│   │   └── users.module.ts
│   ├── orders/
│   ...
├── shared/
│   ├── interceptors/
│   ├── filters/
│   ...
```

Each module owns its controllers, services, and DTOs, so scaling the team does not create merge-conflict nightmares.

### 5. Dependency Injection

In traditional **Express** code, developers manually import classes and call `new` to wire dependencies together. This hard-codes relationships and makes unit testing extremely difficult because you cannot swap implementations.

- **Example:** The old way versus the **NestJS** way:

```typescript
// Old: manual instantiation
const userService = new UserService(new DatabaseConnection());

// NestJS: the framework handles it
@Injectable()
export class UserService { ... }

@Controller('users')
export class UserController {
  constructor(private readonly userService: UserService) {}
}
```

By decorating a class with `@Injectable()`, you hand the responsibility of creating and managing instances to the **IoC Container**. The framework guarantees that each provider is a **Singleton** by default, meaning only one instance lives in memory regardless of how many consumers inject it.

### 6. The Module System

A `@Module()` decorator defines a bounded context. It declares which **Controllers** handle incoming requests and which **Providers** contain the logic.

- **Example 1:** Encapsulation. By default, providers inside a module are completely private. If `OrderModule` needs `UserService`, the application crashes unless `UserModule` explicitly exports it:

```typescript
@Module({
  controllers: [UserController],
  providers: [UserService],
  exports: [UserService],
})
export class UserModule {}
```

- **Example 2:** Global modules. For cross-cutting utilities like `ConfigService` or `DatabaseService`, manually importing their module everywhere is tedious. The `@Global()` decorator makes a module available application-wide, but it should be used sparingly to avoid hidden coupling.

## III. Practice

> **Source code:** [Environment Setup and NestJS Core](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/environment-setup-and-nestjs-core)

### 1. Setup & Run

- **Execution Steps:**
    - Step 1: Clone the repository and navigate into the project folder.
    - Step 2: Install all dependencies:

```bash
npm install
```

  - Step 3: Start the development server:

```bash
npm run start:dev
```

- **Expected Results:**
    - The terminal prints a **NestJS** bootstrap message confirming the application is listening on the default port.
    - No compilation errors appear in the console.

- **Conclusion:** A single `npm install` followed by `npm run start:dev` is all it takes to have a fully functional **NestJS** development server running locally.

### 2. Architecture

- **Execution Steps:**
    - Step 1: Open the `src/` directory and examine the module structure.
    - Step 2: Identify the two feature modules: **CatModule** and **DogModule**.

- **Expected Results:**
    - **CatModule** contains **CatController**, **CatService**, **CatFoodService**, and **CatHealthService**, demonstrating a multi-provider **DI** chain within a single module.
    - **DogModule** imports **CatModule** and its **DogService** injects **CatService**, demonstrating cross-module dependency sharing via `exports`.
    - The root **AppModule** imports both feature modules.

- **Conclusion:** The architecture proves that **NestJS** modules act as encapsulation boundaries. A service from one module can only be consumed by another module if it is explicitly exported.

### 3. System Flow

- **Execution Steps:**
    - Step 1: Trace the application startup from **AppModule**.
    - Step 2: Follow how **AppModule** loads **CatModule** (which registers **CatController**, **CatService**, **CatFoodService**, and **CatHealthService**) and **DogModule** (which imports **CatModule** to access **CatService**).

- **Expected Results:**
    - **CatController** exposes cat-related endpoints. **CatService** delegates to **CatFoodService** and **CatHealthService** via constructor injection.
    - **DogModule** does not duplicate cat logic; it reuses **CatService** through the module `exports` mechanism.
    - All providers are **Singletons**, so only one instance of each service exists across the entire application.

- **Conclusion:** The system flow confirms that **Dependency Injection** and the **Module System** work together to eliminate manual instantiation and enforce clean architectural boundaries.

### 4. Try it out

**Success path:**

- **Execution Steps:**
    - Step 1: Send a request to retrieve all cats:

```bash
curl http://localhost:3000/cats
```

  - Step 2: Check the health status of the cats:

```bash
curl http://localhost:3000/cats/status
```

  - Step 3: Feed a cat with a specific food:

```bash
curl http://localhost:3000/cats/feed/tuna
```

- **Expected Results:**
    - `GET /cats` returns the list of cats managed by **CatService**.
    - `GET /cats/status` returns health information provided by **CatHealthService**.
    - `GET /cats/feed/tuna` returns a feeding confirmation from **CatFoodService**.

- **Conclusion:** Each endpoint delegates to the correct service through **constructor injection**, confirming that the **IoC Container** resolves the full dependency chain automatically.

**Failure path:**

- **Execution Steps:**
    - Step 1: Send a request that exercises cross-module injection via the dog spy endpoint:

```bash
curl http://localhost:3000/dogs/spy
```

  - Step 2: Attempt to steal food through the dog module, which internally relies on **CatService**:

```bash
curl http://localhost:3000/dogs/steal/salmon
```

- **Expected Results:**
    - `GET /dogs/spy` returns data that **DogService** obtained by calling **CatService**, proving cross-module injection works.
    - `GET /dogs/steal/salmon` returns a result showing **DogService** interacting with the cat feeding logic through the shared **CatService** singleton.

- **Conclusion:** The failure path demonstrates that cross-module dependencies only function because **CatModule** explicitly exports **CatService**. Without that export, **NestJS** would throw a runtime error during bootstrap.

## IV. Conclusion

A well-configured environment with **Node.js** version management and a modern package manager eliminates setup friction. The **NestJS CLI** scaffolds a project that already follows modular conventions. The folder structure should be organized by feature domain, not by technical layer, so that teams can scale without conflict. **Dependency Injection** through `@Injectable()` and the **IoC Container** replaces manual `new` calls, ensuring every provider is a testable, swappable **Singleton**. The **Module System** enforces encapsulation by keeping providers private unless explicitly exported, and `@Global()` modules should be reserved for truly cross-cutting concerns.

**Conclusion:** Think of every `@Module()` as a contract: it declares exactly what it exposes and what it consumes. Master this boundary-driven thinking early, because every advanced pattern in **NestJS**, from microservices to dynamic modules, builds directly on top of it.

# references
## 0
### alias
NestJS First Steps
### url
https://docs.nestjs.com/first-steps
## 1
### alias
Providers in NestJS
### url
https://docs.nestjs.com/providers

# minutesRead
25
