# title
Cấu hình Multi-Environment và Logging Production-Ready

# description
Thiết lập hệ thống cấu hình đa môi trường với ConfigModule, tích hợp Winston Logger với nhiều transport, và xây dựng pipeline logging chuyên nghiệp sẵn sàng cho production.

# body

## I. Lời mở đầu

Nhiều lập trình viên khi phát triển ứng dụng **NestJS** thường hardcode thông tin cấu hình như database password, API key trực tiếp vào mã nguồn, và sử dụng `console.log` để ghi log. Cách làm này hoạt động ổn trên máy cá nhân, nhưng khi triển khai lên **production**, mọi thứ sụp đổ: thông tin nhạy cảm bị lộ qua git, log không có cấu trúc khiến hệ thống giám sát không thể truy vấn, và không có cách nào phân biệt cấu hình giữa các môi trường.

Bài học này giải quyết **3 vấn đề cốt lõi**: quản lý cấu hình đa môi trường bằng **ConfigModule** với **registerAs()**, thay thế logger mặc định bằng **Winston** với nhiều transport (Console, File, Loki), và kết nối chúng lại thành một pipeline logging chuyên nghiệp sẵn sàng cho production.

## II. Nội dung chính

### 1. Quản lý cấu hình đa môi trường (ConfigModule)

Mọi thông tin nhạy cảm và thông số thay đổi theo môi trường phải được tách ra khỏi mã nguồn, lưu trong file `.env` và truy cập thông qua **ConfigService**. **NestJS** cung cấp `@nestjs/config` để giải quyết bài toán này một cách có hệ thống.

- **Vi du 1:** Thay vì viết `process.env.DATABASE_HOST` rải rác trong code, bạn tạo các file cấu hình riêng cho từng môi trường: `.env.local` cho phát triển và `.env.production` cho triển khai. **ConfigModule** tự động load đúng file dựa trên biến `NODE_ENV`, và nếu thiếu biến bắt buộc, ứng dụng sẽ dừng ngay khi khởi động thay vì chạy rồi mới crash.

- **Vi du 2:** Sử dụng **registerAs()** để nhóm các biến cấu hình thành namespace. Thay vì gọi `configService.get('DATABASE_HOST')`, `configService.get('DATABASE_PORT')` rời rạc, bạn đăng ký namespace `database` và truy cập `configService.get('database.host')`, `configService.get('database.port')`. Cách này giúp cấu hình có tổ chức và dễ quản lý khi số lượng biến tăng lên.

### 2. Winston Logger và hệ thống Transport

Logger mặc định của **NestJS** in text có màu ra console, rất đẹp để đọc bằng mắt nhưng hoàn toàn vô dụng cho production. Các hệ thống giám sát như **Grafana Loki**, **Datadog**, **ElasticSearch** yêu cầu log dạng **JSON** có cấu trúc để có thể truy vấn, filter và tạo alert tự động.

- **Vi du 1:** **Winston** cho phép cấu hình nhiều **transport** đồng thời: **Console transport** để hiển thị log trên terminal khi phát triển, **File transport** để ghi log vào file cho mục đích audit, và **Loki transport** để đẩy log lên **Grafana Loki** cho việc giám sát tập trung. Mỗi transport có thể cấu hình level riêng, ví dụ console hiển thị mọi level còn file chỉ ghi từ `warn` trở lên.

- **Vi du 2:** Tích hợp Winston vào NestJS thông qua **WinstonModule.forRootAsync** kết hợp với **ConfigService**. Cách này cho phép cấu hình logger dựa trên biến môi trường: ở local chỉ bật console transport, ở production bật thêm file và Loki transport. Logger được đăng ký global nên mọi module trong ứng dụng đều có thể inject và sử dụng.

### 3. Chuẩn hoá Response và Exception Filter

Một ứng dụng production-ready không chỉ cần cấu hình và logging tốt mà còn cần chuẩn hoá cách trả dữ liệu cho client. **Response Interceptor** đóng gói mọi response thành format thống nhất, còn **Exception Filter** đảm bảo lỗi không bao giờ lộ thông tin nội bộ ra ngoài.

- **Vi du 1:** **ResponseInterceptor** cấp global nhận data thô từ controller và đóng gói thành `{ "statusCode": 200, "message": "Success", "data": { ... } }`. Frontend chỉ cần xử lý một format duy nhất cho mọi endpoint.

- **Vi du 2:** **AllExceptionsFilter** bắt mọi exception chưa được xử lý, ghi log chi tiết (bao gồm stack trace, request info) vào hệ thống **Winston**, và trả về client một JSON an toàn không chứa thông tin nhạy cảm như SQL query hay IP server.

## III. Thực hành

> **Source code:** [Production-Ready Config and Logging](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/production-ready-config-and-logging)

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
  - Bước 1: Clone repository từ GitHub về máy.
  - Bước 2: Cài đặt dependencies:
    ```bash
    npm install
    ```
  - Bước 3: Khởi chạy ứng dụng ở chế độ local (mặc định):
    ```bash
    npm run start:dev
    ```
  - Bước 4: Khởi chạy ứng dụng ở chế độ production để so sánh:
    ```bash
    $env:NODE_ENV="production"; npm run start:dev
    ```
- **Kết quả mong đợi:** Ở chế độ local, ứng dụng load cấu hình từ `.env.local` và log ra console. Ở chế độ production, ứng dụng load cấu hình từ `.env.production` và bật thêm các transport như file hoặc **Loki**.
- **Kết luận:** Chỉ cần thay đổi biến `NODE_ENV`, toàn bộ cấu hình và hành vi logging tự động chuyển đổi mà không cần sửa code.

### 2. Kiến trúc (Architecture)

- **Các bước thực hiện:**
  - Bước 1: Mở thư mục `src/` và xác định cấu trúc cấu hình: các file `.env.local`, `.env.production` ở thư mục gốc, các file **registerAs()** config trong thư mục config.
  - Bước 2: Xem cách **WinstonModule.forRootAsync** được cấu hình trong `AppModule`, sử dụng **ConfigService** để đọc biến môi trường và khởi tạo các transport tương ứng.
  - Bước 3: Xác định vị trí đăng ký global của **Response Interceptor** và **Exception Filter**.
- **Kết quả mong đợi:** Hiểu được cách các file cấu hình, module Winston, interceptor và filter được tổ chức và kết nối với nhau trong kiến trúc ứng dụng.
- **Kết luận:** Kiến trúc production-ready tách biệt rõ ràng giữa cấu hình (config), logging (Winston), và xử lý response/error (interceptor/filter).

### 3. Luồng hệ thống (System Flow)

- **Các bước thực hiện:**
  - Bước 1: Theo dõi luồng khởi tạo: **NestJS** đọc `NODE_ENV` -> load file `.env` tương ứng -> **ConfigModule** parse và validate -> **WinstonModule** nhận config và khởi tạo các transport -> ứng dụng sẵn sàng.
  - Bước 2: Theo dõi luồng runtime khi có request: controller xử lý -> **ResponseInterceptor** đóng gói response -> nếu có lỗi, **ExceptionFilter** bắt và format -> **Winston** ghi log theo transport đã cấu hình.
  - Bước 3: So sánh log output giữa chế độ local và production. Local hiển thị log dạng text trên console, production ghi log dạng **JSON** có cấu trúc.
- **Kết quả mong đợi:** Nắm được toàn bộ luồng từ khởi tạo đến runtime, và cách môi trường ảnh hưởng đến hành vi logging.
- **Kết luận:** Mọi thành phần từ config đến logging đều được điều khiển bởi biến môi trường, đảm bảo cùng một codebase chạy đúng ở mọi môi trường.

### 4. Thử nghiệm (Try it out)

- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng ở chế độ local và gửi request thành công (Success path):
    ```bash
    curl http://localhost:3000/
    ```
    Quan sát log trên console và kiểm tra format response trả về.
  - Bước 2: Gửi request gây lỗi để kiểm tra Exception Filter (Failure path):
    ```bash
    curl http://localhost:3000/error
    ```
    Xác nhận response trả về JSON an toàn, không chứa stack trace. Kiểm tra log trên console xem lỗi chi tiết có được ghi lại không.
  - Bước 3: Chuyển sang chế độ production và lặp lại các bước trên:
    ```bash
    $env:NODE_ENV="production"; npm run start:dev
    ```
    So sánh format log giữa hai chế độ. Kiểm tra xem file log hoặc Loki transport có được kích hoạt hay không.
- **Kết quả mong đợi:** Ở local, log hiển thị dạng text trên console, response vẫn tuân thủ format chuẩn. Ở production, log chuyển sang dạng **JSON** có cấu trúc, các transport bổ sung được kích hoạt. Exception Filter hoạt động nhất quán ở cả hai môi trường.
- **Kết luận:** Hệ thống cấu hình và logging hoạt động hoàn toàn tự động dựa trên biến môi trường, không cần bất kỳ thay đổi code nào khi chuyển đổi giữa các môi trường.

## IV. Kết luận

Một ứng dụng **NestJS** production-ready đòi hỏi **3 trụ cột**: cấu hình đa môi trường với **ConfigModule** và **registerAs()** để tổ chức biến theo namespace, logging có cấu trúc với **Winston** và nhiều transport để phục vụ giám sát tập trung, và chuẩn hoá response/error thông qua **Interceptor** và **Exception Filter** để bảo vệ thông tin nội bộ.

Ba thành phần này không hoạt động riêng lẻ mà kết nối chặt chẽ: **ConfigService** cung cấp thông số cho **WinstonModule**, Winston ghi log cho **ExceptionFilter**, và tất cả đều thay đổi hành vi dựa trên biến `NODE_ENV`.

**Kết luận:** Đừng đợi đến ngày triển khai production mới nghĩ đến cấu hình và logging. Hãy thiết lập chúng ngay từ dòng code đầu tiên, và ứng dụng của bạn sẽ luôn sẵn sàng chuyển từ máy dev lên server production chỉ bằng một biến môi trường.

# references
## 0
### alias
NestJS Configuration
### url
https://docs.nestjs.com/techniques/configuration
## 1
### alias
Winston Logger for NestJS
### url
https://github.com/gremo/nest-winston

# minutesRead
30
