# title
Production Config & Standard Logging

# description
Transform a simple learning project into a resilient production application using multi-environment configuration with DotEnv, structured logging with Winston, and namespace-based config organization.

# body

## I. Introduction

Most tutorials hardcode database URLs, API keys, and port numbers directly into the source code. This works until the project needs to run in a second environment, at which point developers start duplicating files, commenting out lines, and accidentally committing secrets to version control.

Production applications solve this by externalizing every environment-specific value into configuration files and reading them through a validated, type-safe service. At the same time, the built-in **NestJS** logger prints unstructured text to the console, which is impossible to search or aggregate in a monitoring stack. Replacing it with a structured logger like **Winston** turns logs into queryable data that can flow into dashboards and alerting systems. This lesson covers both pillars: robust configuration management and production-grade logging.

## II. Core Concepts

### 1. Centralized Configuration with @nestjs/config

Hardcoding database URLs or secret keys is a severe security vulnerability. Production applications read settings dynamically from **Environment Variables** stored in `.env` files or injected by cloud platforms.

- **Example:** The official `@nestjs/config` module loads `.env` files and exposes values through **ConfigService**. Instead of calling `process.env.DATABASE_URL` scattered across dozens of files, you inject **ConfigService** and call `configService.get('DATABASE_URL')`. The service validates that required variables exist at startup, crashing the application immediately if a critical value like `DATABASE_URL` or `JWT_SECRET` is missing, rather than failing silently at runtime.

### 2. Multi-Environment Configuration

Real projects run in at least two environments: **local** development and **production**. Each environment has different database hosts, log levels, and feature flags.

- **Example:** Create separate files like `.env.local` and `.env.production`. The `@nestjs/config` module can be configured to load the correct file based on the `NODE_ENV` variable. In **local** mode, the database might point to `localhost:5432`, while in **production** it connects to a managed cloud instance. This ensures that a single codebase handles every environment without code changes.

### 3. Namespace Configuration with registerAs

As the number of configuration variables grows, a flat list of keys becomes difficult to manage. **Namespace configuration** groups related variables under a single object.

- **Example:** Use the `registerAs()` function from `@nestjs/config` to create a namespace like `database` that bundles `host`, `port`, `username`, and `password` into one typed object. Instead of calling `configService.get('DATABASE_HOST')`, you call `configService.get('database.host')`. This organizes configuration by domain, prevents naming collisions, and makes it easy to inject only the config subset that a specific module needs.

### 4. Structured Logging with Winston

The built-in **NestJS** logger prints raw text to the console. In production, logs are ingested by tools like **Elasticsearch**, **Grafana Loki**, or **Datadog**, and these tools require structured **JSON**.

- **Example:** A structured log entry like `{"level":"info","message":"User logged in","userId":123,"timestamp":"2024-10-12T10:00:00Z"}` is immediately searchable and filterable in any dashboard. A raw text line like `[INFO] User 123 logged in` requires complex regex parsing to extract the same information. **Winston** produces structured **JSON** by default and supports multiple transports simultaneously.

### 5. Winston Transports and Integration

**Winston** can send logs to multiple destinations at the same time using transports. Each transport can have its own log level and format.

- **Example:** A typical production setup uses **3** transports simultaneously: a **Console** transport for local development output, a **File** transport that writes to disk for post-mortem analysis, and a **Loki** transport that streams logs to **Grafana Loki** for real-time dashboards and alerting. In **NestJS**, use `WinstonModule.forRootAsync()` with **ConfigService** to dynamically configure these transports based on the current environment. In **local** mode, you might enable only the console transport; in **production**, you enable all three.

## III. Practice

> **Source code:** [Production Ready Config and Logging](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/production-ready-config-and-logging)

### 1. Setup & Run

- **Execution Steps:**
    - Step 1: Clone the repository and navigate into the project folder.
    - Step 2: Install all dependencies:

```bash
npm install
```

  - Step 3: Start the development server in **local** mode (default):

```bash
npm run start:dev
```

  - Step 4: In a separate terminal, start the server in **production** mode to observe different configuration loading:

```bash
NODE_ENV=production npm run start:dev
```

- **Expected Results:**
    - In **local** mode, the application loads `.env.local` and logs appear in the console with the local configuration values.
    - In **production** mode, the application loads `.env.production` and the logger behavior changes according to the production transport configuration.
    - No compilation errors appear in either mode.

- **Conclusion:** A single codebase supports multiple environments by switching the `NODE_ENV` variable. The `@nestjs/config` module handles the correct `.env` file selection automatically.

### 2. Architecture

- **Execution Steps:**
    - Step 1: Open the `src/` directory and locate the configuration files and the logger setup.
    - Step 2: Identify the `.env.local` and `.env.production` files at the project root.
    - Step 3: Find the `registerAs()` namespace configuration definitions and the **WinstonModule** setup.

- **Expected Results:**
    - Configuration is organized using `registerAs()` namespaces, grouping related variables (database, logging, application) into typed objects.
    - **WinstonModule** is initialized asynchronously with `forRootAsync()`, injecting **ConfigService** to determine which transports to activate.
    - The architecture separates environment loading, config namespacing, and logger initialization into distinct, testable units.

- **Conclusion:** The architecture follows the **NestJS** convention of asynchronous module initialization with dependency-injected configuration, ensuring that the logger and all config values are fully resolved before any request is processed.

### 3. System Flow

- **Execution Steps:**
    - Step 1: Trace the startup sequence: the application loads the appropriate `.env` file based on `NODE_ENV`, registers namespace configs via `registerAs()`, and initializes **WinstonModule** with the resolved configuration.
    - Step 2: Observe how **ConfigService** is injected into the **WinstonModule** factory to decide which transports (Console, File, Loki) to activate.

- **Expected Results:**
    - In **local** mode, only the **Console** transport is active, printing human-readable logs.
    - In **production** mode, additional transports (**File**, **Loki**) are activated alongside the Console transport.
    - Every log entry includes structured fields such as `level`, `message`, `timestamp`, and contextual metadata.

- **Conclusion:** The system flow demonstrates that configuration and logging are resolved at bootstrap time, not at request time. This guarantees that every component in the application operates with validated, environment-appropriate settings from the first request onward.

### 4. Try it out

**Success path:**

- **Execution Steps:**
    - Step 1: With the server running in **local** mode, send a request to any available endpoint:

```bash
curl http://localhost:3000
```

  - Step 2: Check the console output and verify that the log entry contains structured fields such as the request method, URL, and timestamp.

- **Expected Results:**
    - The console displays a structured log line with the request details.
    - The response body follows the application's standard format.
    - **ConfigService** values (such as the application port) match what is defined in `.env.local`.

- **Conclusion:** In local mode, the **Console** transport provides immediate feedback with structured log data, making development-time debugging fast and efficient.

**Failure path:**

- **Execution Steps:**
    - Step 1: Stop the server and rename or delete the `.env.local` file to simulate a missing configuration:

```bash
mv .env.local .env.local.bak
```

  - Step 2: Attempt to start the server:

```bash
npm run start:dev
```

- **Expected Results:**
    - The application fails to start and throws a configuration validation error during bootstrap.
    - The error message clearly indicates which required environment variable is missing.
    - No request is ever accepted because the server never finishes initialization.

- **Conclusion:** The failure path proves that `@nestjs/config` with validation acts as a startup gate. Missing or invalid configuration is caught immediately at boot time, preventing the application from running in an undefined state. After testing, restore the file with `mv .env.local.bak .env.local`.

## IV. Conclusion

Production-grade **NestJS** applications externalize every environment-specific value into `.env` files and access them through **ConfigService** with startup validation. The `registerAs()` function organizes growing configuration into typed namespaces, preventing key collisions and improving maintainability. Replacing the built-in logger with **Winston** transforms raw console output into structured **JSON** that monitoring tools can ingest, search, and alert on. Multiple transports (**Console**, **File**, **Loki**) can run simultaneously, each configured per environment through `WinstonModule.forRootAsync()`.

**Conclusion:** Configuration and logging are not afterthoughts to bolt on before deployment. They are foundational infrastructure that must be established at the very beginning of a project. An application that validates its config at startup and emits structured logs from day one is an application that can be debugged, monitored, and scaled with confidence.

# references
## 0
### alias
NestJS Configuration
### url
https://docs.nestjs.com/techniques/configuration
## 1
### alias
NestJS Pino Logger
### url
https://github.com/iamolegga/nestjs-pino

# minutesRead
30
