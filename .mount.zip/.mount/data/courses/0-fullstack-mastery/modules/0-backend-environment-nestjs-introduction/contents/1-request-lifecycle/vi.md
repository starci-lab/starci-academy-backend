# title
Vòng đời HTTP Request (Lifecycle)

# description
Khám phá chính xác hành trình một gói tin HTTP đi xuyên qua Middleware, Guard, Interceptor và Pipe trước khi chạm vào Controller, và cách NestJS chuẩn hoá response trên đường ra.

# body

## I. Lời mở đầu

Trong các framework đơn giản như **Express** thuần, request từ client bay thẳng vào hàm handler mà không qua bất kỳ rào chắn nào. Lập trình viên phải tự tay viết logic kiểm tra token, validate dữ liệu, format response ngay bên trong handler, biến mỗi route thành một khối code khổng lồ trộn lẫn mọi trách nhiệm.

**NestJS** thiết kế vòng đời request thành một chuỗi các chốt kiểm duyệt (pipeline), mỗi chốt chỉ đảm nhận đúng một nhiệm vụ. Biết chính xác thứ tự thực thi của chuỗi này là kỹ năng bắt buộc để đặt đúng logic vào đúng chỗ: xác thực ở **Guard**, validate ở **Pipe**, format response ở **Interceptor**.

## II. Nội dung chính

### 1. Middleware

**Middleware** là lớp rìa ngoài cùng của pipeline, chạy đầu tiên trước mọi thành phần khác. Middleware trong **NestJS** hoạt động giống hệt Express: nhận `req`, `res`, `next` và có toàn quyền thao tác trên request trước khi chuyển tiếp.

- **Ví dụ:** **RequestIdMiddleware** gán một **UUID** duy nhất cho mỗi request ngay khi nó vừa đến server. **LoggerMiddleware** ghi lại method, URL và thời điểm truy cập. Cả hai đều chạy trước khi request đi sâu hơn vào pipeline, đảm bảo mọi request đều có thể truy vết từ đầu đến cuối.

### 2. Guard

**Guard** là chốt an ninh quyết định request có được phép đi tiếp hay bị từ chối. Guard chỉ trả về `true` (cho qua) hoặc `false` (chặn lại với lỗi **403** hoặc **401**). Đây là nơi duy nhất nên đặt logic **Authentication** và **Authorization**.

- **Ví dụ:** **TimingGuard** kiểm tra xem request có đến trong khung giờ cho phép hay không. Nếu ngoài giờ, guard trả về `false` và client nhận ngay lỗi **403 Forbidden** mà không cần chạm vào controller hay service.

### 3. Interceptor (chiều vào)

**Interceptor** đứng sát cửa controller, có khả năng can thiệp vào cả chiều vào lẫn chiều ra của request. Ở chiều vào, interceptor thường dùng để đo đạc thời gian xử lý, ghi log bắt đầu, hoặc biến đổi dữ liệu trước khi controller nhận.

- **Ví dụ:** **ExecutionTimerInterceptor** ghi lại thời điểm request bắt đầu xử lý, sau đó ở chiều ra sẽ tính toán tổng thời gian thực thi và gắn vào metadata của response. Thông tin này cực kỳ hữu ích cho việc giám sát hiệu năng.

### 4. Pipe

**Pipe** là bộ lọc và biến đổi dữ liệu đầu vào. Pipe nhận raw data từ request (body, params, query), validate và transform trước khi controller sử dụng. Nếu dữ liệu không hợp lệ, Pipe ném lỗi **400 Bad Request** ngay lập tức mà controller không hề hay biết.

- **Ví dụ:** **ParsePositiveIntPipe** kiểm tra tham số trên URL có phải số nguyên dương hay không. Nếu client gửi `/items/-5` hoặc `/items/abc`, pipe chặn ngay và trả về lỗi **400** kèm thông báo rõ ràng, bảo vệ controller khỏi dữ liệu rác.

### 5. Controller và Service

Sau khi vượt qua tất cả các chốt kiểm duyệt, request đến được **Controller**. Tại đây, controller chỉ đóng vai trò điều phối: nhận dữ liệu đã được validate sạch sẽ từ pipe, gọi **Service** để xử lý logic nghiệp vụ, và trả về kết quả. Service là nơi chứa toàn bộ logic tính toán và tương tác database.

- **Ví dụ:** `GET /items/5` sau khi qua **ParsePositiveIntPipe** sẽ đến controller với giá trị `5` đã được đảm bảo là số nguyên dương. Controller gọi service để truy vấn database và trả về item tương ứng.

### 6. Interceptor (chiều ra) và Response Transform

Sau khi controller trả về data, luồng HTTP quay ngược qua **Interceptor** chiều ra. Đây là nơi lý tưởng để chuẩn hoá format response cho toàn bộ ứng dụng.

- **Ví dụ:** **ResponseTransformInterceptor** nhận data thô từ controller và đóng gói thành cấu trúc chuẩn `{ data, timestamp, requestId }`. Mọi endpoint trong ứng dụng đều trả về cùng một format, giúp frontend xử lý dễ dàng và nhất quán.

### 7. Exception Filter

**Exception Filter** là lớp bảo vệ cuối cùng trong pipeline. Khi bất kỳ thành phần nào ở trên ném ra exception, filter sẽ bắt lấy, giấu stack trace nguy hiểm, và trả về client một JSON lỗi an toàn, sạch sẽ. Đây là cơ chế đảm bảo ứng dụng không bao giờ lộ thông tin nội bộ ra bên ngoài.

- **Ví dụ:** Nếu service ném lỗi do truy vấn database thất bại, thay vì client nhận được stack trace chứa thông tin SQL và IP server, **Exception Filter** sẽ trả về `{ "statusCode": 500, "message": "Internal Server Error" }` và ghi log chi tiết lỗi ở phía server để developer xử lý.

## III. Thực hành

> **Source code:** [Request Lifecycle](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/request-lifecycle)

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
  - Bước 1: Clone repository từ GitHub về máy.
  - Bước 2: Cài đặt dependencies:
    ```bash
    npm install
    ```
  - Bước 3: Khởi chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng khởi động thành công, terminal hiển thị log **NestJS** sẵn sàng nhận request.
- **Kết luận:** Dự án demo đã được cấu hình sẵn đầy đủ các thành phần pipeline, chỉ cần **2 lệnh** để chạy.

### 2. Kiến trúc (Architecture)

- **Các bước thực hiện:**
  - Bước 1: Mở thư mục `src/` và xác định các thành phần pipeline đã được cài đặt: **RequestIdMiddleware**, **LoggerMiddleware**, **TimingGuard**, **ExecutionTimerInterceptor**, **ResponseTransformInterceptor**, **ParsePositiveIntPipe**.
  - Bước 2: Xem cách các thành phần được đăng ký trong module: middleware qua `configure()` trong `AppModule`, guard và interceptor qua `APP_GUARD` / `APP_INTERCEPTOR`, pipe qua decorator `@UsePipes()` hoặc parameter decorator.
- **Kết quả mong đợi:** Hiểu được vị trí và vai trò của từng thành phần trong kiến trúc pipeline, cũng như cách **NestJS** cho phép đăng ký chúng ở cấp global hoặc cấp route.
- **Kết luận:** Mỗi thành phần pipeline được tách biệt thành một class riêng với một trách nhiệm duy nhất, tuân thủ nguyên tắc **Single Responsibility**.

### 3. Luồng hệ thống (System Flow)

- **Các bước thực hiện:**
  - Bước 1: Theo dõi luồng xử lý khi một request đến: **Middleware** (gán UUID, ghi log) -> **Guard** (kiểm tra điều kiện) -> **Interceptor** chiều vào (bắt đầu đo thời gian) -> **Pipe** (validate tham số) -> **Controller** -> **Service** -> **Interceptor** chiều ra (format response, ghi thời gian xử lý).
  - Bước 2: Xác nhận cấu trúc response chuẩn hoá: `{ data, timestamp, requestId }`.
- **Kết quả mong đợi:** Nắm được toàn bộ luồng xử lý từ lúc request vào đến lúc response ra, và vai trò của từng chốt kiểm duyệt trong chuỗi.
- **Kết luận:** Pipeline của **NestJS** đảm bảo mỗi request đều đi qua đầy đủ các bước xử lý theo đúng thứ tự, bất kể endpoint nào.

### 4. Thử nghiệm (Try it out)

- **Các bước thực hiện:**
  - Bước 1: Gửi request hợp lệ để quan sát luồng thành công (Success path):
    ```bash
    curl http://localhost:3000/items/5
    ```
    Kiểm tra response có đúng format `{ data, timestamp, requestId }` hay không. Kiểm tra terminal log xem các middleware, guard, interceptor có chạy đúng thứ tự không.
  - Bước 2: Gửi request với tham số không hợp lệ để quan sát luồng thất bại (Failure path):
    ```bash
    curl http://localhost:3000/items/-1
    ```
    **ParsePositiveIntPipe** phải chặn request và trả về lỗi **400 Bad Request**.
  - Bước 3: Thử gửi request với tham số không phải số:
    ```bash
    curl http://localhost:3000/items/abc
    ```
    Xác nhận pipe vẫn chặn đúng và trả lỗi **400**.
- **Kết quả mong đợi:** Request hợp lệ trả về response chuẩn hoá với `data`, `timestamp`, `requestId`. Request không hợp lệ bị chặn tại tầng **Pipe** với lỗi **400**, controller không bao giờ được gọi.
- **Kết luận:** Cơ chế pipeline tách biệt hoàn toàn việc validate dữ liệu khỏi logic nghiệp vụ. Controller chỉ nhận dữ liệu sạch, giúp code gọn gàng và dễ bảo trì.

## IV. Kết luận

Vòng đời request trong **NestJS** không phải là một khái niệm trừu tượng mà là kiến trúc phân tầng cụ thể: **Middleware** -> **Guard** -> **Interceptor** -> **Pipe** -> **Controller** -> **Service** -> **Interceptor** (chiều ra) -> **Exception Filter**. Mỗi tầng giải quyết đúng một loại vấn đề, và **NestJS** đảm bảo thứ tự thực thi luôn nhất quán.

Hiểu rõ pipeline này giúp lập trình viên đặt đúng logic vào đúng chỗ: không bao giờ validate trong controller, không bao giờ format response trong service, không bao giờ kiểm tra quyền trong middleware.

**Kết luận:** Nắm vững vòng đời request là nắm vững cách **NestJS** tư duy. Khi bạn biết chính xác mỗi dòng code nên sống ở tầng nào, ứng dụng của bạn sẽ tự nhiên trở nên sạch sẽ, dễ test và dễ mở rộng.

# references
## 0
### alias
NestJS Execution Lifecycle
### url
https://docs.nestjs.com/faq/request-lifecycle

# minutesRead
25
