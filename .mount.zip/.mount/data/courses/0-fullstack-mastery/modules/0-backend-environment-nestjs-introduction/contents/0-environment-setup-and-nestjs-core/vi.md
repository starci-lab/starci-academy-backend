# title
Thiết lập Môi trường, Lõi NestJS & Dependency Injection

# description
Khởi tạo môi trường Node.js chuyên nghiệp, cài đặt NestJS qua CLI, xây dựng cấu trúc thư mục chuẩn production, và nắm vững Dependency Injection cùng hệ thống Module.

# body

## I. Lời mở đầu

Nhiều lập trình viên khi bắt đầu dự án backend thường nghĩ rằng chỉ cần cài **Node.js**, tạo file `index.js`, gọi vài hàm **Express** là xong. Tư duy này hoạt động ổn với prototype nhỏ, nhưng khi dự án mở rộng lên hàng chục module, hàng trăm API, mọi thứ nhanh chóng trở thành mớ bòng bong: import chồng chéo, khởi tạo object thủ công bằng `new` khắp nơi, không thể test hay thay thế thành phần nào mà không sửa hàng loạt file.

**NestJS** ra đời để giải quyết chính xác vấn đề này. Thay vì để lập trình viên tự xoay xở cấu trúc, framework cung cấp sẵn kiến trúc **Module**, hệ thống **Dependency Injection (DI)**, và công cụ sinh code mạnh mẽ qua **CLI**. Bài học này sẽ đưa bạn từ bước cài đặt môi trường đến việc hiểu rõ cách NestJS quản lý vòng đời của mọi thành phần trong ứng dụng.

## II. Nội dung chính

### 1. Chuẩn hoá môi trường Node.js

Trước khi viết bất kỳ dòng code **NestJS** nào, môi trường phát triển cần được chuẩn hoá để tránh xung đột phiên bản và đảm bảo tính nhất quán giữa các thành viên trong nhóm.

- **Ví dụ:** Sử dụng **nvm** (Node Version Manager) để quản lý phiên bản **Node.js**. Khi dự án A yêu cầu **v18** và dự án B yêu cầu **v20**, bạn chỉ cần gõ `nvm use 18` hoặc `nvm use 20` thay vì gỡ cài rồi cài lại. Package manager cũng nên chuyển sang **pnpm** hoặc **yarn** để tăng tốc cài đặt và quản lý lockfile chặt chẽ hơn so với **npm** mặc định.

### 2. Khởi tạo dự án bằng NestJS CLI

**NestJS CLI** là công cụ sinh code chính thức, giúp tạo ra cấu trúc dự án chuẩn chỉ với một lệnh duy nhất. CLI không chỉ sinh thư mục mà còn thiết lập sẵn **TypeScript**, **ESLint**, **Jest** và các file cấu hình cần thiết.

```bash
npm i -g @nestjs/cli
nest new starci-backend
```

Sau khi chạy xong, dự án sẽ có sẵn các file cốt lõi: `main.ts` (cửa ngõ ứng dụng, khởi tạo **NestFactory**), `app.module.ts` (module gốc gom toàn bộ nhánh lá), `app.controller.ts` (định tuyến HTTP), và `app.service.ts` (chứa logic nghiệp vụ).

### 3. Tổ chức thư mục cho Production

Cấu trúc mặc định đặt mọi file ngang hàng trong `src/` sẽ nhanh chóng trở nên hỗn loạn khi dự án mở rộng. Production đòi hỏi tư duy chia theo **Feature Module** hoặc **Domain Module**, mỗi module là một thư mục chứa trọn vẹn controller, service, DTO và các thành phần liên quan.

- **Ví dụ:** Một dự án thương mại điện tử chia thành `modules/users/`, `modules/orders/`, `modules/products/`, mỗi thư mục chứa đầy đủ `*.controller.ts`, `*.service.ts`, `*.module.ts` và thư mục `dto/`. Thư mục `shared/` chứa các tiện ích dùng chung như **Interceptor**, **Filter**, **Middleware**. Mô hình này giúp hàng chục lập trình viên làm việc song song mà không gây xung đột merge.

### 4. Dependency Injection và IoC Container

Ở **Express** truyền thống, lập trình viên thường khởi tạo object thủ công bằng `new`, tạo ra sự phụ thuộc cứng (tight coupling) giữa các class. **NestJS** loại bỏ hoàn toàn vấn đề này bằng cơ chế **Dependency Injection (DI)**: bạn chỉ cần khai báo kiểu dữ liệu trong constructor, framework tự động tìm và tiêm bản thể phù hợp từ **IoC Container**.

- **Ví dụ:** Thay vì viết `const userService = new UserService(new DatabaseConnection())`, bạn chỉ cần đánh dấu `@Injectable()` lên class `UserService` và khai báo `constructor(private readonly userService: UserService)` trong controller. **NestJS** tự quản lý vòng đời, mặc định theo kiểu **Singleton** (chỉ tạo một bản thể duy nhất cho toàn ứng dụng), giúp tối ưu bộ nhớ và đảm bảo tính nhất quán.

### 5. Hệ thống Module và tính đóng gói

Decorator `@Module()` định nghĩa ranh giới lãnh thổ của một nghiệp vụ. Mọi **Provider** khai báo trong `providers` mặc định là **private**, không thể truy cập từ module khác trừ khi được liệt kê trong mảng `exports`.

- **Vi du 1:** Nếu `OrderModule` muốn sử dụng `UserService` từ `UserModule`, ứng dụng sẽ báo lỗi ngay lập tức trừ khi `UserModule` chủ động export `UserService` trong mảng `exports` và `OrderModule` import `UserModule` trong mảng `imports`.

- **Vi du 2:** Với các module đa dụng như **DatabaseModule** hay **ConfigModule**, việc import đi import lại ở mọi nơi rất phiền phức. NestJS cho phép đánh dấu `@Global()` để biến module thành hàng công cộng. Tuy nhiên, lạm dụng **Global Module** sẽ phá vỡ tính đóng gói và biến kiến trúc thành mạng nhện khó bảo trì.

## III. Thực hành

> **Source code:** [Environment Setup and NestJS Core](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/environment-setup-and-nestjs-core)

### 1. Thiết lập (Setup & Run)

- **Các bước thực hiện:**
  - Bước 1: Clone repository từ GitHub về máy.
  - Bước 2: Cài đặt dependencies bằng lệnh:
    ```bash
    npm install
    ```
  - Bước 3: Khởi chạy ứng dụng ở chế độ phát triển:
    ```bash
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng khởi động thành công trên cổng mặc định, terminal hiển thị log **NestJS** với thông báo sẵn sàng nhận request.
- **Kết luận:** Quy trình khởi tạo dự án **NestJS** chỉ cần **2 lệnh** cơ bản, CLI đã lo trọn phần cấu hình ban đầu.

### 2. Kiến trúc (Architecture)

- **Các bước thực hiện:**
  - Bước 1: Mở thư mục `src/` và quan sát cấu trúc module. Dự án gồm **2 module** chính: **CatModule** và **DogModule**.
  - Bước 2: Trong **CatModule**, xem chuỗi **DI**: `CatController` phụ thuộc vào `CatService`, `CatService` phụ thuộc vào `CatFoodService` và `CatHealthService`.
  - Bước 3: Trong **DogModule**, xem cách module này import **CatModule** để sử dụng `CatService` thông qua `DogService`.
- **Kết quả mong đợi:** Hiểu được chuỗi **Dependency Injection** từ controller xuống service, và cách **Module Encapsulation** hoạt động khi một module muốn sử dụng provider từ module khác.
- **Kết luận:** **NestJS** ép buộc kiến trúc rõ ràng thông qua decorator `@Injectable()`, **Constructor Injection**, và cơ chế **export/import** giữa các module.

### 3. Luồng hệ thống (System Flow)

- **Các bước thực hiện:**
  - Bước 1: Theo dõi luồng khởi tạo từ `AppModule`. **AppModule** import cả **CatModule** và **DogModule**.
  - Bước 2: Khi ứng dụng khởi động, **IoC Container** xây dựng cây phụ thuộc: `CatModule` tạo `CatFoodService` -> `CatHealthService` -> `CatService` -> `CatController`. **DogModule** import `CatModule` nên có thể truy cập `CatService` đã được export.
  - Bước 3: Xác nhận rằng tất cả provider đều là **Singleton**, nghĩa là `CatService` được inject vào cả `CatController` và `DogService` là cùng một bản thể.
- **Kết quả mong đợi:** Nắm được toàn bộ cây phụ thuộc và luồng khởi tạo module trong ứng dụng.
- **Kết luận:** Mô hình **Singleton** mặc định của NestJS đảm bảo mỗi provider chỉ được khởi tạo một lần, giúp tối ưu bộ nhớ và đảm bảo tính nhất quán dữ liệu.

### 4. Thử nghiệm (Try it out)

- **Các bước thực hiện:**
  - Bước 1: Gọi endpoint lấy danh sách mèo:
    ```bash
    curl http://localhost:3000/cats
    ```
  - Bước 2: Kiểm tra trạng thái sức khoẻ mèo:
    ```bash
    curl http://localhost:3000/cats/status
    ```
  - Bước 3: Cho mèo ăn một loại thức ăn cụ thể:
    ```bash
    curl http://localhost:3000/cats/feed/tuna
    ```
  - Bước 4: Gọi endpoint từ **DogModule** để kiểm tra cross-module DI, cho phép chó "do thám" mèo:
    ```bash
    curl http://localhost:3000/dogs/spy
    ```
  - Bước 5: Cho chó "trộm" thức ăn của mèo, kiểm chứng rằng `DogService` sử dụng `CatService` từ module khác:
    ```bash
    curl http://localhost:3000/dogs/steal/salmon
    ```
- **Kết quả mong đợi:** Tất cả **5 endpoint** đều trả về response hợp lệ. Các endpoint `/dogs/spy` và `/dogs/steal/:food` chứng minh rằng **DogModule** truy cập thành công `CatService` nhờ cơ chế export/import giữa các module.
- **Kết luận:** Cross-module **Dependency Injection** hoạt động chính xác khi module nguồn export provider và module đích import module nguồn. Đây là nền tảng của kiến trúc modular trong **NestJS**.

## IV. Kết luận

**NestJS** không chỉ là một framework HTTP mà là một hệ sinh thái kiến trúc hoàn chỉnh. Từ việc chuẩn hoá môi trường với **nvm** và **CLI**, tổ chức thư mục theo **Feature Module**, đến việc uỷ thác toàn bộ việc khởi tạo object cho **IoC Container** thông qua **Dependency Injection**, mọi thứ đều hướng tới một mục tiêu: code dễ mở rộng, dễ test, và dễ bảo trì.

Hệ thống **Module** với cơ chế đóng gói (encapsulation) và export/import là xương sống của mọi dự án NestJS. Hiểu rõ cách các module giao tiếp với nhau thông qua DI chính là bước đầu tiên để xây dựng kiến trúc backend vững chắc.

**Kết luận:** Đừng viết code rồi mới nghĩ kiến trúc. Hãy để **NestJS** ép bạn vào khuôn khổ ngay từ dòng đầu tiên, và bạn sẽ thấy dự án lớn dần mà không bao giờ mất kiểm soát.

# references
## 0
### alias
NestJS First Steps
### url
https://docs.nestjs.com/first-steps
## 1
### alias
Providers in NestJS
### url
https://docs.nestjs.com/providers

# minutesRead
25
