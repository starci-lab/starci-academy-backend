# title
The HTTP Request Lifecycle

# description
Master the exact journey of an incoming HTTP request as it flows through Middlewares, Guards, Interceptors, and Pipes before reaching your business logic in the Controller.

# body

## I. Introduction

In a simple **Express** application, an incoming request passes through a flat chain of middleware functions and then hits the route handler. There is no enforced separation between authentication, validation, data transformation, and response formatting. Developers end up stuffing all of these concerns into the same middleware or, worse, into the controller itself.

**NestJS** replaces this flat pipeline with a rigorously layered lifecycle. Each layer has a single responsibility and a fixed position in the execution order. Understanding this lifecycle is not optional: placing logic in the wrong layer leads to security holes, duplicated code, and bugs that are nearly impossible to trace. This lesson maps out every layer, from the moment a request arrives to the moment a response leaves.

## II. Core Concepts

### 1. Middleware

Middleware is the outermost perimeter of the request lifecycle. It executes first, before any **NestJS**-specific mechanism kicks in. Middleware functions have direct access to the raw **Request** and **Response** objects, just like in **Express**.

- **Example:** A **RequestIdMiddleware** that generates a **UUID** and attaches it to every incoming request as a tracking identifier. A second **LoggerMiddleware** reads this ID and logs the method, URL, and timestamp of each request. Both run before any guard or interceptor is aware the request exists.

### 2. Guards

Guards form the security checkpoint. They execute after middleware and before any interceptor or pipe. A guard must return `true` or `false`. If it returns `false`, **NestJS** immediately responds with **403 Forbidden** or **401 Unauthorized** and nothing deeper in the pipeline ever executes.

- **Example:** A **TimingGuard** that checks whether the current server time falls within an allowed operational window. If the request arrives outside the permitted hours, the guard rejects it with a **403** response, and neither the interceptor nor the controller is ever invoked.

### 3. Interceptors (Pre-Controller)

Interceptors wrap around the controller execution. The pre-controller phase runs after guards pass but before the route handler is called. Interceptors can attach metadata, start timers, or modify the request context.

- **Example:** An **ExecutionTimerInterceptor** that records `Date.now()` before the controller runs, then calculates the elapsed time after the controller returns. This value can be logged or attached to the response headers for performance monitoring.

### 4. Pipes

Pipes are the data sanitization and validation layer. They execute immediately before the controller method and operate on the arguments being passed into it. A pipe can transform a value, validate its shape, or reject the request entirely with a **400 Bad Request**.

- **Example:** A **ParsePositiveIntPipe** that receives a route parameter as a string (e.g., `"42"`), parses it to an integer, and verifies it is a positive number. If the client sends `"abc"` or `"-5"`, the pipe throws a validation error and the controller is never called.

### 5. Controller and Service

Once middleware, guards, interceptors, and pipes have all passed, the controller method finally executes. The controller delegates to one or more services, which contain the actual business logic. This layer is intentionally the deepest because every layer above it exists to protect and prepare data for it.

- **Example:** A controller method that receives a validated, transformed integer ID and calls a service to retrieve the corresponding resource from a database.

### 6. Interceptors (Post-Controller)

After the controller returns a value, the interceptor's post-controller phase activates. This is where outgoing data can be wrapped, transformed, or enriched before being sent to the client.

- **Example:** A **ResponseTransformInterceptor** that takes whatever the controller returns and wraps it in a standardized envelope: `{ data, timestamp, requestId }`. Every endpoint in the application automatically returns a consistent shape without any extra code in each controller.

### 7. Exception Filters

If any layer in the pipeline throws an error, the exception filter catches it. Filters ensure that raw stack traces or database errors never leak to the client. Instead, they format every error into a clean, structured **JSON** response.

- **Example:** A global **HttpExceptionFilter** that catches any unhandled exception, extracts the status code and message, and returns a response with `statusCode`, `message`, `timestamp`, and `path` fields, regardless of which layer threw the error.

## III. Practice

> **Source code:** [Request Lifecycle](https://github.com/StarCi-Academy/resources/tree/main/fullstack-mastery/request-lifecycle)

### 1. Setup & Run

- **Execution Steps:**
    - Step 1: Clone the repository and navigate into the project folder.
    - Step 2: Install all dependencies:

```bash
npm install
```

  - Step 3: Start the development server:

```bash
npm run start:dev
```

- **Expected Results:**
    - The terminal prints a **NestJS** bootstrap message confirming the application is listening.
    - No compilation errors appear in the console.

- **Conclusion:** The project is ready with all lifecycle components (**Middleware**, **Guard**, **Interceptor**, **Pipe**) registered and active.

### 2. Architecture

- **Execution Steps:**
    - Step 1: Open the `src/` directory and locate each lifecycle component file.
    - Step 2: Identify the following components: **RequestIdMiddleware**, **LoggerMiddleware**, **TimingGuard**, **ExecutionTimerInterceptor**, **ResponseTransformInterceptor**, and **ParsePositiveIntPipe**.

- **Expected Results:**
    - Each component is implemented as a separate class with a single responsibility.
    - Middleware classes implement `NestMiddleware`, the guard implements `CanActivate`, interceptors implement `NestInterceptor`, and the pipe implements `PipeTransform`.
    - All are registered at the module level or globally, following the **NestJS** convention.

- **Conclusion:** The architecture demonstrates the separation of concerns enforced by the **NestJS** request lifecycle. Each layer is isolated, testable, and replaceable independently.

### 3. System Flow

- **Execution Steps:**
    - Step 1: Trace the order of execution when a request arrives at any endpoint.
    - Step 2: Verify the flow: **RequestIdMiddleware** attaches a UUID, **LoggerMiddleware** logs the request, **TimingGuard** checks access, **ExecutionTimerInterceptor** starts a timer, **ParsePositiveIntPipe** validates parameters, the **Controller** delegates to the **Service**, the interceptor wraps the response, and if anything fails, the exception filter formats the error.

- **Expected Results:**
    - The console logs confirm the exact order: Middleware runs first, then Guard, then Interceptor (pre), then Pipe, then Controller, then Interceptor (post).
    - Every successful response has the shape `{ data, timestamp, requestId }`.

- **Conclusion:** The system flow proves that **NestJS** enforces a deterministic, layered pipeline. Developers do not have to rely on convention or documentation; the framework itself guarantees execution order.

### 4. Try it out

**Success path:**

- **Execution Steps:**
    - Step 1: Send a valid request with a positive integer parameter:

```bash
curl http://localhost:3000/items/5
```

  - Step 2: Observe the console logs showing each lifecycle layer executing in order.

- **Expected Results:**
    - The **RequestIdMiddleware** assigns a **UUID** visible in the logs.
    - The **TimingGuard** passes and logs that access is allowed.
    - The **ParsePositiveIntPipe** accepts `5` as a valid positive integer.
    - The controller processes the request and the **ResponseTransformInterceptor** wraps the result into `{ data, timestamp, requestId }`.

- **Conclusion:** When all layers pass, the request flows cleanly from middleware to controller, and the response is automatically wrapped in a standardized envelope by the interceptor.

**Failure path:**

- **Execution Steps:**
    - Step 1: Send a request with an invalid (non-positive) parameter to trigger the pipe:

```bash
curl http://localhost:3000/items/-1
```

  - Step 2: Send a request with a non-numeric string to trigger a different validation error:

```bash
curl http://localhost:3000/items/abc
```

- **Expected Results:**
    - Both requests are rejected with a **400 Bad Request** response before the controller is ever invoked.
    - The **ParsePositiveIntPipe** throws a validation exception, and the exception filter formats it into a clean **JSON** error with `statusCode`, `message`, and `timestamp`.
    - The console logs confirm that middleware and guard executed, but the controller did not.

- **Conclusion:** The failure path proves that **Pipes** act as a protective barrier. Invalid data is rejected at the pipeline level, ensuring that the controller and service layers only ever receive clean, validated input.

## IV. Conclusion

The **NestJS** request lifecycle is a deterministic pipeline: **Middleware** runs first for raw request handling, **Guards** enforce security, **Interceptors** wrap controller execution for cross-cutting concerns, **Pipes** validate and transform input, and **Exception Filters** catch and format any errors. Each layer has exactly one job and a fixed position in the sequence.

**Conclusion:** Memorize the order, Middleware, Guard, Interceptor, Pipe, Controller, Interceptor, Filter, and never place logic in the wrong layer. A guard should never validate data, a pipe should never check authentication, and a controller should never format responses. Respecting this separation is what transforms a hobby project into a maintainable enterprise application.

# references
## 0
### alias
NestJS Execution Lifecycle
### url
https://docs.nestjs.com/faq/request-lifecycle

# minutesRead
25
