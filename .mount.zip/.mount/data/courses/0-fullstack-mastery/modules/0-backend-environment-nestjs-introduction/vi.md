# title
Backend Environment & NestJS Introduction

# description
Thiết lập môi trường Node.js, cài đặt NestJS, và nắm vững các kiến thức nền tảng để xây dựng backend, bao gồm: Dependency Injection, Module System, Request Lifecycle, Exception Handling, Logging, Validation, và cách xây dựng các API cơ bản.

# previewContents
## 0
### text
Hiểu tổng quan hệ sinh thái backend và vai trò của các ngôn ngữ/framework như Java, C#, Node.js, Golang và Python trong hệ thống thực tế.
## 1
### text
Thiết lập môi trường Node.js, cài đặt NestJS CLI và xây dựng cấu trúc project chuẩn production ngay từ đầu.
## 2
### text
Hiểu rõ Dependency Injection và Module System để xây dựng kiến trúc dễ mở rộng và dễ bảo trì.
## 3
### text
Nắm vững request lifecycle trong NestJS: Middleware → Guards → Pipes → Controllers → Services → Interceptors → Exception Filters.
## 4
### text
Áp dụng nguyên lý Clean Architecture bằng cách tách biệt tầng xử lý request và business logic.
## 5
### text
Chuẩn bị hệ thống cho production với cấu hình môi trường, logging có cấu trúc (Winston) và chuẩn hóa response API.
