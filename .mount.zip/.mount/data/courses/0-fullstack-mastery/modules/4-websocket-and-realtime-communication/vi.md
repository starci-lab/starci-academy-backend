# title
WebSocket & Real-time Communication

# description
Xây dựng hệ thống realtime có cấu trúc với WebSocket và Socket.IO trong NestJS. Thiết kế event contract, quản lý rooms/namespaces, xác thực kết nối qua JWT handshake, và mở rộng với Redis Adapter.

# previewContents
## 0
### text
Xây dựng WebSocket Gateway với Socket.IO trong NestJS.
## 1
### text
Thiết kế cấu trúc event và quản lý rooms / namespaces hợp lý.
## 2
### text
Xác thực socket thông qua JWT token handshake.
## 3
### text
Mở rộng WebSocket trên nhiều instance với Redis Adapter.
## 4
### text
Hiểu cách backend và frontend giao tiếp realtime.
## 5
### text
Tự thiết kế event contract và flow xử lý realtime rõ ràng, không chỉ "emit cho chạy".
## 6
### text
Quản lý kết nối đúng cách và tránh lỗi phổ biến như leak connection.
## 7
### text
Hiểu rooms/broadcast hoạt động thế nào và khi nào cần Redis Adapter.
## 8
### text
Triển khai tính năng realtime rõ ràng, ổn định và dễ mở rộng về sau.
