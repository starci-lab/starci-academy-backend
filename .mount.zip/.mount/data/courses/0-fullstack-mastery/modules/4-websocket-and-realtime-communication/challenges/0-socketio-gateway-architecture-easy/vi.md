# title
Thiet lap WebSocket Gateway voi Socket.IO

# description
Dựng WebSocket Gateway đầu tiên trong NestJS sử dụng Socket.IO, thiết lập kết nối hai chiều giữa client và server thông qua cơ chế sự kiện (event-driven).

# requirements
Tạo `NotificationsGateway` với decorator `@WebSocketGateway()`. Lắng nghe event `ping` bằng `@SubscribeMessage('ping')` và trả về chuỗi `pong` cho đúng client gửi (không broadcast). Inject một `NotificationsService` vào Gateway để chứng minh DI hoạt động trong context WebSocket. Service có method `getServerTime()` trả thời gian hiện tại. Lắng nghe event `time` và trả về kết quả từ service.

# prerequisites
- Node.js >= 18
- NestJS CLI

# steps

## 0
### title
Khởi tạo project và cài đặt Socket.IO
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới bằng NestJS CLI:
    ```bash
    nest new socketio-gateway-architecture-easy
    ```
  - Bước 2: Di chuyển vào thư mục project và cài đặt các package WebSocket cần thiết:
    ```bash
    cd socketio-gateway-architecture-easy
    npm install @nestjs/websockets @nestjs/platform-socket.io
    ```
  - Bước 3: Chạy thử ứng dụng để đảm bảo project khởi tạo thành công:
    ```bash
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng khởi động thành công trên cổng 3000, terminal hiển thị log NestJS sẵn sàng. Các package `@nestjs/websockets` và `@nestjs/platform-socket.io` đã được thêm vào `package.json`.
- **Kết luận:** Môi trường nền với đầy đủ dependency cho WebSocket đã sẵn sàng để triển khai Gateway.

## 1
### title
Tạo NotificationsGateway và NotificationsService
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `NotificationsModule`, `NotificationsGateway`, và `NotificationsService` bằng CLI hoặc thủ công. Đảm bảo `NotificationsGateway` nằm trong `providers` của `NotificationsModule` và `NotificationsService` cũng được khai báo trong `providers`.
  - Bước 2: Trong `NotificationsService`, tạo method `getServerTime(): string` trả về thời gian hiện tại dưới dạng ISO string bằng `new Date().toISOString()`.
  - Bước 3: Trong `NotificationsGateway`, thêm decorator `@WebSocketGateway()` trên class. Inject `NotificationsService` vào constructor của Gateway.
  - Bước 4: Import `NotificationsModule` vào `AppModule`.
- **Kết quả mong đợi:** Ứng dụng khởi động không lỗi, Gateway được NestJS nhận diện và log trong quá trình bootstrap.
- **Kết luận:** Gateway và Service đã được tạo và kết nối qua DI, sẵn sàng để triển khai các event handler.

## 2
### title
Triển khai event handler cho ping và time
### body
- **Các bước thực hiện:**
  - Bước 1: Trong `NotificationsGateway`, tạo method xử lý event `ping` bằng decorator `@SubscribeMessage('ping')`. Method nhận tham số `client: Socket` và trả về object `{ event: 'ping', data: 'pong' }` để Socket.IO tự động gửi response cho đúng client gọi.
  - Bước 2: Tạo method xử lý event `time` bằng decorator `@SubscribeMessage('time')`. Method gọi `this.notificationsService.getServerTime()` và trả về `{ event: 'time', data: serverTime }`.
  - Bước 3: Thêm `@WebSocketServer() server: Server` để có reference đến WebSocket server instance (dùng cho mục đích debug hoặc mở rộng sau này).
  - Bước 4: Implement interface `OnGatewayConnection` và `OnGatewayDisconnect`. Trong `handleConnection(client: Socket)`, log ra `Client connected: ${client.id}`. Trong `handleDisconnect(client: Socket)`, log ra `Client disconnected: ${client.id}`.
- **Kết quả mong đợi:** Gateway có hai event handler `ping` và `time`. Khi client emit event `ping`, chỉ client đó nhận lại `pong`. Khi client emit event `time`, chỉ client đó nhận lại thời gian hiện tại từ service. Console log hiển thị thông tin kết nối và ngắt kết nối.
- **Kết luận:** Cơ chế event-driven đã hoạt động, DI trong context WebSocket được chứng minh qua việc Gateway gọi thành công Service.

## 3
### title
Kiểm thử Gateway bằng Postman WebSocket
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Mở Postman, tạo kết nối WebSocket mới đến `ws://localhost:3000`. Chọn giao thức **Socket.IO** (không phải Raw WebSocket). Nhấn **Connect** và xác nhận kết nối thành công.
  - Bước 3: Gửi event `ping` (không cần payload hoặc payload rỗng). Xác nhận nhận lại response với event `ping` và data `pong`.
  - Bước 4: Gửi event `time` (không cần payload). Xác nhận nhận lại response với event `time` và data là chuỗi thời gian ISO (ví dụ `2025-01-15T10:30:00.000Z`).
  - Bước 5: Kiểm tra terminal server: phải có log `Client connected: <id>` khi mở kết nối và `Client disconnected: <id>` khi đóng kết nối.
- **Kết quả mong đợi:**
  - Event `ping` -> response `pong` cho đúng client gửi.
  - Event `time` -> response là chuỗi thời gian ISO từ `NotificationsService`.
  - Terminal hiển thị log kết nối và ngắt kết nối.
- **Kết luận:** WebSocket Gateway hoạt động đúng cơ chế event-driven, DI xuyên suốt từ Gateway đến Service, kết nối hai chiều giữa client và server đã được thiết lập thành công.

# references
## 0
### alias
NestJS WebSockets Gateways
### url
https://docs.nestjs.com/websockets/gateways

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
Gateway và DI đúng cấu trúc
##### score
10
##### promptText
`NotificationsGateway` có decorator `@WebSocketGateway()`, inject `NotificationsService` qua constructor. Service có method `getServerTime()` trả thời gian ISO. Gateway implement `OnGatewayConnection` và `OnGatewayDisconnect` với log phù hợp.
#### 1
##### title
Event handler hoạt động đúng
##### score
10
##### promptText
Event `ping` trả `pong` cho đúng client gửi (không broadcast). Event `time` trả kết quả từ `NotificationsService.getServerTime()`. Cả hai event dùng `@SubscribeMessage` đúng cách.

# difficulty
easy

# score
20
