# title
JWT Authentication at Socket Handshake

# description
Secure a WebSocket Gateway by authenticating JWT at the handshake stage, rejecting invalid connections before they consume server resources.

# requirements
In `handleConnection()`, extract the JWT from `client.handshake.headers.authorization`. Verify it using `JwtService`. If valid, attach the payload to `client.data.user`. If invalid or missing, call `client.disconnect()` immediately. In the `sendMessage` event, the sender identity must come from `client.data.user` (do not trust client-sent data).

# prerequisites
- Node.js >= 18
- Docker (PostgreSQL)
- A working JWT AuthModule

# steps

## 0
### title
Initialize the project and install dependencies
### body
- **Steps to follow:**
  - Step 1: Create a new project using the NestJS CLI:
    ```bash
    nest new socket-authentication-easy
    ```
  - Step 2: Navigate to the project directory and install the required packages:
    ```bash
    cd socket-authentication-easy
    npm install @nestjs/websockets @nestjs/platform-socket.io @nestjs/jwt
    ```
  - Step 3: Configure `JwtModule` in `AppModule` or create a separate `AuthModule`. Register `JwtModule.register()` with a `secret` and `signOptions: { expiresIn: '1h' }`.
  - Step 4: Create a REST endpoint `POST /auth/login` that takes `{ username }` and returns `{ accessToken }` using `JwtService.sign({ username, sub: userId })`. This endpoint is used to generate tokens for WebSocket testing.
  - Step 5: Start the application to verify:
    ```bash
    npm run start:dev
    ```
- **Expected result:** The application starts successfully. Calling `POST /auth/login` returns a valid JWT token.
- **Conclusion:** The JWT infrastructure is ready, tokens can be generated for use during WebSocket connections.

## 1
### title
Create ChatGateway with OnGatewayConnection
### body
- **Steps to follow:**
  - Step 1: Create `ChatModule` and `ChatGateway`. Ensure `ChatGateway` is in the `providers` of `ChatModule`.
  - Step 2: In `ChatGateway`, add the `@WebSocketGateway()` decorator and implement the `OnGatewayConnection` interface.
  - Step 3: Inject `JwtService` into the constructor of `ChatGateway`.
  - Step 4: Import `ChatModule` into `AppModule`. Ensure `JwtModule` is exported from `AuthModule` or imported directly in `ChatModule` so that `JwtService` is available for injection.
- **Expected result:** The application starts without errors, `ChatGateway` is recognized by NestJS and `JwtService` is injected successfully.
- **Conclusion:** The Gateway is ready for implementing authentication logic in `handleConnection`.

## 2
### title
Implement JWT authentication in handleConnection
### body
- **Steps to follow:**
  - Step 1: In the `handleConnection(client: Socket)` method, extract the token from the authorization header:
    ```typescript
    const authHeader = client.handshake.headers.authorization;
    ```
    If `authHeader` does not exist or does not start with `Bearer `, call `client.disconnect()` and return immediately.
  - Step 2: Extract the token from the header using `authHeader.split(' ')[1]`. Use a `try-catch` block around `this.jwtService.verify(token)`. If verification succeeds, store the payload in `client.data.user = payload`.
  - Step 3: If `verify` throws an exception (expired token, invalid signature), call `client.disconnect()` in the `catch` block.
  - Step 4: Create a method to handle the `sendMessage` event using `@SubscribeMessage('sendMessage')`. The method takes `client: Socket` and `payload: { message: string }`. Get the sender identity from `client.data.user` (not from the client-sent payload). Emit `newMessage` with `{ sender: client.data.user.username, message: payload.message }`.
- **Expected result:** Clients connecting with a valid token are accepted and `client.data.user` contains the JWT payload. Clients without a token or with an invalid token are disconnected immediately. The `sendMessage` event uses identity from `client.data.user`.
- **Conclusion:** Handshake authentication ensures only valid clients exist in the system, and user identity is safely attached to the socket.

## 3
### title
Test 3 authentication scenarios
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: **Scenario 1 - No token:** Open Postman, create a WebSocket connection (Socket.IO) to `ws://localhost:3000` without adding an `Authorization` header. Verify the connection is rejected (client is disconnected immediately).
  - Step 3: **Scenario 2 - Invalid token:** Create a WebSocket connection with the header `Authorization: Bearer invalid-token-here`. Verify the connection is rejected.
  - Step 4: **Scenario 3 - Valid token:** First call `POST /auth/login` with body `{ "username": "testuser" }` to get an `accessToken`. Then create a WebSocket connection with the header `Authorization: Bearer <accessToken>`. Verify the connection is successful.
  - Step 5: From the valid connection, send the `sendMessage` event with payload `{ "message": "Hello" }`. Verify the response contains `sender` as `testuser` (from `client.data.user.username`) and `message` as `Hello`.
- **Expected result:**
  - Scenario 1: Connection rejected (no token).
  - Scenario 2: Connection rejected (invalid token).
  - Scenario 3: Connection successful, `sendMessage` event returns the correct identity from the JWT payload.
- **Conclusion:** JWT authentication at handshake works correctly for all 3 scenarios, and user identity in events is safely retrieved from `client.data.user` instead of trusting client-sent data.

# references
## 0
### alias
NestJS WebSocket Lifecycle Hooks
### url
https://docs.nestjs.com/websockets/gateways#lifecycle-hooks

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
Handshake authentication works
##### score
10
##### promptText
`handleConnection()` extracts JWT from `client.handshake.headers.authorization`, verifies with `JwtService`. Valid token attaches payload to `client.data.user`. Missing or invalid token calls `client.disconnect()` immediately.
#### 1
##### title
Identity from client.data.user
##### score
10
##### promptText
The `sendMessage` event retrieves sender identity from `client.data.user` (not from client-sent payload). Response contains the correct `sender` from the JWT payload.

# difficulty
easy

# score
20
