# title
Mo rong WebSocket voi Redis Adapter

# description
Giải quyết vấn đề mất tin nhắn khi chạy nhiều instance NestJS bằng cách tích hợp Redis Adapter cho Socket.IO, đảm bảo mọi event được đồng bộ xuyên suốt các instance.

# requirements
Tạo `RedisIoAdapter` extends `IoAdapter`. Khởi tạo `pubClient` và `subClient` kết nối Redis. Gọi `createAdapter(pubClient, subClient)` để tạo adapter. Đăng ký adapter trong `main.ts` bằng `app.useWebSocketAdapter()`. Viết tài liệu giải thích tại sao cần Redis Adapter khi scaling WebSocket (vấn đề mất message cross-instance).

# prerequisites
- Node.js >= 18
- Docker (Redis)
- Đã hiểu Socket.IO Gateway

# steps

## 0
### title
Khởi tạo project và chạy Redis bằng Docker
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới bằng NestJS CLI:
    ```bash
    nest new scaling-with-redis-adapter-easy
    ```
  - Bước 2: Di chuyển vào thư mục project và cài đặt các package cần thiết:
    ```bash
    cd scaling-with-redis-adapter-easy
    npm install @nestjs/websockets @nestjs/platform-socket.io @socket.io/redis-adapter redis
    ```
  - Bước 3: Chạy Redis bằng Docker:
    ```bash
    docker run -d --name redis-ws -p 6379:6379 redis:7-alpine
    ```
  - Bước 4: Xác nhận Redis đang chạy:
    ```bash
    docker exec redis-ws redis-cli ping
    ```
    Kết quả phải trả về `PONG`.
- **Kết quả mong đợi:** Project NestJS đã được khởi tạo với đầy đủ package. Redis container chạy trên port 6379 và phản hồi `PONG`.
- **Kết luận:** Hạ tầng nền (NestJS + Redis) đã sẵn sàng để triển khai Redis Adapter.

## 1
### title
Tạo RedisIoAdapter
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo file `redis-io.adapter.ts` trong thư mục `src`. Import `IoAdapter` từ `@nestjs/platform-socket.io`, `createAdapter` từ `@socket.io/redis-adapter`, và `createClient` từ `redis`.
  - Bước 2: Tạo class `RedisIoAdapter` extends `IoAdapter`. Thêm method `async connectToRedis()` thực hiện:
    ```typescript
    const pubClient = createClient({ url: 'redis://localhost:6379' });
    const subClient = pubClient.duplicate();
    await Promise.all([pubClient.connect(), subClient.connect()]);
    ```
    Lưu reference adapter bằng `this.adapterConstructor = createAdapter(pubClient, subClient)`.
  - Bước 3: Override method `createIOServer(port: number, options?: any)`. Gọi `super.createIOServer(port, options)` để lấy server instance, sau đó gọi `server.adapter(this.adapterConstructor)` và return server.
  - Bước 4: Tạo một Gateway đơn giản `ChatGateway` với decorator `@WebSocketGateway()` và event `sendMessage` broadcast tin nhắn đến tất cả client bằng `this.server.emit()`. Gateway này dùng để kiểm thử adapter hoạt động cross-instance.
- **Kết quả mong đợi:** File `redis-io.adapter.ts` chứa class `RedisIoAdapter` hoàn chỉnh với method `connectToRedis()` và `createIOServer()` override. `ChatGateway` có event `sendMessage` broadcast tin nhắn.
- **Kết luận:** Adapter đã được tạo với logic kết nối Redis và tạo pub/sub channel cho Socket.IO.

## 2
### title
Đăng ký adapter trong main.ts
### body
- **Các bước thực hiện:**
  - Bước 1: Mở file `main.ts`. Sau dòng `const app = await NestFactory.create(AppModule)`, tạo instance adapter:
    ```typescript
    const redisIoAdapter = new RedisIoAdapter(app);
    await redisIoAdapter.connectToRedis();
    app.useWebSocketAdapter(redisIoAdapter);
    ```
  - Bước 2: Chạy ứng dụng và xác nhận không có lỗi kết nối Redis:
    ```bash
    npm run start:dev
    ```
  - Bước 3: Kiểm tra terminal: ứng dụng phải khởi động thành công, Gateway được NestJS nhận diện, và không có lỗi kết nối Redis.
- **Kết quả mong đợi:** Ứng dụng khởi động thành công với `RedisIoAdapter` đã được đăng ký. Không có lỗi kết nối Redis trong console.
- **Kết luận:** Redis Adapter đã được tích hợp vào NestJS WebSocket, mọi event sẽ được đồng bộ qua Redis Pub/Sub.

## 3
### title
Kiểm thử và viết tài liệu giải thích
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Mở Postman, tạo kết nối WebSocket (Socket.IO) đến `ws://localhost:3000`. Gửi event `sendMessage` với payload `{ "message": "Hello Redis" }`. Xác nhận tất cả client kết nối đều nhận được tin nhắn (broadcast hoạt động qua adapter).
  - Bước 3: Xác nhận Redis đang nhận message bằng cách monitor:
    ```bash
    docker exec redis-ws redis-cli monitor
    ```
    Gửi thêm một tin nhắn từ Postman và xác nhận output monitor hiển thị hoạt động pub/sub.
  - Bước 4: Tạo file `SCALING_EXPLANATION.md` trong thư mục gốc project. Viết tài liệu giải thích:
    - Vấn đề: Khi chạy nhiều instance NestJS (ví dụ sau load balancer), mỗi instance có Socket.IO server riêng. Client A kết nối instance 1, Client B kết nối instance 2. Nếu Client A gửi tin nhắn broadcast, chỉ client trên instance 1 nhận được, Client B trên instance 2 không nhận được.
    - Giải pháp: Redis Adapter sử dụng Redis Pub/Sub làm message bus trung gian. Khi một instance emit event, nó publish lên Redis channel. Tất cả instance khác subscribe channel này và forward event đến client của mình.
    - Kết quả: Mọi client trên mọi instance đều nhận được event, giải quyết vấn đề mất message cross-instance.
- **Kết quả mong đợi:**
  - Event `sendMessage` broadcast thành công đến tất cả client qua Redis Adapter.
  - Redis monitor hiển thị hoạt động pub/sub khi có event.
  - File `SCALING_EXPLANATION.md` giải thích rõ vấn đề, giải pháp, và cơ chế Redis Pub/Sub.
- **Kết luận:** Redis Adapter hoạt động đúng, giải quyết vấn đề mất message khi scaling WebSocket. Tài liệu giải thích đầy đủ lý do và cơ chế kỹ thuật.

# references
## 0
### alias
NestJS Redis Adapter
### url
https://docs.nestjs.com/websockets/adapter

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
10
### prompts
#### 0
##### title
RedisIoAdapter triển khai đúng
##### score
10
##### promptText
`RedisIoAdapter` extends `IoAdapter`, có method `connectToRedis()` khởi tạo `pubClient` và `subClient` kết nối Redis. Override `createIOServer()` gắn adapter vào server. `main.ts` đăng ký adapter bằng `app.useWebSocketAdapter()`. Gateway broadcast event hoạt động qua adapter.
## 1
### type
googleDocsUrl
### title
Tai lieu giai thich Scaling WebSocket
### description
Nộp link Google Docs chứa tài liệu giải thích vấn đề scaling WebSocket và giải pháp Redis Adapter.
### score
10
### prompts
#### 0
##### title
Giải thích vấn đề và giải pháp
##### score
10
##### promptText
Tài liệu nêu rõ vấn đề mất message khi chạy nhiều instance (cross-instance communication), giải thích cơ chế Redis Pub/Sub làm message bus trung gian, và mô tả kết quả đạt được khi dùng Redis Adapter.

# difficulty
easy

# score
20
