# title
Set Up a WebSocket Gateway with Socket.IO

# description
Build your first WebSocket Gateway in NestJS using Socket.IO, establishing bidirectional communication between client and server through an event-driven mechanism.

# requirements
Create a `NotificationsGateway` with the `@WebSocketGateway()` decorator. Listen for the `ping` event using `@SubscribeMessage('ping')` and return the string `pong` to only the sending client (no broadcast). Inject a `NotificationsService` into the Gateway to prove DI works within the WebSocket context. The service has a `getServerTime()` method that returns the current time. Listen for the `time` event and return the result from the service.

# prerequisites
- Node.js >= 18
- NestJS CLI

# steps

## 0
### title
Initialize the project and install Socket.IO
### body
- **Steps to follow:**
  - Step 1: Create a new project using the NestJS CLI:
    ```bash
    nest new socketio-gateway-architecture-easy
    ```
  - Step 2: Navigate to the project directory and install the required WebSocket packages:
    ```bash
    cd socketio-gateway-architecture-easy
    npm install @nestjs/websockets @nestjs/platform-socket.io
    ```
  - Step 3: Start the application to verify the project was initialized successfully:
    ```bash
    npm run start:dev
    ```
- **Expected result:** The application starts successfully on port 3000, terminal shows NestJS startup logs. The packages `@nestjs/websockets` and `@nestjs/platform-socket.io` are added to `package.json`.
- **Conclusion:** The base environment with all WebSocket dependencies is ready for implementing the Gateway.

## 1
### title
Create NotificationsGateway and NotificationsService
### body
- **Steps to follow:**
  - Step 1: Create `NotificationsModule`, `NotificationsGateway`, and `NotificationsService` using the CLI or manually. Ensure `NotificationsGateway` is in the `providers` of `NotificationsModule` and `NotificationsService` is also declared in `providers`.
  - Step 2: In `NotificationsService`, create a `getServerTime(): string` method that returns the current time as an ISO string using `new Date().toISOString()`.
  - Step 3: In `NotificationsGateway`, add the `@WebSocketGateway()` decorator on the class. Inject `NotificationsService` into the Gateway constructor.
  - Step 4: Import `NotificationsModule` into `AppModule`.
- **Expected result:** The application starts without errors, the Gateway is recognized and logged by NestJS during bootstrap.
- **Conclusion:** The Gateway and Service are created and connected via DI, ready for implementing event handlers.

## 2
### title
Implement event handlers for ping and time
### body
- **Steps to follow:**
  - Step 1: In `NotificationsGateway`, create a method to handle the `ping` event using the `@SubscribeMessage('ping')` decorator. The method takes a `client: Socket` parameter and returns the object `{ event: 'ping', data: 'pong' }` so Socket.IO automatically sends the response to the calling client only.
  - Step 2: Create a method to handle the `time` event using the `@SubscribeMessage('time')` decorator. The method calls `this.notificationsService.getServerTime()` and returns `{ event: 'time', data: serverTime }`.
  - Step 3: Add `@WebSocketServer() server: Server` to hold a reference to the WebSocket server instance (for debugging or future extension).
  - Step 4: Implement the `OnGatewayConnection` and `OnGatewayDisconnect` interfaces. In `handleConnection(client: Socket)`, log `Client connected: ${client.id}`. In `handleDisconnect(client: Socket)`, log `Client disconnected: ${client.id}`.
- **Expected result:** The Gateway has two event handlers `ping` and `time`. When a client emits `ping`, only that client receives `pong`. When a client emits `time`, only that client receives the current time from the service. Console logs show connection and disconnection information.
- **Conclusion:** The event-driven mechanism works correctly, and DI within the WebSocket context is proven by the Gateway successfully calling the Service.

## 3
### title
Test the Gateway using Postman WebSocket
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Open Postman, create a new WebSocket connection to `ws://localhost:3000`. Select the **Socket.IO** protocol (not Raw WebSocket). Click **Connect** and verify the connection is successful.
  - Step 3: Send the `ping` event (no payload or empty payload required). Verify you receive a response with event `ping` and data `pong`.
  - Step 4: Send the `time` event (no payload required). Verify you receive a response with event `time` and data as an ISO time string (e.g., `2025-01-15T10:30:00.000Z`).
  - Step 5: Check the server terminal: it must show `Client connected: <id>` when the connection opens and `Client disconnected: <id>` when it closes.
- **Expected result:**
  - Event `ping` -> response `pong` to only the sending client.
  - Event `time` -> response is an ISO time string from `NotificationsService`.
  - Terminal displays connection and disconnection logs.
- **Conclusion:** The WebSocket Gateway works correctly with the event-driven mechanism, DI flows seamlessly from Gateway to Service, and bidirectional communication between client and server is established successfully.

# references
## 0
### alias
NestJS WebSockets Gateways
### url
https://docs.nestjs.com/websockets/gateways

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
Gateway and DI structure correct
##### score
10
##### promptText
`NotificationsGateway` has the `@WebSocketGateway()` decorator, injects `NotificationsService` via constructor. Service has a `getServerTime()` method returning ISO time. Gateway implements `OnGatewayConnection` and `OnGatewayDisconnect` with proper logging.
#### 1
##### title
Event handlers work correctly
##### score
10
##### promptText
Event `ping` returns `pong` to only the sending client (no broadcast). Event `time` returns the result from `NotificationsService.getServerTime()`. Both events use `@SubscribeMessage` correctly.

# difficulty
easy

# score
20
