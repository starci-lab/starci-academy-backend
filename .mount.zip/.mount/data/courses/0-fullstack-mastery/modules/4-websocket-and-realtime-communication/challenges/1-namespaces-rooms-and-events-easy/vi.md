# title
Chat theo phong voi Rooms va Broadcast

# description
Tổ chức người dùng WebSocket vào các phòng chat (Rooms), đảm bảo tin nhắn chỉ được gửi đến những người trong cùng phòng.

# requirements
Triển khai event `joinRoom`: client gọi với `{ roomId }`, server thực hiện `client.join(roomId)` và broadcast system message `userJoined` vào phòng. Triển khai event `sendMessage`: server emit `newMessage` chỉ đến `roomId` bằng `client.to(roomId).emit()`. Định nghĩa `SocketEvents` enum cho tất cả event names. Khi client disconnect, log thông tin ngắt kết nối.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Đã hiểu Gateway cơ bản

# steps

## 0
### title
Khởi tạo project và cài đặt dependency
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới bằng NestJS CLI:
    ```bash
    nest new namespaces-rooms-and-events-easy
    ```
  - Bước 2: Di chuyển vào thư mục project và cài đặt các package WebSocket:
    ```bash
    cd namespaces-rooms-and-events-easy
    npm install @nestjs/websockets @nestjs/platform-socket.io
    ```
  - Bước 3: Chạy thử ứng dụng:
    ```bash
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng khởi động thành công, các package WebSocket đã được cài đặt trong `package.json`.
- **Kết luận:** Môi trường nền đã sẵn sàng để triển khai Gateway với Rooms.

## 1
### title
Tạo ChatGateway và định nghĩa SocketEvents enum
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `ChatModule` và `ChatGateway`. Đảm bảo `ChatGateway` nằm trong `providers` của `ChatModule` và `ChatModule` được import vào `AppModule`.
  - Bước 2: Tạo file `socket-events.enum.ts` định nghĩa enum `SocketEvents` với các giá trị:
    ```typescript
    export enum SocketEvents {
      JoinRoom = 'joinRoom',
      SendMessage = 'sendMessage',
      NewMessage = 'newMessage',
      UserJoined = 'userJoined',
    }
    ```
  - Bước 3: Trong `ChatGateway`, thêm decorator `@WebSocketGateway()` và khai báo `@WebSocketServer() server: Server`.
  - Bước 4: Implement interface `OnGatewayDisconnect`. Trong `handleDisconnect(client: Socket)`, log ra `Client disconnected: ${client.id}`.
- **Kết quả mong đợi:** Ứng dụng khởi động không lỗi, enum `SocketEvents` chứa tất cả event names cần dùng, Gateway được NestJS nhận diện.
- **Kết luận:** Cấu trúc cơ bản của Gateway và enum event đã sẵn sàng để triển khai logic Rooms.

## 2
### title
Triển khai joinRoom và sendMessage
### body
- **Các bước thực hiện:**
  - Bước 1: Trong `ChatGateway`, tạo method xử lý event `joinRoom` bằng `@SubscribeMessage(SocketEvents.JoinRoom)`. Method nhận `client: Socket` và `payload: { roomId: string }`. Gọi `client.join(payload.roomId)` để thêm client vào phòng.
  - Bước 2: Sau khi join thành công, broadcast system message vào phòng bằng `this.server.to(payload.roomId).emit(SocketEvents.UserJoined, { message: 'A new user has joined the room', roomId: payload.roomId })`.
  - Bước 3: Tạo method xử lý event `sendMessage` bằng `@SubscribeMessage(SocketEvents.SendMessage)`. Method nhận `client: Socket` và `payload: { roomId: string, message: string }`. Gửi tin nhắn đến tất cả client trong phòng (trừ người gửi) bằng `client.to(payload.roomId).emit(SocketEvents.NewMessage, { senderId: client.id, message: payload.message, roomId: payload.roomId })`.
  - Bước 4: Đảm bảo tất cả event names đều sử dụng giá trị từ `SocketEvents` enum, không dùng chuỗi trực tiếp.
- **Kết quả mong đợi:** Client gọi `joinRoom` được thêm vào phòng và phòng nhận system message. Client gọi `sendMessage` chỉ gửi tin nhắn đến các client khác trong cùng phòng.
- **Kết luận:** Logic Rooms hoạt động đúng: join phòng, broadcast khi có người mới, và gửi tin nhắn cô lập theo phòng.

## 3
### title
Kiểm thử với nhiều client
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: Mở Postman, tạo hai kết nối WebSocket (Socket.IO) đến `ws://localhost:3000`. Gọi hai kết nối này là **Client A** và **Client B**.
  - Bước 3: Từ cả Client A và Client B, gửi event `joinRoom` với payload `{ "roomId": "room-1" }`. Xác nhận cả hai client đều nhận event `userJoined` với thông báo phù hợp.
  - Bước 4: Từ Client A, gửi event `sendMessage` với payload `{ "roomId": "room-1", "message": "Hello from A" }`. Xác nhận Client B nhận event `newMessage` với nội dung tin nhắn, nhưng Client A không nhận lại tin nhắn của chính mình.
  - Bước 5: Mở thêm **Client C**, gửi event `joinRoom` với `{ "roomId": "room-2" }` (phòng khác). Từ Client A, gửi `sendMessage` vào `room-1`. Xác nhận Client C không nhận được tin nhắn vì ở phòng khác.
  - Bước 6: Đóng kết nối Client B, kiểm tra terminal server có log `Client disconnected`.
- **Kết quả mong đợi:**
  - Client cùng phòng nhận tin nhắn, client khác phòng không nhận.
  - Người gửi không nhận lại tin nhắn của chính mình (do dùng `client.to()`).
  - System message `userJoined` được broadcast khi có người join phòng.
  - Terminal log disconnect khi client ngắt kết nối.
- **Kết luận:** Cơ chế Rooms hoạt động chính xác, tin nhắn được cô lập theo phòng, broadcast và unicast đúng hành vi mong đợi.

# references
## 0
### alias
Socket.IO Rooms
### url
https://socket.io/docs/v4/rooms/

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
Quản lý Room đúng cách
##### score
10
##### promptText
`ChatGateway` có event `joinRoom` thực hiện `client.join(roomId)` và broadcast `userJoined` vào phòng. Enum `SocketEvents` được định nghĩa và sử dụng cho tất cả event names. Gateway implement `OnGatewayDisconnect`.
#### 1
##### title
Tin nhắn cô lập theo phòng
##### score
10
##### promptText
Event `sendMessage` dùng `client.to(roomId).emit()` để gửi tin nhắn chỉ đến client trong cùng phòng. Client ở phòng khác không nhận được tin nhắn. Người gửi không nhận lại tin nhắn của chính mình.

# difficulty
easy

# score
20
