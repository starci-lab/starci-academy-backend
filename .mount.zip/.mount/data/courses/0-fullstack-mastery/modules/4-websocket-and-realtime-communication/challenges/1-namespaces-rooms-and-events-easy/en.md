# title
Room-based Chat with Rooms and Broadcast

# description
Organize WebSocket users into chat rooms (Rooms), ensuring messages are only delivered to users within the same room.

# requirements
Implement a `joinRoom` event: the client sends `{ roomId }`, the server calls `client.join(roomId)` and broadcasts a `userJoined` system message to the room. Implement a `sendMessage` event: the server emits `newMessage` only to the `roomId` using `client.to(roomId).emit()`. Define a `SocketEvents` enum for all event names. When a client disconnects, log the disconnection information.

# prerequisites
- Node.js >= 18
- NestJS CLI
- Basic understanding of Gateways

# steps

## 0
### title
Initialize the project and install dependencies
### body
- **Steps to follow:**
  - Step 1: Create a new project using the NestJS CLI:
    ```bash
    nest new namespaces-rooms-and-events-easy
    ```
  - Step 2: Navigate to the project directory and install the WebSocket packages:
    ```bash
    cd namespaces-rooms-and-events-easy
    npm install @nestjs/websockets @nestjs/platform-socket.io
    ```
  - Step 3: Start the application to verify:
    ```bash
    npm run start:dev
    ```
- **Expected result:** The application starts successfully, WebSocket packages are installed in `package.json`.
- **Conclusion:** The base environment is ready for implementing the Gateway with Rooms.

## 1
### title
Create ChatGateway and define SocketEvents enum
### body
- **Steps to follow:**
  - Step 1: Create `ChatModule` and `ChatGateway`. Ensure `ChatGateway` is in the `providers` of `ChatModule` and `ChatModule` is imported into `AppModule`.
  - Step 2: Create a `socket-events.enum.ts` file defining the `SocketEvents` enum with the following values:
    ```typescript
    export enum SocketEvents {
      JoinRoom = 'joinRoom',
      SendMessage = 'sendMessage',
      NewMessage = 'newMessage',
      UserJoined = 'userJoined',
    }
    ```
  - Step 3: In `ChatGateway`, add the `@WebSocketGateway()` decorator and declare `@WebSocketServer() server: Server`.
  - Step 4: Implement the `OnGatewayDisconnect` interface. In `handleDisconnect(client: Socket)`, log `Client disconnected: ${client.id}`.
- **Expected result:** The application starts without errors, the `SocketEvents` enum contains all required event names, and the Gateway is recognized by NestJS.
- **Conclusion:** The basic Gateway structure and event enum are ready for implementing Rooms logic.

## 2
### title
Implement joinRoom and sendMessage
### body
- **Steps to follow:**
  - Step 1: In `ChatGateway`, create a method to handle the `joinRoom` event using `@SubscribeMessage(SocketEvents.JoinRoom)`. The method takes `client: Socket` and `payload: { roomId: string }`. Call `client.join(payload.roomId)` to add the client to the room.
  - Step 2: After a successful join, broadcast a system message to the room using `this.server.to(payload.roomId).emit(SocketEvents.UserJoined, { message: 'A new user has joined the room', roomId: payload.roomId })`.
  - Step 3: Create a method to handle the `sendMessage` event using `@SubscribeMessage(SocketEvents.SendMessage)`. The method takes `client: Socket` and `payload: { roomId: string, message: string }`. Send the message to all clients in the room (except the sender) using `client.to(payload.roomId).emit(SocketEvents.NewMessage, { senderId: client.id, message: payload.message, roomId: payload.roomId })`.
  - Step 4: Ensure all event names use values from the `SocketEvents` enum, never raw strings.
- **Expected result:** A client calling `joinRoom` is added to the room and the room receives a system message. A client calling `sendMessage` sends the message only to other clients in the same room.
- **Conclusion:** Rooms logic works correctly: joining a room, broadcasting when someone joins, and isolating messages per room.

## 3
### title
Test with multiple clients
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Open Postman, create two WebSocket connections (Socket.IO) to `ws://localhost:3000`. Call them **Client A** and **Client B**.
  - Step 3: From both Client A and Client B, send the `joinRoom` event with payload `{ "roomId": "room-1" }`. Verify both clients receive the `userJoined` event with the appropriate message.
  - Step 4: From Client A, send the `sendMessage` event with payload `{ "roomId": "room-1", "message": "Hello from A" }`. Verify Client B receives the `newMessage` event with the message content, but Client A does not receive its own message back.
  - Step 5: Open a third connection **Client C**, send the `joinRoom` event with `{ "roomId": "room-2" }` (a different room). From Client A, send `sendMessage` to `room-1`. Verify Client C does not receive the message because it is in a different room.
  - Step 6: Disconnect Client B, check the server terminal for the `Client disconnected` log.
- **Expected result:**
  - Clients in the same room receive messages, clients in different rooms do not.
  - The sender does not receive their own message back (due to `client.to()`).
  - System message `userJoined` is broadcast when someone joins a room.
  - Terminal logs disconnect when a client disconnects.
- **Conclusion:** The Rooms mechanism works correctly, messages are isolated per room, and broadcast and unicast behave as expected.

# references
## 0
### alias
Socket.IO Rooms
### url
https://socket.io/docs/v4/rooms/

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
20
### prompts
#### 0
##### title
Room management correct
##### score
10
##### promptText
`ChatGateway` has a `joinRoom` event that calls `client.join(roomId)` and broadcasts `userJoined` to the room. The `SocketEvents` enum is defined and used for all event names. Gateway implements `OnGatewayDisconnect`.
#### 1
##### title
Message isolation works
##### score
10
##### promptText
The `sendMessage` event uses `client.to(roomId).emit()` to send messages only to clients in the same room. Clients in different rooms do not receive the message. The sender does not receive their own message back.

# difficulty
easy

# score
20
