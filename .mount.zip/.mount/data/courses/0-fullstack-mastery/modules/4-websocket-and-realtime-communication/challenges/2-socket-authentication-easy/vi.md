# title
Xac thuc JWT tai Socket Handshake

# description
Bảo mật WebSocket Gateway bằng cách xác thực JWT ngay tại thời điểm handshake, từ chối kết nối không hợp lệ trước khi chúng tiêu tốn tài nguyên server.

# requirements
Trong `handleConnection()`, trích JWT từ `client.handshake.headers.authorization`. Verify bằng `JwtService`. Nếu hợp lệ, gắn payload vào `client.data.user`. Nếu không hợp lệ hoặc thiếu token, gọi `client.disconnect()` ngay. Trong event `sendMessage`, danh tính người gửi phải lấy từ `client.data.user` (không tin dữ liệu client gửi).

# prerequisites
- Node.js >= 18
- Docker (PostgreSQL)
- JWT AuthModule đã hoạt động

# steps

## 0
### title
Khởi tạo project và cài đặt dependency
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo project mới bằng NestJS CLI:
    ```bash
    nest new socket-authentication-easy
    ```
  - Bước 2: Di chuyển vào thư mục project và cài đặt các package cần thiết:
    ```bash
    cd socket-authentication-easy
    npm install @nestjs/websockets @nestjs/platform-socket.io @nestjs/jwt
    ```
  - Bước 3: Cấu hình `JwtModule` trong `AppModule` hoặc tạo `AuthModule` riêng. Đăng ký `JwtModule.register()` với `secret` và `signOptions: { expiresIn: '1h' }`.
  - Bước 4: Tạo endpoint REST `POST /auth/login` nhận `{ username }` và trả về `{ accessToken }` bằng `JwtService.sign({ username, sub: userId })`. Endpoint này dùng để tạo token cho việc test WebSocket.
  - Bước 5: Chạy thử ứng dụng:
    ```bash
    npm run start:dev
    ```
- **Kết quả mong đợi:** Ứng dụng khởi động thành công. Gọi `POST /auth/login` trả về JWT token hợp lệ.
- **Kết luận:** Hạ tầng JWT đã sẵn sàng, token có thể được tạo để sử dụng trong quá trình kết nối WebSocket.

## 1
### title
Tạo ChatGateway với OnGatewayConnection
### body
- **Các bước thực hiện:**
  - Bước 1: Tạo `ChatModule` và `ChatGateway`. Đảm bảo `ChatGateway` nằm trong `providers` của `ChatModule`.
  - Bước 2: Trong `ChatGateway`, thêm decorator `@WebSocketGateway()` và implement interface `OnGatewayConnection`.
  - Bước 3: Inject `JwtService` vào constructor của `ChatGateway`.
  - Bước 4: Import `ChatModule` vào `AppModule`. Đảm bảo `JwtModule` được export từ `AuthModule` hoặc được import trực tiếp trong `ChatModule` để `JwtService` khả dụng cho injection.
- **Kết quả mong đợi:** Ứng dụng khởi động không lỗi, `ChatGateway` được NestJS nhận diện và `JwtService` inject thành công.
- **Kết luận:** Gateway đã sẵn sàng để triển khai logic xác thực trong `handleConnection`.

## 2
### title
Triển khai xác thực JWT trong handleConnection
### body
- **Các bước thực hiện:**
  - Bước 1: Trong method `handleConnection(client: Socket)`, trích xuất token từ header authorization:
    ```typescript
    const authHeader = client.handshake.headers.authorization;
    ```
    Nếu `authHeader` không tồn tại hoặc không bắt đầu bằng `Bearer `, gọi `client.disconnect()` và return ngay.
  - Bước 2: Tách token từ header bằng `authHeader.split(' ')[1]`. Sử dụng `try-catch` bọc quanh `this.jwtService.verify(token)`. Nếu verify thành công, lưu payload vào `client.data.user = payload`.
  - Bước 3: Nếu `verify` ném exception (token hết hạn, sai chữ ký), gọi `client.disconnect()` trong block `catch`.
  - Bước 4: Tạo method xử lý event `sendMessage` bằng `@SubscribeMessage('sendMessage')`. Method nhận `client: Socket` và `payload: { message: string }`. Lấy danh tính người gửi từ `client.data.user` (không lấy từ payload client gửi). Emit `newMessage` với `{ sender: client.data.user.username, message: payload.message }`.
- **Kết quả mong đợi:** Client kết nối với token hợp lệ được chấp nhận và `client.data.user` chứa payload JWT. Client không có token hoặc token sai bị disconnect ngay. Event `sendMessage` sử dụng danh tính từ `client.data.user`.
- **Kết luận:** Xác thực tại handshake đảm bảo chỉ client hợp lệ mới tồn tại trong hệ thống, danh tính người dùng được gắn an toàn vào socket.

## 3
### title
Kiểm thử 3 kịch bản xác thực
### body
- **Các bước thực hiện:**
  - Bước 1: Chạy ứng dụng:
    ```bash
    npm run start:dev
    ```
  - Bước 2: **Kịch bản 1 - Không có token:** Mở Postman, tạo kết nối WebSocket (Socket.IO) đến `ws://localhost:3000` mà không thêm header `Authorization`. Xác nhận kết nối bị từ chối (client bị disconnect ngay lập tức).
  - Bước 3: **Kịch bản 2 - Token không hợp lệ:** Tạo kết nối WebSocket với header `Authorization: Bearer invalid-token-here`. Xác nhận kết nối bị từ chối.
  - Bước 4: **Kịch bản 3 - Token hợp lệ:** Đầu tiên gọi `POST /auth/login` với body `{ "username": "testuser" }` để lấy `accessToken`. Sau đó tạo kết nối WebSocket với header `Authorization: Bearer <accessToken>`. Xác nhận kết nối thành công.
  - Bước 5: Từ kết nối hợp lệ, gửi event `sendMessage` với payload `{ "message": "Hello" }`. Xác nhận response chứa `sender` là `testuser` (lấy từ `client.data.user.username`) và `message` là `Hello`.
- **Kết quả mong đợi:**
  - Kịch bản 1: Kết nối bị từ chối (không có token).
  - Kịch bản 2: Kết nối bị từ chối (token không hợp lệ).
  - Kịch bản 3: Kết nối thành công, event `sendMessage` trả đúng danh tính từ JWT payload.
- **Kết luận:** Xác thực JWT tại handshake hoạt động chính xác cho cả 3 kịch bản, danh tính người dùng trong event được lấy an toàn từ `client.data.user` thay vì tin tưởng dữ liệu client gửi.

# references
## 0
### alias
NestJS WebSocket Lifecycle Hooks
### url
https://docs.nestjs.com/websockets/gateways#lifecycle-hooks

# submissions
## 0
### type
githubUrl
### title
Link GitHub Repository
### description
Nộp link GitHub repository chứa source code challenge của bạn.
### score
20
### prompts
#### 0
##### title
Xác thực handshake hoạt động
##### score
10
##### promptText
`handleConnection()` trích JWT từ `client.handshake.headers.authorization`, verify bằng `JwtService`. Token hợp lệ thì gắn payload vào `client.data.user`. Token thiếu hoặc sai thì gọi `client.disconnect()` ngay.
#### 1
##### title
Danh tính lấy từ client.data.user
##### score
10
##### promptText
Event `sendMessage` lấy danh tính người gửi từ `client.data.user` (không từ payload client gửi). Response chứa đúng `sender` từ JWT payload.

# difficulty
easy

# score
20
