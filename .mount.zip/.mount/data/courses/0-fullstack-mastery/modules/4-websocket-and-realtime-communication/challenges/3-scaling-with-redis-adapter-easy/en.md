# title
Scale WebSocket with Redis Adapter

# description
Solve the problem of lost messages when running multiple NestJS instances by integrating a Redis Adapter for Socket.IO, ensuring all events are synchronized across instances.

# requirements
Create a `RedisIoAdapter` that extends `IoAdapter`. Initialize `pubClient` and `subClient` connecting to Redis. Call `createAdapter(pubClient, subClient)` to create the adapter. Register the adapter in `main.ts` using `app.useWebSocketAdapter()`. Write a document explaining why Redis Adapter is needed when scaling WebSocket (the cross-instance message loss problem).

# prerequisites
- Node.js >= 18
- Docker (Redis)
- Basic understanding of Socket.IO Gateway

# steps

## 0
### title
Initialize the project and run Redis with Docker
### body
- **Steps to follow:**
  - Step 1: Create a new project using the NestJS CLI:
    ```bash
    nest new scaling-with-redis-adapter-easy
    ```
  - Step 2: Navigate to the project directory and install the required packages:
    ```bash
    cd scaling-with-redis-adapter-easy
    npm install @nestjs/websockets @nestjs/platform-socket.io @socket.io/redis-adapter redis
    ```
  - Step 3: Run Redis using Docker:
    ```bash
    docker run -d --name redis-ws -p 6379:6379 redis:7-alpine
    ```
  - Step 4: Verify Redis is running:
    ```bash
    docker exec redis-ws redis-cli ping
    ```
    The result must return `PONG`.
- **Expected result:** The NestJS project is initialized with all required packages. The Redis container runs on port 6379 and responds with `PONG`.
- **Conclusion:** The base infrastructure (NestJS + Redis) is ready for implementing the Redis Adapter.

## 1
### title
Create the RedisIoAdapter
### body
- **Steps to follow:**
  - Step 1: Create a `redis-io.adapter.ts` file in the `src` directory. Import `IoAdapter` from `@nestjs/platform-socket.io`, `createAdapter` from `@socket.io/redis-adapter`, and `createClient` from `redis`.
  - Step 2: Create a `RedisIoAdapter` class that extends `IoAdapter`. Add an `async connectToRedis()` method that does:
    ```typescript
    const pubClient = createClient({ url: 'redis://localhost:6379' });
    const subClient = pubClient.duplicate();
    await Promise.all([pubClient.connect(), subClient.connect()]);
    ```
    Store the adapter reference using `this.adapterConstructor = createAdapter(pubClient, subClient)`.
  - Step 3: Override the `createIOServer(port: number, options?: any)` method. Call `super.createIOServer(port, options)` to get the server instance, then call `server.adapter(this.adapterConstructor)` and return the server.
  - Step 4: Create a simple `ChatGateway` with the `@WebSocketGateway()` decorator and a `sendMessage` event that broadcasts messages to all clients using `this.server.emit()`. This Gateway is used to test that the adapter works cross-instance.
- **Expected result:** The `redis-io.adapter.ts` file contains a complete `RedisIoAdapter` class with `connectToRedis()` and `createIOServer()` override. `ChatGateway` has a `sendMessage` event that broadcasts messages.
- **Conclusion:** The adapter is created with Redis connection logic and pub/sub channel creation for Socket.IO.

## 2
### title
Register the adapter in main.ts
### body
- **Steps to follow:**
  - Step 1: Open `main.ts`. After the line `const app = await NestFactory.create(AppModule)`, create the adapter instance:
    ```typescript
    const redisIoAdapter = new RedisIoAdapter(app);
    await redisIoAdapter.connectToRedis();
    app.useWebSocketAdapter(redisIoAdapter);
    ```
  - Step 2: Run the application and verify there are no Redis connection errors:
    ```bash
    npm run start:dev
    ```
  - Step 3: Check the terminal: the application must start successfully, the Gateway should be recognized by NestJS, and there should be no Redis connection errors.
- **Expected result:** The application starts successfully with the `RedisIoAdapter` registered. No Redis connection errors in the console.
- **Conclusion:** The Redis Adapter is integrated into the NestJS WebSocket system, all events will be synchronized via Redis Pub/Sub.

## 3
### title
Test and write the explanation document
### body
- **Steps to follow:**
  - Step 1: Start the application:
    ```bash
    npm run start:dev
    ```
  - Step 2: Open Postman, create a WebSocket connection (Socket.IO) to `ws://localhost:3000`. Send the `sendMessage` event with payload `{ "message": "Hello Redis" }`. Verify all connected clients receive the message (broadcast works through the adapter).
  - Step 3: Verify Redis is receiving messages by monitoring:
    ```bash
    docker exec redis-ws redis-cli monitor
    ```
    Send another message from Postman and verify the monitor output shows pub/sub activity.
  - Step 4: Create a `SCALING_EXPLANATION.md` file in the project root. Write a document explaining:
    - Problem: When running multiple NestJS instances (e.g., behind a load balancer), each instance has its own Socket.IO server. Client A connects to instance 1, Client B connects to instance 2. If Client A sends a broadcast message, only clients on instance 1 receive it; Client B on instance 2 does not.
    - Solution: Redis Adapter uses Redis Pub/Sub as an intermediary message bus. When an instance emits an event, it publishes to a Redis channel. All other instances subscribe to this channel and forward the event to their own clients.
    - Result: All clients on all instances receive the event, solving the cross-instance message loss problem.
- **Expected result:**
  - The `sendMessage` event broadcasts successfully to all clients through the Redis Adapter.
  - Redis monitor shows pub/sub activity when events occur.
  - The `SCALING_EXPLANATION.md` file clearly explains the problem, solution, and Redis Pub/Sub mechanism.
- **Conclusion:** The Redis Adapter works correctly, solving the message loss problem when scaling WebSocket. The explanation document thoroughly covers the reasoning and technical mechanism.

# references
## 0
### alias
NestJS Redis Adapter
### url
https://docs.nestjs.com/websockets/adapter

# submissions
## 0
### type
githubUrl
### title
GitHub Repository Link
### description
Submit the GitHub repository link containing your challenge source code.
### score
10
### prompts
#### 0
##### title
RedisIoAdapter implemented correctly
##### score
10
##### promptText
`RedisIoAdapter` extends `IoAdapter`, has a `connectToRedis()` method that initializes `pubClient` and `subClient` connecting to Redis. Overrides `createIOServer()` to attach the adapter to the server. `main.ts` registers the adapter using `app.useWebSocketAdapter()`. Gateway broadcast events work through the adapter.
## 1
### type
googleDocsUrl
### title
Scaling WebSocket Explanation Document
### description
Submit a Google Docs link containing the document explaining the WebSocket scaling problem and Redis Adapter solution.
### score
10
### prompts
#### 0
##### title
Problem and solution explained
##### score
10
##### promptText
The document clearly states the message loss problem when running multiple instances (cross-instance communication), explains the Redis Pub/Sub mechanism as an intermediary message bus, and describes the outcome when using Redis Adapter.

# difficulty
easy

# score
20
