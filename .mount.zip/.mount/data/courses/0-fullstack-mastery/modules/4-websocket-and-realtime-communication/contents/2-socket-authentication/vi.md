# title
Xác thực thẻ nhớ ở cửa Socket Handshake

# description
Đâm chốt phòng thủ ngay ở chốt chặn mở ống truyền Socket. Diệt gọn bọn bot phá hoại kết nối dựa trên logic quét quét quét token JWT ngay tắp lự.

# body

## 1. Lỗ thủng vỡ tràn RAM

Một kết nối WebSocket ảo tuy rỗng ruột nhưng chôn chân giữ cứng 1 mẩu RAM lớn hơn nhiều so với Request REST bật tắt gián đoạn. Nếu 1 bầy Hacker cho gọi kịch bản gõ gõ mốc `connect()` 100,000 vạn lần, Server bạn phình to báo chớp đèn đỏ ứ ự.
Phải chém đứt đầu ngay những kết nối nặc danh không giấy tờ, dập tắt tận cội trồi bằng việc Xét hỏi "Giấy Đi Đường JWT" ngay phút đầu **Bắt Tay (Handshake)**.

## 2. Giao kèo Token

Không rải đều Header như REST, Client chỉ việc ném Token 1 lần duy nhất lúc vạch ống:
```javascript
// Frontend viết lệnh đâm HTTP mở hầm
const socket = io('http://localhost:3000', {
  extraHeaders: {
    Authorization: "Bearer ...CỤC_TOKEN_CHUA_CAY..."
  }
});
```

## 3. Lên nòng Guard chặt chém ở Cửa Gateway

NestJS đập thẳng 1 phương thức Interface tên là `handleConnection()` cho Gateway. 
Bể chứa Logic tước ngòi nổ diễn ra thầm lặng ở đây:
```typescript
@WebSocketGateway()
export class ChatGateway implements OnGatewayConnection {
  constructor(private jwtService: JwtService) {}

  // Ngay vòng búng dây kết nối đầu tiên
  async handleConnection(client: Socket) {
    try {
      // 1. Cướp lấy giọt JWT trong giỏ Handshake
      const token = client.handshake.headers.authorization?.split(' ')[1];
      const payloadDaDich = this.jwtService.verify(token); // Xác minh xịn xò
      
      // 2. Quẳng mảnh thông tin vào cốp xe cục Socket
      client.data.user = payloadDaDich; 
    } catch (e) {
      // 3. Fake hả? Chém văng đứt cáp đuổi thẳng cổ!
      client.disconnect(); 
    }
  }
}
```
Lúc này, cái biến `client.data.user` đã ghim chặt thông tin `ID=123`. Khi User gõ tin nhắn, code ở hàm Message chỉ việc lôi cái `.user` ra tra cứu là biết chuẩn bài đích thị ai gõ, bố Hacker cũng chẳng giả mạo ID người khác được.

# references
## 0
### alias
Socket Authentication
### url
https://dev.to/steevehook/nestjs-websockets-with-jwt-authentication-3aab

# minutesRead
20