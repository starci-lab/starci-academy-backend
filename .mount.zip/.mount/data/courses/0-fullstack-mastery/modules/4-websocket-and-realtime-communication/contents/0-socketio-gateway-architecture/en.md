# title
Socket.IO Gateway Architecture

# description
Understand the paradigm shift from standard HTTP request-response cycles to full-duplex WebSocket communication. Learn how NestJS encapsulates Socket.IO using Gateways.

# body

## 1. WebSockets vs HTTP

HTTP is unidirectional. The client asks a question, and the server answers. The server cannot initiate a conversation. 
If an e-commerce order status updates to "Shipping", using standard HTTP means the frontend must send a request every 5 seconds to ask "Is it shipped yet?" (Long Polling). This exhausts server resources aggressively.
**WebSockets** create a persistent, bi-directional tunnel. The connection stays open indefinitely, allowing the backend to instantly "push" the new status to the client with sub-millisecond latency.

## 2. NestJS Gateways

NestJS treats WebSocket classes similarly to HTTP Controllers, but calls them **Gateways**.
```typescript
import { WebSocketGateway, SubscribeMessage, MessageBody } from '@nestjs/websockets';

@WebSocketGateway(80, { namespace: 'events' })
export class EventsGateway {
  @SubscribeMessage('ping') // Listens for the "ping" event from the client
  handleEvent(@MessageBody() data: string): string {
    return data; // NestJS automatically emits this back to the client
  }
}
```
Gateways act as providers. They seamlessly inject services precisely like regular controllers, allowing you to save WebSocket payloads directly to PostgreSQL natively.

## 3. The Underlying Engine (Socket.IO)

NestJS supports two major libraries: `ws` (barebones WebSockets) and `socket.io`.
`socket.io` is overwhelmingly preferred strictly because of its rich developer experience. It inherently features broken-connection auto-reconnects, broadcasting paradigms, and graceful degradation (falling back to HTTP Long Polling securely if severe corporate firewalls block WebSockets).

# references
## 0
### alias
NestJS WebSockets Gateways
### url
https://docs.nestjs.com/websockets/gateways

# minutesRead
15