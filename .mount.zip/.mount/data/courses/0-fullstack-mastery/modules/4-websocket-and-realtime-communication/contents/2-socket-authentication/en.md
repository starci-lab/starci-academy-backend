# title
Socket Authentication Handshake

# description
Protect your WebSocket gates exactly like your REST routes. Master validating the Initial Handshake passing JWT Bearers fundamentally inside NestJS intercepting structures gracefully.

# body

## 1. The Vulnerable Open Pipe 

WebSocket connections consume considerable memory natively on the Node Server instance locally. If malicious bots initiate 100,000 blank unauthenticated connections gracefully mimicking traffic, your server RAM aggressively spikes causing catastrophic outages.
You must absolutely intercept and outrightly disconnect fake unauthenticated connections explicitly at the exact first fraction of a microsecond during the initialization Handshake. 

## 2. The Token Handshake

Unlike REST, WebSockets do not attach standard `Authorization` headers explicitly on subsequent pings naturally. The authentication must forcefully occur upfront intimately attached to the `io.connect()` query natively matching strictly.
```javascript
// Frontend explicitly injecting the header
const socket = io('http://localhost:3000', {
  extraHeaders: {
    Authorization: "Bearer ...YOUR_JWT_TOKEN..."
  }
});
```

## 3. NestJS Middleware Implementation

NestJS gateways expose a crucial interface method seamlessly: `handleConnection()$.
Inside this function natively explicitly evaluate structurally the extracted token utilizing `@nestjs/jwt`.
```typescript
@WebSocketGateway()
export class ChatGateway implements OnGatewayConnection {
  constructor(private jwtService: JwtService) {}

  async handleConnection(client: Socket) {
    try {
      // 1. Extract strictly the payload inherently
      const token = client.handshake.headers.authorization?.split(' ')[1];
      const decodedPayload = this.jwtService.verify(token);
      
      // 2. Attach globally into socket dynamically explicitly
      client.data.user = decodedPayload; 
    } catch (e) {
      // 3. Drop malicious unauthorized execution heavily!
      client.disconnect(); 
    }
  }
}
```
Because `client.data.user` explicitly embeds the decoded object naturally inside memory, subsequent room messages correctly natively map accurately identifying intrinsically exactly *who* sent the chat logically.

# references
## 0
### alias
Socket Authentication
### url
https://dev.to/steevehook/nestjs-websockets-with-jwt-authentication-3aab

# minutesRead
20