# title
Chống sập Server bằng Redis Adapter

# description
Rạch ròi mổ xẻ tử huyệt chí mạng nhất khi nâng cấp dồn ngang Nodejs Websockets. Trình bày bài học dùng Redis dàn xếp "Tụ Tụ" (Pub/Sub) gánh Server.

# body

## 1. Bi kịch Tách Kênh (Scaling Crisis) 

Web Chat của bạn rần rần 2 Vạn anh mập, công ty chạy cân bằng tải (Load Balancer) nhân bản con NestJS ra làm 3 máy (Node 1, Node 2, Node 3).
- **Nam** log vào vô tình cắm rễ ống truyền bên mạng **Node 1**.
- **Vy** log vào ngẫu nhiên rớt sang **Node 2**.
Nam nhắn câu "Anh yêu em" lên Room chat. Thằng máy Node 1 liền gào rú thông qua lệnh `.emit()` lục lọi mớ trí nhớ RAM tĩnh của nó. Đắng cay thay, trên vòi mạch RAM của máy Node 1 hoàn toàn không hề có dấu vết thẻ socket của con Vy. Mạng báo gửi thành công nhưng con Vy vĩnh viễn mù khơi ngậm tăm màn hình trống lốc!

## 2. Kênh phát thanh Redis Pub/Sub giải cứu thế giới

Để máy tính này có thể thọc mồm xuyên qua máy tính kia, ta cần xây một trạm Loa Mạng Viễn Thông tổng đứng ở giữ. Trạm cắm đó không ai khác là `Redis`.
Khi Nam cất tiếng ở Node 1, đoạn code xịn sò (Adapter) của socket lập tức chặn đứng sự ngớ ngẩn đó lại. Nó vứt lời nói ra thẳng cột Loa Redis Tổng đài. 
Redis có trò ma thuật văng vẳng (Pub/Sub), nó gào dội ngược lệnh xuống tất cả các nhánh **Node 2** và **Node 3**. Node 2 thấy vậy lật đật ngó xuống danh sách Socket xem đứa tên Vy có online không, có là lập tức nhồi lệnh bắn bùp. Tin nhắn tới đích chót lọt không trượt phát nào!

## 3. Lắp ráp Code vào NestJS 

Sức ép khổng lồ này lại được NestJS biến tấu ảo diệu chỉ bằng 1 cái ống lồng ngoài (Adapter). Bạn code ra một `RedisIoAdapter`. Khởi tạo 2 con bot `pubClient` và `subClient` móc nối vào Redis chạy lệnh `createAdapter(pubClient, subClient)`.
Bưng cục đó vào thẳng `main.ts` chặn họng khai sinh:
```typescript
//...
const redisIoAdapter = new RedisIoAdapter(app);
await redisIoAdapter.connectToRedis();
app.useWebSocketAdapter(redisIoAdapter); // Thay mẹ não lõi gốc luôn!
```
Bùm! Không cần làm đổi bất kể 1 dòng logic Emit() ngớ ngẩn nào ở file lõi bên trong, tự hệ thống đã mượt mà chịu chéo hàng ngàn Request dồn dập tởn tóc gáy.

# references
## 0
### alias
NestJS Redis Adapter
### url
https://docs.nestjs.com/websockets/adapter

# minutesRead
30