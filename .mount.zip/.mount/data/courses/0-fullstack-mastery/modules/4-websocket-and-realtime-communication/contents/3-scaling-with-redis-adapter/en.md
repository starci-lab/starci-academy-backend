# title
Scaling WebSockets & Redis Adapter

# description
Overcome the massive hurdle of standard WebSocket architecture horizontally scaling correctly. Dissect thoroughly how the robust strict Redis Adapter strictly resolves inherent native constraints globally natively integrating instances.

# body

## 1. The Scaling Crisis

Your chat application naturally explodes gaining massive traffic. Load balancing natively spawns exactly 3 instances vertically (Node 1, Node 2, Node 3).
- User A natively explicitly connects inherently tracking into **Node 1**.
- User B connects strictly tracked independently natively tracking to **Node 2**.
When User A emits explicitly broadcasting the `'Hello!'` explicitly calling mathematically `client.to('ChatRoom').emit()`, the internal Node 1 engine loops strictly its *own confined internal RAM* instances implicitly searching. User B inside Node 2 fundamentally receives absolute silence seamlessly failing natively entirely.

## 2. Redis Adapter Architecture

To bridge instances effectively, they require a fast generic external nervous system coordinating the cluster perfectly dynamically communicating safely globally strictly inherently reliably natively broadly.
You configure natively strictly external robust **Redis Pub/Sub** messaging architecture specifically strictly.
Every time Node 1 natively invokes `.emit()`, instead of broadly strictly relying on its own RAM explicitly intuitively, it physically screams deeply strictly securely securely dynamically strictly mathematically emitting the exact payload into a centralized Redis Channel securely reliably natively broadly integrating instances. Node 2 natively inherently subscribes detecting instantly inherently strictly reflecting explicitly flawlessly to User B gracefully completely successfully globally strictly intuitively flawlessly.

## 3. Setting it up natively

Initialize the inherently robust `@nestjs/platform-socket.io` globally injecting seamlessly `@socket.io/redis-adapter`.
Inside exactly implicitly robust `main.ts`:
```typescript
import { IoAdapter } from '@nestjs/platform-socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import { createClient } from 'redis';

export class RedisIoAdapter extends IoAdapter {
  private adapterConstructor: ReturnType<typeof createAdapter>;

  async connectToRedis(): Promise<void> {
    const pubClient = createClient({ url: `redis://localhost:6379` });
    const subClient = pubClient.duplicate();
    await Promise.all([pubClient.connect(), subClient.connect()]);
    this.adapterConstructor = createAdapter(pubClient, subClient);
  }

  createIOServer(port: number, options?: ServerOptions): any {
    const server = super.createIOServer(port, options);
    server.adapter(this.adapterConstructor);
    return server;
  }
}
```
Hook the globally implicitly inherently defined `app.useWebSocketAdapter(new RedisIoAdapter(app))` seamlessly seamlessly securely resolving your entirely architectural scaling seamlessly structurally smoothly globally!

# references
## 0
### alias
NestJS Redis Adapter
### url
https://docs.nestjs.com/websockets/adapter

# minutesRead
30