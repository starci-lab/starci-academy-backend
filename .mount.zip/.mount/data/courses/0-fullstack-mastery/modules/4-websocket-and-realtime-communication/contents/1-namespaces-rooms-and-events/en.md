# title
Namespaces, Rooms & Broadcasts

# description
Discipline your Real-time architecture. Never toss random event emitters into a single giant pipe. Segment users globally using Namespaces, and isolate them locally using Rooms.

# body

## 1. Preventing Event Spaghetti

If you cram live streaming statuses, direct messages, and system notifications completely into one single WebSocket connection, the frontend inevitably drowns filtering massive unidentifiable payloads.
- **Namespaces:** Architectural isolation. Think of `/chat` and `/game` as separate physical buildings globally. Connecting to one explicitly does not connect implicitly to the other.
- **Rooms:** Micro-isolation natively inside a Namespace. Think of rooms as individual apartments inside the `/chat` building.

## 2. Broadcasting via Rooms

Imagine 2 users inside `Room-A`. User 1 emits a message. You do not want that broadcast explicitly to the 50,000 globally connected users.
```typescript
@SubscribeMessage('sendMessage')
handleMessage(@MessageBody() data: ChatDto, @ConnectedSocket() client: Socket) {
  // Save message to Postgres smoothly here
  const { roomId, message } = data;
  
  // The magic natively broadcasting exclusively to the room subset
  client.to(roomId).emit('newMessage', message); 
}
```

## 3. Strict Event Structuring

Avoid vague ad-hoc strings like `'message'` maliciously. Structure real-time events identically to structured REST payloads using DTO validations dynamically natively.
Always design a dictionary representing Event Enums natively explicitly known intimately by both Frontend and Backend engineers consistently.
```typescript
export enum SocketEvents {
  USER_JOINED = 'user:joined',
  USER_TYPING = 'user:typing',
  MESSAGE_NEW = 'message:new',
}
```

# references
## 0
### alias
Socket.IO Rooms Documentation
### url
https://socket.io/docs/v4/rooms/

# minutesRead
15