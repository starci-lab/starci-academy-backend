# title
Kiến trúc Socket.IO Gateway

# description
Tiếp nạp tư duy dịch chuyển từ Request-Response sang kết nối 2 chiều (WebSockets). Khám phá cách NestJS quản lý kết nối Socket thông qua Gateways tuyệt đẹp.

# body

## 1. WebSockets đối đầu HTTP

HTTP bị "đớt". Client hỏi 1 câu, server đáp 1 câu rồi cúp máy. Server vĩnh viễn không bao giờ có thể tự tìm client gọi trước được. 
Ví dụ làm chức năng "Trạng thái huỷ đơn hàng": Nếu dùng HTTP, Frontend phải viết hàm SetInterval cứ 5 giây đập gọi API hỏi "Huỷ chưa?". Hàng nghìn user x 5s/ping sẽ bòn rút RAM và CPU khủng khiếp (Long Polling).
**WebSockets** đào 1 đường hầm ngầm. Hầm này chui từ Client phi thẳng vào Server và mở chặn vĩnh viễn. Đơn huỷ 1 cái, Server lập tức phi thông tin qua đường hầm đẩy tẹt rẹt thẳng mặt Frontend với độ trễ chưa tới 1 phần nghìn tuổi thanh xuân.

## 2. NestJS Gateways là cái quái gì?

Ở luồng HTTP, ta có `Controllers`. Ở luồng Socket, thứ đó được gọi là `Gateways`.
Cách code giống nhau y đúc:
```typescript
import { WebSocketGateway, SubscribeMessage, MessageBody } from '@nestjs/websockets';

@WebSocketGateway(80, { namespace: 'events' })
export class EventsGateway {
  @SubscribeMessage('ping') // Dỏng tai lên nghe lệnh "ping" từ Client
  handleEvent(@MessageBody() data: string): string {
    return 'Pong!'; // Lập tức móc túi quăng thẳng lại cho Client lệnh "Pong"!
  }
}
```
Gateway bản chất vẫn là class bình thường. Ta có thể thoải mái Inject các biến Service (như TypeORM, Redis...) vào trong ngoặc Constructor để lưu trữ tin nhắn chat vào Database dễ ợt.

## 3. Quái vật Socket.IO

Nest hỗ trợ 2 lõi: `ws` thuần và `socket.io`.
Team Dev thường sống chết chọn `socket.io`. Vì sao? Vì nó trang bị súng ống quá khủng: Ví dụ chạy vô hầm mất sóng 3G (đứt kết nối), vừa ngoi lên chớp mạng, Socket.io tự lập tức "vá" hàn lại đường kết nối cũ trong nháy mắt. Thậm chí nếu Wifi khách hàng rởm ko chặn đường hầm, nó sẽ tự lật ngược chuyển mô hình về dọn rác Long Polling giở hơi kia thay thế để web ko bị sập.

# references
## 0
### alias
NestJS WebSockets Gateways
### url
https://docs.nestjs.com/websockets/gateways

# minutesRead
15