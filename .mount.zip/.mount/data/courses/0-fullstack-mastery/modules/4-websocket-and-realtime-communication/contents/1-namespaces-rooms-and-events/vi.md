# title
Tổ chức Namespaces, Rooms & Broadcast

# description
Dọn rác đống dây điện chằng chịt trong kiến trúc Socket. Cấm cản việc ném toàn bộ Event vào chung rổ. Quản lý phân lô người dùng bằng Không gian (Namespace) và Phòng chat (Rooms).

# body

## 1. Cuộc khủng hoảng Mỳ Ý Event

Nếu bạn nhét tính năng thả tim Bài post, theo dõi Giao hàng, tin nhắn Chat chung hết vào một cổng kết nối, Frontend sẽ ngập ngụa trong đống Data quái thai bắn dồn dập khiến App bị đơ cật lực.
- **Namespaces:** Giống như Chia Cổng. Cổng `/chat` đứt gãy không liên quan tới cổng rạp hát `/game`.
- **Rooms:** Khái niệm chia Lô phân Nền (Cụ vòm) cực nhỏ. Người chạy ra chạy vào Phòng tuỳ ý. Trong 1 Namespace có thể tạo ra hàng triệu Rooms.

## 2. Loa phát thanh (Broadcast) thẳng vào Rooms

Có 5 Vạn anh em đang online. User 1 nói nhỏ ở "Phòng Ăn". Mắc mớ gì bạn gào cái Event văng lên cho 4 Vạn 9 người còn lại nghe?
SocketIO hỗ trợ hàm chắt lọc cực phẩm:
```typescript
@SubscribeMessage('sendMessage')
handleMessage(@MessageBody() data: ChatDto, @ConnectedSocket() client: Socket) {
  const { roomId, message } = data;
  
  // Gào vào đúng cục diện Phòng roomId: Chỉ User nào Join phòng mới dính event này
  client.to(roomId).emit('newMessage', message); 
}
```

## 3. Kỉ luật xương máu mang tên DTO

Ở REST ta bắt chặt mồm cái Response bằng DTO thế nào, thì ở luồng Socket này bạn cũng phải quy định cái "Mạng lệnh" y như thế. Đừng bao giờ đẻ tuỳ hứng cái lệnh string `'tin_nhan'`. Mai mốt bạn Frontend xoá nhánh đi mất thì tạch cả núi. 
Chốt sổ bằng bộ Enum 2 bên Frontend/Backend khắc lên trán:
```typescript
export enum SocketEvents {
  USER_JOINED = 'nguoidung_vaophong',
  USER_TYPING = 'nguoidung_danggogo',
  MESSAGE_NEW = 'tinnhan_ra_lo',
}
```
Mọi hoạt động bắn emit phải dùng cái hằng số trên rập khuôn rạch ròi.

# references
## 0
### alias
Socket.IO Rooms Documentation
### url
https://socket.io/docs/v4/rooms/

# minutesRead
15