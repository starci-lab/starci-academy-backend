import path from 'node:path';

/** Explicit legacy roots retain their sibling state; never move data or rewrite frozen paths. */
export function stateRoot(workRoot) {
  const root=path.resolve(workRoot);
  return path.join(path.dirname(root),path.basename(root)==='.work'?'.starci':'.starcitemp');
}
