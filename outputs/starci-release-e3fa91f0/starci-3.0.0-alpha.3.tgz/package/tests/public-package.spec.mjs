import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {stateRoot} from '../workflows/storage.mjs';
import {init,update} from '../bin/starci-skills.mjs';

const runtime=fileURLToPath(new URL('../',import.meta.url));
const cli=path.join(runtime,'bin/starci.mjs');
const invoke=(...args)=>spawnSync(process.execPath,[cli,...args],{encoding:'utf8',timeout:30000});
function temp(t){const root=fs.mkdtempSync(path.join(os.tmpdir(),'starci-package-'));t.after(()=>{assert.equal(path.dirname(root),fs.realpathSync(os.tmpdir()));assert.ok(path.basename(root).startsWith('starci-package-'));fs.rmSync(root,{recursive:true,force:true});});return root;}

test('public starci CLI installs the host separately from project metadata and refuses overwrites',t=>{
 const root=temp(t),host=path.join(root,'host'),be=path.join(root,'backend'),fe=path.join(root,'frontend');
 for(const dir of [host,be,fe])fs.mkdirSync(dir);
 const result=invoke('init','--dir',host);assert.equal(result.status,0,result.stderr);
 for(const file of ['AGENTS.md','CLAUDE.md','.claude/SKILL.md','.claude/README.md'])assert.ok(fs.existsSync(path.join(host,file)));
 assert.equal(fs.existsSync(path.join(host,'.starciwork')),false);assert.deepEqual(fs.readdirSync(fe),[]);
 const work=path.join(be,'.starciwork');assert.equal(invoke('workspace','init',work,'--id','synthetic').status,0);
 const before=fs.readFileSync(path.join(work,'workspace.yaml'),'utf8');
 assert.equal(invoke('validate',work).status,0);assert.notEqual(invoke('workspace','init',work,'--id','other').status,0);
 assert.equal(fs.readFileSync(path.join(work,'workspace.yaml'),'utf8'),before);
 assert.equal(invoke('workflows').status,0);assert.equal(invoke('workflow','implement-frontend').status,0);
 assert.notEqual(invoke('unknown-command').status,0);assert.notEqual(invoke('workspace','delete',work).status,0);
});

test('state follows the explicit root, never the presence of a competing tree or a digest rewrite',t=>{
 const base=temp(t);
 for(const dir of ['.starci','.starcitemp'])fs.mkdirSync(path.join(base,dir));
 assert.equal(stateRoot(path.join(base,'.starciwork')),path.join(base,'.starcitemp'));
 assert.equal(stateRoot(path.join(base,'.work')),path.join(base,'.starci'));
 assert.equal(stateRoot(path.join(base,'custom-metadata')),path.join(base,'.starcitemp'));
 assert.deepEqual(fs.readdirSync(path.join(base,'.starci')),[]);
 assert.deepEqual(fs.readdirSync(path.join(base,'.starcitemp')),[]);
});

test('update migrates known pre-rename bootstraps and preserves custom instructions and product bytes',t=>{
 const host=temp(t),opts={dir:host,force:false,bootstrap:true,upgradeMajor:false};
 init(opts,()=>{});
 const old=fs.readFileSync(path.join(runtime,'init/AGENTS.md'),'utf8').replaceAll('.starciwork','.work').replaceAll('.starcitemp','.starci');
 for(const name of ['AGENTS.md','CLAUDE.md'])fs.writeFileSync(path.join(host,name),old+'\nCustom: keep project rules.\n');
 for(const dir of ['.work','.starci','.starciwork','.starcitemp']){fs.mkdirSync(path.join(host,dir));fs.writeFileSync(path.join(host,dir,'owned.txt'),'user data');}
 update(opts,()=>{});
 for(const name of ['AGENTS.md','CLAUDE.md']){const text=fs.readFileSync(path.join(host,name),'utf8');assert.ok(text.includes('.starciwork'));assert.ok(text.endsWith('Custom: keep project rules.\n'));}
 for(const dir of ['.work','.starci','.starciwork','.starcitemp'])assert.equal(fs.readFileSync(path.join(host,dir,'owned.txt'),'utf8'),'user data');
});
