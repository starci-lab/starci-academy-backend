# Directory naming and compatibility

New projects use this mapping:

| Previous directory | New canonical directory | Owner |
| --- | --- | --- |
| `.work` | `.starciwork` | Project backend; durable BE + FE metadata/evidence |
| `.starci` | `.starcitemp` | Same backend; BE + FE plan/run/approval/staging |
| `.claude` | unchanged | Host; shared runtime |
| `.workspaces` | unchanged | Host; project bindings |

This release changes installation templates, documentation and new-project conventions. It **does not automatically rename existing project directories**. Public package/CLI naming changes to `starci`; the previous scoped package is not assumed to redirect to it.

## Resume existing work

Keep the existing explicit binding. `workflows/storage.mjs` resolves a root named `.work` to sibling `.starci`. A `.starciwork` root, or another explicitly provided nonlegacy root, resolves to sibling `.starcitemp`. Selection uses the bound root, never whichever state directory happens to exist. The function does not create, move or delete directories.

Do not change the bound root halfway through a run. Absolute paths can participate in goal/request digests; moving files alone cannot transfer an approval. Having both directory pairs on disk does not authorize merging them or choosing a replacement automatically.

## Migrate deliberately

There is no automatic migration command in this alpha. A separate migration must:

1. Identify the backend owner and stop concurrent writes; inventory bindings, unfinished plans, receipts and source/evidence references.
2. Make a recoverable backup and verify the original workspace before moving anything.
3. Design an exact path/reference transition. Finish active plans first where practical; otherwise present revised goals and obtain actual new approvals rather than editing signed receipts.
4. Change the project binding, state locations and backend ignore rules together; validate metadata and required evidence at the destination.
5. Resume only verified records and retain the original recovery copy until migration is accepted.

Do not rename `work/node@2`, `work/evidence@1`, object fields such as `workRoot`, `.workspaces`, `.worktrees`, or `.starci-skills.json` as a filesystem migration. They have distinct compatibility roles. `init`/`update` preserve both old and new product directory names from installer cleanup.
