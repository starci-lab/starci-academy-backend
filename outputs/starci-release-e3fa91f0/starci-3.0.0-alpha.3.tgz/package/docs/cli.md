# CLI reference

Run `starci` through a reviewed npm archive/version, or `node <host>/.claude/bin/starci.mjs`. Paths below are explicit; commands do not infer a frontend as the project owner.

| Command | Effect |
| --- | --- |
| `init --dir <host>` | Install runtime, managed host bootstraps and absent local config. |
| `update --dir <host>` | Update installer-owned runtime; preserve local modifications by default. |
| `doctor --dir <host> [--quick]` | Run installed contract tests and report drift. Tests use isolated fixtures. |
| `version`, `--version` | Print package version. |
| `workspace init <new-root> --id <id>` | Create a new YAML metadata root; refuse an existing root. |
| `validate <root>` | Validate workspace and evidence; nonzero exit on invalid input. |
| `tree <root>` | Print interpreted node tree/status. |
| `impact <root> <id>` | Inspect dependents affected by an ID. |
| `stale <root>` | Inspect stale completion evidence. |
| `ops`, `op <id>` | List operators or read one contract. |
| `workflows`, `workflow <id>` | List workflows or read one matrix. |
| `route <intent>` | Inspect matching workflow routes; no execution. |
| `plan <goal.yaml>` | Preflight a frozen workflow goal; no approval or dispatch. |
| `audit-legacy <root>` | Read-only legacy inventory, not import/migration. |

The historical internal `cli/main.mjs init` remains an implementation entrypoint. The public distinction is `starci init` for host installation and `starci workspace init` for project metadata.

## Full plan authoring helpers

From the installed `.claude` directory:

```sh
node scripts/plan.mjs template
node scripts/plan.mjs create /absolute/filled-plan.yaml /absolute/backend/.starcitemp/plans/my-task
node scripts/plan.mjs render /absolute/backend/.starcitemp/plans/my-task/goal/index.yaml
```

The template intentionally fails validation until filled from real scope. `create` refuses an existing destination and creates the four-file plan bundle. These helpers do not confer user approval. The top-level `starci plan` preflights a workflow goal; it is not a replacement for the complete Plan v2 authoring helper.

## Installation flags

`--no-bootstrap` leaves host instructions untouched. `--force` explicitly permits overwriting locally changed runtime files; use only after review and backup. `--upgrade-major` opts into an incompatible major runtime update, not data migration. `--quick` limits doctor to its selected checks. Invalid data-command arguments exit nonzero.
